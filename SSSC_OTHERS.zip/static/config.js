var globalConfig = {
  /* mock server*/
  // httpMethod:"GET",
  // serverUrl: "http://0.0.0.0:9090",
  // serverUrl: "http://192.168.43.84:9090",
  // serverUrl: "http://10.65.81.9:9090",
  
  // // chals
  // httpMethod:"POST",
  // serverUrl: "http://10.65.81.235:8080/api" ,

  // // brett
  //  httpMethod:"POST",
  //  serverUrl: "http://10.65.81.164:8080/api", 
  // // Alex
  //  httpMethod:"POST",
  //  serverUrl: "http://10.72.5.241:8080/api",
  // serverUrl: "http://10.72.5.70:8080/api",

  //// zhouyuan
  // httpMethod:"POST",
  // serverUrl: "http://10.65.81.106:8080/api",

  // // SIT
  httpMethod:"POST",
  //serverUrl: "http://10.48.25.72:8080/api",

  //httpMethod:"GET",
serverUrl: "http://cangzdwsql01:9000/",
//serverUrl: "http://cangzdwsql01:9100/",


  versionNumber:"SIT:V1.0.42",
  forgetLink:"https://agencyuat.aia.com.kh/caps/login",

  //api url transfer 2020.03.12
  apis:{
    rule_summary_query:'http://cangzdwsql01:9000/ruleservice/ruleGroup',
    general_infor_query:'http://cangzdwsql01:9000/ruleservice/generalInfomation',
    frequency_infor_query:'http://cangzdwsql01:9000/ruleservice/frequency',
  
    adjustment_batch:'http://cangzdwsql01:9000/calculationresultservice/adjustmentBatch',
    adjustment_query:'http://cangzdwsql01:9000/calculationresultservice/adjustmentresult',
    transaction_query:'http://cangzdwsql01:9000/calculationresultservice/transactionSummry',
    transaction_detail:"http://cangzdwsql01:9000/calculationresultservice/transactionDetail",
    transaction_trace_detail:"http://cangzdwsql01:9000/calculationresultservice/transactiondetailDepositTrace",
    compensation_query:"http://cangzdwsql01:9000/calculationresultservice/depositSummary",
    compensation_trace:"http://cangzdwsql01:9000/calculationresultservice/transactionDepositTrace",
    payment_query:"http://cangzdwsql01:9000/calculationresultservice/paymentSummary",
    payment_trace:"http://cangzdwsql01:9000/calculationresultservice/depositPaymentTrace",
    pipeline_detail:"http://cangzdwsql01:9000/calculationresultservice/pipelineresult",
  
    pipeline_trigger:"http://cangzdwsql01:9000/pipelineservice/pipelinetrigger",
    login_validate:"http://cangzdwsql01:9000/userservice/token",
    user_query:"http://cangzdwsql01:9000/userservice/user",
    role_query:"http://cangzdwsql01:9000/userservice/role",
    users_query:"http://cangzdwsql01:9000/userservice/users",
    roles_query:"http://cangzdwsql01:9000/userservice/roles",
  
    agent_query:"http://cangzdwsql01:9000/channeladminservice/agent",
    agent_insert:"http://cangzdwsql01:9000/channeladminservice/agents",
    version_query:"http://cangzdwsql01:9000/channeladminservice/version",
    agency_query:"http://cangzdwsql01:9000/channeladminservice/entity",
  
    relation_query:"http://cangzdwsql01:9000/channeladminservice/positionRelation",
    position_query:"http://cangzdwsql01:9000/channeladminservice/positionNode",
  
    const_master:"http://cangzdwsql01:9000/contestservice/contestMaster",
    const_criteria:"http://cangzdwsql01:9000/contestservice/contestCriteria",
  },  
}