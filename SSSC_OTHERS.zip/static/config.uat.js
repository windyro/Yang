var globalConfig = {
    httpMethod:"POST",
    //serverUrl:document.location.protocol+"//"+document.location.host+"/webglory/api",
    serverUrl:"http://cangzdwsql01:9100/",
    versionNumber:"UAT:V1.0.15",
    forgetLink:"https://agencyuat.aia.com.kh/caps/password/forgetpassword"
}
