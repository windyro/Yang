var globalConfig = {
    httpMethod:"POST",
    serverUrl:document.location.protocol+"//"+document.location.host+"/webipos/api",
    versionNumber:"Production:V1.0",
    forgetLink:"https://agency.aia.com.kh/caps/password/forgetpassword",
    onlinePaymentLink: "https://module.aia.com.kh/payment"
}
