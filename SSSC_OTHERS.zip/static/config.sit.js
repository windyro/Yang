var globalConfig = {
    /* mock server*/
    // httpMethod:"GET",
    // serverUrl: "http://0.0.0.0:9090",
    // serverUrl: "http://192.168.43.84:9090",
    // serverUrl: "http://10.65.81.9:9090",
    
    // // chals
    // httpMethod:"POST",
    // serverUrl: "http://10.65.81.235:8080/api" ,
  
    // // brett
    //  httpMethod:"POST",
    //  serverUrl: "http://10.65.81.164:8080/api", 
    // // Alex
    //  httpMethod:"POST",
    //  serverUrl: "http://10.72.5.241:8080/api",
    // serverUrl: "http://10.72.5.70:8080/api",
  
    //// zhouyuan
    // httpMethod:"POST",
    // serverUrl: "http://10.65.81.106:8080/api",
  
    // // SIT
    httpMethod:"POST",
    //serverUrl: "http://10.48.25.72:8080/api",
  
    //httpMethod:"GET",
    //serverUrl: "http://cangzdwsql01:9001",
   // serverUrl: "http://10.96.111.43:9001",
  serverUrl: "http://cangzdwsql01:9000/",
  
  
    versionNumber:"SIT:V1.0.42",
    forgetLink:"https://agencyuat.aia.com.kh/caps/login"
  }