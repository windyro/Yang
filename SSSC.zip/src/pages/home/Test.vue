<template>
  <section class="content-wrap">
  <div class="content-fluid margin-left-3xl margin-right-3xl quo-list ">
        <el-row :gutter="20" class="row">
            <el-col :xs="24" :sm="8" :md="8" :lg="8">
              <h5>Test  i18N</h5>
            </el-col>
            <el-col :xs="24" :sm="8" :md="8" :lg="8">
                <gl-select :edit="true" placeholder="I18N " v-model="local" :valueData="local"  @change="changeLocal">		
                       <el-option
                    v-for="item in i18List"
                    :key="item.code"
                    :label="item.name"
                    :value="item.code"
                  ></el-option>
                 </gl-select> 
            </el-col>            
        </el-row>
   </div>     
  </section>
</template>

<script>
export default {
    data() {
        return {
            local: this.$i18n.locale,
            i18List: [
                {code:"en",name:'English'},
                {code:"zh",name:'Chinese'},
            ],
        };
    },
    
    methods:{
        changeLocal(){      
        this.$i18n.locale = this.local;
        },
    },
}
</script>