<template>
  <section class="home-wrap">
    <!-- <div class="row"> -->
    <h3>WELCOME, {{$store.state.user.userInfo.username?$store.state.user.userInfo.username:$store.state.user.userInfo.loginId}}</h3>
    <div class="center-div">

      <!--el-col
        :xs="12"
        :sm="8"
        :md="6"
        :lg="6"
        class="icon-nav cursor-p"
        v-for="item in menu"
        :key="item.title"
        @click.native="goTo(item)"
      >


           <img :src="item.icon" alt class="icon-top">
             <h5>{{$t(item.title)}}</h5>
      </el-col-->

        <el-col class="icon-nav-small" @click.native="goTo(menu[0])" >
              <img :src="menu[0].icon" alt class="icon">
         </el-col>
          <el-col class="icon-nav-middle" @click.native="goTo(menu[1])">
              <img :src="menu[1].icon" alt class="icon">
         </el-col>

        <el-col class="icon-nav-middle" @click.native="goTo(menu[2])">
              <img :src="menu[2].icon" alt class="icon">
         </el-col>   

        <el-col class="icon-nav-small" @click.native="goTo(menu[3])">
              <img :src="menu[3].icon" alt class="icon">
         </el-col>   
    </div>
    <!-- </div> -->
    <div class="footer-version">
      CURRENT VERSION:
      <span>{{versionNumber}}</span>
      <br />

      BUILD ID:{{buildId}}
    </div>
  </section>
</template>
<script>
import { mapState } from "vuex";

import img1 from '../../assets/images/SICM1.png';
import img2 from '../../assets/images/Channel1.png';
import img3 from '../../assets/images/Performance1.png';
import img4 from '../../assets/images/System1.png';

export default {
  data() {
    return {
      menu: [
        {
          icon: img1,
          title: "menu.sicm",
          link: "rule_summary",
          inintMethod: "$initGeneralInformation",
          auth:false,
        },
        {
          icon: img2,
          title: "menu.channel",
          link: "agent_maintain",
          inintMethod: "$initGeneralInformationChannelAdmin",
          auth:false,
        },
        {
          icon: img3,
          title: "menu.performance",
          link: "master_information",
          inintMethod: "$initGeneralInformationContest",
          auth:false,
        }, 
         {
          icon: img4,
          title: "menu.system",
          link: "authority_user",
          auth:false,
        }, 
         /*,
        {
          icon: "#factsheet-prime",
          title: "post nb",
          link: "post_nb"
        },
        {
          icon: "#press_release-prime",
          title: "si submission",
          link: "si_submission"
        } */
      ],
      versionNumber: "",
      buildId: "",
      menuConfig:[],
    };
  },
  computed: {
    ...mapState({
      agentCode: state => state.agentCode,
      },
    ),
  },
  created: function() {
    this.setMenu();
    this.$emit("getTitle", "");
    //var sestoken = sessionStorage.getItem("token");
    //var cookietoken = this.$cookies.get("token");
    // if (sestoken != cookietoken) {
    //   this.$router.replace("/");
    // }
    this.versionNumber = globalConfig.versionNumber;
    this.buildId = new Date().formatDate("yyyyMMddHH");
  },
  watch:{
    '$parent.menuConfig':{
      handler(){
        this.setMenu();
      }
    }
  },
  methods: {
    setMenu(){
      this.menuConfig=this.$parent.menuConfig;
      this.menu.forEach(item=>{
        let equalMenu=this.menuConfig.find(x=>x.comp==item.title);
        if(equalMenu){
          item.auth=true;
          item.link=equalMenu.default;
        }
      });
    },
    goTo(item) {
      if(item.auth){
        this.$parent.changeComp(item.title);
        this.$router.replace({ name: item.link });
        if(item.inintMethod){
          this[item.inintMethod](this);
        }
        sessionStorage.setItem('comp',item.title);
      }else{
        this.$alert(this.$t("message.noPermissionPrompt"), "Warning", {
          confirmButtonText: "OK",
          cancelButtonText: "Cancel",
        });
      }
    },
  },
};
</script>


