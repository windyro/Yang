<template>
  <div class="content-wrap" @click.prevent="doBuble">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
      <aia-form
        class="responsive-form"
        alias="manual_adjustment">

        <template slot="scroll">
          <div>
            <gl-search :headerList="headerList"  @doSearch="doSearch" ref='glSearch'></gl-search>
          </div>
          <gl-object-table :data="tableData" :isHighLight="true" @currentChange="handleCurrent">     
            <el-table-column :label="$t('label.compensationDate')" width="auto" prop="compensationDate">
              <template slot-scope="scope">
                  <span>{{scope.row.compensationDate|convertDate}}</span>
              </template>            
            </el-table-column>

            <el-table-column :label="$t(headerList[0].name)" width="auto" prop="eventType"></el-table-column>

            <el-table-column :label="$t('label.value')" width="auto">
              <template slot-scope="scope">
                <span>{{Number(scope.row.value).toFixed(2)}}</span>
              </template>
            </el-table-column>
                           
            <el-table-column :label="$t(headerList[1].name)" width="auto" prop="commAgent"></el-table-column>

            <el-table-column :label="$t(headerList[2].name)" width="auto" prop="commAgency"></el-table-column>
            
            <el-table-column :label="$t(headerList[3].name)"  width="auto" prop="policyNumber"></el-table-column>

            <el-table-column :label="$t('label.productCat')" width="auto" prop="productCat"></el-table-column>
          </gl-object-table>
          <TransactionDetail :current="current"/>
        </template>
        <template slot="buttons"> 
          <Import :disabled="!isModify" :header="header" @excelData="importExlData"/>
        </template> 
        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage" :change-size="changeSize"></gl-page>
        </template>
      </aia-form>
    </section>
  </div>
</template>
<script>
import Import from './Import'
import TransactionDetail from '../result/TransactionDetail'

export default {
  components:{
    Import,
    TransactionDetail,
  },
  data(){
    return {
      headerList:[
          {
            code:'EvenType',
            name: 'label.eventType',
            type: "input",
            select: "",
            optionList: [],
          },
          {
            code:'CommAgent', 
            name: 'label.commAgent',
            type: "input",
            select: "",
            optionList: [],
          },          
          {
            code:'CommAgency', 
            name: 'label.commAgency',
            type: "input",
            select: "",
            optionList: [],
          },
          {
            code:'PolicyNumber', 
            name: 'label.policyNumber',
            type: "input",
            select: "",
            optionList: [],
          },    
          {
            code:'CompensationStartDate', 
            name: 'label.compStartDate',
            type: "date",
            select: "other",
            optionList: [],
          },
          {
            code:'CompensationEndDate', 
            name: 'label.compEndDate',
            type: "date",
            select: "other",
            optionList: [],
          },
      ],
      tableData:[],
      total:0,
      pageSize:10,
      searchList:[],
      display:false,
      current:null,
      currentPage:1,
      isModify:this.$checkPageModify(this.$route.name),
      header:['compensationDate','agentCode','commAgency','value','description','expenseAccount','agentBalance','gstCode'],
    }
  },
  created(){
    this.doSearch();
  },
  methods:{
    changePage(page){
      this.current=null;
      this.currentPage=page;
      this.doSearch(this.searchList,true,page);
    },
    async changeSize(size){
      this.pageSize=size;
      await this.doSearch(this.searchList,true,1);
    },
    async doSearch(searchList=[],firstClick = true,page=1){
      this.searchList=searchList;
      this.currentPage=page;

      let param={
        action:"GET",
        startPage: page,
        pageSize: this.pageSize,
      }

      let {processingunit,businessunit}=this.$store.state.user.userInfo;
      param.company=processingunit?processingunit:'';
      param.channel=businessunit?businessunit:'';      
      
      searchList.forEach(x=>{
        if(!this.$isEmpty(x.value)){
          let prop=x.headerSelected.name.substring(6);
          param[prop]=x.value;
        }
      })

      let response=await this.$caller.adjustment_query(param)
      if(response.responseCode==="000"){
        let {data,total}={...response};
        this.total=total;
        this.tableData=data;
      } else{
        this.$alert("Response Code: " + response.responseCode, "Attention", {
            confirmButtonText: "OK",
        });

        if(!this.$isEmpty(response.reasonCode)){
            this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                confirmButtonText: "OK",
            });
        }
      }
    },
    doBuble(e){
      e.stopPropagation();
    },
    handleCurrent(current){
      this.current=current;
    },
    importExlData(exl){      
      let submittedBy=this.$store.state.user.userInfo.username;
      let newExl=exl.map(xl=>{
        return {...xl,submittedBy,policyNumber:'',eventType:'MA',productdesc:'',businessunitmap:'',mantxn:'',}
      })
      let jsonExl=JSON.stringify(newExl);
      this.$caller.adjustment_batch(jsonExl).then(res=>{
        if(res.responseCode!='000'){
          this.$alert(this.$t('message.adjustImportFailed'),"Error",{confirmButtonText: "OK",});
        }else{
          this.doSearch();
        }
      });
    }
  },
}
</script>