<template>
    <div>
        <button class="btn-primary" @click.prevent="displayDialog" :disabled="disabled">{{$t('import')}}</button>
        <gl-dialog ref="dialog" :dialogTableVisible="display" @doCloseDialog="closeDialog" class="import-dialog bt5">
            <template slot="dialog-content">
                <div class="content-container">
                    <div tabindex="0" class="upload-container">
                        <a href="javascript:;" class="btn btn-secondary">
                        {{$t("Upload")}}
                            <input ref="file" type="file" name="file" class="upload-input" @change="handleChange">
                        </a>
                    </div>
                    
                    <div class="file-name-div">
                        <span v-if="!file" class="no-file">{{$t("message.noFileSelected")}}</span>
                        <span v-else class="file-name">{{file.name}}</span>
                    </div>


                    <button class="btn-primary" @click.prevent="submit">{{$t("Submit")}}</button>
                    <div class="upload-div">
                        <span>{{$t("message.pleaseClick")}}</span>
                        <a target="_blank" href="static/excel/Manual_Adjust_Template.xlsx">{{$t("here")}}</a>
                        <span>{{$t("message.downLoadTemplate")}}</span>
                    </div>
                </div>
            </template>
        </gl-dialog>
    </div>
</template>
<script>
import axios from 'axios'
import XLSX from 'xlsx'

export default {
    name:'Import',
    props:{
        disabled:{
            type:Boolean,
            default:false,
        },
        header:{
            type:Array,
            default:null,
        },
    },
    data(){
        return{
            display:false,
            file:null,
            hrefUrl:'static/excel/Manual_Adjust_Template.xlsx',
            test:null,
        }
    },
    methods:{
        displayDialog(){
            this.display=true;
            this.file=null;
        },
        closeDialog(display){
            this.display=display;
            this.$refs['file'].value=null;//清楚已选择的文件
        },
        handleChange(file){
            this.file=file.target.files[0];
        },
        submit(){
            const fileReader = new FileReader();
            fileReader.onload = (ev) => {
                try {
                    const data = ev.target.result;
                    const workbook = XLSX.read(data, {
                        // type: 'binary', // 以字符编码的方式解析
                        type:'array'
                    })
                    const exlname = workbook.SheetNames[0]; // 取第一张表
                    let exl;
                    if(this.header){
                        const options={
                            header:this.header,
                            raw:false,
                            range:1,
                        }
                        exl = XLSX.utils.sheet_to_json(workbook.Sheets[exlname],options);                         
                    }else{
                        exl = XLSX.utils.sheet_to_json(workbook.Sheets[exlname]); 
                    }
                    if(exl&&exl.length>0){
                        this.$emit('excelData',exl);
                    }else{
                        this.$alert(this.$t('message.adjustImportWarning'), "Attention", {
                            confirmButtonText: "OK",
                        });
                    }
                    this.display=false;
                } catch (e) {
                    console.log(e);
                    return false;
                }
            }
            // fileReader.readAsBinaryString(this.file.raw); //该方法已被废除
            fileReader.readAsArrayBuffer(this.file);
        },
    },
}
</script>
<style lang="scss">
.import-dialog{
    .dialog-window{
        width:40%;
    }
    .dialog-content{
        .content-container{
            display:flex;
            flex-direction:column;
            align-items:center;
            .file-name-div{
                margin:10px 0;
                .no-file,.file-name{
                    margin:10px 0 20px;
                }
            }


            .upload-div{
                margin-top:10px;
            }
        }
    }
    .upload-container{
        display: flex;
        position: inherit;
        .btn-secondary {
            position: relative;
            .upload-input{
                opacity: 0;
                position: absolute;
                overflow: hidden;
                top: 0;
                right: 0;
                width: 100%;
                height:100%;
            }
        }        
    }
}
</style>