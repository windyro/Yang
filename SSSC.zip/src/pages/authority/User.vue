<template>
  <div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
      <aia-form
        class="responsive-form"
        alias="authority_user">

        <template slot="scroll">
          <div>
            <gl-search :headerList="searchHeaderList"  @doSearch="doSearch" ref='glSearch'></gl-search>
          </div>
          <gl-object-table :data="tableData" ref="userTable">
            <el-table-column :label="$t(headerList[1].name)"  width="auto">
                <template slot-scope="scope">
                    <gl-link v-if="scope.row.loginID!=='SA'" type="primary" @click="modify(scope.row, scope.$index)">{{$t(scope.row.loginId)}}</gl-link >
                    <span v-else>{{scope.row.loginID}}</span>
                </template>
            </el-table-column>

            <el-table-column :label="$t(headerList[0].name)" width="auto" prop="enabled">
                <template slot-scope="scope">
                  <gl-select :edit="false" v-model="scope.row.enabled" :valueData="scope.row.enabled" :optionList="headerList[0].optionList">
                  </gl-select>
                </template>
            </el-table-column>

            <el-table-column :label="$t(headerList[2].name)"  width="auto" prop="username"></el-table-column>

            <el-table-column  :label="$t(headerList[4].name)" width="auto" prop="rolelist">
                <template slot-scope="scope">
                    <p v-for="item in scope.row.rolelist" :key="item">{{item}}</p>
                </template>
            </el-table-column>
               
            <el-table-column :label="$t(headerList[5].name)" width="auto" prop="email"></el-table-column>

            <el-table-column :label="$t(headerList[6].name)" width="auto" prop="remark"></el-table-column>

            <el-table-column :label="$t('label.operation')">
                <template slot-scope="scope">
                    <gl-button type="text" @click="deleteItem(scope.row,scope.$index)">{{$t('label.delete')}}</gl-button>
                </template>
            </el-table-column>
          </gl-object-table >
        </template>
        <template slot="buttons"> 
            <button class="btn-primary" @click.prevent="add">{{$t('add')}}</button>
            <Add :headerList="userFields" :display="display" :form="form" @save="save" @close="close"/>
        </template> 
        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :current-page.sync="currentPage" :changePage="changePage" :change-size="changeSize"></gl-page>
        </template>
      </aia-form>
    </section>
  </div>
</template>
<script>
import Add from './Add';
import {mapState,mapActions,mapMutations} from 'vuex';
import util from "@/models/Utility";
export default {
    components:{
        Add,
    },
    data(){
        return {
            headerList:[
                {
                    code:'enabled', 
                    name: 'label.enabled',
                    type: "select",
                    select: "other",
                    optionList: [
                        {code:'1',name:'Active'},
                        {code:'2',name:'Terminate'},
                    ],
                    required:true,
                },       
                {
                    code:'loginId', 
                    name: 'label.loginId',
                    type: "input",
                    required:true,
                    noDisplay:false,
                },
                {
                    code:'username', 
                    name: 'label.username',
                    type: "input",
                    required:false,
                    noDisplay:true,
                },
                {
                    code:'password', 
                    name: 'label.password',
                    type: "inputPassword",
                    required:true,
                },
                {
                    code:'rolelist', 
                    name: 'label.rolelist',
                    type: "selectMultiple",
                    select: "other",
                    optionList: [],
                    required:true,
                },
                {
                    code:'email', 
                    name: 'label.email',
                    type: "input",
                    required:false,
                    noDisplay:true,
                },
                {
                    code:'remark', 
                    name: 'label.remark',
                    type: "input",
                    required:false,
                },
                {
                    code: 'processingunit',
                    name: 'label.company',
                    type: "select",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'businessunit',
                    name: 'label.channel',
                    type: "select",
                    select: "other",
                    optionList: [],
                },
            ],
            tableData:[],
            total:0,
            pageSize:10,
            searchList:[],
            display:false,
            modifyIndex:-1,
            form:{
                loginId: '',
                username: '',
                password: null,
                remark: null,
                enabled: "1",
                email: null,
                rolelist:[],
                processingunit:null,
                businessunit:null,
            },
            currentPage:1,
            userFields:[],
            companies:[],
            channels:[],

        }
    },    
    computed:{
        ...mapState('role',['allRoles']),
        searchHeaderList(){
            let headerList=this.headerList.filter(x=>x.code!=='password'&&x.code!=='rolelist');
            return headerList;
        },
    },
    watch:{
        allRoles(val){
            this.headerList[4].optionList=[...val];
        }
    },
    async created(){
        this.companies=await this.$getGeneralList("company", this);
        this.channels=await this.$getGeneralList("channel", this);

        await this.queryRoles();
        this.headerList[4].optionList=[...this.allRoles];
        this.doSearch();

        this.companies.forEach(x=>x.disabled=false);
        this.channels.forEach(x=>x.disabled=false);
        this.headerList[8].optionList=this.channels;
        this.headerList[7].optionList=this.companies;        
    },
    methods:{
        ...mapMutations('user',['addUser','deleteUser']),
        ...mapActions('role',['queryRoles']),
        changePage(page){
            this.currentPage=page;
            this.doSearch(this.searchList,true,page);
        },
        changeSize(size){
            this.pageSize=size;
            this.doSearch(this.searchList,true,1);
        },
        async doSearch(searchList=[],firstClick = true,page=1){
            this.searchList=searchList;
            this.currentPage=page;
            
            let param={
                action:"GET",
                pageSize:this.pageSize,
                startPage:page,
            }
            // let {processingunit,businessunit}=this.$store.state.user.userInfo;
            // param.company=processingunit?processingunit:'';
            // param.channel=businessunit?businessunit:'';  

            searchList.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.name.substring(6);
                    param[prop]=x.value;
                }
            });
            let response=await this.doRequest(param);
            if(response){
                let {userlist,total}={...response};
                this.total=total;
                //process rolelist to ['a','b',...]
                this.tableData=userlist.map(user=>{
                    // let {loginId,username,password,remark,enabled,email,rolelist,}={...user};
                    let {action,pageSize,startPage,rolelist,...rest}={...user};
                    // let newUser={loginId,username,password,remark,enabled,email,};
                    let newUser={...rest,};
                    let newRolelist=[];
                    rolelist.forEach(role=>{
                        newRolelist.push(role.roleName);
                    });
                    newUser.rolelist=[...newRolelist];
                    return newUser;
                });
            }
        },
        add(){
            this.userFields=this.headerList.filter(x=>x.code!=='password');
            this.userFields[1].noDisplay=false;
            this.modifyIndex=-1;
            
            this.display=true;
            this.form={};
        },
        modify(row,index){
            this.userFields=this.headerList.slice();
            this.userFields[1].noDisplay=true;
            this.userFields[3].required=false;
            this.form={};
            this.modifyIndex=index;
            let {action,pageSize,startPage,...userInfo}={...row};
            this.form=userInfo;
            this.display=true;
        },
        save(form){
            let rolelist=[];
            form.rolelist.forEach(roleName=>{
                rolelist.push({roleName,});
            });
            if(this.modifyIndex>-1){
                this.modifySave(rolelist);
            }else{
                this.addSave(rolelist);
            }
            this.display=false;
        },
        async addSave(rolelist){
            let param={
                action:'POST',
                ...this.form,
                rolelist,
            }
            // param.password=util.encryptByDES(param.password);
            let res=await this.doRequest(param);
            if(!res){
                this.$alert("Add User Failed.", {
                    confirmButtonText: "OK",
                });
            }else{
                await this.doSearch();
                this.addUser({loginId:this.form.loginId,username:this.form.username});
            }
        },
        async modifySave(rolelist){
            let param={
                action:'UPDATE',
                ...this.form,
                rolelist,
            }
            if(param.password){
                param.password=util.encryptData(param.password);
            }
            
            let res=await this.doRequest(param);
            if(!res){
                this.$alert("Update User Failed.", {
                    confirmButtonText: "OK",
                });
            }else{
                this.tableData.splice(this.modifyIndex,1,{...this.form});
            }
        },
        deleteItem(row,index){
            let _this = this;
            this.$confirm(this.$t("message.confirmDelete"), "Warning", {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
               closeOnClickModal:false,
            })
            .then(async () => {
                let param={
                    action:'DELETE',
                    loginId:row.loginId,
                }
                let res=await _this.doRequest(param);
                if(!res){
                    _this.$alert("Delete User Failed.", {
                        confirmButtonText: "OK",
                    });
                }else{
                    _this.doSearch();
                    _this.deleteUser(row.loginId);
                }
            });
        },
        async doRequest(param){
            try{
                let response=await this.$caller.user_query(param);
                if(response.responseCode==="000"){
                    return response;
                }else{
                    return false;
                }
            }catch(e){
                this.$alert(e, {
                    confirmButtonText: "OK",
                });   
            }
        },
        close(){
            this.display=false;
        },
    },
}

</script>  