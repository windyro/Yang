<template>
  <div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
      <aia-form
        class="responsive-form"
        alias="authority_user">

        <template slot="scroll">
          <div>
            <gl-search :headerList="searchHeaderList"  @doSearch="doSearch" ref='glSearch'></gl-search>
          </div>
          <gl-object-table :data="tableData" ref="userTable" class="within-scroll-table">
            <el-table-column :label="$t(headerList[0].name)" width="auto">
                <template slot-scope="scope">
                    <gl-link type="primary" @click="modify(scope.row, scope.$index)">{{$t(scope.row.roleId)}}</gl-link >
                </template>
            </el-table-column>

            <el-table-column :label="$t(headerList[1].name)"  width="auto" prop="roleName"></el-table-column>

            <el-table-column :label="$t(headerList[2].name)"  width="auto">
                <template slot-scope="scope">
                    <p v-for="item in scope.row.authority" :key="item">{{item}}</p>
                </template>
            </el-table-column>

            <el-table-column  :label="$t(headerList[4].name)" width="auto" prop="userlist">
                <template slot-scope="scope">
                    <span v-for="item in scope.row.userlist" :key="item">{{item}},</span>
                </template>
            </el-table-column>
               
            <el-table-column :label="$t(headerList[3].name)" width="auto" prop="remark"></el-table-column>

            <el-table-column :label="$t('label.operation')">
                <template slot-scope="scope">
                    <gl-button :disabled="scope.row.roleId==='System_Admin'" type="text" @click="deleteItem(scope.row,scope.$index)">{{$t('label.delete')}}</gl-button>
                </template>
            </el-table-column>
          </gl-object-table >
        </template>
        <template slot="buttons"> 
            <button class="btn-primary" @click.prevent="add">{{$t('add')}}</button>
            <Add :headerList="headerList" :display="display" :radioGroup="radioGroup" :form="form" @save="save" @close="close" @selectRadio="radioChange" @removeTag="removeAuthority"/>
        </template> 
        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :current-page.sync="currentPage" :changePage="changePage" :change-size="changeSize"></gl-page>
        </template>
      </aia-form>
    </section>
  </div>
</template>
<script>
import Add from './Add';
import {mapState,mapMutations,mapActions} from 'vuex';
import pagesConfig from '@/models/pageConfig'

export default {
    components:{
        Add,
    },
    data(){
        return {
            headerList:[
                {
                    code:'roleId', 
                    name: 'label.roleId',
                    type: "input",
                    required:true,
                    noDisplay:true,
                },       
                {
                    code:'roleName', 
                    name: 'label.roleName',
                    type: "input",
                    required:true,
                    noDisplay:false,
                },
                {
                    code:'authority', 
                    name: 'label.authority',
                    type: "selectRadio",
                    select: "other",
                    optionList:pagesConfig.pages,
                    required:true,
                },
                {
                    code:'remark', 
                    name: 'label.remark',
                    type: "input",
                    required:false,
                },
                {
                    code:'userlist', 
                    name: 'label.members',
                    type: "transfer",
                    select:"other",
                    optionList:[],
                    titles:['Staff List', 'Member of Role'],
                    transferProp:{key: 'loginId',label: 'username'},
                    required:true,
                },
            ],
            radioGroup:[
                {code:'(NP)',name:'label.noPermission'},
                {code:'(R)',name:'label.read'},
                {code:'(M)',name:'label.modify'},
            ],
            tableData:[],
            total:0,
            pageSize:10,
            searchList:[],
            display:false,
            form:{
                roleId:'',
                roleName:'',
                authority:[],
                members:[],
                remark:'',
            },
            modifyIndex:-1,
            currentPage:1,
        }
    },
    computed:{
        ...mapState('user',['allUsers']),
        searchHeaderList(){
            let headerList=this.headerList.filter(x=>x.code!=='roleId'&&x.code!=='userlist');
            return headerList;
        },
    },
    watch:{
        allUsers(val){
            this.headerList[4].optionList=[...val];
        }
    },
    async created(){
        await this.queryUsers();
        this.headerList[4].optionList=[...this.allUsers];

        this.doSearch();
    },
    methods:{
        ...mapMutations('role',['addRole','deleteRole']),
        ...mapActions('user',['queryUsers']),
        changePage(page){
            this.currentPage=page;
            this.doSearch(this.searchList,true,page);
        },
        changeSize(size){
            this.pageSize=size;
            this.doSearch(this.searchList,true,1);
        },
        async doSearch(searchList=[],firstClick = true,page=1){
            this.searchList=searchList;
            this.currentPage=page;

            let param={
                action:"GET",
                startPage:page,
                pageSize:this.pageSize,
            }
            // let {processingunit,businessunit}=this.$store.state.user.userInfo;
            // param.company=processingunit?processingunit:'';
            // param.channel=businessunit?businessunit:'';  

            searchList.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.name.substring(6);
                    param[prop]=x.value;
                }
            });

            let response=await this.doRequest(param);

            if(response){
                let {rolelist,total}={...response};
                this.total=total;
                this.tableData=rolelist.map(role=>{
                    let {roleId,roleName,authority,remark,userlist}={...role};
                    let newRole={roleId,roleName,authority:[],remark,userlist:[],};
                    userlist.forEach(user=>{
                        newRole.userlist.push(user.loginId);
                    });

                    newRole.authority=authority.split(',');
                    return newRole;
                });
            }
        },
        add(){
            this.headerList[1].noDisplay=false;
            this.modifyIndex=-1;
            this.form={
                roleId:'Do not need to input.',
                roleName:'',
                authority:[],
                userlist:[],
                remark:'',
            };
            this.display=true;
        },
        modify(row,index){
            if(row.roleName==pagesConfig.adminRole){
                this.headerList[1].noDisplay=true;
            }

            this.form={};
            this.modifyIndex=index;
            let temp={...row};
            let {roleId,roleName,authority,remark,userlist,}={...temp};
            this.form={
                roleId,
                roleName,
                authority:[...authority],
                remark,
                userlist,
            };
            this.display=true;
        },
        save(form){
            let {roleId,roleName,authority,remark,userlist,}={...this.form};
            
            authority=authority.join(",");
            userlist=this.allUsers.filter(user=>{
                return userlist.some(x=>x===user.loginId);
            })

            let params={
                roleName,
                authority,
                remark,
                userlist,
            }
            
            if(this.modifyIndex>-1){
                params.roleId=roleId;
                this.modifySave(params);
            }else{
                this.addSave(params);
            }
            this.display=false;
        },
        async addSave(params){
            let param={
                action:'POST',
                ...params,
            }
            let res=await this.doRequest(param);
            if(!res){
                this.$alert("Add Role Failed.", {
                    confirmButtonText: "OK",
                });
            }else{
                this.addRole(param.roleName);
                this.doSearch();
            }
        },
        async modifySave(params){
            let param={
                action:'UPDATE',
                ...params,
            }
            
            let res=await this.doRequest(param);
            if(!res){
                this.$alert("Update Role Failed.", {
                    confirmButtonText: "OK",
                });
            }else{
                this.tableData.splice(this.modifyIndex,1,{...this.form});
                this.modifyIndex=-1;
            }
        },
        async deleteItem(row,index){
            let _this = this;
            this.$confirm(this.$t("message.confirmDelete"), "Warning", {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
              closeOnClickModal:false,
            })
            .then(async () => {
                let {roleName,remark,roleId,authority,}={...row};
                let param={
                    action:'DELETE',
                    roleName,
                    remark,
                    roleId,
                    authority:authority.join(","),
                }
                let res=await _this.doRequest(param);
                if(!res){
                    _this.$alert("Delete Role Failed.", {
                        confirmButtonText: "OK",
                    });
                }else{
                    _this.deleteRole(row.roleId);
                    _this.doSearch();
                }
            });
        },
        async doRequest(param){
            try{
                let response=await this.$caller.role_query(param)
                if(response.responseCode==="000"){
                    return response;
                }else{
                    return false;
                }
            }catch(e){
                this.$alert(e, {
                    confirmButtonText: "OK",
                });   
            }            
        },
        close(){
            this.display=false;
        },
        radioChange(radio){
            let selectValue=radio.name+radio.radioValue;
            let index=this.form[radio.optionCode].findIndex(x=>x.includes(radio.name));
            if(index>-1){
                this.$set(this.form[radio.optionCode],index,selectValue);
            }else{
                this.form[radio.optionCode].push(selectValue);
            }
        },
        removeAuthority(tag){
            let index=this.form['authority'].findIndex(x=>x===tag);
            this.form['authority'].splice(index,1);
        },
    },
}

</script>  