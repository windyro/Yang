<template>
    <div>
        <gl-dialog @doCloseDialog="doCloseDialog" :dialogTableVisible = "display" class="add-dialog">
            <template slot="dialog-content">
                <el-form label-position="top" :model="form" ref="addForm" label-width="100px">
                    <el-row :gutter="36" class="add-row">
                        <el-col  :xs="24" :sm="24" :md="12" :lg="12" v-for="item in headerList" :key="item.code">
                            <el-form-item :prop="item.code" :rules="item.required?rules:[]">
                                <template slot="label">
                                    <h6>{{$t(item.name)}}</h6>
                                </template>                            
                                <el-input v-if="item.type==='input'" :disabled="item.noDisplay" v-model="form[item.code]" :placeholder="$t('message.pleaseInput')" >{{inputValue(item)}}</el-input>
                                <el-input v-else-if="item.type==='inputPassword'" type="password" auto-complete="new-password" v-model="form[item.code]" :placeholder="$t('message.pleaseInput')">{{inputValue(item)}}</el-input>                                
                                <gl-select v-else-if="item.type==='select'" v-model="form[item.code]" :optionList="item.optionList" :valueData="form[item.code]" class="select-popper"></gl-select>
                                <!--<gl-select-multiple v-else-if="item.type==='selectMultiple'" v-model="form[item.code]" :optionList="item.optionList" :valueData="form[item.code]" class="select-popper"></gl-select-multiple>-->
                                <el-select multiple  v-else-if="item.type==='selectMultiple'" v-model="form[item.code]" class="select-popper">
                                    <el-option
                                        v-for="op in item.optionList"
                                        :key="op"
                                        :label="op"
                                        :value="op">
                                    </el-option>
                                </el-select>
                                <el-transfer v-else-if="item.type==='transfer'" v-model="form[item.code]" :titles="item.titles" :props="item.transferProp" :data="item.optionList" filterable></el-transfer>
                                <SelectRadio v-else-if="item.type==='selectRadio'" :optionCode="item.code" :optionValue="form[item.code]" :optionList="item.optionList" :radioGroup="radioGroup" @selectRadio="radioChange" @removeTag="removeTag"/>
                                <!--<gl-date v-else-if="item.type=='date'"
                                        :disabled="item.noDisplay"
                                        :type="item.type"
                                        v-model="form[item.code]"
                                        :value="form[item.code]"
                                        :editable="true"
                                        class="input-class">
                                </gl-date>     -->
                                <el-date-picker
                                    v-else-if="item.type=='date'"
                                    :disabled="item.noDisplay"
                                    v-model="form[item.code]"
                                    type="date">
                                </el-date-picker>
                            </el-form-item>    
                        </el-col>
                    </el-row>
                </el-form>
            </template>
            <template slot="buttons">
                <button class="btn-primary"  @click.prevent="doSave">{{$t('label.save')}}</button>
                <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>           
            </template>
        </gl-dialog>
    </div>
</template>
<script>
import SelectRadio from '@/components/common/SelectRadio';

export default {
    components:{
        SelectRadio,
    },
    props:{
        headerList:{
            type:Array,
            default:[],
        },
        display:{
            type:Boolean,
            default:false,
        },
        form:{
            type:Object,
            default:()=>{
                return {};
            },
        },
        radioGroup:{
            type:Array,
            default:null,
        },
    },
    data(){
        return{
            rules:[{required: true, message: "Can't be empty", trigger: "blur"}],
        }
    },
    watch:{
        display(val){
            if(val){
                this.$refs['addForm']&&this.$refs['addForm'].resetFields();
            }
        },
    },
    methods:{
        inputValue(item){
            let value;
            for(let prop in this.form){
                if(prop&&prop===item.code){
                    value=this.form[prop];
                    break;
                }
            }
            return value;
        },
        doSave(){
            this.$refs['addForm'].validate(valid=>{
                if(valid){
                    this.$emit('save',this.form);
                }
            });
        },
        doCloseDialog(){
            this.$emit('close',false);
        },
        radioChange(radio){
            this.$emit('selectRadio',radio);
        },
        removeTag(tag){
            this.$emit('removeTag',tag);
        },
    },
}
</script>  
<style lang="scss">
@import "./add.scss";
</style>