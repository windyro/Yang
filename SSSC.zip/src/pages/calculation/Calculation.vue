<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="ruleForm" class="responsive-form" alias="calculation_job" :model="ruleForm">

            <template slot="scroll">

                <div>
                    <gl-search :headerList="headerListReal" @doSearch="doSearch" ref='glSearch'>
                    </gl-search>
                </div>

                <!--span class="h6 float-right add-btn cursor-p" @click="addNew">+ add new</span-->
                <gl-object-table :data="tableData">
                    <el-table-column :label="$t(headerList[0].name)" width="auto">
                        <template slot-scope="scope">                        
                            <gl-date :edit="false"  v-model="scope.row.period" :value="scope.row.period" type="month" ></gl-date>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[1].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.stage" :valueData="scope.row.stage" :optionList="headerList[1].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[2].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.company" :valueData="scope.row.company" :optionList="headerList[2].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <!--<el-table-column :label="$t(headerList[3].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.channel" :valueData="scope.row.channel" :optionList="headerList[3].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column  :label="$t('label.city')" width="auto" prop="city">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.city" :valueData="scope.row.city" :optionList="citys">
                            </gl-select>
                        </template>
                    </el-table-column> 
                     <el-table-column :label="$t(headerList[4].name)" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.compensation}}</span>
                        </template>
                    </el-table-column-->

                    <el-table-column :label="$t(headerList[4].name)" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.status}}</span>
                        </template>
                    </el-table-column>


                    <el-table-column :label="$t((headerList[5].name))" width="auto">
                        <template slot-scope="scope">
                            <gl-date :edit="false"  v-model="scope.row.startTime" :value="scope.row.startTime" type="datetime"></gl-date>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[6].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-date :edit="false"  v-model="scope.row.endTime" :value="scope.row.endTime" type="datetime"></gl-date>
                        </template>
                    </el-table-column>
                </gl-object-table>

                <run-job
                :headerList="headerList"
                :dialogTableVisible = "dialogTableVisible"
                v-if="dialogTableVisible"
                @doCloseDialog="doCloseDialog"
                @doRunJob = "doRunJob"
                >
                </run-job>               
 

            </template>

            <template slot="pages">
                <gl-page :total="total" :currentPage="currentPage" :pageSize="pageSize" ref="glPage" :changePage="changePage" :change-size="changeSize">
                </gl-page>
            </template>

            <template slot="buttons">   
                 <button class="btn-primary" @click.prevent="runJobDialog" :disabled="!isModify">{{$t('label.calculation')}}</button>
            </template>

        </aia-form>
    </section>
</div>
</template>

<script>
import RunJob from "./RunJob";
import util from "@/models/Utility";
export default {
    components:{
        RunJob,
    },
    props: ["title"],
    data() {
        return {
   
            dialogTableVisible: false,
            selectDate: [],
            headerList: [{
                    code: 'period',
                    name: 'label.period',
                    type: "month",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'stage',
                    name: 'label.stage',
                    type: "select",
                    select: "other",
                    optionList: util.data().jobStageList,
                },
                {
                    code: 'company',
                    name: 'label.company',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("company", this),
                },
                // {
                //     code: 'channel',
                //     name: 'label.channel',
                //     type: "select",
                //     select: "other",
                //     optionList: this.$getGeneralList("channel", this).filter(option=>!option.disabled),
                // },
                {
                    code: 'compensation',
                    name: 'label.compensation',
                    type: "input",
                    select: "",
                    optionList: [],
                },

                {
                    code: 'status',
                    name: 'label.status',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'startTime',
                    name: 'label.start_time',
                    type: "date",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'endTime',
                    name: 'label.end_time',
                    type: "date",
                    select: "other",
                    optionList: [],
                },
            ],

            headerListReal: [],
            tableData: [],
            total:0,
            currentPage: 1,
            pageSize:10,
            searchList:[],
            // citys:this.$getGeneralList("city", this),
            isModify:this.$checkPageModify(this.$route.name),
            ruleForm:{},
            companies:[],
        };
    },



    created() {
        this.companies=this.$getGeneralList("company", this);
        this.headerListReal.push(this.headerList[0]);
        this.headerListReal.push(this.headerList[1]);
        this.headerListReal.push(this.headerList[2]);
        this.headerListReal.push(this.headerList[5]);
        // alert(this.$route.name);
        this.$emit("getTitle", "");
        //this.prepare();
        this.doSearch(this.searchList);
    },
    mounted: function () {
        //this.doSearch({});
    },

    watch:{
        headerList(val){
            console.log('val',val);
        }
    },

    methods: {

        appendGeneralList(listName){
            var optionList = [{code: "All,",  name: "label.all"}];
            optionList=optionList.concat(this.$getGeneralList(listName, this));
            return optionList;
        },

        prepare() {
            for(var i=0; i<10; i++) {
                this.tableData.push({ //add a new row
                    period: "2019-10-01",
                    stage: "FINALIZE",
                    company: "AGY_PU",
                    // channel: "MMAGY",
                    compensation: "All",
                    status: "Completed",
                    startTime: "2019-11-26 01:00:24",
                    endTime: "2019-11-26 04:00:24",
                });
            }

            this.total = this.tableData.length;
            this.currentPage = this.$refs.glPage.currentPage;
            this.pageSize = this.$refs.glPage.pageSize;
        },

        async doSearch(searchList=[],page=1) {
            this.searchList=searchList;
            let param={
                action:"GET",
                startPage: page,
                pageSize: this.pageSize,
            };
    
            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';
            param.channel=businessunit?businessunit:'';

            searchList.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.code;
                    param[prop]=x.value;
                }
            });
            this.currentPage=page;
            let response=await this.$caller.pipeline_detail(param);

            if(response.responseCode=="000"){
                let {pipelineResult,total}={...response};
                this.total=total;
                this.tableData=pipelineResult;
            }
            else{
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });
                if(!this.$isEmpty(response.reasonCode)){
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },


        changePage(page) {
            this.doSearch(this.searchList, page)
        },

        async changeSize(size){
            this.pageSize=size;
            await this.doSearch(this.searchList,1);
        },

        doRunJob(editData){
           //alert(JSON.stringify(editData));
           this.dialogTableVisible = false;
           var param = {
                compensationType: editData.stage,
                period: editData.period,
                company: editData.company,
                action:"POST",
           };

           this.$caller.pipeline_trigger(param).then(res => {
                if(res.responseCode != "000"){

                    this.$alert("Response Code: " + res.responseCode, "Attention", {
                        confirmButtonText: "OK",
                    });
                    if(!this.$isEmpty(res.reasonCode)){
                        this.$alert("Reason Code: " + res.reasonCode + this.$responseDesc(res.reasonDesc), "Attention", {
                            confirmButtonText: "OK",
                        });
                    }

                }
                else{
                    this.doSearch(this.$refs.glSearch.searchList, 1);
                }
           });

        },

        doCloseDialog(){
           this.dialogTableVisible = false;
        },

        runJobDialog(){
            //this.$refs.ruleForm.childTest();
            this.dialogTableVisible = true;
        },

    },
};
</script>

<style lang="scss" scoped>
.view-Form {
    background: none;
    border: 0;
}

.email-style {
    width: 100%;

    span {
        display: inline-block;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        width: 100%;
    }
}
</style>
