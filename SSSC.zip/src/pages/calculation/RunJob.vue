<template>
   <aia-el-form alias="runJobDialog" ref="runJobForm" :model="runJobForm" :rules="$formValidator.rules">

        <gl-dialog
            @doCloseDialog="doCloseDialog"
            :dialogTableVisible = "dialogTableVisible"
        >
            
                <template slot="dialog-content">
                    <div>
                        <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[0].name)}}</h6></label>
                                <gl-date prop="period" :rules="$formValidator.rules.required" :edit="true"  v-model="runJobForm.period" :value="runJobForm.period" type="month" ></gl-date>
                            </el-col>   
                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[2].name)}}</h6></label>
                                <gl-select prop="company" :rules="$formValidator.rules.required" :edit="true" v-model="runJobForm.company" :valueData="runJobForm.company" :optionList="headerList[2].optionList" @change="doChange()">
                                </gl-select>
                            </el-col>
                        </el-row>

                        <!--<el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                            
                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[3].name)}}</h6></label>
                                <gl-select prop="channel" :rules="$formValidator.rules.required"  :edit="true" v-model="runJobForm.channel" :valueData="runJobForm.channel" :optionList="headerList[3].optionList" :allOption="true" @change="doChange()">
                                </gl-select>
                            </el-col>     
                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[5].name)}}</h6></label>
                                <gl-select prop="city" :rules="$formValidator.rules.required" :edit="true" v-model="runJobForm.city" :valueData="runJobForm.city" :optionList="headerList[5].optionList" :allOption="true" @change="doChange()">
                                </gl-select>
                            </el-col>             
                        </el-row>  -->  


                        <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                            <!--el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[4].name)}}</h6></label>
                                <gl-select prop="compensation" :rules="$formValidator.rules.required" :edit="true" v-model="runJobForm.compensation" :valueData="runJobForm.compensation" :optionList="headerList[4].optionList" :allOption="true">
                                </gl-select>
                            </el-col-->

                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[1].name)}}</h6></label>
                                <gl-select prop="stage" :rules="$formValidator.rules.required" :edit="true" v-model="runJobForm.stage" :valueData="runJobForm.stage" :optionList="headerList[1].optionList" >
                                </gl-select>
                            </el-col>                       
                        </el-row>               
                    </div>
                </template> 

                <template slot="buttons">   
                    <button class="btn-primary"  @click.prevent="doRunJob">{{$t('label.run_calculation')}}</button>
                    <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
                </template>
        </gl-dialog>

   </aia-el-form>

</template>
<script>
import util from "@/models/Utility";
export default {
  name: 'RunJob',
  props: ["dialogTableVisible"],
  data() {
    return {

      headerList: [
        {
            code: 'Period',
            name: 'label.period',
            type: "month",
            select: "",
            optionList: [],
        },
        {
            code: 'Stage',
            name: 'label.stage',
            type: "select",
            select: "other",
            optionList: util.data().jobStageList,
        },
        {
            code: 'Company',
            name: 'label.company',
            type: "select",
            select: "other",
            optionList: this.$getGeneralList("company", this),
        },
        // {
        //     code: 'Channel',
        //     name: 'label.channel',
        //     type: "select",
        //     select: "other",
        //     optionList: this.$getGeneralList("channel", this).filter(option=>!option.disabled),
        // },
        {
            code: 'Compensation',
            name: 'label.compensation',
            type: "input",
            select: "",
            optionList: [],
        },
        // {
        //     code: 'City',
        //     name: 'label.city',
        //     type: "select",
        //     select: "other",
        //     optionList: this.$getGeneralList("city", this),
        // },
     ],
    
      runJobForm:  {period: '',
                    stage: '',
                    company: '',
                    // channel: '',
                    compensation: 'All',},
      dialogTable: this.dialogTableVisible,


    };
  },

  created() {  
     // this.searchCompensation();
  },
  methods: {

    doCloseDialog(){
        this.$emit("doCloseDialog", this.dialogTable);
    },

    doRunJob(){
    
        if(!this.$refs.runJobForm.validate()){
            return;
        }
        this.$emit("doRunJob", this.runJobForm);
    },

    doChange(){
        this.searchCompensation();
       
    },

    async searchCompensation() {
        
        var param = {
            action: 'GET',
            name: '',
            company: this.runJobForm.company=="All" ? "" : this.runJobForm.company,
            // channel: this.runJobForm.channel=="All" ? "" : this.runJobForm.channel,
            paymentFlag: '',
            description: '',
            frequency: '',
        };

          try {
            var res = await util.getRuleSummaryList(this, 1, 400, param);
            //this.headerList[4].optionList.length = 0;
            // this.headerList[4].optionList.splice(0, this.headerList[4].optionList.length);
            this.headerList[3].optionList.splice(0, this.headerList[3].optionList.length);

            this.runJobForm.compensation="All";
            if (res.responseCode =="000"){
                res.ruleGroupModel.forEach((element,index) =>{
                    // this.headerList[4].optionList.push({code: element.ruleGroupModelId,  name: element.name});
                    this.headerList[3].optionList.push({code: element.ruleGroupModelId,  name: element.name});
                });
             //alert(JSON.stringify(this.headerList[4].optionList));
            }
            else{
                this.$alert("Response Code: " + res.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });

                if(!this.$isEmpty(res.reasonCode)){
                    this.$alert("Reason Code: " + res.reasonCode + this.$responseDesc(res.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }

            } catch (e) {
                this.$alert(this.$t(e), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }

      },

  },
};
</script>

<style lang="scss">

</style>


