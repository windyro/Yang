<template>
    <div class="family-member">
        <el-collapse accordion :value="'1'">
            <el-collapse-item class="detail-collapse" name="1">
                <template slot="title">
                    <h6>{{$t('label.familyMember')}}</h6>
                </template>
                <el-row class="add-delete-row">
                    <el-col :span="1">
                        <el-button type="text" icon="el-icon-plus" @click.prevent="add"  :disabled="!isEdit">{{$t('label.add')}}</el-button>
                    </el-col>
                    <el-col :span="1">
                        <el-button type="text" icon="el-icon-close" @click.prevent="delMbr" :disabled="!isEdit">{{$t('label.delete')}}</el-button>
                    </el-col>
                </el-row>
                <el-table :data="member" @select-change="selectChange">
                    <el-table-column type="selection" width="55"></el-table-column>

                    <el-table-column :label="$t('label.familyMemberName')" width="auto" prop="familyMemberName">
                        <template slot-scope="scope">
                            <el-input v-if="scope.row.isEdit" v-model="scope.row.familyMemberName"/>
                            <span v-else>{{scope.row.familyMemberName}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.relationshipWithAgent')" width="auto" prop="relationshipWithAgent">
                        <template slot-scope="scope">
                            <gl-select v-if="scope.row.isEdit" 
                                :type="'select'" 
                                :edit="true" 
                                :valueData="scope.row.relationshipWithAgent" 
                                v-model="scope.row.relationshipWithAgent" 
                                :optionList="relationshipOptionList">
                            </gl-select>  
                            <span v-else>{{scope.row.relationshipWithAgent}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.identificationNumb')" width="auto" prop="identificationNumb">
                        <template slot-scope="scope">
                            <el-input v-if="scope.row.isEdit" v-model="scope.row.identificationNumb"/>
                            <span v-else>{{scope.row.identificationNumb}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.gender')" width="auto" prop="gender">
                        <template slot-scope="scope">
                            <gl-select v-if="scope.row.isEdit" 
                                :type="'select'" 
                                :edit="true" 
                                :valueData="scope.row.gender" 
                                v-model="scope.row.gender" 
                                :optionList="genderList">
                            </gl-select>    

                            <span v-else>{{scope.row.gender}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.dob')" width="auto" prop="dob">
                        <template slot-scope="scope">
                            <el-date-picker
                                v-if="scope.row.isEdit"
                                v-model="scope.row.dob"
                                type="date">
                            </el-date-picker>  

                            <span v-else>{{scope.row.dob}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.contactNo')" width="auto" prop="contactNo">
                        <template slot-scope="scope">
                            <el-input v-if="scope.row.isEdit" v-model="scope.row.contactNo"/>
                            <span v-else>{{scope.row.contactNo}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.residentialAddress')" width="auto" prop="residentialAddress">
                        <template slot-scope="scope">
                            <el-input v-if="scope.row.isEdit" v-model="scope.row.residentialAddress"/>
                            <span v-else>{{scope.row.residentialAddress}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.postalCode')" width="auto" prop="postalCode">
                        <template slot-scope="scope">
                            <el-input v-if="scope.row.isEdit" v-model="scope.row.postalCode"/>
                            <span v-else>{{scope.row.postalCode}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.operation')">
                        <template slot-scope="scope">
                            <gl-button type="text" v-if="scope.row.isEdit" @click="saveRow(scope.row,scope.$index)">{{$t('label.save')}}</gl-button>
                            <gl-button type="text" v-if="scope.row.isEdit" @click="cancel(scope.row,scope.$index)">{{$t('label.cancel')}}</gl-button>
                            <gl-button type="text" v-else @click="editRow(scope.row,scope.$index)">{{$t('label.edit')}}</gl-button>
                        </template>
                    </el-table-column>
                </el-table>   
            </el-collapse-item>
        </el-collapse>
    </div>

</template>
<script>
export default {
    props:{
        tableData:{
            type:Array,
            default:[],
        },
        isEdit:{
            type:Boolean,
            default:false,
        },
    },
    data(){
        return{
            member:[],
            modifyIndex:-1,
            isAdd:false,
            genderList:[
                {code:'male',name:'male'},
                {code:'female',name:'female'},
            ],
            relationshipOptionList:[
                {code:'Father',name:'Father'},
                {code:'Mother',name:'Mother'},        
                {code:'Spouse',name:'Spouse'},
                {code:'Child',name:'Child'},          
                {code:'Brother',name:'Brother'},                
                {code:'Sister',name:'Sister'},                
            ],
            multiSelect:[],
        }
    },
    watch:{
        tableData:{
            handler(val){
                this.member=val.map(item=>{
                    return {...item,isEdit:false,}
                });
            },
            immediate:true,//立即执行
        }
    },
    methods:{
        selectChange(val){
            this.multiSelect=val;
        },
        add(){
            this.member.push({
                familyMemberName:null,
                relationshipWithAgent:null,
                identificationNumb:null,
                gender:null,
                dob:null,
                contactNo:null,
                residentialAddress:null,
                postalCode:null,
                isEdit:true,
            })
        },
        delMbr(){
            this.member=this.member.filter(x=>this.multiSelect.some(y=>x==y));
        },
        cancel(row,index){
            this.member.splice(index,1);
            this.member[index].isEdit=false;
        },
        saveRow(row,index){
            this.member.splice(index,1,{...row});       
            this.member[index].isEdit=false;    
        },
        editRow(row,index){
            this.member[index].isEdit=true;        
        }
    },
}
</script>
<style lang="scss">
.family-member{
    margin:15px 0;
    .detail-collapse{
        min-height: 140px;
        h6{
            color: #828282;
            margin:10px 0;
        }
        .el-collapse-item__header{
            border-bottom: 1px solid #f5e8e8;
            margin: 0 0 12px;
            padding-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .el-icon-arrow-right:before{
            content:'\25BC';
            color: #6b6b6b;
        }
        .el-collapse-item__arrow.is-active{
            transform: rotate(180deg);
            transition-duration:0.6s;
        }

        .add-delete-row{
            .el-button{
                border: none;
                background: #fff;
                width: 100%;
                color: #737070;
                font-weight: 800;
                font-size: 14px;
                i{
                    margin-right: 4px;
                    color: #596C80; 
                }
            }
        }

        td div{
            height:100%;
            margin-bottom: 0;
        }
    }
}

</style>