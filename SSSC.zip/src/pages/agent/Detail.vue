<template>
    <div class="content-wrap">
        <section class="content-fluid margin-left-3xl margin-right-3xl">
            <aia-form class="responsive-form" alias="agentForm" ref="agentForm" :model="detailForm" :rules="$formValidator.rules">
                <template slot="scroll">
                    <gl-version ref='glVersion' 
                        :currentVersion="currentVersion"
                        :versionData="versions"
                        :isModify="isModify"
                        @viewVersion="doViewVersion"
                        @removeVersion ="doRemoveVersion"
                    >                               

                    </gl-version>

                    <gl-tabs :tabPosition="'top'" style="margin-top:40px;" v-model="defaultTab">
                        <el-tab-pane :label="$t('label.agentBasicInfo')" name="1">
                            <FieldList :fields="basicInfo" :isEdit="newVersionStatus" :form="detailForm.basicForm" :formName="'basicForm'" :getSelectedObjFunc="getSelectedObjFunc"/>
                        </el-tab-pane>
                        <el-tab-pane :label="$t('label.agentContractInfo')" name="2">
                            <FieldList :fields="contractInfo" :isEdit="newVersionStatus" :form="detailForm.contractForm" :formName="'contractForm'" :getSelectedObjFunc="getSelectedObjFunc"/>
                        </el-tab-pane> 
                        <el-tab-pane :label="$t('label.agentFamilyInfo')" name="3">
                            <FieldList :fields="familyInfo"  :isEdit="newVersionStatus" :form="detailForm.familyForm" :formName="'familyForm'" :getSelectedObjFunc="getSelectedObjFunc"/>
                            <el-collapse  :value="'1'">
                                <el-collapse-item class="family-collapse" name="1">
                                    <template slot="title">
                                        <h6>{{$t('label.familyMember')}}</h6>
                                    </template>
                                    <gl-element-table :headerList="memberHeaders" :tableData="familyMember" :edit="newVersionStatus" @saveRow="getFamilyMember" ref="relationTable">
                                    </gl-element-table>
                                </el-collapse-item>    
                            </el-collapse>  
                        </el-tab-pane> 
                        <el-tab-pane :label="$t('label.hierarchyTree')" name="4">
                            <gl-tree :data="treeData" :childrenSrc="fileSvg" :parentSrc="fileFolderSvg" :currentKey="Number(seq)" :defaultExpandKeys="[Number(seq)]" :nodeKey="'id'" @goToDetail="goToDetail"></gl-tree>
                        </el-tab-pane>
                    </gl-tabs>
                </template>

                <template slot="buttons"> 
                    <button v-if="newVersionStatus" class="btn-primary" @click.prevent="save()">{{$t('label.save')}}</button>
                    <button v-if="!newVersionStatus&&isModify" class="btn-primary" @click.prevent="newVersion">{{$t('label.new_version')}}</button>
                    <button class="btn-secondary" @click.prevent="back">{{$t('label.back')}}</button>
                </template> 
            </aia-form>
        </section>
    </div>
</template>
<script>
import FieldList from './FieldList';
import util from "@/models/Utility";
import fileFolder from '@/assets/images/fileFolder.svg';
import file from '@/assets/images/file.svg';

export default {
    components:{
        FieldList,
    },
    data(){
        return{
            fileSvg:file,
            fileFolderSvg:fileFolder,
            basicInfo:[
                {name:'companyCode',value:'',type:'select',required:true,optionList:this.$getGeneralList("company", this),model:'positionModel',},
                // {name:'companyCode',value:'',type:'input',required:true,},

                {name:'channelCode',value:'',type:'select',required:true,optionList:this.$getGeneralList("channel", this),model:'positionModel',},
                // {name:'channelCode',value:'',type:'input',required:true,},

                {
                    code:'districtCode', 
                    hidden: 'parentpositionSeq',
                    name: 'districtCode',
                    type: "selectSearch",
                    required:true,
                    apiName: "position_query",
                    apiInput: "code",
                    apiParm: {
                        action:"GET", 
                        nodeType: "SELF",
                        recordType:'AGY',
                        isLast: "1",
                        pageSize: 50, 
                        startPage: 1,
                    },
                    apiResult: {resultList: 'positionNodeModel', code: 'seq', name: 'code'},
                    model:'positionModel',
                },
                // {name:'districtCode',value:'',type:'input',required:true,},

                // {name:'agencyCode',value:'',type:'selectSearch',required:true,},
                {
                    code:'agencyCode', 
                    hidden: 'parentpositionSeq',
                    name: 'agencyCode',
                    type: "selectSearch",
                    required:true,
                    apiName: "position_query",
                    apiInput: "code",
                    apiParm: {
                        action:"GET", 
                        nodeType: "SELF",
                        recordType:'AGY',
                        isLast: "1",
                        pageSize: 50, 
                        startPage: 1,
                    },
                    apiResult: {resultList: 'positionNodeModel', code: 'seq', name: 'code'},
                    model:'positionModel',
                },

                {name:'locationCode',value:'',type:'input',},

                {name:'agentCode',value:'',type:'input',required:true,model:'participantModel',},
                // {name:'agentCode',value:'',disabled:true,},

                {name:'agentName',value:'',type:'input',required:true,},
                // {name:'agentTitle',value:'',type:'select',required:true, optionList: this.$getGeneralList("title", this),model:'positionModel',},
                {name:'title',value:'',type:'select',required:true, optionList: this.$getGeneralList("title", this),model:'positionModel',},

                {name:'agentClass',value:'',type:'input',required:true,},

                {name:'agentType',value:'',type:'select',required:true,optionList:[
                    {code:'Standard Agent',name:'Standard Agent'},
                    {code:'Non-Standard Agent',name:'Non-Standard Agent'},
                    {code:'Staff Agent',name:'Staff Agent'},
                ],model:'participantModel',},
                {name:'agentStatus',value:'',type:'select',required:true,optionList:[
                    {code:'Active',name:'Active'},
                    {code:'Pending',name:'Pending'},
                    {code:'Terminated',name:'Terminated'},
                ],model:'participantModel',},
                {name:'recruitSource',value:'',type:'select',required:true,optionList:[
                    {code:'New',name:'New'},
                    {code:'Rejoin',name:'Rejoin'},
                    {code:'Transfer',name:'Transfer'},                
                ],model:'participantModel',},
                {name:'recruiterCode',value:'',type:'input',required:true,model:'participantModel',},
                {name:'businessUnit',value:'',type:'input',required:true,model:'participantModel',},
                {name:'identificationNumb',value:'',type:'input',required:true,model:'participantModel',},
                {name:'email',value:'',type:'input',required:true,model:'participantModel',},
                {name:'highestEducation',value:'',type:'input',required:true,model:'educationModel',},
                {name:'graduateSchool',value:'',type:'input',required:true,model:'educationModel',},
                {name:'domicilePlace',value:'',type:'input',model:'participantModel',},
                {name:'eventCalendar',value:'',type:'input',model:'participantModel',},
                {name:'hireDate',value:'',required:true,type:'date',model:'participantModel',},
                {name:'taxId',value:'',type:'input',required:true,model:'participantModel',},
                {name:'gender',value:'',type:'select',required:true,optionList:[
                    {code:'Male',name:'Male'},
                    {code:'Female',name:'Female'}, 
                ],model:'participantModel',},
                {name:'dob',value:null,type:'date',required:true,model:'participantModel',},


                {name:'beneficiaryName',value:'',type:'input',required:true,model:'participantModel',},
                {name:'fsc1stAssignment',value:'',type:'input',model:'participantModel',},
                {name:'fortsAgent',value:'',type:'select',optionList:[
                    {code:'1',name:'Yes',},
                    {code:'2',name:'No',},
                ],model:'participantModel',},
                {name:'nationality',value:'',type:'input',model:'participantModel',},
                {name:'preferredLanguage',value:'',type:'input',model:'participantModel',},
                {name:'agentTelephone',value:'',type:'input',model:'participantModel',},
                {name:'agentCellPhone',value:'',type:'input',required:true,model:'participantModel',},
                {name:'emergencyContact',value:'',type:'input',required:true,model:'participantModel',},
                {name:'emergencyContactNo',value:'',type:'input',required:true,model:'participantModel',},
                {name:'residentialAddress',value:'',type:'input',required:true,model:'participantModel',},
                {name:'postalCode',value:'',type:'input',model:'participantModel',},
                {name:'retiredAgtAPFEligible',value:'',type:'input',},
                {name:'retiredDate',value:'',type:'input',type:'date',model:'participantModel',},
                {name:'rejoinFlag',value:'',type:'input',model:'participantModel',},
                {name:'rejoinDate',value:'',type:'input',type:'date',model:'participantModel',},
                // {name:'recordType',value:'',type:'select',required:true,optionList:[
                //     {code:'AGY',name:'AGY',},
                //     {code:'AGT',name:'AGT',},                    
                // ],model:'participantModel',}, 
                // {name:'createDate',value:'',required:true,type:'date',},
                {name:'effectiveStartDate',value:util.data().defaultStartDate,required:true,type:'date',model:'participantModel',},
                {name:'effectiveEndDate',value:util.data().defaultEndDate,required:true,type:'date',model:'participantModel',},
                {name:'versionLog',value:'',type:'input',model:'',}
            ],
            contractInfo:[
                // {name:'contractCode',value:'',type:'input',required:true,optionList:[],},
                {name:'contractCode',value:'',type:'input',required:true,model:'contractModel',},
                {name:'identificationNumb',value:'',type:'input',required:true,model:'contractModel',},
                {name:'baseSalary',value:'',type:'input',required:true,model:'contractModel',},
                {name:'agentTitle',value:'',type:'input',model:'contractModel',},
                {name:'agentClass',value:'',type:'input',},
                {name:'promotionDate',value:'',type:'input',type:'date',model:'contractModel',},
                {name:'demotionDate',value:'',type:'input',type:'date',model:'contractModel',},
                {name:'terminationDate',value:'',type:'input',type:'date',model:'contractModel',},
                {name:'paidInPolicyCurrency',value:'',type:'input',required:true,model:'contractModel',},
                {name:'paymentMethod',value:'',type:'input',required:true,model:'contractModel',},
                {name:'usdAcctNumb',value:'',type:'input',model:'contractModel',},
                {name:'usdBankCode',value:'',type:'input',model:'contractModel',},
                {name:'usdBranchCode',value:'',type:'input',model:'contractModel',},
                {name:'localAcctNumb',value:'',type:'input',model:'contractModel',},
                {name:'localBankCode',value:'',type:'input',model:'contractModel',},
                {name:'localBranchCode',value:'',type:'input',model:'contractModel',},
            ],
            familyInfo:[
                {name:'maritalStatus',value:'',type:'select',required:true,optionList:[
                    {code:'Single',name:'Single'},
                    {code:'Married',name:'Married'},
                    {code:'Divorced',name:'Divorced'},                
                ],model:'participantModel',},
                {name:'familyContact',value:'',type:'input',required:true,model:'participantModel',},
                {name:'familyAddress',value:'',type:'input',required:true,model:'participantModel',},
            ],
            familyMember:[],
            fieldData:[],
            headerList:[],
            versions:[],
            newVersionStatus:false,
            currentVersion:{},
            isSave:false,
            basicForm:{},
            contractForm:{},
            familyForm:{},

            detailForm:{
                basicForm:{},
                contractForm:{},
                familyForm:{},
            },

            memberHeaders:[
                {code:'familyMemberName',name:'label.familyMemberName',value:'',type:'input',required:true,rules: this.$formValidator.rules.required,},

                {
                    code:'relationshipWithAgent',
                    name:'label.relationshipWithAgent',
                    value:'',
                    type:'select',
                    rules: this.$formValidator.rules.required,
                    required:true,
                    optionList:[
                        {code:'Father',name:'Father'},
                        {code:'Mother',name:'Mother'},
                        {code:'Spouse',name:'Spouse'},
                        {code:'Child',name:'Child'},
                        {code:'Brother',name:'Brother'},
                        {code:'Sister',name:'Sister'},
                    ],
                },

                {code:'identificationNumb',name:'label.identificationNumb',value:'',type:'input',required:true,rules: this.$formValidator.rules.required,},

                {
                    code:'gender',
                    name:'label.gender',
                    value:'',
                    type:'select',
                    required:true,
                    rules: this.$formValidator.rules.required,
                    optionList:[
                        {code:'male',name:'male'},
                        {code:'female',name:'female'},
                    ],
                },

                {code:'dob',name:'label.dob',value:'',type:'input',type:'date',required:true,rules: this.$formValidator.rules.required,},
                {code:'contactNo',name:'label.contactNo',value:'',type:'input',required:true,rules: this.$formValidator.rules.required,},
                {code:'residentialAddress',name:'label.residentialAddress',value:'',type:'input',required:true,rules: this.$formValidator.rules.required,},
                {code:'postalCode',name:'label.postalCode',value:'',type:'input',required:true,rules: this.$formValidator.rules.required,},

            ],
            seq:null,
            isModify:false,
            treeData:[],
            defaultTab:'1',
        };
    },
    async created(){
        await this.initTreeData();

        this.initForm(this.basicInfo,this.detailForm.basicForm);
        this.detailForm.basicForm.managerSeq=null;
        this.detailForm.basicForm.managerAgency=null;
        this.detailForm.basicForm.positionSeq=null;

        this.initForm(this.contractInfo,this.detailForm.contractForm);
        this.initForm(this.familyInfo,this.detailForm.familyForm);

        const {seq,isModify,agentCode}=this.$route.query;
        
        this.isModify=isModify;
        if(seq||agentCode){
            let param={
                action:"GET",
                seq,
                isLast:'1',    
                agentCode,   
            }
            
            this.seq=seq;
            this.doDetail(param);
        }else{
            this.newVersionStatus=true;
        }

    },
    methods:{
        async initTreeData(){
            this.treeData=await this.$getGeneralList('hierarchyTree',this);
        },
        getSelectedObjFunc(name,code,seq,formName){
            this.detailForm[formName][name]=code;
            if(name=='agencyCode'){
                this.detailForm.basicForm.managerSeq=seq;
                this.detailForm.basicForm.managerAgency=code;
            }
        },
        initForm(info,form){
            info.forEach(x=>{
                this.$set(form,x.name,x.value);
            });
        },
        async doDetail(agentParam){
            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            agentParam.company=processingunit?processingunit:'';
            agentParam.channel=businessunit?businessunit:'';     

            this.newVersionStatus=false;

            this.familyMember=[];
            let agentRes=await this.$caller.agent_query(agentParam);
            if(agentRes&&agentRes.responseCode=='000'){
                this.$refs['agentForm']&&this.$refs['agentForm'].resetFields();

                if(agentRes.agentModel.length>0){
                    let info={...agentRes.agentModel[0]};
                    let fields={...info.familyModel,...info.positionModel,...info.educationModel,...info.contractModel,...info.participantModel,};
                    this.currentVersion=fields.versionModel;


                    for(let p in fields){
                        if(p=='lastName'){
                            this.detailForm.basicForm.agentName=fields[p];
                        }
                        this.getFieldValue(p,fields,this.basicInfo,this.detailForm.basicForm);
                        this.getFieldValue(p,fields,this.contractInfo,this.detailForm.contractForm);
                        this.getFieldValue(p,fields,this.familyInfo,this.detailForm.familyForm);
                    }
                    this.detailForm.basicForm.versionLog=this.currentVersion.versionLog;
                    
                    this.detailForm.basicForm.managerAgency=fields.managerAgency;
                    this.detailForm.basicForm.managerSeq=fields.managerSeq;
                    this.detailForm.basicForm.agencyCode=fields.managerAgency;//agencyCode要与managerAgency一致
                    this.detailForm.basicForm.positionSeq=fields.positionSeq;

                    this.familyMember=info.familyModel.map((member,index)=>{
                        return {index,...member};
                    });                   
                    this.seq=fields.seq;
                }

                this.queryVersions();
            }
        },
        async queryVersions(){
            let versionParam={
                action:"GET",
                type:"AGENT",
                seq:this.seq,
                pageSize:50,
                startPage:1,
            }
            // let {processingunit,businessunit}=this.$store.state.user.userInfo;
            // versionParam.company=processingunit?processingunit:'';
            // versionParam.channel=businessunit?businessunit:'';  

            let versions=await this.versionRequest(versionParam);
            if(versions&&versions.length>0){
                this.versions=versions;
            }
        },
        getFieldValue(pro,fields,arr,form){
            let index=arr.findIndex(x=>x.name==pro);
            if(index>-1){
                form[pro]=fields[pro];
            }
        },
        newVersion(){
            this.$confirm(this.$t("message.copyVersion"), this.$t("message.warning"), {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
              closeOnClickModal: false,
            })
            .then(() => {
                this.detailForm.basicForm.effectiveEndDate = util.data().defaultEndDate;
                this.newVersionStatus=true;                
            })
            .catch(() => {
                this.isSave=false;
            });
        },
        getFamilyMember(rows){
            this.familyMember=rows.map(row=>{
                let {index,...rest}={...row};
                return {participantSeq:null,name:this.detailForm.basicForm.agentCode,...rest};//name属性姑且为agentCode 
            });
        },
        async save(){
            this.isSave=true;         
            let valid=this.$refs['agentForm'].validate();

            if(valid){                
                try{
                    let paramModel=this.getFieldNewAgent();
                    let param={
                        action:'POST',
                        ...paramModel,
                    }

                    let res=await this.$caller.agent_insert(param);
                    if(res&&res.responseCode==='000'){
                        this.$alert(this.$t("message.saveSuccess"), this.$t("message.confirm"), {
                            confirmButtonText: "OK",
                        });
                        if(!this.seq){
                            this.seq=res.data;
                        }

                        //再获取一次agent data
                        let param={
                            action:"GET",
                            seq:this.seq,
                            isLast:'1',       
                        }
                        this.doDetail(param);
                        this.newVersionStatus = false;
                    }
                }catch(e){
                    console.log(e);
                }
            }
        },
        back(){
            this.$router.replace({name:'agent_maintain',});
        },
        doViewVersion(selectedVersion){
            let param={
                action:"GET",
                seq:this.seq,
                effectiveStartDate:selectedVersion.effectiveStartDate,    
                effectiveEndDate:selectedVersion.effectiveEndDate,              
            };
            this.doDetail(param);
            this.newVersionStatus = false;
        },
        async doRemoveVersion(selectedVersion){
            let {effectiveStartDate,effectiveEndDate}={...selectedVersion};
            let removeParam={
                action:'UPDATE',
                versionRequest:{
                    type:'ENTITY',
                    seq:this.seq,
                    effectiveStartDate,
                    effectiveEndDate,
                },
                versionModel:{
                    removeDate: util.getNowDate(),
                }
            };
            let res=await this.versionRequest(removeParam);
            if(res){
                let versionParam={
                    action:"GET",
                    type:"ENTITY",
                    seq:this.seq,
                    startPage: 1,
                    pageSize: 50,
                }
                let versions=await this.versionRequest(versionParam);
                if(versions&&versions.length>0){
                    this.versions=versions;
                }
            }
        },
        async versionRequest(param){
            let res=await this.$caller.version_query(param);
            if(res&&res.responseCode==="000"){
                return res.versionModel?res.versionModel:true;
            }else{
                return false;
            }
        },
        getFieldNewAgent(){
            let allFormProps={...this.detailForm.basicForm,...this.detailForm.contractForm,...this.detailForm.familyForm};
            let {agentCode,agentName,businessUnit,hireDate,versionLog,positionSeq,}={...this.detailForm.basicForm};
            let fields=[...this.basicInfo,...this.contractInfo,...this.familyInfo];

            let participantModel={seq:null,firstName:null,middleName:null,lastName:agentName,versionModel:{},};
            let positionModel={positionSeq,managerAgency:null,managerSeq:null,leaderCode:null,entityType:null,businessUnit,};
            let contractModel={participantSeq:null,name:agentCode,hireDate,};//name姑且等于agentCode
            let educationModel={participantSeq:null,name:agentCode,};//name姑且等于agentCode
            let familyModel=this.familyMember;

            if(this.seq){
                //versionModel,PositionModel 这2个的seq要带上
                this.currentVersion.versionLog=versionLog;
                participantModel.seq=this.seq;
                participantModel.versionModel={
                    ...this.currentVersion,
                    effectiveStartDate:allFormProps.effectiveStartDate,
                    effectiveEndDate:allFormProps.effectiveEndDate,
                };
                // positionModel.positionSeq=this.seq;
            }

            fields.forEach(field=>{
                let prop=field.name;
                let value=allFormProps[prop];
                if(field.model=='participantModel'){
                    participantModel[prop]=value;
                }
                if(field.model=='positionModel'){
                    positionModel[prop]=value;
                }
                if(field.model=='contractModel'){
                    contractModel[prop]=value;
                }
                if(field.model=='educationModel'){
                    educationModel[prop]=value;
                }
            });

            positionModel.managerAgency=allFormProps.managerAgency;
            positionModel.managerSeq=allFormProps.managerSeq;

            return {participantModel,positionModel,contractModel,educationModel,familyModel,};
        },
        goToDetail(data){
            let {id,recordType,leaderCode,isLeader}=data;
            this.defaultTab='1';
            let param={
                action:"GET",
                seq:!isLeader?id:null,
                isLast:'1',                
            };
            if(recordType=='AGT'||isLeader){
                param.agentCode=isLeader?leaderCode:null;
                this.doDetail(param);
            }
            if(recordType=='AGY'&&!isLeader){
                this.$router.replace({
                    name:'hierarchy_agency_detail',
                    query:{
                        seq:id,
                        isModify:this.isModify,
                    }
                });
            }
        },
    },
}
</script>
<style lang="scss">
.family-collapse{
    .el-collapse-item__header{
        border-bottom: 0px solid #f5e8e8;
        margin: 46px 0 12px;
        padding-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .el-icon-arrow-right:before{
        content:'\25BC';
        color: #6b6b6b;
    }
    .el-collapse-item__arrow.is-active{
        transform: rotate(180deg);
        transition-duration:0.6s;
    }
}

</style>
