<template>
  <div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
      <aia-form
        class="responsive-form"
        alias="agent_maintain">

        <template slot="scroll">
          <div>
            <gl-search :headerList="searchList"  @doSearch="doSearch" ref='glSearch'></gl-search>
          </div>
          <gl-object-table :data="tableData" ref="userTable">
            <el-table-column :label="$t(headerList[0].name)"  width="auto">
                <template slot-scope="scope">
                    <gl-link type="primary" @click="goToDetail(scope.row, scope.$index)">{{$t(scope.row.agentCode)}}</gl-link >
                </template>
            </el-table-column>

<!--            <el-table-column :label="$t('label.firstName')" width="auto" prop="firstName"></el-table-column>

            <el-table-column :label="$t('label.middleName')" width="auto" prop="middleName"></el-table-column>-->

            <el-table-column :label="$t(headerList[1].name)" width="auto" prop="lastName"></el-table-column>

            <el-table-column :label="$t(headerList[2].name)"  width="auto" prop="identificationNumb"></el-table-column>

            <el-table-column :label="$t(headerList[3].name)" width="auto" prop="agencyCode"></el-table-column>

            <el-table-column  :label="$t(headerList[4].name)" width="auto" prop="title"></el-table-column>
               
            <el-table-column :label="$t(headerList[5].name)" width="auto" prop="agentStatus"></el-table-column>

            <!--<el-table-column :label="$t(headerList[6].name)" width="auto" prop="agencyCode"></el-table-column>-->

            <el-table-column :label="$t(headerList[6].name)" width="auto" prop="hireDate"></el-table-column>

          </gl-object-table >

          
          <hierarchy-tree
               :dialogTableVisible = "dialogTableVisible"
                v-if="dialogTableVisible"
                @doCloseDialog="closeHierarchyTree"
                @doGoToDetail="doGoToDetail"
                >
          </hierarchy-tree> 
        </template>

        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :current-page.sync="currentPage" :changePage="changePage" :change-size="changeSize"></gl-page>
        </template>

        <template slot="buttons"> 
            <button class="btn-primary" @click.prevent="openHierarchyTree()">{{$t('label.hierarchyTree')}}</button>
            <button class="btn-primary" @click.prevent="add" v-if="isModify">{{$t('add')}}</button>
            <Add :headerList="headerList" :display="display" :form="form" @save="save" @close="close"/>
        </template> 

      </aia-form>
    </section>
  </div>
</template>
<script>
import Add from "../authority/Add";
import HierarchyTree from "../hierarchy/HierarchyTree";
export default {
    components:{
        Add,
        HierarchyTree,
    },
    data(){
        return{
            headerList:[
                {
                    code:'agentCode', 
                    name: 'label.agentCode',
                    type: "input",
                    required:true,
                    noDisplay:false,
                },
                {
                    code:'agentName', 
                    name: 'label.agentName',
                    type: "input",
                    required:true,
                    noDisplay:false,
                },
                {
                    code:'identificationNumb', 
                    name: 'label.identificationNumb',
                    type: "input",
                    required:true,
                    noDisplay:false,
                },
                {
                    code:'agencyCode', 
                    name: 'label.agencyCode',
                    type: "input",
                    select: "",
                    required:true,
                },
                {
                    code:'title', 
                    name: 'label.title',
                    type: "input",
                    required:true,
                },
                {
                    code:'agentStatus', 
                    name: 'label.agentStatus',
                    type: "select",
                    select: "other",
                    optionList: [
                        {code:'1',name:'Active'},
                        {code:'2',name:'Pending'},
                        {code:'3',name:'Terminate'},
                    ],
                    required:true,
                },       
                // {
                //     code:'agencyCode', 
                //     name: 'label.agencyCode',
                //     type: "select",
                //     select: "other",
                //     required:true,
                // },
                {
                    code:'hireDate', 
                    name: 'label.hireDate',
                    type: "date",
                    select: "other",
                    optionList: [],
                    required:true,
                    noDisplay:true,
                },
            ],
            tableData:[],
            total:0,     
            currentPage:1,
            pageSize:10,
            form:{},
            display:false,
            search:[],
            isModify:this.$checkPageModify(this.$route.name),
            dialogTableVisible: false,
        }
    },
    computed:{
        searchList(){
            return this.headerList.slice(0,4);
        }
    },
    async created(){
        await this.doSearch();
    },
    methods:{
        async doSearch(search=[],page=1) {
            this.search=search;
            let param={
                action:"GET",
                startPage: page,
                pageSize: this.pageSize,
                isLast:'1',
                removeDate:'2200-01-01',
            };

            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';
            param.channel=businessunit?businessunit:'';            

            search.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.code;
                    param[prop]=x.value;
                }
            });
            this.currentPage=page;
            let response=await this.$caller.agent_query(param);

            if(response.responseCode=="000"){
                let {agentModel,total}={...response};
                this.total=total;
                this.tableData=agentModel.map(x=>{
                    return {...x.participantModel,...x.positionModel};    
                });
            }
            else{
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });
                if(!this.$isEmpty(response.reasonCode)){
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },
        async changePage(page){
            this.currentPage=page;
            await this.doSearch(this.search,page);
        },
        async changeSize(size){
            this.pageSize=size;
            await this.doSearch(this.search,1);
        },
        add(){
            this.$router.replace({name:'agent_detail',query:{isModify:this.isModify,}});
        },
        save(form){
            this.form=form;
            this.display=false;
        },
        close(){
            this.display=false;
        },
        goToDetail(row,index){
            let {seq,agentCode}=row;
            this.$router.replace({
                name:'agent_detail',
                query:{
                    seq,
                    isModify:this.isModify,
                }
            });
        },

        openHierarchyTree(){
          this.dialogTableVisible = true;
        },
        closeHierarchyTree(){
           this.dialogTableVisible = false;
        },
        doGoToDetail(data){

            let {id,recordType,leaderCode,isLeader}=data;

            this.defaultTab='1';
            let param={
                action:"GET",
                seq:!isLeader?id:null,
                isLast:'1',     
            };

            if(recordType=='AGT'||isLeader){
                param.agentCode=isLeader?leaderCode:null;
                this.doDetail(param);
            }
            else if(recordType=='AGY'&&!isLeader){
                this.$router.replace({
                    name:'hierarchy_agency_detail',
                    query:{
                        seq:id,
                        isModify:this.isModify,
                    }
                });
            }
           this.dialogTableVisible = false;
        },
    }
}
</script>  