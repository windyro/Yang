<template>
    <div>
        <gl-button class="version-button" type="text" icon="el-icon-files" @click.prevent="displayDialog">{{$t('label.versionManagement')}}</gl-button>
        <gl-dialog ref="dialog" :dialogTableVisible="display" @doCloseDialog="closeDialog" class="import-dialog bt5">
            <template slot="dialog-content">
                 <gl-object-table :data="tableData">
                    <el-table-column :label="$t('label.effectiveStartDate')" width="auto" prop="effectiveStartDate"></el-table-column>

                    <el-table-column :label="$t('label.effectiveEndDate')"  width="auto" prop="effectiveEndDate"></el-table-column>

                    <el-table-column :label="$t('label.versionLog')"  width="auto" prop="versionLog"></el-table-column>

                    <el-table-column  :label="$t('label.lastUpdatedDate')" width="auto" prop="lastUpdatedDate"></el-table-column>
                    
                    <el-table-column :label="$t('label.removeDate')" width="auto" prop="removeDate"></el-table-column>
                    
                    <el-table-column :label="$t('label.operation')">
                        <template slot-scope="scope">
                            <gl-button type="text" @click="view(scope.row,scope.$index)">{{$t('label.view')}}</gl-button>
                            <gl-button type="text" @click="copy(scope.row,scope.$index)">{{$t('label.copy')}}</gl-button>
                            <gl-button type="text" @click="remove(scope.row,scope.$index)">{{$t('label.remove')}}</gl-button>
                        </template>
                    </el-table-column>
                 </gl-object-table>
            </template>
            <template slot="buttons">
                <button class="btn-secondary" @click.prevent="closeDialog">{{$t('close')}}</button>
            </template>
            <template>
                <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage"></gl-page>
            </template>
        </gl-dialog>
    </div>
</template>
<script>
export default {
    name:'Version',
    props:{
        tableData:{
            type:Array,
            default:()=>[],
        },
        total:{
            type:Number,
            default:0,
        },
    },
    data(){
        return{
            display:false,
            pageSize:10,
            changePage:1,
        };
    },
    methods:{
        displayDialog(){
            this.display=true;
        },
        closeDialog(){
            this.display=false;
        },
        view(){},
        copy(){},
        remove(){},
        currentPage(page){
            this.currentPage=page;
        },
    },
}
</script>
<style lang="scss">
.el-dialog{
    overflow:hidden;
}
.dialog-content{
    min-height: 200px;
    overflow: auto;
}
.version-button{
    position: absolute;
    right: 48px;
    i{
        margin-right: 5px;
    }
}
</style>