<template>
  <div class="loginPage">
    <!-- <iframe src="/static/pdf/sign.html" width="1200" height="600"></iframe> -->
    <div id="PageLogin">
      <div class="logo text-center"></div>
      <p class="h3">Login To Glory</p>
      <aia-el-form v-model="loginData" alias="LoginForm">
        <el-form-item >
          <label class="form-label margin-bottom-xxs p3 bt4 text-left label-default">USERID</label>
          <aia-input class="margin-bottom-xs" type="text" placeholder v-model="loginData.userId" @keyup.enter.native="doLogin()"></aia-input>
        </el-form-item>

        <el-form-item >
          <label class="form-label margin-bottom-xxs p3 bt4 text-left label-default">PASSWORD</label>
          <aia-input class="margin-bottom-xs" type="password" v-model="loginData.password" @keyup.enter.native="doLogin()"></aia-input>
          <!--p><a class="lk1" :href="forgetLink" target="blank">Forgot your password?</a></p-->
          <br/>
          <br/>
        </el-form-item>
        <!--
          http://10.115.26.30:8082/caps/password/forgetpassword
           <el-form-item>
          <aia-select :value="loginData.LoginTo" class="primary-select margin-bottom-xxs btn-stretch" id="editable-field-dropdown">
            <el-option disabled value selected data-option-placeholder>Select to login glory/iCare</el-option>
            <el-option value="glory">glory</el-option>
            <el-option value="iCare">iCare</el-option>
          </aia-select>
        </el-form-item>-->
        <aia-button
          class="btn btn-primary btn-stretch margin-top-l"
          type="button"
          @click="doLogin"
        >login</aia-button>

      </aia-el-form>

      <el-dialog
        :visible.sync="isShow"
        append-to-body
        title="END USER LICENCE"
        center
        class="user-License"
        :close-on-click-modal="false"
        :show-close="false"
      >
        <el-scrollbar wrap-class="rules-con">
          <div class="padding-left-m padding-right-m" v-html="licenseMsg"></div>
        </el-scrollbar>
        <div>
          <aia-button
            class="btn btn-primary margin-top-l"
            type="button"
            @click="agreeLicense"
          >I agree</aia-button>
          <aia-button
            class="btn margin-top-l disagreeBtn pull-right"
            type="button"
            @click="disagreeLicense"
          >Disagree</aia-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import util from "@/models/Utility";
import pageConfig from "@/models/pageConfig";
// my temp test for mock data & real server data, must be deleted later.
// function mytemptest(owner) {
//   var param = { agentCode: "A01110" };
//     owner.$apiCaller_agent.contact_list(owner, param, function(result) {
//     alert("contact_list -------- result = " + JSON.stringify(result));
//   });
// };


export default {
  data() {
    return {
      loginData: {
        // userId: "B00165",
        // userId: "A01110",
        // userId:"Seasion",
        // password: "W3lcom38@",
        userId: "",
        password: "",
        idNo: "",
      },
      isShow: false,
      disableOtherToken: "0",
      licenseMsg: this.$t("message.licenseMes"),
      forgetLink:window.globalConfig.forgetLink,
    };
  },
  created() { 
    if(this.$cookies.get("token")){
      this.logout();
    }
  },
  methods: {
    agreeLicense: function() {
      let _this = this;
      let param = {
        agentCode: this.loginData.userId,
        agreeLicense: "1",
      };
      this.$caller
        .agent_agree_license_save(param)
        .then(res => {
          if (0 == res.errorCode) {
            this.isShow = false;
            this.$nextTick(() => {
              _this.$router.replace({ name: "Home" });
            });
          }
        })
        .catch(() => {});
    },
    disagreeLicense: function() {
      let param = {
        agentCode: this.loginData.userId,
        agreeLicense: "0",
      };
      this.$caller
        .agent_agree_license_save(param)
        .then(res => {
          if (0 == res.errorCode) {
              this.$cookies.remove("token");
              this.$cookies.remove("sequence");
              this.$cookies.remove("userId");
              this.$router.replace("/");
              this.isShow = false;
          }
        })
        .catch(() => {});
   
    },
    doLogin: async function() {
      let _this = this;
      if (this.loginData.userId == "" || this.loginData.password == "") {
        this.$alert("Please input USERID and PASSWORD", "Error", {
          confirmButtonText: "OK",
        });
        return;
      }
      // var param = {
      //   userId: this.loginData.userId,
      //   password: util.encryptData(this.loginData.password),
      //   idNo: this.loginData.idNo,
      //   disableOtherToken: this.disableOtherToken,
      // };


      let param={
        loginId:this.loginData.userId,
        password: util.encryptData(this.loginData.password),
        //password: this.loginData.password,
      }
      console.log(util.encryptData(this.loginData.password));

      let loginRes=await this.$caller.login_validate(param);
      if(loginRes.responseCode==="000"){
        let {jwtToken,user}={...loginRes.token};
        this.$store.state.user.userInfo=user;
        _this.$cookies.set('token',jwtToken);    
        sessionStorage.setItem('token',jwtToken);
        _this.$initGeneralInformation(_this);
        _this.$router.replace({ name: "Home" });        

        let rolelist=user.rolelist;
        let isAdmin=rolelist.some(role=>role.roleName===pageConfig.adminRole);
        this.$store.state.user.isAdmin=isAdmin;
        this.$store.state.user.authority=this.configAuthority(rolelist);
        sessionStorage.setItem("store",JSON.stringify(this.$store.state));
      }

      // this.$caller.agent_token_get(param).then(res => {
      //    this.loginData.idNo ="";
      //   if (0 == res.errorCode) {
      //     if (res.result.registeredAgent == "1" && res.result.token != "") {
	    //       this.$cookies.set("userId", res.result.agentCode);
      //       this.$cookies.set("token", res.result.token);
      //       this.$cookies.set("sequence", 0);
      //       this.$store.commit("loginStatus", res.result);
      //       sessionStorage.setItem("token", res.result.token);
      //       if (res.result.agreeLicense == "0") {
      //         this.isShow = true;
      //       } else {
      //         this.$nextTick(() => {
      //           _this.$router.replace({ name: "Home" });
      //         });
      //       }
      //     } else if (res.result.registeredAgent == "0") {
      //       this.$prompt("ID Number", "", {
      //         confirmButtonText: "OK",
      //         cancelButtonText: "Cancel",
      //         inputPlaceholder: "Please input ID Number"
      //       })
      //         .then(({ value }) => {
      //           _this.loginData.idNo = value;
      //           _this.doLogin();
      //         })
      //         .catch(() => {});
      //     }
      //     if (res.result.hasOtherToken == 1) {
      //       this.$confirm(this.$t("message.reLoginConfirm"), "Warning", {
      //         confirmButtonText: "OK",
      //         cancelButtonText: "Cancel",
      //         type: "Error",
      //          closeOnClickModal:false,
      //       })
      //         .then(() => {
      //           _this.disableOtherToken = 1;
      //           _this.doLogin();
      //         })
      //         .catch(() => {});
      //     }
      //   } else if (104 == res.errorCode) {
      //     this.$alert(this.$t("message.userIdNotExist"), "Attention", {
      //       confirmButtonText: "OK"
      //     });
      //     return;
      //   } else if (105 == res.errorCode) {
      //     this.$alert(this.$t("message.userIdLock"), "Attention", {
      //       confirmButtonText: "OK"
      //     });
      //     return;
      //   } else if (106 == res.errorCode||109 == res.errorCode) {
      //     this.$alert(this.$t("message.userInputError"), "Attention", {
      //       confirmButtonText: "OK"
      //     });
      //     return;
      //   }else if (107 == res.errorCode||108 == res.errorCode) {
      //     this.$alert(this.$t("message.noAuthor"), "Attention", {
      //       confirmButtonText: "OK"
      //     });
      //     return;
      //   }else if (1 == res.errorCode) {
      //     this.$alert(this.$t("message.needLoginInfo"), "Attention", {
      //       confirmButtonText: "OK"
      //     });
      //     return;
      //   }
      // });
      // @import "../assets/css/message-box.css";}
    },
    logout() {
      // let agentcode = this.$store.state.agent.agentCode;
      // if (!this.$isEmpty(agentcode)) {
      //   var param = {
      //     "userId": agentcode,
      //   };
        // this.$caller.agent_token_disable(param).then(res => {
          this.$cookies.remove("token");
          // this.$cookies.remove("sequence");
          // this.$cookies.remove("userId");
          sessionStorage.removeItem("token");
        // });
        this.$cookies.remove("token");
        this.$router.replace("/");
      // }
    },
    configAuthority(rolelist){
      let tempAuth=[];
      rolelist.forEach(role=>{
        let auth=role.authority.split(",");
        tempAuth=tempAuth.concat(auth);
        tempAuth=[...new Set(tempAuth)];
      });

      let authPages=[];
      tempAuth.forEach(auth=>{
        let page=pageConfig.pages.find(p=>auth.includes(p.name));
        if(page){
          let index=auth.indexOf('(');
          let radioValue=auth.substring(index);

          let isExistIndex=authPages.findIndex(x=>x.code==page.code);
          if(isExistIndex>-1){
            let existAuth=authPages[isExistIndex].radioValue;
            let existAuthNum=pageConfig.returnAuthNumber(existAuth); 
            let newAuthNum=pageConfig.returnAuthNumber(radioValue);
            if(newAuthNum>existAuthNum){
              authPages[isExistIndex].radioValue=radioValue;
            }
          }else{
            authPages.push({...page,radioValue,});
          }
        }
      });

      return authPages;
    },
  },
};
</script>

<style lang="scss">
@import "../components/element/dialog/dialog.css";
@import '@/assets/css/variable.scss';
.user-License {
  .el-dialog {
    margin-top: 10vh;
    min-width:250px;
    .el-dialog__body{
      padding-left:0;
      padding-right:0;
      padding-bottom: 0; 
    }
    &.el-dialog--center {
      .el-dialog__header {
        font: normal 20px "AIATitle", "Calibri", sans-serif;
        background-color: #42403d;
        color: #ffffff;
      }
      .el-dialog__title {
        color: #ffffff;
      }
    }
    .rules-con {
      height: 50vh;
      overflow: auto;
    }
    .el-button {
      padding-left:0;
      padding-right:0;
      height:36px;
      line-height: 36px;
      width: 50%;
      text-transform: none;
      min-width:50px;
    }
    .disagreeBtn {
      background-color: #596e82;
    }
  }
}
.el-message-box__wrapper {
  position: absolute;
  top: 0px !important;

  .el-message-box__btns {
    text-align: center;
    .el-button {
      display: inline-block;
    }
  }
  .el-icon-warning {
    font-size: 25px;
    display: inline-block;
    color: #ef9333e4;
  }
  .el-message-box__input {
    text-align: center;
    .el-input {
      width: 90%;
    }
  }
}
.loginPage {
  width: 100%;
  height: 100vh;
  //background: url(../assets/images/loginBg.jpeg) center 30% no-repeat;
  background: url(../assets/images/bg.png) center 30% no-repeat;
  background-size: cover;
  /* background-position:  */
  .el-button span{
    width:100%;
    line-height: 30px;
  }
  @include phone {
    div#PageLogin {
      width: 300px;
      position: fixed;
      margin: 0 auto;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%)
    }
  }
}

#PageLogin {
  width: 350px;
  position: absolute;
  left: 100%;
  top: calc(50% - 40px);
  top: -webkit-calc(50% - 0px);
  transform: translate(-150%, -50%);
  padding: 40px;
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.7);
  .logo {
    height: 70px;
    background: url(../assets/images/logo.png) center center no-repeat;
    background-size: auto 100%;
  }
  .h3 {
    text-align: center;
    text-transform: none;
    margin-bottom: 30px;
    margin-top: 20px;
  }
}
.label-default {
  width: 250px;
  margin: 8px auto;
}
.lk1,.lk1:visited {
  font-size: 16px;
  line-height: 14px;
  color: #22A8DA;
}
</style>
