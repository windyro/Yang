<template>
  <div v-show="display">
    <h1 id="detail-h1">hide</h1>
    <section>
      <aia-form
        class="responsive-form"
        alias="result_transaction">
        <template slot="scroll">
            <el-collapse accordion :value="'1'">
                <el-collapse-item class="detail-collapse" name="1">
                    <template slot="title">
                        <h6>{{$t('label.TRANSACTION_FIELD')}}</h6>
                    </template>

                    <el-row :gutter="36">
                        <el-col>
                            <h6>{{$t("label.STANDARD_FIELD")}}:</h6>
                        </el-col>
                        <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6" v-for="item in standardList" :key="item.name" :label="$t(item.name)">
                            <el-form-item :label="$t('label.'+item.name)" class="form-item">
                                <el-input v-model="item.value" :disabled="true"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="36">
                        <el-col>
                            <h6>{{$t("label.CUSTOMIZED_FIELD")}}:</h6>
                        </el-col>
                        <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6" v-for="item in customizedList" :key="item.name">
                            <el-form-item :label="item.name" class="form-item">
                                <el-input v-model="item.value" :disabled="true"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-collapse-item>
            </el-collapse>
        </template>
      </aia-form>
    </section>
  </div>
</template>
<script>
export default {
    name:'TransactionDetail',
    props:{
        current:{
            type:Object,
            default:null,
        },
    },
    data(){
        return {
            standardList:[],
            customizedList:[],
            display:false,
        }
    },
    watch:{
        async current(newVal,oldVal){
            if(newVal!==oldVal&&newVal!==null){
                await this.queryDetail();
                this.$nextTick(()=>{
                setTimeout(()=>{
                    var wrap=document.querySelector('#detail-h1');
                    wrap.scrollIntoView({
                        block: 'start',
                        behavior: 'smooth',
                    });
                },300);
                })
            }else if(!newVal){
                this.display=false;
            }
        },
    },
    methods:{
        async queryDetail(){
            let {compensationDate,value,productCat,...params}={...this.current};
            let param={
                action:"POST",
                ...params,
            }
            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';
            param.channel=businessunit?businessunit:'';

            let response=await this.$caller.transaction_detail(param);
            if(response.responseCode==='000'&&response.transDetailModel){
                let {genericFields,dataSource,transactionSeq,...standardList}=response.transDetailModel[0];
                this.standardList=[];
                for(let prop in standardList){
                    let item={name:prop,value:standardList[prop]};
                    this.standardList.push(item);
                }
                this.customizedList=genericFields;
                this.display=true;
            } else{
                this.display=false;
            }          
        },
    },
}
</script>
<style lang="scss">
#detail-h1{
    height:46px;
    visibility:hidden;
}
.detail-collapse{
    h6{
        color: #828282;
        margin:10px 0;
    }
    .el-collapse-item__header{
        border-bottom: 1px solid #f5e8e8;
        margin: 0 0 12px;
        padding-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .el-icon-arrow-right:before{
        content:'\25BC';
        color: #6b6b6b;
    }
    .el-collapse-item__arrow.is-active{
        transform: rotate(180deg);
        transition-duration:0.6s;
    }
}

.form-item{
    .el-form-item__label{
        margin:10px 0;
        font-family: "AIABody", Arial, "Helvetica Neue", Helvetica, sans-serif;
        font-size: 14px;
        line-height: 16px;
    }    
    .el-input.is-disabled .el-input__inner{
        background-color: #FAF9F3;
        border-color: #c3c2b9;
        color: #828282;
        cursor: auto;
    }
}
</style>