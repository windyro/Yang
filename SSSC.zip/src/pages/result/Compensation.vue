<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form class="responsive-form" alias="result_compensation">

            <template slot="scroll">
                <div>
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch'></gl-search>
                </div>
                <gl-object-table :data="tableData">
                    <el-table-column :label="$t('label.company')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.company" :valueData="scope.row.company" :optionList="companies">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.channel')" width="auto" prop="channel">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.channel" :valueData="scope.row.channel" :optionList="channels">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.compensationName')" width="auto" prop="compensationName"></el-table-column>

                    <el-table-column :label="$t('label.payee')" width="auto" prop="payee"></el-table-column>

                    <el-table-column :label="$t('label.managerAgency')" width="auto" prop="managerAgency"></el-table-column>

                    <el-table-column :label="$t('label.title')" width="auto" prop="title"></el-table-column>

                    <el-table-column :label="$t('label.period')" width="auto" prop="period"></el-table-column>

                    <!--<el-table-column :label="$t('label.earningCode')" width="auto" prop="earningCode"></el-table-column>-->

                    <el-table-column :label="$t('label.isHeld')" width="auto" prop="isHeld">
                    <template slot-scope="scope">
                        <span>{{scope.row.isHeld==="0"?"No":"Yes"}}</span>
                    </template>
                    </el-table-column>
                    
                    <el-table-column :label="$t('label.value')" width="auto" prop="value">
                    <template slot-scope="scope">
                        <gl-link type="primary" @click="toTransaction(scope.row, scope.$index)">{{$toThousandsNoZero(scope.row.value)}}</gl-link >
                    </template>
                    </el-table-column>
          </gl-object-table >
        </template>
        <template slot="buttons"> 
           <Export :allData="allData" name="Compensation Result" :fieldsList="headerList" @export="exportXlsx"/>
        </template> 
        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage" :change-size="changeSize"></gl-page>
        </template>
      </aia-form>
    </section>
</div>
</template>

<script>
import Export from './Export'

export default {
    components: {
        Export,
    },
    data() {
        return {
            headerList: [{
                    code: 'Compensation Name',
                    name: 'label.compensationName',
                    type: "input",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'Payee',
                    name: 'label.payee',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'StartPeriod',
                    name: 'label.startPeriod',
                    type: "month",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'EndPeriod',
                    name: 'label.endPeriod',
                    type: "month",
                    select: "other",
                    optionList: [],
                },
            ],
            tableData: [],
            total: 0,
            pageSize: 10,
            currentPage: 1,
            searchList: [],
            channels: this.$getGeneralList("channel", this),
            companies: this.$getGeneralList("company", this),
            citys: this.$getGeneralList("city", this),
            allData: [],
            isTrace:false,
        }
    },
    async created() {
        const {
            paymentSeq
        } = this.$route.query
        if (paymentSeq) {
            this.isTrace=true;
        }
        await this.doSearch(this.searchList);
    },
    methods:{
        async changePage(page){
            this.currentPage=page;
            await this.doSearch(this.searchList,true,page);
        },
        async changeSize(size){
            this.pageSize=size;
            await this.doSearch(this.searchList,true,1);
        },      
        async doSearch(searchList=[],firstClick = true,page=1,isAll=false){
            this.searchList=searchList;
            this.currentPage=page;

            let param;
            let response;

            let tempParam={};
            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            tempParam.company=processingunit?processingunit:'';
            tempParam.channel=businessunit?businessunit:'';

            if(isAll){
                param={
                    action:"POST",
                    ...tempParam,
                }
            }
            if(this.isTrace&&searchList.length==0){
                if(!isAll){
                    param={
                        action:"POST",
                        startPage:page,
                        pageSize:this.pageSize,
                        ...tempParam,
                    }
                }
                param.paymentSeq=this.$route.query.paymentSeq;
                response=await this.$caller.payment_trace(param);
            }else{
                if(!isAll){
                    param={
                        action:"POST",
                        startPage:page,
                        pageSize:this.pageSize,
                        ...tempParam,
                    }
                }
                searchList.forEach(x => {
                    if (!this.$isEmpty(x.value)) {
                        let prop = x.headerSelected.name.substring(6);
                        param[prop] = x.value;
                    }
                });

                response = await this.$caller.compensation_query(param);
            }

            if (response.responseCode === "000") {
                let {
                    transModel,
                    total
                } = {
                    ...response
                };


                if (isAll) {
                    this.allData = transModel;
                } else {
                    this.tableData = transModel;
                }
                this.total = total;
            } else {
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });

                if (!this.$isEmpty(response.reasonCode)) {
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },
        toTransaction(row, index) {
            this.$router.push({
                name: 'result_transaction',
                query: {
                    depositSeq: row.depositSeq,
                },
            });
        },
        async exportXlsx() {
            await this.doSearch(this.searchList, true, 1, true);
        },
    },
}
</script>
