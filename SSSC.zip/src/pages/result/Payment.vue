<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form class="responsive-form" alias="result_payment">

            <template slot="scroll">
                <div>
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch'></gl-search>
                </div>
                <gl-object-table :data="tableData" ref="paymentTable">
                    <el-table-column :label="$t('label.company')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.company" :valueData="scope.row.company" :optionList="companies">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.channel')" width="auto" prop="channel">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.channel" :valueData="scope.row.channel" :optionList="channels">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.payee')" width="auto" prop="payee"></el-table-column>

                    <el-table-column :label="$t('label.payeeAgency')" width="auto" prop="payeeAgency"></el-table-column>

                    <el-table-column :label="$t('label.payeeTitle')" width="auto" prop="payeeTitle"></el-table-column>

                    <el-table-column :label="$t('label.period')" width="auto" prop="period"></el-table-column>

                    <!--<el-table-column :label="$t('label.earningCode')" width="auto" prop="earningCode"></el-table-column>

                    <el-table-column :label="$t('label.earningGroup')" width="auto" prop="earningGroup"></el-table-column>-->

                    <el-table-column :label="$t('label.status')" width="auto" prop="status"></el-table-column>

                    <el-table-column :label="$t('label.postDate')" width="auto" prop="postDate">
                        <template slot-scope="scope">
                            <span>{{scope.row.postDate|convertDate}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.paymentMethod')" width="auto" prop="paymentMethod"></el-table-column>

                    <el-table-column :label="$t('label.bank')" width="auto" prop="bank"></el-table-column>

                    <el-table-column :label="$t('label.bankAccount')" width="auto" prop="bankAccount"></el-table-column>

                    <el-table-column :label="$t('label.value')" width="auto" prop="value">
                        <template slot-scope="scope">
                            <gl-link type="primary" @click="toCompensation(scope.row, scope.$index)">{{$toThousandsNoZero(scope.row.value)}}</gl-link>
                        </template>
                    </el-table-column>
                </gl-object-table>
            </template>
            <template slot="buttons"> 
                <Export :allData="allData" name="Payment Result" :fieldsList="headerList" @export="exportXlsx" />
            </template>
            <template slot="pages">
                <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage" :change-size="changeSize"></gl-page>
            </template>
        </aia-form>
    </section>
</div>
</template>

<script>
import Export from './Export'

export default {
    components: {
        Export,
    },
    data() {
        return {
            headerList: [
                {
                    code: 'StartPeriod',
                    name: 'label.startPeriod',
                    type: "month",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'EndPeriod',
                    name: 'label.endPeriod',
                    type: "month",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'Payee',
                    name: 'label.payee',
                    type: "input",
                    select: "",
                    optionList: [],
                },
            ],
            tableData: [],
            total: 0,
            pageSize: 10,
            searchList: [],
            currentPage: 1,
            channels: this.$getGeneralList("channel", this),
            companies: this.$getGeneralList("company", this),
            citys: this.$getGeneralList("city", this),
            allData: [],
        }
    },
    async created() {
        await this.doSearch();
    },
    methods: {
        async changePage(page) {
            this.currentPage = page;
            await this.doSearch(this.searchList, true, page);
        },
        async changeSize(size){
            this.pageSize=size;
            await this.doSearch(this.searchList,true,1);
        },
        async doSearch(searchList = [], firstClick = true, page = 1, isAll = false) {
            this.currentPage = page;
            this.searchList = searchList;

            let param;
            if (isAll) {
                param = {
                    action: "POST",
                }
            } else {
                param = {
                    action: "POST",
                    startPage: page,
                    pageSize: this.pageSize,
                }
            }

            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';
            param.channel=businessunit?businessunit:'';


            searchList.forEach(x => {
                if (!this.$isEmpty(x.value)) {
                    let prop = x.headerSelected.name.substring(6);
                    param[prop] = x.value;
                }
            })

            let response = await this.$caller.payment_query(param);
            if (response.responseCode === "000") {
                let {
                    transModel,
                    total
                } = {
                    ...response
                };
                this.total = total;

                transModel.forEach(x=>{
                    if(x.paymentMethod=='DC'){
                        x.paymentMethod='Direct Credit';
                    }
                    if(x.paymentMethod=='CQ'){
                        x.paymentMethod='Cheque';
                    }
                })

                if (isAll) {
                    this.allData = transModel;
                } else {
                    this.tableData = transModel;
                }
            } else {
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });

                if (!this.$isEmpty(response.reasonCode)) {
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },
        toCompensation(row, index) {
            this.$router.push({
                name: 'result_compensation',
                query: {
                    paymentSeq: row.paymentSeq,
                },
            })
        },
        async exportXlsx() {
            await this.doSearch(this.searchList, true, 1, true);
        },
    },
}
</script>
