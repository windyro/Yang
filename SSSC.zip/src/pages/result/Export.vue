<template>
    <!--<download-excel :data="allData" :name="name" :fields="fields">
        <el-button class="btn-primary">{{$t('export')}}</el-button>
    </download-excel>-->

    <button class="btn-primary" @click.prevent="exportFile">{{$t('export')}}</button>
</template>
<script>
import FileSaver from 'file-saver'
import XLSX from 'xlsx'

export default {
    props:{
        allData:{
            type:Array,
            default:()=>[],
        },
        fieldsList:{
            type:Array,
            default:[],
        },
        name:{
            type:String,
            default:'empty.xlsx',
        },
    },
    name:'Export',
    watch:{
        allData(val){
            this.exportXlsx();
        }
    },
    methods:{
        exportFile(){
            this.$emit('export');
        },
        exportXlsx(){
            if(this.allData.length>=10000){
                let _this=this;
                this.$alert(this.$t("message.mostExport"), "Attention", {confirmButtonText: "OK",}).then(()=>{
                    _this.createXlsx();
                });
            }else{
                this.createXlsx();
            }
        },
        createXlsx(){    
            try {
                const wb = { SheetNames: ['Sheet1'], Sheets: {}, Props: {} };
                wb.Sheets['Sheet1'] = XLSX.utils.json_to_sheet(this.convertCode());//通过json_to_sheet转成单页(Sheet)数据
                const wbout = XLSX.write(wb, { bookType: 'xlsx', bookSST: true, type: 'array' });        
                FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream' }), this.name+'.xlsx');
                return wbout;
            } catch (e) {
                console.log('e:',e)
                if (typeof console !== 'undefined'){
                    console.log(e, wbout);
                }
            }
        },        
        convertCode(){
            if(this.allData.length>0){
                let exportData=this.allData.map(x=>{
                    return {...x};
                })
                this.fieldsList.forEach(x=>{
                    if(x.optionList.length>0){
                        let prop=x.name.substring(6);
                        exportData.forEach(item=>{
                            let temp=item[prop];
                            item[prop]=x.optionList.find(p=>p.code===temp).name;
                        })
                    }
                })
                return exportData;
            }
        },
    },
}
</script>      