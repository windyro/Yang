<template>
  <div id="content-wrap" class="content-wrap" @click.prevent="doBuble">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
      <aia-form
        class="responsive-form"
        alias="result_transaction">

        <template slot="scroll">
          <div>
            <gl-search :headerList="headerList"  @doSearch="doSearch" ref='glSearch'></gl-search>
          </div>
          <gl-object-table class="transaction-table" :data="tableData" :isHighLight="true" @currentChange="handleCurrent"> 
               
            <el-table-column :label="$t('label.compensationDate')" width="auto" prop="compensationDate"></el-table-column>

            <el-table-column :label="$t(headerList[0].name)" width="auto" prop="eventType"></el-table-column>

            <el-table-column :label="$t('label.value')" width="auto" prop="value">
              <template slot-scope="scope">
                <span>{{$toThousandsNoZero(scope.row.value)}}</span>
              </template>
            </el-table-column>
                           
            <el-table-column :label="$t(headerList[1].name)" width="auto" prop="commAgent"></el-table-column>

            <el-table-column :label="$t(headerList[2].name)" width="auto" prop="commAgency"></el-table-column>
            
            <el-table-column :label="$t(headerList[3].name)"  width="auto" prop="policyNumber"></el-table-column>

            <el-table-column :label="$t('label.productCat')" width="auto" prop="productCat"></el-table-column>
          </gl-object-table>

          <TransactionDetail :current="current"/>
        </template>
        <template slot="buttons"> 
           <Export :allData="allData" name="Transaction Result" :fieldsList="headerList" @export="exportXlsx"/>
        </template> 
        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage" :change-size="changeSize"></gl-page>
        </template>
      </aia-form>
    </section>
  </div>
</template>
<script>
import Export from './Export'
import TransactionDetail from './TransactionDetail'

export default {
  components:{
    Export,
    TransactionDetail,
  },
  data(){
    return {
      headerList:[
          {
            code:'EvenType',
            name: 'label.eventType',
            type: "input",
            select: "",
            optionList: [],
          },
          {
            code:'CommAgent', 
            name: 'label.commAgent',
            type: "input",
            select: "",
            optionList: [],
          },          
          {
            code:'CommAgency', 
            name: 'label.commAgency',
            type: "input",
            select: "",
            optionList: [],
          },
          {
            code:'PolicyNumber', 
            name: 'label.policyNumber',
            type: "input",
            select: "",
            optionList: [],
          },    
          {
            code:'CompensationStartDate', 
            name: 'label.compStartDate',
            type: "date",
            select: "other",
            optionList: [],
          },
          {
            code:'CompensationEndDate', 
            name: 'label.compEndDate',
            type: "date",
            select: "other",
            optionList: [],
          },
      ],
      tableData:[],
      total:0,
      pageSize:10,
      currentPage:1,
      searchList:[],
      current:null,
      citys:this.$getGeneralList("city", this),
      allData:[],
      isTrace:false,
    }
  },
  async created(){
    const {depositSeq}=this.$route.query;
    if(depositSeq){
      this.isTrace=true;
    }
    await this.doSearch(this.searchList);
  },
  methods:{
    changePage(page){
      this.current=null;
      this.currentPage=page;
      this.doSearch(this.searchList,true,page);
    },
    async changeSize(size){
        this.pageSize=size;
        await this.doSearch(this.searchList,true,1);
    },
    async doSearch(searchList=[],firstClick = true,page=1,isAll=false){
      this.searchList=searchList;
      this.currentPage=page;

      let param={};
      let response;

      let {processingunit,businessunit}=this.$store.state.user.userInfo;
      let attachParam={};
      attachParam.company=processingunit?processingunit:'';
      attachParam.channel=businessunit?businessunit:'';

      if(isAll){
        param={
          action:"POST",
          ...attachParam,
        }
      }
      if(this.isTrace&&searchList.length==0){
        if(!isAll){
          param={
              action:"POST",
              startPage:page,
              pageSize:this.pageSize,
              depositSeq:String(this.$route.query.depositSeq),
              ...attachParam,
          }
          response=await this.$caller.compensation_trace(param);
        }else{              
          param.depositSeq=this.$route.query.depositSeq;         

          response=await this.$caller.transaction_trace_detail(param);
        }
      }else{
        searchList.forEach(x => {
            if (!this.$isEmpty(x.value)) {
                let prop = x.headerSelected.name.substring(6);
                param[prop] = x.value;
            }
        });

        if(!isAll){
          param={
            action:"POST",
            startPage:page,
            pageSize:this.pageSize,
            ...param,
            ...attachParam,
          }
          // console.log('a',param);

          response=await this.$caller.transaction_query(param);
        }else{
          response=await this.$caller.transaction_detail(param);
        }
      }

      if(response.responseCode==="000"){
        if(isAll){
          let {transDetailModel,total}={...response};
          this.total=total;
          return transDetailModel;          
        }else{
          let {transModel,total}={...response};
          this.total=total;
          this.tableData=transModel;          
        }
      }else{
        this.$alert("Response Code: " + response.responseCode, "Attention", {
            confirmButtonText: "OK",
        });

        if(!this.$isEmpty(response.reasonCode)){
            this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                confirmButtonText: "OK",
            });
        }        
      }
    },
    handleCurrent(current){
      this.current=current;
    },
    doBuble(e){
      e.stopPropagation();
    },
    async exportXlsx(){
      let temp=await this.doSearch(this.searchList,true,1,true);
      this.allData=temp.map(item=>{
        let {genericFields,...restFields}={...item};
        let newItem={...restFields,};
        if(genericFields instanceof Array){
          genericFields.forEach(field=>{
            let code=field.name.replace(/\s*/g, '');
            newItem[code]=field.value;
          });
        }
        return newItem;
      });
    },
  },
}
</script>
<style lang="scss">
.transaction-table{
  margin-bottom:46px;
}
</style>