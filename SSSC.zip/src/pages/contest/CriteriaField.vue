<template>
    <div>
        <el-row :gutter="24" v-for="(item,index) in form" :key="item.name">
            <el-col :xs="24" :sm="11" :md="8" :lg="6" :xl="6">
                <el-form-item class="form-item" :rules="item.required?$formValidator.rules.required:[]" :prop="formName[index].name">
                    <gl-select 
                        :edit="true" 
                        v-model="item.name" 
                        :valueData="item.name"
                        :optionList="nameList"
                        @change="changeOperator(item)"> 
                    </gl-select>
                </el-form-item>
            </el-col>
            <el-col :xs="24" :sm="11" :md="4" :lg="4" :xl="4">
                <gl-select type="comparisonName" 
                    :edit="true" 
                    v-if="item.type"
                    v-model="item.ruleTemplateId" 
                    :valueData="item.ruleTemplateId"
                    :optionList="comparisonNameList"
                    @change="changeComparison(item)"> 
                </gl-select>
            </el-col>
            <el-col :xs="24" :sm="11" :md="10" :lg="8" :xl="8">
                <el-input v-if="item.type=='input'" v-model="item.criteriaValue" ></el-input>
                <gl-select v-if="item.type=='select'" 
                    :edit="true" 
                    v-model="item.criteriaValue" 
                    :valueData="item.criteriaValue"                    
                    :optionList="getOptionList(item)">
                </gl-select>      
                <el-date-picker v-if="item.type=='date'&&item.ruleTemplateId!=='T_BETWEEN'" 
                    value-format="yyyy-MM-dd"                    
                    v-model="item.criteriaValue"
                    type="date">
                </el-date-picker>   
            </el-col>
            <el-col :xs="24" :sm="22" :md="10" :lg="8" :xl="8" v-if="item.type=='date'&&item.ruleTemplateId=='T_BETWEEN'">
                <div class="date-between">
                    <gl-date :rules="$formValidator.rules.required" v-model="item.startTimeValue" :value="item.startTimeValue" type="date" :endDateStr="item.endTimeValue" @change="getStartT(item.startTimeValue,index)"></gl-date>
                    <span class="between">-</span>
                    <gl-date :rules="$formValidator.rules.required" v-model="item.endTimeValue" :value="item.endTimeValue" type="date" :beginDateStr="item.startTimeValue" @change="getEndT(item.endTimeValue,index)"></gl-date>
                </div>              
            </el-col>
    
            <el-col :xs="24" :sm="1" :md="1" :lg="1" style="padding-right: 2px; padding-left: 2px; width: 35px;">
                <span class="iconfont cursor-p"  v-if="index==0" id="addBtn" @click="addCondition">&#xe612;</span>
                <span class="iconfont cursor-p"  v-if="index!=0" id="delBtn" @click="delCondition(index)">&#xe651;</span>
            </el-col>            
        </el-row>        
    </div>

</template>
<script>
import util from "@/models/Utility";

export default {
    props:{
        form:{
            type:Array,
            default:[],    
        },
        formName:{
            type:String,
            default:'form',
        },
        nameList:{
            type:Array,
            default:[],               
        },
    },
    data(){
        return{
            comparisonNameList: util.data().comparisonNameList,
        }
    },
    watch:{
        "form":{
            handler(val){
                val.forEach(x=>{
                    if(x){
                        if(x.name){
                            let nameItem=this.nameList.find(name=>name.code==x.name);
                            if(nameItem){
                                nameItem.disabled=true;
                                x.type=nameItem.type;
                            }                        
                        }

                        if(x.ruleTemplateId=='T_BETWEEN'&&x.criteriaValue){
                            let timeArr=x.criteriaValue.split(',');
                            
                            x.startTimeValue=timeArr[0];
                            x.endTimeValue=timeArr[1];
                        }                        
                    }

                });
            },
            immediate:true,
        },
    },
    methods:{
        getOptionList(item){
            let optionList=[];
            if(item.name){
                optionList=this.nameList.find(x=>x.code==item.name).optionList;
            }
            return optionList;
        },
        changeOperator(item){
            if(item.name){
                let nameItem=this.nameList.find(x=>x.code==item.name);
                item.type=nameItem.type;
                item.criteriaValue=null;
            }

            this.nameList.forEach(x=>{
                x.disabled=this.form.some(s=>s.name===x.code)?true:false
            })         
        },
        changeComparison(item){
            item.criteriaValue=null;
        },  
        addCondition(){
            this.$emit('addField',this.formName);
        },        
        delCondition(index){
            if(this.form[index].name){
                let nameItem=this.nameList.find(x=>x.code==this.form[index].name);
                if(nameItem){
                    nameItem.disabled=false;
                }
            }
            let delField={
                index,
                formName:this.formName,
            }
            this.$emit('delField',delField);
        },
        getCriteriaValue(item){
            item.criteriaValue=item.dateRange[0]+','+item.dateRange[1];
        },
        getStartT(time,index){
            this.form[index].criteriaValue=time+','+this.form[index].endTimeValue;
        },
        getEndT(time,index){
            this.form[index].criteriaValue=this.form[index].startTimeValue+','+time;
        }
    },
}
</script>
<style lang="scss">
.iconfont{
    font-size: 30px;
    color: rgba($color: #6F6E68, $alpha: 0.5);
    &:hover{
        color: rgba($color: #6F6E68, $alpha: 1);
    }
}
.el-col .el-date-editor.el-input, .el-date-editor.el-input__inner{
    width:100%;
}
.date-between{
    // margin-bottom: 13px;
    display: flex;
    align-items: stretch;
    justify-content: space-between;    
    .between{
        margin: 6px 10px 13px;
        font-size: 20px;  
    }
    .el-form-item{
        width:50%;
    }
}

.el-col .el-input .el-input__inner{
    color: #606266;
    font-size: 14px;
}
</style>