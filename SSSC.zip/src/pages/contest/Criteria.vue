<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="ruleForm" class="responsive-form" alias="master_information" :rules="$formValidator.rules" :model="ruleForm">

            <template slot="scroll">
                <div>
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch'></gl-search>
                </div>
                <gl-object-table :data="ruleForm.tableData" ref="criteriaTable">
                    <el-table-column :label="$t('label.company')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.processingUnitSeq'"  :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.processingUnitSeq" :valueData="scope.row.processingUnitSeq" :optionList="headerList[0].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.channel')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.businessUnitSeq'" :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.businessUnitSeq" :valueData="scope.row.businessUnitSeq" :optionList="headerList[1].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>       

                    <el-table-column :label="$t('label.branch')" width="auto">
                        <template slot-scope="scope">
                            <el-form-item  v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.branchSeq'" >
                                <el-input v-model="scope.row.branchSeq"></el-input>                                           
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.branchSeq}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('menu.location')" width="auto">
                        <template slot-scope="scope">
                            <!--<gl-select :prop="'tableData.' + scope.$index + '.locationSeq'" :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.locationSeq" :valueData="scope.row.locationSeq" :optionList="headerList[3].optionList">
                            </gl-select>-->
                            <el-form-item  v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.locationSeq'" >
                                <el-input v-model="scope.row.locationSeq"></el-input>                                           
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.locationSeq}}</span>
                        </template>
                    </el-table-column>   

                    <el-table-column :label="$t('label.criteriaCode')" width="auto" prop="criteriaCode">
                        <template slot-scope="scope">
                            <el-form-item  v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.criteriaCode'" >
                                <el-input v-model="scope.row.criteriaCode"></el-input>                                           
                            </el-form-item>
                            <gl-link v-else type="primary" @click="toCriteriaDetail(scope.row, scope.$index)">{{scope.row.criteriaCode}}</gl-link>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.criteriaDescription')" width="auto">
                        <template slot-scope="scope">
                            <el-form-item v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.criteriaDescription'"  :rules="$formValidator.rules.required">
                                <el-input v-model="scope.row.criteriaDescription" :id="'contestnameid' + scope.$index"></el-input>   
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.criteriaDescription}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column v-if="isModify" :label="$t('label.operation')">
                        <template slot-scope="scope">
                            <gl-button type="text" @click="editRow(scope.row,scope.$index)" v-show="!scope.row.edit" >{{$t('label.edit')}}</gl-button>
                            <gl-button type="text" @click="copyRow(scope.row,scope.$index)" v-show="!scope.row.edit" >{{$t('label.copy')}}</gl-button>
                            <gl-button type="text" @click="saveRow(scope.row,scope.$index, 'ruleForm')" v-show="scope.row.edit">{{$t('label.save')}}</gl-button>
                            <gl-button type="text" @click="editRowCancel(scope.row,scope.$index)" v-show="scope.row.edit">{{$t('label.cancel')}}</gl-button>
                        </template>
                    </el-table-column>
                </gl-object-table>
            </template>

            <template slot="pages">
                <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage" :change-size="changeSize"></gl-page>
            </template>
        </aia-form>
    </section>
</div>
</template>

<script>

export default {
    data() {
        return {            
            headerList: [
                // {
                //     code: 'contestCriteriaSeq',
                //     name: 'label.contestCriteriaSeq',
                //     type: "input",
                //     select: "",
                //     optionList: [],
                // },            
                {
                    code: 'processingUnitSeq',
                    name: 'label.company',
                    type: "select",
                    select: "other",
                    optionList:this.$getGeneralList("company", this),
                },
                {
                    code: 'businessUnitSeq',
                    name: 'label.channel',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("channel", this),
                },
                // {
                //     code: 'branchSeq',
                //     name: 'label.branch',
                //     type: "input",
                //     select: "",
                //     optionList: [],
                // },
                // {
                //     code: 'locationSeq',
                //     name: 'menu.location',
                //     type: "input",
                //     select: "",
                //     optionList: [],
                // },
                {
                    code: 'criteriaCode',
                    name: 'label.criteriaCode',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'criteriaDescription',
                    name: 'label.description',
                    type: "input",
                    select: "",
                    optionList: [],
                },
            ],
            total: 0,
            pageSize: 10,
            searchList: [],
            currentPage: 1,
            currentIndex: null,
            currentEdit: {},

            ruleForm:{tableData: [],},
            isModify:this.$checkPageModify(this.$route.name),
        }
    },
    async created() {
        await this.doSearch();
    },
    methods: {
        async changePage(page) {
            this.currentIndex=null;
            this.currentPage = page;
            await this.doSearch(this.searchList, true, page);
        },
        async changeSize(size){
            this.pageSize=size;
            await this.doSearch(this.searchList,true,1);
        },
        async doSearch(searchList = [], firstClick = true, page = 1, isAll = false) {
            this.currentPage = page;
            this.searchList = searchList;
            this.currentIndex=null;

            this.ruleForm.tableData=[
                {
                    contestCriteriaSeq: null,
                    contestMasterSeq: null,
                    processingUnitSeq: null,
                    businessUnitSeq: null,
                    branchSeq: null,
                    locationSeq: null,
                    criteriaCode: null,
                    criteriaDescription: null,
                    criteriaData: null,
                    summaryTypeItem: null,
                    edit:false,
                },
            ];

            let param={
                action:"GET",
                startPage:page,
                pageSize:this.pageSize,
            };

            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.processingUnitSeq=processingunit?processingunit:'';
            param.businessUnitSeq=businessunit?businessunit:'';


            searchList.forEach(x => {
                if (!this.$isEmpty(x.value)) {
                    let prop = x.headerSelected.code;
                    param[prop] = x.value;
                }
            });

            let response = await this.$caller.const_criteria(param);
            if (response.responseCode === "000") {
                // let contestCriteriaModel=response.contestCriteriaModel.filter(x=>this.headerList[0].optionList.some(company=>company.code==x.processingUnitSeq)&&this.headerList[1].optionList.some(channel=>channel.code==x.businessUnitSeq));

                this.ruleForm.tableData.unshift.apply(this.ruleForm.tableData,response.contestCriteriaModel);
                this.ruleForm.tableData.forEach(x=>{
                    x.edit=false;
                })
                this.total=response.total;
            } else {
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });

                if (!this.$isEmpty(response.reasonCode)) {
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },
        // toMaster(row, index) {
        //     this.$router.push({
        //         name: 'contest_criteria',
        //     });
        // },
        // toSummary(row,index){
        //     this.$router.push({
        //         name: 'rule_summary',
        //     });
        // },
        editRow(row, index) {
            //this.$refs.ruleForm.testChild(row.name);
            if (this.currentIndex != null) {
                this.$alert(this.$t("message.singleRowEdit"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }

            if (row.edit == false) {
                this.currentEdit = JSON.parse(JSON.stringify(row));
                this.currentIndex = index;
                row.edit = true;
                this.$set(this.ruleForm.tableData, index, row);
            }

            this.$nextTick(() => {
              this.$forceUpdate();
            });           
        },
        saveRow(row, index, formName) {
            if(!this.$refs.ruleForm.validate()){
                return;
            }
                    
            var opt = 'INSERT';
            let {edit,contestCriteriaSeq,contestMasterSeq,summaryTypeItem,...rest,}={...row};
            let contestCriteriaModel={...rest};

            if (this.currentIndex < this.ruleForm.tableData.length - 1) {
                opt = 'UPDATE';
                contestCriteriaModel={contestCriteriaSeq,summaryTypeItem,...rest};
            }
            this.$confirm(this.$t("message.toSave"), this.$t("message.confirm"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                })
                .then(() => {

                    var param = {
                        action: opt,
                        contestCriteriaModel,
                    }
                    this.$caller.const_criteria(param).then(res => {
                        this.currentEdit = {};
                        this.currentIndex = null;
                        this.doSearch(this.$refs.glSearch.searchList,true,this.currentPage,false);
                    });
                })
                .catch((e) => {
                    this.$alert(this.$t(e), this.$t("message.error"), {
                        confirmButtonText: "OK",
                    });
                    return;
                });
        },
        copyRow(val, index) {
            if (this.currentIndex != null) {
                this.$alert(this.$t("message.singleRowEdit"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }
            let indexLast = this.ruleForm.tableData.length - 1;
            this.currentEdit = JSON.parse(JSON.stringify(this.ruleForm.tableData[indexLast]));
            this.currentIndex = indexLast;

            this.ruleForm.tableData.splice(indexLast, 1, JSON.parse(JSON.stringify(val)));
            this.ruleForm.tableData[indexLast].edit = true;

        },
        editRowCancel(row, index) {
            this.$confirm(this.$t("message.notToSave"), this.$t("message.warning"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                })
                .then(() => {
                    row = JSON.parse(JSON.stringify(this.currentEdit));
                    row.edit = false;
                    this.$set(this.ruleForm.tableData, index, row);
                    this.currentEdit = {};
                    this.currentIndex = null;
                })
                .catch(() => {});

            this.$nextTick(() => {
              this.$forceUpdate();
            });
        },
        toCriteriaDetail(row,index){
            this.$router.replace({
                name:'criteria_detail',
                params:{
                    criteria:{...row},
                },
                query:{
                    criteriaSeq:row.contestCriteriaSeq,
                    lastRouter:this.$router.currentRoute.name,
                },
            });
        },
    },
}
</script>
