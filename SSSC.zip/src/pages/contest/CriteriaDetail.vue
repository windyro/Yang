<template>
    <div class="content-wrap">
        <section class="content-fluid margin-left-3xl margin-right-3xl">
            <aia-form
            ref="detailForm"
            class="responsive-form"
            alias="detailForm"
            :model="detailForm"
            :rules="$formValidator.rules"
            >
                <template slot="scroll">
                    <gl-tabs  tabPosition="top" class="detail-tab">
                        <el-tab-pane :label="$t('label.basic')">
                            <el-row>
                                <el-row>
                                    <gl-tabs tabPosition="left">
                                        <el-tab-pane label="KPI">
                                            <CriteriaField :form="detailForm.basic.kpi" :formName="'basic.kpi'" :nameList="kpiList" @addField="addField" @delField="delField"/>
                                        </el-tab-pane>
                                        <el-tab-pane label="Segment">
                                            <CriteriaField :form="detailForm.basic.segment" :formName="'basic.segment'" :nameList="segmentList" @addField="addField" @delField="delField"/>
                                        </el-tab-pane>
                                        <el-tab-pane label="Product">
                                            <CriteriaField :form="detailForm.basic.product" :formName="'basic.product'" :nameList="productList" @addField="addField" @delField="delField"/>
                                        </el-tab-pane>
                                    </gl-tabs>
                                </el-row>
                            </el-row>
                        </el-tab-pane>            

                        <el-tab-pane :label="$t('label.advanced')">
                            <el-input
                                type="textarea"
                                :rows="2"
                                :placeholder="$t('message.advancedPlaceholder')"
                                v-model="detailForm.advance"
                                class="advance-textarea">
                            </el-input>                            
                        </el-tab-pane>
                    </gl-tabs>                       
                </template>   

                <template slot="buttons">   
                    <button class="btn-primary"  @click.prevent="save">{{$t('label.save')}}</button>
                    <button class="btn-secondary" @click.prevent="back">{{$t('label.back')}}</button>
                </template>
            </aia-form>

        </section>
    </div>        
</template>
<script>
import CriteriaField from './CriteriaField';

export default {
    components:{
        CriteriaField,
    },
    data(){
        return{
            detailForm:{
                basic:{
                    kpi:[
                        {name: "",},                         
                    ],
                    segment:[
                        {name: "",ruleTemplateId:"",criteriaValue:"",type:'input'},                         
                    ],
                    product:[
                        {name: "",ruleTemplateId:"",criteriaValue:"",type:'input'},                         
                    ],
                },
                advance:'',
            },
            kpiList:this.$getGeneralList('kpi',this),
            segmentList:this.$getGeneralList('segment',this),
            productList:this.$getGeneralList('product',this),
            contestCriteriaSeq:null,
            criteria:null,
        }
    },
    created(){
        this.kpiList.forEach(x=>x.disabled=false);
        this.segmentList.forEach(x=>x.disabled=false);
        this.productList.forEach(x=>x.disabled=false);
        this.init();
    },
    methods:{
        async queryDetail(){
            let {criteriaSeq}=this.$route.query;
            if(criteriaSeq){

                let param={
                    action:'GET',
                    contestCriteriaSeq:criteriaSeq,                    
                }
                // let {processingunit,businessunit}=this.$store.state.user.userInfo;
                // param.company=processingunit?processingunit:'';
                // param.channel=businessunit?businessunit:'';                 
                let res=await this.$caller.const_criteria(param);
                if(res.responseCode=='000'){
                    this.criteria=res.contestCriteriaModel[0];
                }
            }           
        },
        async init(){
            let {criteria}=this.$route.params;
            if(criteria){
                this.criteria=criteria;           
            }else{
                await this.queryDetail();
            }             
            if(this.criteria){
                let {basic,advance}=this.criteria.criteriaData;
                if(basic){
                    let {kpi,segment,product}=basic;
                    kpi.forEach((x,index)=>{
                        if(!x){
                            kpi.splice(index,1,{name:'',});
                        }
                    })

                    segment.forEach((x,index)=>{
                        if(!x){
                            segment.splice(index,1,{name: "",ruleTemplateId:"",criteriaValue:"",type:'input'});
                        }
                    })

                    product.forEach((x,index)=>{
                        if(!x){
                            product.splice(index,1,{name: "",ruleTemplateId:"",criteriaValue:"",type:'input'});
                        }
                    })

                    this.detailForm.basic={
                        kpi:kpi&&kpi.length>0?[...kpi]:[{name:'',}],
                        segment:segment&&segment.length>0?segment.map(x=>{return {...x,type:'input',}}):[{name: "",ruleTemplateId:"",criteriaValue:"",type:'input'}],
                        product:product&&product.length>0?product.map(x=>{return {...x,type:'input',}}):[{name: "",ruleTemplateId:"",criteriaValue:"",type:'input'}],
                    }                  
                }
                if(advance){
                    this.detailForm.advance=advance;
                }     
            }

        },        
        checkFieldNull(arr){
            if(arr.length>0){
                let hasNull=arr.some(x=>x.name===null||x.name===""||x.ruleTemplateId===null||x.ruleTemplateId===""||x.criteriaValue===null||x.criteriaValue==="");
                return hasNull?true:false;
            }
            return true;
        },
        async save(){          
            let {kpi,segment,product}=this.detailForm.basic;
            let kpiNull=this.checkFieldNull(kpi);
            let segmentNull=this.checkFieldNull(segment);
            let productNull=this.checkFieldNull(product);

            if(kpiNull||segmentNull||productNull){
                this.$confirm(this.$t("message.kpiConfirm"), this.$t("message.confirm"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                }).then(()=>{
                    return;
                });
            }
            else{
                let tempDetail={
                    basic:{
                        kpi:kpi.map(x=>{return {name:x.name}}),
                        segment:segment.map(x=>{
                            let {type,startTimeValue,endTimeValue,...rest}={...x};
                            return {...rest};
                        }),
                        product:product.map(x=>{
                            let {type,startTimeValue,endTimeValue,...rest}={...x};
                            return {...rest};
                        }),
                    },
                    advance:this.detailForm.advance,
                    
                }

                let {criteriaData,edit,...rest}={...this.criteria};
                let param={
                    action:"UPDATE",
                    contestCriteriaModel:{           
                        ...rest,                            
                        criteriaData:tempDetail,
                    }
                }

                let response = await this.$caller.const_criteria(param);
                if (response.responseCode === "000") {        
                    this.$alert(this.$t("message.saveSuccess"), this.$t("message.confirm"), {
                        confirmButtonText: "OK",
                    });
                    await this.queryDetail();
                } else {
                    this.$alert("Response Code: " + response.responseCode, "Attention", {
                        confirmButtonText: "OK",
                    });

                    if (!this.$isEmpty(response.reasonCode)) {
                        this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                            confirmButtonText: "OK",
                        });
                    }
                }                     
            }            
       
        },
        back(){
            this.kpiList.forEach(x=>x.disabled=false);
            this.segmentList.forEach(x=>x.disabled=false);
            this.productList.forEach(x=>x.disabled=false);
            let {lastRouter}=this.$route.query;
            this.$router.replace({name:lastRouter});
        },
        addField(formName){
            let nameArr=formName.split('.');
            if(nameArr[1]==='kpi'){
                this.detailForm[nameArr[0]]['kpi'].push(
                    {name:'',ruleTemplateId:null},
                )
            }else{
                this.detailForm[nameArr[0]][nameArr[1]].push(
                    {name: "",ruleTemplateId:"",criteriaValue:"",type:'input'},                         
                )                
            }


        },
        delField(del){
            let {index,formName}=del;
            let nameArr=formName.split('.');
            this.detailForm[nameArr[0]][nameArr[1]].splice(index,1);
        },
    },
}
</script>  
<style lang="scss">
.detail-tab{
    .el-tabs--left.el-tabs--border-card .el-tabs__header.is-left{
        position: absolute;
        width: 12em;        
    }


    .el-tabs--border-card>.el-tabs__content{
        padding: 20px 25px;        
        min-height: 25em;
        margin-left: 12em;
    }    

    .el-tabs--border-card>.el-tabs__header .el-tabs__item{
        padding:0 !important;
    }
}
.advance-textarea {
    .el-textarea__inner{
        min-height: 160px !important;
    }    
}



</style>