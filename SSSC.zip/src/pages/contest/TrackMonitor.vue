<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">       
        <aia-form class="track-form" alias="track_monitor">
            <template slot="scroll">
                <div style="padding-left: 13em;">
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch' class="track-search"></gl-search>
                </div>
                <el-row style="margin-top:25px;">
                    <el-row>
                        <div id="myChart" style="height:300px;"></div>
                    </el-row>
                </el-row>                   
            </template>         
        </aia-form>
    </section>
</div>
</template>
<script>
export default {
    data(){
        return {
            headerList:[
                {
                    code:'district',
                    name:'menu.district',
                    type: "select",
                    select: "other",
                    optionList:[
                        {code:'DIST003',name:'DIST003'},
                    ],
                },
                {
                    code:'agency',
                    name:'menu.agency',
                    type: "select",
                    select: "other",
                    optionList:[
                        {code:'CT00001',name:'CT00001'},
                        // {code:'CT00002',name:'CT00002'},
                    ],
                },
                {
                    code:'eventType',
                    name:'label.kpi',
                    type: "select",
                    select: "other",
                    optionList:[
                        // {code:'6',name:'FYC'},
                        {code:'1',name:'FYP'},
                    ],
                },
                {
                    code:'agent',
                    name:'menu.agent',
                    type: "select",
                    select: "other",
                    optionList:[
                        {code:'CL00001',name:'CL00001'},
                        // {code:'CL00002',name:'CL00002'},
                    ],
                },
            ],
            valueOptions:[],
            form:{
                selectType:null,
                selectValue:null,                
            },
            chart:null,
            options:{
                color:['#675bba','#d14a61','#5793f3','#d48265', '#91c7ae','#749f83', ],
                title:{
                    text:'Contest calculation result ranking',
                    subtext: 'Contest calculation ratio against target (Monthly)',
                    left: 'center'
                },
                toolbox: {
                    feature: {
                        dataView: {show: true, readOnly: false},
                        magicType: {show: true, type: ['line', 'bar']},
                        restore: {show: true},
                        saveAsImage: {show: true}
                    }
                },                
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'cross',
                        crossStyle: {
                            color: '#999'
                        }
                    }
                },
                legend:{
                    data:['Silver Agency','Gold Agency','Platinum Agency'],
                },
                xAxis:{
                    data:['1st week','2nd week','3rd week','4th week',],
                },
                yAxis:[
                    {
                        type: 'value',
                        scale: true,
                        name: 'data',
                        min: 0,
                        max:5500000,
                        splitLine:{
                    　　　　show:false,
                    　　}
                    },           
                    {  
                        type: 'value',  
                        name:'prorated',
                        axisLabel: {  
                            show: true,  
                            formatter: '{value} %'  
                        },  
                        scale: true,
                        min: 0,
                        max:100,
                        show: true,  
                        interval:25,
                    }  
                ],
                series:[
                    {
                        type:'line',
                        name:'Silver Agency weekly prorated(%)',
                        data:[],
                        yAxisIndex: 1,
                    },      
                    {
                        type:'line',
                        name:'Gold Agency weekly prorated(%)',
                        data:[],
                        yAxisIndex: 1,
                    },
                    {
                        type:'line',
                        name:'Platinum Agency weekly prorated(%)',
                        data:[],
                        yAxisIndex: 1,
                    },                                                                            
                    {
                        type:'bar',
                        name:'Silver Agency Data($)',
                        data:[],
                    },
                    {
                        type:'bar',
                        name:'Gold Agency Data($)',
                        data:[],
                    },      
                    {
                        type:'bar',
                        name:'Platinum Agency Data($)',
                        data:[],
                    },                        
                ],
            },
            allData:[
                {district:'DIST003',agency:'CT00001',eventType:'1',agent:'CL00001',T1:200000,T2:1000000,T3:1000000,week:'1st week',},
                {district:'DIST003',agency:'CT00001',eventType:'1',agent:'CL00001',T1:600000,T2:1500000,T3:2500000,week:'2nd week',},
                {district:'DIST003',agency:'CT00001',eventType:'1',agent:'CL00001',T1:1000000,T2:2000000,T3:4000000,week:'3rd week',},
                {district:'DIST003',agency:'CT00001',eventType:'1',agent:'CL00001',T1:1200000,T2:2500000,T3:5500000,week:'4th week',},

                // {district:'DIST003',agency:'CT00001',eventType:'6',agent:'CL00001',T1:200000,T2:20,T3:15,week:'1st week',},
                // {district:'DIST003',agency:'CT00001',eventType:'6',agent:'CL00001',T1:300000,T2:70,T3:90,week:'2nd week',},
                // {district:'DIST003',agency:'CT00001',eventType:'6',agent:'CL00001',T1:300000,T2:90,T3:200,week:'3rd week',},
                // {district:'DIST003',agency:'CT00001',eventType:'6',agent:'CL00001',T1:300000,T2:200,T3:350,week:'4th week',},

                // {district:'DIST003',agency:'CT00002',eventType:'6',agent:'CL00002',T1:200000,T2:35,T3:45,week:'1st week',},
                // {district:'DIST003',agency:'CT00002',eventType:'6',agent:'CL00002',T1:300000,T2:90,T3:90,week:'2nd week',},
                // {district:'DIST003',agency:'CT00002',eventType:'6',agent:'CL00002',T1:300000,T2:190,T3:140,week:'3rd week',},
                // {district:'DIST003',agency:'CT00002',eventType:'6',agent:'CL00002',T1:300000,T2:230,T3:550,week:'4th week',},

                // {district:'DIST003',agency:'CT00002',eventType:'1',agent:'CL00002',T1:200000,T2:500000,T3:1000000,week:'1st week',},
                // {district:'DIST003',agency:'CT00002',eventType:'1',agent:'CL00002',T1:400000,T2:1000000,T3:190,week:'2nd week',},
                // {district:'DIST003',agency:'CT00002',eventType:'1',agent:'CL00002',T1:600000,T2:1000000,T3:240,week:'3rd week',},
                // {district:'DIST003',agency:'CT00002',eventType:'1',agent:'CL00002',T1:600000,T2:1000000,T3:650,week:'4th week',},                
            ],
            searchList: [],
            chartData:[],
            target1:1200000,
            target2:2500000,
            target3:5500000,
        }
    },
    created(){
        this.$nextTick(()=>{
            let chartElement=document.querySelector('#myChart');
            this.chart=this.$chart.init(chartElement);
            this.chart.setOption(this.options);    
            
            this.doSearch();
        })
    },
    methods:{
        doSearch(searchList=[]){
            this.searchList = searchList;

            this.chartData=this.allData.slice();
            searchList.forEach((x,index) => {
                if (!this.$isEmpty(x.value)) {
                    let prop = x.headerSelected.code;
                    this.chartData=this.chartData.filter(y=>y[prop]===x.value);
                }
            });

            let series=[];
            let series0=[0,0,0,0,],series1=[0,0,0,0,],series2=[0,0,0,0,],series3=[0,0,0,0,],series4=[0,0,0,0,],series5=[0,0,0,0,];
            let w1,w2,w3,w4;
            this.chartData.forEach(x=>{
                if(x.week=='1st week'){
                    series0[0]+=x.T1;
                    series1[0]+=x.T2;
                    series2[0]+=x.T3;

                    series3[0]+=x.T1;
                    series4[0]+=x.T2;
                    series5[0]+=x.T3;
                }

                if(x.week=='2nd week'){
                    series0[1]+=x.T1;
                    series1[1]+=x.T2;
                    series2[1]+=x.T3;

                    series3[1]+=x.T1;
                    series4[1]+=x.T2;
                    series5[1]+=x.T3;                    
                }

                if(x.week=='3rd week'){
                    series0[2]+=x.T1;
                    series1[2]+=x.T2;
                    series2[2]+=x.T3;

                    series3[2]+=x.T1;
                    series4[2]+=x.T2;
                    series5[2]+=x.T3;                    
                }
                
                if(x.week=='4th week'){
                    series0[3]+=x.T1;
                    series1[3]+=x.T2;
                    series2[3]+=x.T3;

                    series3[3]+=x.T1;
                    series4[3]+=x.T2;
                    series5[3]+=x.T3;                    
                }                
            })            

            // this.calculateProrated(series0,this.target1);
            // this.calculateProrated(series1,this.target2);
            // this.calculateProrated(series2,this.target3);
            series0=series0.map(x=>{
                return (x/this.target1*100).toFixed(2);
            })

            series1=series1.map(x=>{
                return (x/this.target2*100).toFixed(2);
            })
            series2=series2.map(x=>{
                return (x/this.target3*100).toFixed(2);
            })
            
            this.options.series[0].data=[...series0];
            this.options.series[1].data=[...series1];
            this.options.series[2].data=[...series2];    

            this.options.series[3].data=[...series3];
            this.options.series[4].data=[...series4];
            this.options.series[5].data=[...series5];            

            console.log(this.options.series);

            this.chart.setOption(this.options);            

        },
    }
}
</script>
<style lang="scss">
.track-search{
    // #addBtn{display: none;}
    .btn-primary{margin-left:10px;}
    .el-input__inner{color: #606266;}    
}

</style>