<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="ruleForm" class="responsive-form" alias="master_information" :rules="$formValidator.rules" :model="ruleForm">

            <template slot="scroll">
                <div>
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch'></gl-search>
                </div>
                <gl-object-table :data="ruleForm.tableData" ref="tableData" class="within-scroll-table">
                    <el-table-column :label="$t('label.contestCode')" width="auto">
                        <template slot-scope="scope">
                            <el-form-item v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.contestCode'"  :rules="$formValidator.rules.required">
                                <el-input v-model="scope.row.contestCode" :id="'nameid' + scope.$index" :ref="'nameref' + scope.$index"></el-input>   
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.contestCode}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.name')" width="auto">
                        <template slot-scope="scope">
                            <el-form-item v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.contestName'"  :rules="$formValidator.rules.required">
                                <el-input v-model="scope.row.contestName" :id="'contestnameid' + scope.$index"></el-input>   
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.contestName}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.description')" width="auto">
                        <template slot-scope="scope">
                            <el-form-item v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.contestName'"  :rules="$formValidator.rules.required">
                                <el-input v-model="scope.row.contestDescription" :id="'descriptionid' + scope.$index"></el-input>   
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.contestDescription}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.company')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.processingUnitSeq'"  :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.processingUnitSeq" :valueData="scope.row.processingUnitSeq" :optionList="headerList[0].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.channel')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.businessUnitSeq'" :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.businessUnitSeq" :valueData="scope.row.businessUnitSeq" :optionList="headerList[1].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>               

                    <!--branchCode=branchSeq-->
                    <el-table-column :label="$t('label.branch')" width="auto">
                        <template slot-scope="scope">
                            <el-form-item  v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.branchSeq'" >
                                <el-input v-model="scope.row.branchSeq"></el-input>                                           
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.branchSeq}}</span>
                        </template>
                    </el-table-column>

                    <!--locationCode=locationSeq-->
                    <el-table-column :label="$t('menu.location')" width="auto">
                        <template slot-scope="scope">
                            <!--<gl-select :prop="'tableData.' + scope.$index + '.locationSeq'"  :edit="scope.row.edit" v-model="scope.row.locationSeq" :valueData="scope.row.locationSeq" :optionList="[]">
                            </gl-select>-->
                            <el-form-item v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.locationSeq'"  :rules="$formValidator.rules.required">
                                <el-input v-model="scope.row.locationSeq" :id="'locationSeq' + scope.$index"></el-input>   
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.locationSeq}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.criteria')" width="auto" prop="criteriaCode">
                        <template slot-scope="scope">
                            <gl-select v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.contestCriteriaSeq'"  :edit="scope.row.edit" v-model="scope.row.contestCriteriaSeq" :valueData="scope.row.contestCriteriaSeq" :optionList="criteriaList">
                            </gl-select>

                            <gl-link v-else type="primary" @click="toCriteria(scope.row, scope.$index)">{{convertCriteriaCode(scope.row.contestCriteriaSeq)}}</gl-link>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.tieringDefinition')" width="auto">
                        <template slot-scope="scope">
                            <!--gl-select-multiple v-if="scope.row.edit"
                                :prop="'tableData.' + scope.$index + '.measurementArray'"
                                :edit="scope.row.edit" 
                                v-model="scope.row.measurementArray" 
                                :valueData="scope.row.measurementArray"
                                :optionList="tieringDefinitions">
                            </gl-select-multiple

                            <gl-link type="primary" v-for="item in scope.row.measurements" :key="item" @click="toRuleDetail(scope.row)">{{item.name}}</gl-link>   -->              
                            <gl-link type="primary" @click="toRuleDetail(scope.row)">{{convertTiering(scope.row.measurement)}}</gl-link>  
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.frequency')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.calculationFrequency'" :rules="$formValidator.rules.required" :optionList="frequencies" :edit="scope.row.edit" v-model="scope.row.calculationFrequency" :valueData="scope.row.calculationFrequency">
                            </gl-select>  
                        </template>
                    </el-table-column>               

                    <el-table-column :label="$t('label.startDate')" width="auto">
                        <template slot-scope="scope">
                            <gl-date :prop="'tableData.' + scope.$index + '.startDate'"  :rules="$formValidator.rules.required" :edit="scope.row.edit"   v-model="scope.row.startDate" :value="scope.row.startDate" type="date" :endDateStr="scope.row.endDate"></gl-date>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.endDate')" width="auto">
                        <template slot-scope="scope">
                            <gl-date :prop="'tableData.' + scope.$index + '.endDate'"  :rules="$formValidator.rules.required" :edit="scope.row.edit"   v-model="scope.row.endDate" :value="scope.row.endDate" type="date" :beginDateStr="scope.row.startDate"></gl-date>
                        </template>
                    </el-table-column>          

                    <el-table-column :label="$t('label.active')" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.active'" :rules="$formValidator.rules.required" type="yesNo" :edit="scope.row.edit" v-model="scope.row.active" :valueData="scope.row.active">
                            </gl-select>                            
                        </template>
                    </el-table-column>      

                    <el-table-column v-if="isModify" :label="$t('label.operation')">
                        <template slot-scope="scope">
                            <gl-button type="text" @click="editRow(scope.row,scope.$index)" v-show="!scope.row.edit" >{{$t('label.edit')}}</gl-button>
                            <gl-button type="text" @click="copyRow(scope.row,scope.$index)" v-show="!scope.row.edit" >{{$t('label.copy')}}</gl-button>
                            <gl-button type="text" @click="saveRow(scope.row,scope.$index, 'ruleForm')" v-show="scope.row.edit">{{$t('label.save')}}</gl-button>
                            <gl-button type="text" @click="editRowCancel(scope.row,scope.$index)" v-show="scope.row.edit">{{$t('label.cancel')}}</gl-button>
                        </template>
                    </el-table-column>
                </gl-object-table>
            </template>
            <template slot="pages">
                <gl-page :total="total" :pageSize="pageSize" :changePage="changePage" :current-page.sync="currentPage" :change-size="changeSize"></gl-page>
            </template>
        </aia-form>
    </section>
</div>
</template>

<script>
import util from "@/models/Utility";

export default {
    data() {
        return {
            headerList: [
                {
                    code: 'processingUnitSeq',
                    name: 'label.company',
                    type: "select",
                    select: "other",
                    optionList:this.$getGeneralList("company", this),
                },
                {
                    code: 'businessUnitSeq',
                    name: 'label.channel',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("channel", this),
                },
                // {
                //     code: 'branchSeq',
                //     name: 'label.branch',
                //     type: "input",
                //     select: "",
                //     optionList: [],
                // },
                // {
                //     code: 'locationCode',
                //     name: 'menu.location',
                //     type: "input",
                //     select: "",
                //     optionList: [],
                // },
                // {
                //     code: 'contestMasterSeq',
                //     name: 'label.contestMasterSeq',
                //     type: "input",
                //     select: "",
                //     optionList: [],
                // },
                {
                    code: 'contestCode',
                    name: 'label.contestCode',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'contestName',
                    name: 'label.name',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'contestDescription',
                    name: 'label.description',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'startDate',
                    name: 'label.startDate',
                    type: "date",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'endDate',
                    name: 'label.endDate',
                    type: "date",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'active',
                    name: 'label.active',
                    type: "select",
                    select: "yesNo",
                    optionList: [],
                },
            ],
            total: 0,
            pageSize: 10,
            currentIndex: null,
            currentEdit: {},
            searchList: [],
            currentPage: 1,
            ruleForm:{tableData: [],},
            isModify:this.$checkPageModify(this.$route.name),
            tieringDefinitions:[],            
            frequencies:[
                {code:'Monthly',name:'Monthly',},
                {code:'Quarterly(rolling)',name:'Quarterly(rolling)',},
                {code:'Quarterly(financial)',name:'Quarterly(financial)',},
                {code:'Yearly(rolling)',name:'Yearly(rolling)',},
                {code:'Yearly(financial)',name:'Yearly(financial)',},
            ],
            criteriaList:[],
            newTiering:{},
            company:null,
            channel:null,
        }
    },
    async created() {        
        let {processingunit,businessunit}=this.$store.state.user.userInfo;
        this.company=processingunit?processingunit:'';
        this.channel=businessunit?businessunit:'';

        await this.initTieringDef();
        await this.initCriteriaCode();
        await this.doSearch();
    },
    methods: {
        convertCriteriaCode(seq){
            let index=this.criteriaList.findIndex(x=>x.code==seq);

            return index>-1?this.criteriaList[index].name:null;
        },
        convertCriteriaData(seq){
            let index=this.criteriaList.findIndex(x=>x.code==seq);
            return index>-1?this.criteriaList[index].criteriaData:null;
        },
        async initCriteriaCode(){
            let res=await this.$caller.const_criteria({action:"GET",processingUnitSeq:this.company,businessUnitSeq:this.channel,});
            if(res.responseCode=="000"){
                this.criteriaList=res.contestCriteriaModel.map(x=>{
                    return {code:x.contestCriteriaSeq,name:x.criteriaCode, criteriaData:x.criteriaData};
                })
            }
        },
        async initTieringDef(){
            if(this.tieringDefinitions.length==0){
                let param={action:'GET',paymentFlag:'N',company:this.company,channel:this.channel,};
                let res=await this.$caller.rule_summary_query(param);
                if(res.responseCode=='000'){
                    this.tieringDefinitions=res.ruleGroupModel.map(x=>{
                        return {code:x.ruleGroupModelId,name:x.name};
                    });
                }
            }
        },
        async changePage(page) {
            this.currentIndex=null;
            this.currentPage = page;
            await this.doSearch(this.searchList, true, page);
        },
        async changeSize(size){
            this.pageSize=size;
            await this.doSearch(this.searchList,true,1);
        },
        convertTiering(measurement){
            let tiering=String(measurement);
            let index=this.tieringDefinitions.findIndex(x=>x.code==tiering);
            return index>-1?this.tieringDefinitions[index].name:null;
        },
        async doSearch(searchList = [], firstClick = true, page = 1, isAll = false) {
            this.currentPage = page;
            this.searchList = searchList;
            this.currentIndex=null;

            this.ruleForm.tableData=[
                {
                    contestMasterSeq: null,
                    contestCriteriaSeq: null,
                    processingUnitSeq: null,
                    businessUnitSeq: null,
                    branchSeq: null,
                    locationSeq: null,
                    contestCode: "",
                    contestName: "",
                    contestDescription: "",
                    startDate: util.data().defaultStartDate,
                    endDate: util.data().defaultEndDate,
                    calculationFrequency: "",
                    measurement: "",
                    deposit: null,
                    active: "Y",
                    contestCriteriaModel: null,
                    edit:false,
                },
            ];

            let param = {
                action: "GET",
                startPage: page,
                pageSize: this.pageSize,
                processingUnitSeq:this.company,
                businessUnitSeq:this.channel,
            }
      
            // let {processingunit,businessunit}=this.$store.state.user.userInfo;
            // param.processingUnitSeq=processingunit?processingunit:'';
            // param.businessUnitSeq=businessunit?businessunit:'';


            searchList.forEach(x => {
                if (!this.$isEmpty(x.value)) {
                    let prop = x.headerSelected.code;
                    param[prop] = x.value;
                }
            })

            let response = await this.$caller.const_master(param);
            if (response.responseCode === "000") {
                let {contestMasterModel,total} = {...response};
                this.total = total;
                contestMasterModel.forEach(x=>{
                    x.edit=false;
                })

                this.ruleForm.tableData.unshift.apply(this.ruleForm.tableData,contestMasterModel);

                let index=contestMasterModel.findIndex(x=>x.contestMasterSeq==this.newTiering.masterSeq);
                if(index>-1){
                    this.tieringDefinitions.push({code:contestMasterModel[index].measurement,name:this.newTiering.name});
                }

            } else {
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });

                if (!this.$isEmpty(response.reasonCode)) {
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },
        toCriteria(row, index) {
            this.$router.push({
                name: 'criteria_detail',
                query:{
                    criteriaSeq:row.contestCriteriaSeq,
                    lastRouter:this.$router.currentRoute.name,
                }
            });
        },
        toSummary(row,index){
            this.$router.push({
                name: 'rule_summary',
                params:{
                    lastRouter:this.$router.currentRoute.name,
                }
            });
        },
        editRow(row, index) {
            if (this.currentIndex != null) {
                this.$alert(this.$t("message.singleRowEdit"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }

            if (row.edit == false) {
                this.currentEdit = JSON.parse(JSON.stringify(row));
                this.currentIndex = index;
                row.edit = true;
                this.$set(this.ruleForm.tableData, index, row);
            }

            this.$nextTick(() => {
              this.$forceUpdate();
            });           
        },
        saveRow(row, index, formName) {
            if(!this.$refs.ruleForm.validate()){
                return;
            }
                    
            var opt = 'INSERT';
            let {edit,...rest,}={...row};
            let contestMasterModel={...rest};          

            if (this.currentIndex < this.ruleForm.tableData.length - 1) {
                opt = 'UPDATE';
            }
            this.$confirm(this.$t("message.toSave"), this.$t("message.confirm"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                })
                .then(() => {
                    var param = {
                        action: opt,
                        contestMasterModel,
                    }
                    this.$caller.const_master(param).then(res => {
                        this.newTiering={
                            code:null,
                            name:'CONTEST_'+contestMasterModel.contestCode,
                            masterSeq:res.contestMasterSeq,
                        }

                        this.currentEdit = {};
                        this.currentIndex = null;
                        this.doSearch(this.$refs.glSearch.searchList,true,this.currentPage,false);
                    });
                })
                .catch((e) => {
                    this.$alert(this.$t(e), this.$t("message.error"), {
                        confirmButtonText: "OK",
                    });
                    return;
                });
        },
        copyRow(val, index) {
            if (this.currentIndex != null) {
                this.$alert(this.$t("message.singleRowEdit"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }
            let indexLast = this.ruleForm.tableData.length - 1;
            this.currentEdit = JSON.parse(JSON.stringify(this.ruleForm.tableData[indexLast]));
            this.currentIndex = indexLast;

            this.ruleForm.tableData.splice(indexLast, 1, JSON.parse(JSON.stringify(val)));
            this.ruleForm.tableData[indexLast].edit = true;
        },
        editRowCancel(row, index) {
            this.$confirm(this.$t("message.notToSave"), this.$t("message.warning"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                })
                .then(() => {
                    row = JSON.parse(JSON.stringify(this.currentEdit));
                    row.edit = false;
                    this.$set(this.ruleForm.tableData, index, row);
                    this.currentEdit = {};
                    this.currentIndex = null;
                })
                .catch(() => {});

            this.$nextTick(() => {
              this.$forceUpdate();
            });
        },
        toRuleDetail(item){
           
            let criteriaData = this.convertCriteriaData(item.contestCriteriaSeq);
            //console.log(JSON.stringify(criteriaData));
            this.$router.push({
                name: 'rule_detail',
                params: {
                    rule: {ruleGroupModelId:item.measurement,
                           criteriaData:criteriaData,
                           lastRouter:this.$router.currentRoute.name,
                          },
                },
            });            
        },
    },
}
</script>
