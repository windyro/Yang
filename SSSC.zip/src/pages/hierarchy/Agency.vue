<template>
  <div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
      <aia-form
        class="responsive-form"
        alias="agent_maintain">

        <template slot="scroll">
          <div>
            <gl-search :headerList="searchList"  @doSearch="doSearch" ref='glSearch'></gl-search>
          </div>
          <gl-object-table :data="tableData" ref="agencyTable">
            <el-table-column :label="$t(headerList[0].name)"  width="auto">
                <template slot-scope="scope">
                    <gl-link type="primary" @click="goToDetail(scope.row)">{{$t(scope.row.agencyCode)}}</gl-link >
                </template>
            </el-table-column>

            <el-table-column :label="$t(headerList[1].name)" width="auto" prop="agencyName"></el-table-column>

            <el-table-column :label="$t(headerList[2].name)" width="auto">
                <template slot-scope="scope">
                    <gl-select  :edit="false" v-model="scope.row.title" :valueData="scope.row.title" :optionList="headerList[2].optionList">
                    </gl-select>
                </template>
            </el-table-column>

            <el-table-column :label="$t(headerList[3].name)" width="auto" prop="leaderCode"></el-table-column>

            <el-table-column  :label="$t(headerList[4].name)" width="auto" prop="leaderName"></el-table-column>
               
            <el-table-column :label="$t(headerList[5].name)" width="auto">
                <template slot-scope="scope">
                    <gl-select  :edit="false" v-model="scope.row.leaderTitle" :valueData="scope.row.leaderTitle" :optionList="headerList[5].optionList">
                    </gl-select>
                </template>
            </el-table-column> 

          </gl-object-table >

          <hierarchy-tree
               :dialogTableVisible = "dialogTableVisible"
                v-if="dialogTableVisible"
                @doCloseDialog="closeHierarchyTree"
                @doGoToDetail="doGoToDetail"
                >
          </hierarchy-tree>  
        </template>

        <template slot="pages">
          <gl-page :total="total" :pageSize="pageSize" :current-page.sync="currentPage" :changePage="changePage" :changeSize="changeSize"></gl-page>
        </template>

        <template slot="buttons"> 
            <button class="btn-primary" @click.prevent="openHierarchyTree()">{{$t('label.hierarchyTree')}}</button>
            <button class="btn-primary" @click.prevent="add" v-if="isModify">{{$t('add')}}</button>
        </template> 

      </aia-form>
    </section>
  </div>
</template>
<script>
import HierarchyTree from "./HierarchyTree";
export default {
    components:{
        HierarchyTree,
    },
    data(){
        return{
            headerList:[
                {
                    code:'agencyCode', 
                    name: 'label.agencyCode',
                    type: "input",
                },
                {
                    code:'agencyName', 
                    name: 'label.agencyName',
                    type: "input",
                    noDisplay:false,
                },
                {
                    code:'title', 
                    name: 'label.entityType',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("agencyTitle", this),
                },
                {
                    code:'leaderCode', 
                    name: 'label.leaderCode',
                    type: "input",
                    noDisplay:false,
                },
                {
                    code:'leaderName', 
                    name: 'label.leaderName',
                    type: "input",
                    noDisplay:false,
                },
                {
                    code:'leaderTitle', 
                    name: 'label.leaderTitle',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("title", this),
                },            
            ],
            tableData:[],
            total:0,     
            currentPage:1,
            pageSize:10,
            form:{},
            display:false,
            search:[],
            isModify:this.$checkPageModify(this.$route.name),
            dialogTableVisible: false,
        }
    },
    computed:{
        searchList(){
            return this.headerList.slice(0,4);
        }
    },
    async created(){
        await this.doSearch();
        //console.log(this.$getGeneralList("hierarchyTree", this));
    },
    methods:{
        async doSearch(search=[],page=1) {
            try{
                this.search=search;
                let param={
                    action:"GET",
                    startPage: page,
                    pageSize: this.pageSize,
                    isLast:'1',
                    removeDate:'2200-01-01',    
                };

                let {processingunit,businessunit}=this.$store.state.user.userInfo;
                param.company=processingunit?processingunit:'';
                param.channel=businessunit?businessunit:'';                         

                search.forEach(x=>{
                    if(!this.$isEmpty(x.value)){
                        let prop=x.headerSelected.code;
                        param[prop]=x.value;
                    }
                });
                this.currentPage=page;
                let response=await this.$caller.agency_query(param);
                let {entityModel,total}=response;
                this.tableData=entityModel.map(x=>{
                    let {participantModel,positionModel,leaderModel}=x;

                    return {
                        agencyCode:participantModel?participantModel.agentCode:null,
                        agencyName:participantModel?participantModel.lastName:null,
                        title:positionModel?positionModel.title:null,
                        leaderCode:leaderModel?leaderModel.code:null,
                        leaderName:leaderModel?leaderModel.lastName:null,
                        leaderTitle:leaderModel?leaderModel.title:null,
                        seq:participantModel?participantModel.seq:null,
                    };
                });
                this.total=total;
            }catch(e){
                console.log(e);
            }            
        },
        changePage(page){
            this.doSearch(this.search,page);
            this.currentPage=page;
        },
        changeSize(size) {
            this.pageSize=size;
            this.doSearch(this.searchList,1);
        },
        add(){
            this.$router.replace({name:'hierarchy_agency_detail',});
        },
        save(form){
            this.form=form;
            this.display=false;
        },
        close(){
            this.display=false;
        },
        goToDetail(row){
            let {seq,}=row;
            this.$router.replace({
                name:'hierarchy_agency_detail',
                query:{
                    seq,
                    isModify:this.isModify,
                }
            });
        },

        openHierarchyTree(){
          this.dialogTableVisible = true;
        },
        closeHierarchyTree(){
           this.dialogTableVisible = false;
        },
        doGoToDetail(data){

            let {id,recordType,leaderCode,isLeader}=data;

            this.defaultTab='1';
            let param={
                action:"GET",
                seq:id,
                isLast:'1',     
            };

            if(recordType=='AGY'&&!isLeader){
                this.goToDetail(param);
            }
            if(recordType=='AGT'||isLeader){
                this.$router.replace({
                    name:'agent_detail',
                    query:{
                        seq:!isLeader?id:null,
                        isModify:this.isModify,
                        agentCode:isLeader?leaderCode:null,                        
                    }
                });
            }
           this.dialogTableVisible = false;
        },
    }
}
</script>  