<template>
   <!-- <el-form :ref="formName" :model="form">-->
        <el-row :gutter="36">
            <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6" v-for="item in fields" :key="item.name" :label="$t(item.name)">
                <el-form-item v-if="item.type !='hidden'" :label="$t('label.'+item.label)" class="form-item" :rules="item.required?$formValidator.rules.required:[]" :prop="formName+'.'+item.name">
                    <el-input v-if="item.type=='input'" v-model="form[item.name]" :disabled="!isEdit"></el-input>
                    <el-input v-else-if="item.type=='inputView'" v-model="form[item.name]" :disabled="true"></el-input>
                    <el-date-picker
                        v-else-if="item.type=='date'"
                        value-format="yyyy-MM-dd"
                        :disabled="!isEdit"
                        v-model="form[item.name]"
                        type="date">
                    </el-date-picker>      
                    <gl-select v-else-if="item.type=='select'" 
                        :edit="true" 
                        v-model="form[item.name]" 
                        :valueData="form[item.name]"
                        :disabled="!isEdit"
                        :optionList="item.optionList">
                    </gl-select>
                    <gl-select v-else-if="item.type=='selectView'" 
                        :edit="true" 
                        v-model="form[item.name]" 
                        :valueData="form[item.name]"
                        :disabled="true"
                        :optionList="item.optionList">
                    </gl-select>
                    <gl-select-search v-else-if="item.type==='selectSearch'" 
                        :apiName="item.apiName" 
                        :apiInput="item.apiInput" 
                        :apiParm="item.apiParm" 
                        :apiResult="item.apiResult" 
                        v-model="form[item.name]" 
                        :valueData="form[item.name]" 
                        :getSelectedObj="getSelectedObj"
                        :itemName="item.name"
                        :disabled="!isEdit" >
                    </gl-select-search>       
                </el-form-item>
            </el-col>
        </el-row>    
    <!--</el-form>-->
</template>    
<script>
export default {
    props:{
        form:{
            type:Object,
            default:()=>{}
        },
        formName:{
            type:String,
            default:'form',
        },
        fields:{
            type:Array,
            default:[],
        },
        isSave:{
            type:Boolean,
            default:false,
        },
        isEdit:{
            type:Boolean,
            default:false,
        },

        getSelectedObjFunc: {
            type: Function,
            default: null,
        },
    },
    data(){
        return {
            rules:[{required: true, message: "Can't be empty", trigger: "blur"}],
        };
    },
    watch:{
        isSave(val){
            if(val){
                // this.saveInfo();
            }
        },
    },
    methods:{
        saveInfo(){
            this.$refs[this.formName].validate(valid=>{
                if(valid){
                    this.$emit('saveInfo',this.formName);
                }else{
                    this.$emit('validIsFalse',this.formName);
                }
            })
        },

        getSelectedObj(itemName, obj){
            if (this.getSelectedObjFunc) {
                this.getSelectedObjFunc(itemName, obj);
            }
        }
    },
}
</script>
<style lang="scss">
.form-item .el-date-editor.el-input, .el-date-editor.el-input__inner{
    width:100%;
}

.form-item .el-input.is-disabled .el-input__inner{
    color:#606266; 
}
.form-item .el-input__inner{
    color:#606266; 
}
</style>