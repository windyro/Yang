<template>
<div class="content-wrap">
    <section class="content-fluid channel-admin-detail margin-left-3xl margin-right-3xl">
        <aia-form ref="relationshipDetailForm" class="responsive-form" alias="relationshipDetailForm" :model="relationshipDetailForm" :rules="$formValidator.rules">

            <template slot="scroll">

                <el-collapse accordion :value="'1'">
                    <el-collapse-item class="relationshipdetail-collapse" name="1">
                        <template slot="title">
                            <h6>{{$t('label.relationship_type')}}</h6>
                        </template>

                        <el-row :gutter="36">
                            <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6"  >
                                <label class="bt5 label_required">{{$t('label.type')}}</label>
                                <el-form-item prop="relationship.name" :rules="$formValidator.rules.required">
                                    <el-input v-model="relationshipDetailForm.relationship.name" ></el-input>
                                </el-form-item>
                            </el-col>

                            <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6"  >
                                <label class="bt5">{{$t('label.description')}}</label>
                                <el-form-item prop="relationship.description">
                                    <el-input v-model="relationshipDetailForm.relationship.description"></el-input>
                                </el-form-item>
                            </el-col>

                            <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6"  >
                                <label class="bt5 label_required">{{$t('label.active')}}</label>
                                <gl-select prop="relationship.active"  :rules="$formValidator.rules.required" :edit="true" v-model="relationshipDetailForm.relationship.active" :valueData="relationshipDetailForm.relationship.active" type="yesNo" >
                                </gl-select>
                            </el-col>
                        </el-row>

                    </el-collapse-item>
                </el-collapse>     

                <el-collapse  :value="'1'">
                    <el-collapse-item class="relationshipdetail-collapse" name="1">
                        <template slot="title">
                            <h6>{{$t('label.relationship_detail')}}</h6>
                        </template>

                        <gl-element-table :headerList="headerList" :tableData="tableData" :edit="isModify" ref="relationTable">
                        </gl-element-table>
                    </el-collapse-item>    
                </el-collapse>  

            </template>

     
            <template slot="buttons">   
                 <button class="btn-primary" @click.prevent="doSave" v-if="isModify">{{$t('label.save')}}</button>
                 <button class="btn-secondary" @click.prevent="doBack">{{$t('label.back')}}</button>
            </template>

        </aia-form>
    </section>
</div>
</template>

<script>
import util from "@/models/Utility";
export default {
    props: {},
    data() {
        return {

            relationshipDetailForm: { 
                relationship: {
                    dataTypeSeq: "",
                    name: "", 
                    description: "", 
                    active: "",
                    createDate: "",
                    removeDate: "",
                },
            },

            headerList:[
                {
                    code:'parent', 
                    hidden: 'parentpositionSeq',
                    name: 'label.parent',
                    type: "selectSearch",
                    required:true,
                    rules: this.$formValidator.rules.required,
                    apiName: "position_query",
                    apiInput: "code",
                    apiParm: {action:"GET", 
                              nodeType: "SELF",
                              isLast: "1",
                              pageSize: 50, 
                              startPage: 1,
                             },
                    apiResult: {resultList: 'positionNodeModel', code: 'seq', name: 'code'},
                },  
                {
                    code:'child', 
                    hidden: 'childpositionSeq',
                    name: 'label.child',
                    type: "selectSearch",
                    required:true,
                    rules: this.$formValidator.rules.required,
                    apiName: "position_query",
                    apiInput: "code",
                    apiParm: {action:"GET", 
                              nodeType: "SELF",
                              isLast: "1",
                              pageSize: 50, 
                              startPage: 1,
                             },
                    apiResult: {resultList: 'positionNodeModel', code: 'seq', name: 'code'},
                },      
                {
                    code:'effectiveStartDate', 
                    name: 'label.effectedStartDate',
                    type: "date",
                    required:true,
                    rules: this.$formValidator.rules.required,
                    defaultValue:util.data().defaultStartDate,
                }, 
                {
                    code:'effectiveEndDate', 
                    name: 'label.effectedEndDate',
                    type: "date",
                    required:true,
                    rules: this.$formValidator.rules.required,
                    defaultValue:util.data().defaultEndDate,
                }, 
                {
                    code:'removeDate',
                    type: "hidden",
                    defaultValue:util.data().defaultEndDate,

                },
            ],


            tableData: [],
            isModify:false,
         
        };
    },



    created() {
        let {isModify}=this.$route.query;
        this.isModify=isModify;
        //alert(JSON.stringify (this.relationshipDetailForm.relationship));
        this.prepare();
    },


    methods: {
        getTitle(){
            if(!util.isEmpty(this.relationshipDetailForm.relationship.name)){
                this.$emit("getTitle", this.relationshipDetailForm.relationship.name);
            }
        },
        prepare() {
           
            if(!this.$isEmpty(this.$route.params.selectedRelationship)){
                this.relationshipDetailForm.relationship= this.$route.params.selectedRelationship;
                this.initData();
                this.getTitle();
            }
            
        },

        initData(){
            this.tableData=this.relationshipDetailForm.relationship.positionRelationModel.map(item => ({
                parent: item.parentModel.code,      
                child: item.childModel.code,
                positionRelationSeq: item.positionRelationSeq,
                parentpositionSeq: item.parentpositionSeq,
                childpositionSeq: item.childpositionSeq,      
                effectiveStartDate: item.effectiveStartDate.substring(0,10),
                effectiveEndDate: item.effectiveEndDate.substring(0,10),
                createDate: item.createDate.substring(0,10),
                removeDate: item.removeDate.substring(0,10),
            }));
        },

        async doRequest(param){
            try{
                let response=await this.$caller.relation_query(param);
                if(response.responseCode==="000"){
                    return response;
                }else{
                    return false;
                }
            }catch(e){
                this.$alert(e, {
                    confirmButtonText: "OK",
                });   
            }
        },

        async doSave(){
            if(!this.$refs.relationshipDetailForm.validate()){
                return;
            }
            let positionRelationTypeModel = this.relationshipDetailForm.relationship;
            positionRelationTypeModel.positionRelationModel = this.$refs.relationTable.tableDataEdit.map(item => ({
                    positionRelationSeq: item.positionRelationSeq,
                    parentpositionSeq: item.parentpositionSeq,
                    childpositionSeq: item.childpositionSeq,      
                    effectiveStartDate: item.effectiveStartDate.substring(0,10),
                    effectiveEndDate: item.effectiveEndDate.substring(0,10),
                    removeDate: item.removeDate.substring(0,10),
                }));;
             //alert(JSON.stringify (positionRelationTypeModel));
            let action = this.$isEmpty(this.relationshipDetailForm.relationship.dataTypeSeq)?'INSERT':'UPDATE';
            let param={
                action: action, 
                positionRelationTypeModel: positionRelationTypeModel,
            }

            let response=await this.doRequest(param);

            if(response){
                let dataTypeSeq="";
                if(action==="INSERT"){
                    dataTypeSeq = response.dataTypeSeq;
                }else{
                    dataTypeSeq = this.relationshipDetailForm.relationship.dataTypeSeq;
                }

                this.$alert(this.$t("message.saveSuccess"), this.$t("message.confirm"), {
                    confirmButtonText: "OK",
                });
                this.doGet(dataTypeSeq);
            }
        },

        async doGet(dataTypeSeq){
            let param={
                action:"GET",
                seq: dataTypeSeq,
                startPage: 1,
                pageSize: 1,
            };

            let response=await this.doRequest(param);

            if(response){
                this.relationshipDetailForm.relationship = response.positionRelationList[0];
                this.initData();
            }
        },

        async doRequest(param){
            try{
                let response=await this.$caller.relation_query(param);
                if(response.responseCode==="000"){
                    return response;
                }else{
                    return false;
                }
            }catch(e){
                this.$alert(e, {
                    confirmButtonText: "OK",
                });   
            }
        },

        doBack(){
            var link = "hierarchy_relationship";
            this.$router.replace({name: link});
        },
        

    },
};
</script>

<style lang="scss">
.relationshipdetail-collapse{
    .el-collapse-item__header{
        border-bottom: 0px solid #f5e8e8;
        margin: 46px 0 12px;
        padding-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .el-icon-arrow-right:before{
        content:'\25BC';
        color: #6b6b6b;
    }
    .el-collapse-item__arrow.is-active{
        transform: rotate(180deg);
        transition-duration:0.6s;
    }
}

</style>
