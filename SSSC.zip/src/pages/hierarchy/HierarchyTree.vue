<template>

        <gl-dialog
            @doCloseDialog="doCloseDialog"
            :dialogTableVisible = "dialogTableVisible"
        >

                <template slot="dialog-content">
                    <gl-tabs :tabPosition="'top'" style="margin-top:40px;" :v-model="1">
                        <el-tab-pane :label="$t('label.hierarchyTree')">
                            <gl-tree :data="treeData" :childrenSrc="fileSvg" :parentSrc="fileFolderSvg" :defaultExpandKeys="[Number(defaultExpandKeys)]"  :nodeKey="'id'" @goToDetail="doGoToDetail" ></gl-tree>
                        </el-tab-pane>
                    </gl-tabs> 
                </template> 

                <template slot="buttons">   
                    <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
                </template>
        </gl-dialog>


</template>
<script>
import fileFolder from '@/assets/images/fileFolder.svg';
import file from '@/assets/images/file.svg';

export default {
  name: 'HierarchyTree',
  props: ["dialogTableVisible"],
  data() {
    return {
        fileSvg: file,
        fileFolderSvg: fileFolder,
        treeData:[],
        defaultExpandKeys: 0,
        dialogTable: this.dialogTableVisible,
    };
  },

  created() {  
    this.initTreeData();
  },
  methods: {
    async initTreeData(){
        this.treeData=await this.$getGeneralList('hierarchyTree',this);
        this.defaultExpandKeys = this.treeData[0].id;
    },

    doCloseDialog(){
        this.$emit("doCloseDialog");
    },

    doGoToDetail(data){
        this.$emit("doGoToDetail", data);
    },
  },
};
</script>

<style lang="scss">

</style>


