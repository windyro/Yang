<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="relationshipForm" class="responsive-form" alias="relationshipForm" >

            <template slot="scroll">

                <div>
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch'>
                    </gl-search>
                </div>

                <!--span class="h6 float-right add-btn cursor-p" @click="addNew">+ add new</span-->
                <gl-object-table :data="tableData">
                    <el-table-column :label="$t(headerList[0].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-link type="primary" @click="toRelationshipDetail(scope.row, scope.$index)">{{scope.row.name}}</gl-link>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[1].name)" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.description}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[2].name)" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.active}}</span>
                        </template>
                    </el-table-column>

                </gl-object-table>

            </template>

            <template slot="pages">
                <gl-page :total="total" :currentPage="currentPage" :pageSize="pageSize" ref="glPage" :changePage="changePage" :changeSize="changeSize">
                </gl-page>
            </template>

            <template slot="buttons">   
                 <button class="btn-primary" @click.prevent="toRelationshipDetail(null,null)" v-if="isModify">{{$t('label.add')}}</button>
            </template>

        </aia-form>
    </section>
</div>
</template>

<script>
import util from "@/models/Utility";
export default {

    data() {
        return {
   
            headerList: [
                {
                    code: 'typeName',
                    name: 'label.type',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'description',
                    name: 'label.description',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'active',
                    name: 'label.active',
                    type: "select",
                    select: "yesNo",
                    optionList: [],
                },
            ],

            tableData: [],
            total:0,
            currentPage:1,
            pageSize:10,
            searchList:[],
            isModify:this.$checkPageModify(this.$route.name),
        };
    },



    created() {
        // alert(this.$route.name);
        this.$emit("getTitle", "");
        this.doSearch();
    },


    methods: {

        prepare() {

        },


        async doSearch(searchList=[],firstClick = true,page=1) {
            this.searchList=searchList;
            this.currentPage=page;

            let param={
                action:"GET",
                startPage: page,
                pageSize: this.pageSize,
            };

            // let {processingunit,businessunit}=this.$store.state.user.userInfo;
            // param.company=processingunit?processingunit:'';
            // param.channel=businessunit?businessunit:'';             

            searchList.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.code;
                    param[prop]=x.value;
                }
            });
            let response=await this.doRequest(param);

            if(response){
                let {positionRelationList,total}={...response};
                this.total=total;
                this.tableData=positionRelationList;
            }

        },

        async doRequest(param){
            try{
                let response=await this.$caller.relation_query(param);
                if(response.responseCode==="000"){
                    return response;
                }else{
                    return false;
                }
            }catch(e){
                this.$alert(e, {
                    confirmButtonText: "OK",
                });   
            }
        },

        toRelationshipDetail(row, index) {

            var detail = "hierarchy_relationship_detail";
            this.$router.push({
                name: detail,
                params: {
                    selectedRelationship: row,
                },
                query:{
                    isModify:this.isModify,
                },
            });
        },
        changePage(page) {
            this.currentPage=page;
            this.doSearch(this.searchList,true,page);
        },

        changeSize(size) {
            this.pageSize=size;
            this.doSearch(this.searchList,true,1);
        },

    },
};
</script>

<style lang="scss" scoped>
.view-Form {
    background: none;
    border: 0;
}

.email-style {
    width: 100%;

    span {
        display: inline-block;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        width: 100%;
    }
}
</style>
