<template>
    <div class="content-wrap">
        <section class="content-fluid margin-left-3xl margin-right-3xl">
            <aia-form class="responsive-form" alias="agencyForm" ref="agencyForm" :model="agencyForm" :rules="$formValidator.rules">
                <template slot="scroll">
                    <gl-version ref='glVersion' 
                        :currentVersion="currentVersion"
                        :versionData="versions"
                        :isModify="isModify"
                        @viewVersion="doViewVersion"
                        @removeVersion="doRemoveVersion"
                    >         
                    </gl-version>

                    <gl-tabs :tabPosition="'top'" style="margin-top:40px;" v-model="defaultTab">
                        <el-tab-pane :label="$t('label.entityInfo')" name="1">
                            <FieldList :fields="fields" :isEdit="newVersionStatus" :form="agencyForm.form" :getSelectedObjFunc="getSelectedObjFunc"/>
                        </el-tab-pane> 
                        <el-tab-pane :label="$t('label.hierarchyTree')" name="2">
                            <gl-tree :data="treeData" :childrenSrc="fileSvg" :parentSrc="fileFolderSvg" :currentKey="Number(query.seq)" :defaultExpandKeys="[Number(query.seq)]" :nodeKey="'id'" @goToDetail="goToDetail" class="agency-tree"></gl-tree>
                        </el-tab-pane>
                    </gl-tabs>                    
                </template>

                <template slot="buttons"> 
                    <button v-if="newVersionStatus" class="btn-primary" @click.prevent="save">{{$t('label.save')}}</button>
                    <button v-if="isModify&&!newVersionStatus" class="btn-primary" @click.prevent="newVersion">{{$t('label.new_version')}}</button>
                    <button class="btn-secondary" @click.prevent="back">{{$t('label.back')}}</button>
                </template> 
            </aia-form>
        </section>
    </div>
</template>
<script>
import FieldList from './FieldList';
import Export from '../result/Export';
import util from "@/models/Utility";
import fileFolder from '@/assets/images/fileFolder.svg';
import file from '@/assets/images/file.svg';
import createTree from '@/models/createTree';

export default {
    components:{
        FieldList,
        Export,
    },
    data(){
        return{
            fileSvg:file,
            fileFolderSvg:fileFolder,
            fields:[
                //{model:'positionModel',name:'entityType',label:'entityType', value:'',type: "select", required:true, optionList:this.$getGeneralList("entity", this),},
                {model:'participantModel',name:'agentCode',label:'agencyCode',value:'',type: "input", required:true,},
                {model:'participantModel',name:'lastName',label:'agencyName',value:'',type: "input",required:true,},
                {model:'positionModel',name:'title',label:'entityType',value:'',type: "select", required:true, optionList: this.$getGeneralList("agencyTitle", this)},
                {model:'positionModel',
                 name:'leaderCode',
                 label:'leaderCode',
                 value:'',
                 type: "selectSearch", 
                 required:false,
                 apiName: "position_query",
                 apiInput: "code",
                 apiParm: {action:"GET", 
                            recordType: "AGT",
                            nodeType: "SELF",
                            isLast: "1",
                            pageSize: 50, 
                            startPage: 1,
                          },
                 apiResult: {resultList: 'positionNodeModel', code: 'code', name: 'code'},
                },
                {model:"",name:'leaderName', label:'leaderName',value:'',type: "inputView",required:false,},
                {model:"",name:'leaderTitle',label:'leaderTitle',value:'',type: "selectView",required:false, optionList: this.$getGeneralList("title", this)},
                {model:'positionModel',
                 name:'managerAgency',
                 label:'managerCode',
                 value:'',
                 type: "selectSearch", 
                 required:false,
                 apiName: "position_query",
                 apiInput: "code",
                 apiParm: {action:"GET", 
                            recordType: "AGY",
                            nodeType: "SELF",
                            isLast: "1",
                            pageSize: 50, 
                            startPage: 1,
                          },
                 apiResult: {resultList: 'positionNodeModel', code: 'code', name: 'code'},
                },
                {model:"",name:'managerTitle',label:'managerTitle',value:'',type: "selectView", required:false, optionList: this.$getGeneralList("agencyTitle", this)},   
                {model:'participantModel',name:'postalCode',label:'agencyPostalCode',value:'',type: "input",required:true,},
                {model:'participantModel',name:'residentialAddress',label:'agencyAddress',value:'',type: "input",required:true,},
                {model:'participantModel',name:'agentTelephone',label:'agencyPhoneNumber',value:'',type: "input",required:true,},
                {model:'positionModel',name:'companyCode',label:'companyCode',value:'',type: "select",required:true,optionList:this.$getGeneralList("company", this),},
                {model:'positionModel',name:'businessUnit',label:'businessUnit',value:'',type: "select",required:true,optionList:this.$getGeneralList("channel", this),},
                //{name:'locationCode',value:'',required:true,},
                {model:'participantModel',name:'agentStatus',label:'entityStatus',value:'',type: "select",required:true,optionList:util.data().agentStateList,},
                {model:'versionModel',name:'effectiveStartDate',label:'effectiveStartDate',value:'',type:'date',required:true},
                {model:'versionModel',name:'effectiveEndDate',label:'effectiveEndDate',value:'',type:'date',required:true},
                {model:'versionModel',name:'createDate',label:'createDate',value:'',type:'inputView',},
                {model:'versionModel',name:'versionLog',label:'versionLog',value:'',type:'input',required:true,},

                {model:'positionModel',name:'managerSeq',value:'',type: "hidden", },
            ],
            entityModel:{},
            query: {},
            form:{},
            fieldData:[],
            headerList:[],
            versions:[],
            newVersionStatus:false,
            currentVersion:{},
            agencyForm:{
                form:{},
            },
            isModify:false,
            treeData:[],
            defaultTab:'1',
            attachTitle:[
                {code1:'leaderCode',code2:'leaderTitle',name:'Leader',agency:null,seq:null},
            ]
        };
    },
    created(){
        this.initForm(this.fields,this.agencyForm.form);
        this.query=this.$route.query;
        if(this.query.seq){
            let param={
                action:"GET",
                seq:this.query.seq,
                isLast:'1',                
            };
            this.doDetail(param);
            this.isModify=this.query.isModify;
        }else{
            this.getFieldNewEntity();
            this.doCopyVersion();
        }
        this.initTreeData();
    },
    methods:{
        async initTreeData(){
            this.treeData=await this.$getGeneralList('hierarchyTree',this);
        },
        initForm(info,form){
            info.forEach(x=>{
                this.$set(form,x.name,null);
            });
        },
        initAttachTitle(form){
            this.attachTitle.forEach(x=>{
                x.agency=form[x.code1];
                if(x.code2){
                    x.agency +='-'+form[x.code2];
                }
                x.seq=form.managerSeq;
            })
        },
        newVersion(){
            this.$confirm(this.$t("message.copyVersion"), this.$t("message.warning"), {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
              closeOnClickModal: false,
            })
            .then(() => {
                this.doCopyVersion();
            });
        },
        async doDetail(param){
            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';
            param.channel=businessunit?businessunit:''; 


            this.newVersionStatus=false;
            let agencyRes=await this.$caller.agency_query(param);
            if(agencyRes && agencyRes.responseCode==="000"){
                this.$refs['agencyForm']&&this.$refs['agencyForm'].resetFields();

                this.entityModel={...agencyRes.entityModel[0]};
                let agencyFields={...this.entityModel.participantModel,...this.entityModel.participantModel.versionModel,...this.entityModel.positionModel};

                agencyFields.effectiveStartDate = this.entityModel.participantModel.versionModel.effectiveStartDate.substring(0,10);
                agencyFields.effectiveEndDate = this.entityModel.participantModel.versionModel.effectiveEndDate.substring(0,10);
                agencyFields.createDate = this.entityModel.participantModel.versionModel.createDate.substring(0,10);
                agencyFields.removeDate = this.entityModel.participantModel.versionModel.removeDate.substring(0,10);

                this.currentVersion=this.entityModel.participantModel.versionModel;

                for(let p in agencyFields){
                    this.getFieldValue(p,agencyFields,this.fields,this.agencyForm.form);
                }


                this.getSelectedObjFunc("leaderCode",this.entityModel.leaderModel);
                this.getSelectedObjFunc("managerAgency",this.entityModel.managerAgencyModel);

                let versionParam={
                    action:"GET",
                    type:"ENTITY",
                    seq:param.seq,
                    startPage: 1,
                    pageSize: 50,
                    company:company?company:'',
                    channel:channel?channel:'',
                }
                let versionRes=await this.$caller.version_query(versionParam);
                let {versionModel,total}=versionRes;
                this.versions=versionModel;
            }

        },
        getFieldValue(pro,agencyfields,arr,form){
            let index=arr.findIndex(x=>x.name==pro);
            if(index>-1){
                form[pro]=agencyfields[pro];
            }
        },

        getFieldNewEntity(){
            this.entityModel.participantModel ={};
            this.entityModel.participantModel.versionModel ={};
            this.entityModel.positionModel ={};

           this.fields.forEach((element,index) =>{
                this.agencyForm.form[element.name]="";
                if(element.model ==="positionModel"){
                    this.entityModel.positionModel[element.name]="";
                }
                else if(element.model ==="participantModel"){
                    this.entityModel.participantModel[element.name]="";
                }
                else if(element.model ==="versionModel"){
                    this.entityModel.participantModel.versionModel[element.name]="";
                }
            });

            this.entityModel.participantModel.versionModel.removeDate="";
            this.entityModel.participantModel.versionModel.isLast="";
        },

        genFieldValue(){
            for(let p in this.agencyForm.form){
                //console.log(p);
                //console.log(JSON.stringify(p));
                if(p in this.entityModel.participantModel.versionModel){
                    this.entityModel.participantModel.versionModel[p] = this.agencyForm.form[p];
                }
                if(p in this.entityModel.participantModel){
                    this.entityModel.participantModel[p] = this.agencyForm.form[p];
                }
                if(p in this.entityModel.positionModel){
                    this.entityModel.positionModel[p] = this.agencyForm.form[p];
                }
            }
            this.entityModel.participantModel.seq = this.newVersionStatus ? "" : this.query.seq;
            this.entityModel.positionModel.agencyCode = this.entityModel.participantModel.agentCode;
            //console.log(JSON.stringify(this.entityModel));
        },

        save(){
            //this.genFieldValue();
            let valid=this.$refs['agencyForm'].validate();
            if(valid){
                this.saveAgency();
            }
        },
        doViewVersion(selectedVersion){
            this.newVersionStatus = false;
            let param={
                action:"GET",
                seq:this.query.seq,
                effectiveStartDate:selectedVersion.effectiveStartDate,    
                effectiveEndDate:selectedVersion.effectiveEndDate,              
            };
            this.doDetail(param);
        },
        async doRemoveVersion(selectedVersion){
            let param={
                action:"UPDATE",
                versionRequest: {
                    type:"ENTITY",
                    seq:this.query.seq,
                    effectiveStartDate:selectedVersion.effectiveStartDate,    
                    effectiveEndDate:selectedVersion.effectiveEndDate,      
                },   
                versionModel:{
                    removeDate: util.getNowDate(),
                },      
            };

            let response=await this.$caller.version_query(param);
            if(response && response.responseCode==="000"){
                let versionParam={
                    action:"GET",
                    type:"ENTITY",
                    seq:this.query.seq,
                    startPage: 1,
                    pageSize: 50,
                }
                let versionRes=await this.$caller.version_query(versionParam);
                let {versionModel,total}=versionRes;
                this.versions=versionModel;
            }
        },

        async saveAgency(){
            try{
                this.genFieldValue();
                
                let param={
                    action:'INSERT',
                    entityModel:this.entityModel,
                }
                let response=await this.$caller.agency_query(param);
                if(response && response.responseCode==="000"){
                    this.query.seq = response.participantSeq;
                    this.$alert(this.$t("message.saveSuccess"), this.$t("message.confirm"), {
                        confirmButtonText: "OK",
                    });
                    let param={
                        action:"GET",
                        seq:this.query.seq,
                        isLast:'1',                
                    };
                    this.doDetail(param);
                    this.newVersionStatus = false;
                }

            }catch(e){
                console.log(e);
            }
        },
        back(){
            this.$router.replace({name:'hierarchy_agency',});
            //let {lastRouter}=this.$route.query;
            //this.$router.replace({name:lastRouter});
        },

        doCopyVersion(){
            this.newVersionStatus=true;
            this.agencyForm.form.effectiveStartDate = this.$isEmpty(this.query.seq)?util.data().defaultStartDate:"";
            this.agencyForm.form.effectiveEndDate = util.data().defaultEndDate;
            this.agencyForm.form.createDate=util.getNowDate();
            this.agencyForm.form.removeDate = util.data().defaultEndDate;
            // console.log(this.agencyForm.form);
        },

        getSelectedObjFunc(itemName, obj){
            if(this.$isEmpty(obj)){
                return;
            }
            if(itemName==="leaderCode"){
                this.agencyForm.form.leaderName = (this.$isEmpty(obj.firstName)?"":(obj.firstName+ " "))
                +(this.$isEmpty(obj.middleName)?"":(obj.middleName+ " "))
                +(this.$isEmpty(obj.lastName)?"":obj.lastName);

                this.agencyForm.form.leaderTitle = obj.title;
            }
            else if(itemName==="managerAgency"){
                this.agencyForm.form.managerTitle = obj.title;
                this.agencyForm.form.managerSeq = obj.seq;
            }
            //alert(itemName + ":  " +JSON.stringify(obj));
        },

        goToDetail(data){
            let {id,recordType,leaderCode,isLeader}=data;

            this.defaultTab='1';
            let param={
                action:"GET",
                seq:id,
                isLast:'1',     
            };

            if(recordType=='AGY'&&!isLeader){
                this.doDetail(param);
            }
            if(recordType=='AGT'||isLeader){
                this.$router.replace({
                    name:'agent_detail',
                    query:{
                        seq:!isLeader?id:null,
                        isModify:this.isModify,
                        agentCode:isLeader?leaderCode:null,                        
                    }
                });
            }                

        },
    },
}
</script>
