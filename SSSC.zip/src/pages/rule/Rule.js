import util from "@/models/Utility";
export default{

    data() {
        return {
        }

    },

    convertRuleDetail(row, colIndex, instance, summaryType){

        var detail = row.detail[colIndex];
        var resultStr ="";

        let summaryList = summaryType == "MEASUREMENT"?instance.$getGeneralList("measurement", instance):instance.$getGeneralList("summary", instance); 
        summaryList = summaryList.concat(instance.$getGeneralList("function", instance));
        summaryList = summaryList.concat(instance.$getGeneralList("functionMeasurement", instance))
        if(util.isEmpty(detail.criteria) && util.isEmpty(detail.value) && util.isEmpty(detail.codemap)){ // new item
            return resultStr;
        }
    
        if(detail.type =="variable"){
            resultStr = this.codeToName(detail.criteria,summaryList);
            if(!util.isEmpty(detail.value)){
                resultStr += " is " + detail.value;
            }
        }

        else if(detail.type == "formula"){

            resultStr = detail.value;
        }

        else if(detail.type == "label"){

            resultStr = detail.value;
        }
        
        else if (detail.type =="condition" ){
            //condition   
            let comparisonName = {};
            comparisonName = util.data().comparisonNameList.find((item)=>{
            return item.code === detail.codemap;      }); 
            if(util.isNull(comparisonName)){
                return "Can't find comparisonName";
            }

            let valueData = this.convertOptionName(detail.criteria, detail.value, instance,summaryType);  
            let functionParametersStr =  instance.$isEmpty(detail.functionParameters)?"":"(" + detail.functionParameters + ")";         
            resultStr = this.codeToName(detail.criteria,summaryList)+ " " 
                    + functionParametersStr + " "
                    + instance.$t(comparisonName.name) + " "
                    + valueData;
        }
    
        return resultStr;

    },

    codeToName(code, optionList){
        if(!optionList){
            return"";
        }   
      
        if(code==""){
            return"";
        }

        let obj = {};  
        obj = optionList.find((item)=>{
        return item.code === code;      }); 
        if(obj){
            return obj.name;
        }
        return "";
    },

    nameToCode(name,optionList){
        if(!optionList){
            return"";
        }   
      
        if(name==""){
            return"";
        }

        let obj = {};  
        obj = optionList.find((item)=>{
        return item.name === name;      }); 
        if(obj){
            return obj.code;
        }
        return "";
    },

    convertOptionName(criteria, value, instance,summaryType){

            var resultStr =value;
            let summary = {};
            let summaryList = summaryType == "MEASUREMENT"?instance.$getGeneralList("measurement", instance):instance.$getGeneralList("summary", instance); 
            summaryList = summaryList.concat(instance.$getGeneralList("function", instance));
            summaryList = summaryList.concat(instance.$getGeneralList("functionMeasurement", instance))

            summary = summaryList.find((item)=>{
                return item.code === criteria;    }); 
                if(util.isNull(summary)){
                    return "Can't find summary field";
            }


            if(summary.type == "select"){

                var codes = resultStr.split(","); 
                resultStr="";
                summary.optionList.forEach(item=>{
                    if (codes.indexOf(item.code) != -1){
                        resultStr = resultStr + item.name + ",";
                    }
                });

                if(util.isEmpty(resultStr)){
                    return "Can't find option list";
                }

                resultStr = resultStr.substring(0, resultStr.length-1);
            }
            return resultStr;
    },

    getVariableList(header){
        
        var result = [];
        header.forEach(element=>{
            if(element.type == "variable"){
                result.push({code: element.name, name: element.name});
            }
        });  

        return result;
    },

    getSummarySelected(criteria,instance){

        var summaryList = instance.$getGeneralList("summary", instance);
        return summaryList.find((item)=>{
            return item.code === criteria; 
       });

    },
    
}