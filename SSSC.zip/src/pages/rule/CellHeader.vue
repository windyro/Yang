<template>

    <aia-el-form alias="ruleHeaderDialog" ref="ruleHeaderForm" :model="ruleHeaderForm" :rules="$formValidator.rules">
        <gl-dialog
          @doCloseDialog="doCloseDialog"
          :dialogTableVisible = "dialogTableVisible"
        >
              <template slot="dialog-title">
                      <gl-object-table :data="ruleHeaderForm.editData">
                          <el-table-column  :label="$t('label.name')" width="auto">
                          <template slot-scope="scope">
                              <el-form-item :prop="'editData.' + scope.$index + '.name'" :rules="$formValidator.rules.detailHeader">
                                  <el-input  v-model="scope.row.name"></el-input>
                              </el-form-item>
                          </template>
                          </el-table-column>

                          <el-table-column  :label="$t('label.type')" width="auto">
                          <template slot-scope="scope">
                                  <gl-select  :prop="'editData.' + scope.$index + '.type'" 
                                              :rules="$formValidator.rules.required"
                                              :edit="true" 
                                              v-model="scope.row.type" 
                                              :valueData="scope.row.type" 
                                              :optionList="typeOptionList">
                                  </gl-select>
                          </template>
                          </el-table-column>
                      </gl-object-table>
              </template>
                      

              <template slot="buttons">   
                  <button class="btn-primary"  @click.prevent="doneEdit">{{$t('label.done')}}</button>
                  <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
              </template>
        </gl-dialog>
    </aia-el-form>
</template>
<script>
import util from "@/models/Utility";
import rulejs from "./Rule";
export default {
  name: 'RuleHeader',
  props: ["dialogTableVisible", "headerData"],
  data() {
    return {
      typeOptionList: util.data().cellTypeList,
      ruleHeaderForm: {editData: []},
      dialogTable: this.dialogTableVisible,

    };
  },
  mounted() {

  },
  created() {  
      
      this.ruleHeaderForm.editData.push(JSON.parse(JSON.stringify(this.$props.headerData[0])));
      //alert(JSON.stringify(this.editData));
  },
  methods: {

    doCloseDialog(){
        this.$emit("doCloseDialog", this.dialogTable);
    },

    doneEdit(){
        if(!this.$refs.ruleHeaderForm.validate()){
            return;
        }
        this.$emit("doDoneEditHeader", this.ruleHeaderForm.editData[0]);
    },

  },
};
</script>

<style lang="scss">

</style>


