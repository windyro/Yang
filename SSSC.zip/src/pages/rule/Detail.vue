<template>

    <div class="content-wrap">
            <section class="content-fluid margin-left-3xl margin-right-3xl">
                <aia-form
                ref="ruleForm"
                class="responsive-form"
                alias="rule_verify"
                >

                    <template slot="scroll">
                        <gl-tabs  tabPosition="top">
                            <el-tab-pane :label="$t('label.basic')" >

                                    <gl-object-table :data="tableData">
                                        <el-table-column  v-for="(column, colIndex) in headerEdit" :key="colIndex" width="auto" >
                                            <template slot="header" slot-scope="scope">
                                                <div class="header-pos">
                                                    <span>{{column.name}}</span>
                                                </div>
                                                <div class="dropdown-header-pos">
                                                    <gl-dropdown 
                                                                :Edit="$t('label.edit')" @doEdit="doEditHeader(colIndex)" 
                                                                :Add="$t('label.add_column')" @doAdd="doAddColumn(colIndex)"
                                                                :Add2="$t('label.add_row')" @doAdd2="doAddRow(-1)"
                                                                :Delete="$t('label.delete_column')" @doDelete="doDeleteColumn(colIndex)"
                                                                >
                                                    </gl-dropdown>
                                                </div>
                                            </template>
                                            <template slot-scope="scope">
                                                <div>
                                                    <!--span >{{scope.row.detail[colIndex].value}}</span-->
                                                    <span class="bt5">{{convertRuleDetail(scope.row, colIndex)}}</span>
                                                </div>
                                                <div class="dropdown-pos">
                                                    <gl-dropdown :Edit="$t('label.edit')" @doEdit="doEdit(colIndex, scope.$index)"
                                                                :Copy="$t('label.copy')" @doCopy="doCopy(colIndex, scope.$index)"
                                                                :Paste="$t('label.paste')" @doPaste="doPaste(colIndex, scope.$index)"
                                                                :Add="$t('label.add_column')" @doAdd="doAddColumn(colIndex)"
                                                                :Add2="$t('label.add_row')" @doAdd2="doAddRow(scope.$index)"
                                                                :Delete="$t('label.delete_column')" @doDelete="doDeleteColumn(colIndex)"
                                                                :Delete2="$t('label.delete_row')" @doDelete2="doDeleteRow(scope.$index)"
                                                                >
                                                    </gl-dropdown>
                                                </div>
                                            </template>
                                        </el-table-column>
                                    </gl-object-table >
                            </el-tab-pane>
                  

                            <el-tab-pane :label="$t('label.advanced')"  >
                                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 20px; padding-left: 0px;">
                                        <label><h6>{{$t("label.hold")}}</h6></label>
                                        <gl-select v-model="ruleGroupModel.holdFlag" :valueData="ruleGroupModel.holdFlag"  :edit="true"  type="other" :optionList="holdList">
                                        </gl-select>
                
                                    </el-col> 
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 0px; padding-left: 0px;">
                                        <br/>
                                        <br/>
                                        <span class="bt5"><i>If On hold flag set to true, No payment for this calculation</i></span>
                                    </el-col>
                                </el-row>

                                 <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 20px; padding-left: 0px;">
                                        <label><h6>{{$t("label.period")}}</h6></label>
                                        <gl-select v-model="ruleGroupModel.periodType" :valueData="ruleGroupModel.periodType"  :edit="true"  type="other" :optionList="periodTypeList">
                                        </gl-select>
                
                                    </el-col> 
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 0px; padding-left: 0px;">
                                        <br/>
                                        <br/>
                                        <span class="bt5"><i>The period frequency of calculated measurement result used as input.</i></span>
                                    </el-col>   
                                </el-row>       

                                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 20px; padding-left: 0px;">
                                        <label><h6>{{$t("label.periodIndex")}}</h6></label>
                                        <gl-select v-model="ruleGroupModel.periodIndex" :valueData="ruleGroupModel.periodIndex"  :edit="true"  type="other" :optionList="periodIndexList">
                                        </gl-select>
                
                                    </el-col> 
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 0px; padding-left: 0px;">
                                        <br/>
                                        <br/>
                                        <span class="bt5"><i>The period slot used as input, e.g. 0 means current, -1 means last</i></span>
                                    </el-col>   
                                </el-row>             

                                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 20px; padding-left: 0px;">
                                        <label><h6>{{$t("label.ruleType")}}</h6></label>
                                        <gl-select v-model="ruleGroupModel.ruleType" :valueData="ruleGroupModel.ruleType"  :edit="true"  type="other" :optionList="ruleTypeList">
                                        </gl-select>
                
                                    </el-col> 
                                    <el-col :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 0px; padding-left: 0px;">
                                        <br/>
                                        <br/>
                                        <span class="bt5"><i></i></span>
                                    </el-col>   
                                </el-row>                                               
                            </el-tab-pane>
     
                           </gl-tabs>

                            <rule-cell
                            :conditionData="conditionData"
                            :variableList="variableList"
                            :ruleGroupModel="ruleGroupModel"
                            :dialogTableVisible = "dialogTableVisible"
                            v-if="dialogTableVisible"
                            @doCloseDialog="doCloseDialog"
                            @doDoneEdit = "doDoneEdit"
                           >
                           </rule-cell>

                           <rule-header
                            :headerData="headerData"
                            :dialogTableVisible = "dialogHeaderVisible"
                            v-if="dialogHeaderVisible"
                            @doCloseDialog="doCloseHeaderDialog"
                            @doDoneEditHeader = "doDoneEditHeader"
                           >
                           </rule-header>      
                    </template>


                    <template slot="buttons">   
                            <button class="btn-primary" @click.prevent="doSave" v-if="isModify">{{$t('label.save')}}</button>
                            <button class="btn-primary" @click.prevent="doVerify">{{$t('label.verify')}}</button>
                            <button class="btn-secondary" @click.prevent="doBack">{{$t('label.back')}}</button>
                    </template>

 
                </aia-form>

             </section>
        </div>

</template>


<script>
import util from "@/models/Utility";
import rulejs from "./Rule";
import RuleCell from "./Cell";
import RuleHeader from "./CellHeader";
export default {
    components:{
        RuleCell,
        RuleHeader,
    },
    data(){
        return{
            tableData: [],
            ruleForm: {name: "ss"},
            headerEdit:  [],
            headerData: [{name: '',  type: ""}],
            variableList: [],
            copyCell: null,
            dialogTableVisible: false,
            dialogHeaderVisible: false,
            conditionData: [{name: '',  type: "", criteria: '', codemap: '', value: ''}],
            nowRowIndex: null,
            nowColIndex: null,
            ruleGroupModel: {},
            ruleGroupModelId: null,

            periodTypeList:  util.data().periodTypeList,
            periodIndexList:  util.data().periodIndexList,
            holdList: util.data().holdList,
            ruleTypeList:util.data().ruleTypeList,
            isModify:this.$checkPageModify(this.$route.name),
        };

    },
    created() { 
        this.tableData = [];  
        this.headerEdit = []; 
        this.prepare();
    },


  methods: {
      getTitle(){
          //alert("Detail: " + this.$route.params.rule.name);
          if(!util.isEmpty(this.ruleGroupModel.name)){
             this.$emit("getTitle", this.ruleGroupModel.name);
          }
      },

      prepare(){
        if(this.ruleGroupModelId == null){
            this.ruleGroupModelId = this.$route.params.rule.ruleGroupModelId;
        }

        if(this.$isEmpty(this.ruleGroupModelId) ){
            this.generateNewRule();
        }else{
            this.getRuleDetail();
        }            
        //this.initAdvanceSetting();
                    
           
      },

      initAdvanceSetting(){
          //this.$set(this.ruleGroupModel, "hold", "N");
      },

      async getRuleDetail(){

            var param = {
                startPage: "1",
                pageSize: "1",
                ruleGroupModelId: this.ruleGroupModelId,
                action: 'GET',
            }; 
            try{

                var res = await util.getRuleSummaryList(this,1,1,param);    

                if (res.responseCode =="000"){
                    
                    this.ruleGroupModel = res.ruleGroupModel[0];
                    this.getTitle();

                    if(!this.$isEmpty(this.ruleGroupModel.ruleDetailModelList)){

                        //each row
                        this.ruleGroupModel.ruleDetailModelList.forEach(row =>{

                            this.tableData.push({
                                id: row.ruleDetailModelId,
                                detail: [],
                            });
                            // alert(JSON.stringify(row));
                            //condition type
                            if(row.ruleModelList){
                                row.ruleModelList.forEach(col =>{
                                    this.tableData[this.tableData.length-1].detail.push({
                                        name: col.name,
                                        type: "condition", 
                                        codemap: col.ruleTemplateId,
                                        criteria: col.criteriaKey,
                                        value: col.criteriaValue,
                                        //operator: col.operator,
                                        functionParameters: col.functionParameters,
                                        complicatedModelInd: col.complicatedModelInd,
                                    });
                                });

                            }

                            //customized type
                            if(row.customizedModel){
                                row.customizedModel.forEach(col =>{
                                    this.tableData[this.tableData.length-1].detail.push({
                                        name: col.key,
                                        type: "label", 
                                        codemap: "",
                                        criteria: "",
                                        value: col.value,
                                    });
                                });                                  
                            }
                            
                            //variable type
                            if(row.calculateModel.parameters){
                                row.calculateModel.parameters.forEach(col =>{
                                    this.tableData[this.tableData.length-1].detail.push({
                                        name: col.name,
                                        type: "variable", 
                                        codemap: "",
                                        criteria: col.criteriaKey,
                                        value: col.criteriaValue,
                                    });
                                });                                  
                            }
                            //formula type
                            if(!this.$isEmpty(row.calculateModel.algorithm)){
                                this.tableData[this.tableData.length-1].detail.push({
                                    name: row.calculateModel.name,
                                    type: "formula", 
                                    codemap: "",
                                    criteria: "Formula",
                                    value: row.calculateModel.algorithm,
                                });
                            };
                        });//each row
                        
                    }
                }
            }catch(e){

            }


            if(this.tableData.length > 0) {
                this.tableData[0].detail.forEach(element =>{
                    this.headerEdit.push({name: element.name, type: element.type});
                });
            }      
            else if(this.tableData.length==0){ //it is a new rule

                let criteriaData = this.$route.params.rule.criteriaData;
                let lastRouter = this.$route.params.rule.lastRouter;
                if(!this.$isEmpty(criteriaData) ){
                  this.generateNewRuleContest(criteriaData.basic.kpi);
                }else{
                  this.generateNewRule();
                }
            }

      },

      generateNewRule(){
            this.headerEdit.push({name: "Relationship", type: "condition"});
            this.headerEdit.push({name: "Variable", type: "variable"});
            this.headerEdit.push({name: "Formula", type: "formula"});
      },

      generateNewRuleContest(kpi){
            this.headerEdit.push({name: "Tier Code", type: "label"});
            this.headerEdit.push({name: "Tier Name", type: "label"});
            if(!this.$isEmpty(kpi)){
                let kpiList = this.$getGeneralList('kpi',this);
                kpi.forEach(x => {
                    let kpiIndex = kpiList.findIndex(y=>y.code==x.name);
                    let kpiName = kpiList[kpiIndex].name
                    this.headerEdit.push({name: kpiName, type: "condition"});
                })
                this.doAddRow(0);
                
                this.tableData[0].detail[0].value='1';
                this.tableData[0].detail[1].value='Platinum Club';

                kpi.forEach((x,index) => {
                    this.tableData[0].detail[2+index].criteria=x.name;
                    this.tableData[0].detail[2+index].codemap='T_EQUAL';
                })
              // alert(JSON.stringify(this.tableData[0].detail));
            }
           
                
      },

      generateRuleDetail(){
          if(this.tableData.length==0){
              return;
          }
          this.ruleGroupModel.ruleDetailModelList=[];

          this.tableData.forEach(row =>{//each row
                
                this.ruleGroupModel.ruleDetailModelList.push({
                    ruleModelList: [],
                    calculateModel: {parameters:[], algorithm: null, name: null},
                    customizedModel: [],
                });

                var index = this.ruleGroupModel.ruleDetailModelList.length-1
                row.detail.forEach(col =>{//each col
                     if(!this.$isEmpty(col.name) && !this.$isEmpty(col.type))
                     {
                        if(col.type=="condition"){
                            this.ruleGroupModel.ruleDetailModelList[index].ruleModelList.push({
                                    name: col.name,
                                    criteriaKey: col.criteria,
                                    criteriaValue: col.value,
                                    ruleTemplateId: col.codemap,
                                    functionParameters: col.functionParameters,
                                    complicatedModelInd: col.complicatedModelInd,
                            });
                        }

                        else if(col.type=="label"){
                            this.ruleGroupModel.ruleDetailModelList[index].customizedModel.push({
                                    key: col.name,
                                    value: col.value,
                                    type: "LABEL",
                            }); 
                        }
                        
                        else if(col.type=="variable"){
                            this.ruleGroupModel.ruleDetailModelList[index].calculateModel.parameters.push({
                                    name: col.name,
                                    criteriaKey: col.criteria,
                                    criteriaValue: col.value,
                            });
                        }
                        else if(col.type=="formula"){
                            this.ruleGroupModel.ruleDetailModelList[index].calculateModel.name=col.name;
                            this.ruleGroupModel.ruleDetailModelList[index].calculateModel.algorithm = col.value;
                        }
                     }
                });
          });//each row

          //alert(JSON.stringify(this.ruleGroupModel));
          this.$confirm(this.$t("message.toSave"), this.$t("message.confirm"), {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
              closeOnClickModal:false,
            })
            .then(() => {
              var param = {
                action: 'UPDATE',
                ruleGroupModel: this.ruleGroupModel,
              }
            console.log('param:',param);


              this.$caller.rule_summary_query(param).then(res => {
                  if(res.responseCode=="000"){
                      this.tableData = [];  
                      this.headerEdit = []; 
                      this.getRuleDetail();
                  }
              });
             })
            .catch(() => {});

          
      },

      doCloseDialog(){
          this.dialogTableVisible = false;
      },

      doCloseHeaderDialog(){
          this.dialogHeaderVisible = false;
          this.$nextTick(() => {
              this.$forceUpdate();
          });
      },

      doDoneEdit(editData){
         // this.tableData[this.nowRowIndex].detail[this.nowColIndex] = JSON.parse(JSON.stringify(editData));
          this.$set(this.tableData[this.nowRowIndex].detail, this.nowColIndex, JSON.parse(JSON.stringify(editData)));
          this.dialogTableVisible = false;
          this.$nextTick(() => {
              this.$forceUpdate();
          });
      },

      doDoneEditHeader(editData){
          this.$set(this.headerEdit, this.nowColIndex, JSON.parse(JSON.stringify(editData)));
          this.$nextTick(() => {
              this.$forceUpdate();
          });

          this.tableData.forEach(element=>{
            element.detail[this.nowColIndex].name = this.headerEdit[this.nowColIndex].name;
            element.detail[this.nowColIndex].type = this.headerEdit[this.nowColIndex].type;
            //this.$set(element.detail, colIndex, attr); 
          }); 
          this.dialogHeaderVisible = false;
      },      
      
      doEdit(colIndex, rowIndex){
          if(util.isEmpty(this.headerEdit[colIndex].name) || util.isEmpty(this.headerEdit[colIndex].type) ){
            this.$alert(this.$t("message.defineNameType"), this.$t("message.error"), {
                confirmButtonText: "OK",
            });
            return;
          }

          
          this.nowRowIndex =rowIndex;
          this.nowColIndex =colIndex;
          this.conditionData[0] = this.tableData[this.nowRowIndex].detail[this.nowColIndex];
          this.variableList = rulejs.getVariableList(this.headerEdit);
          this.dialogTableVisible = true;
      },

      doEditHeader(colIndex){
          
         // this.nowRowIndex =rowIndex;
          this.nowColIndex =colIndex;
          this.headerData[0] = this.headerEdit[this.nowColIndex];
          this.dialogHeaderVisible = true;
      },

      doCopy(colIndex, rowIndex){
          this.copyCell = this.tableData[rowIndex].detail[colIndex];
          //alert("doCopy " + JSON.stringify(this.copyCell));
      },

      doPaste(colIndex, rowIndex){
          if(util.isEmpty(this.headerEdit[colIndex].name) || util.isEmpty(this.headerEdit[colIndex].type) ){
            this.$alert(this.$t("message.defineNameType"), this.$t("message.error"), {
                confirmButtonText: "OK",
            });
            return;
          }

          if(!this.copyCell){
              return;
          }
          var attr = this.copyCell;
          this.$set(this.tableData[rowIndex].detail, colIndex, attr);
      },

      doAddColumn(colIndex){
            
            this.tableData.forEach(element=>{
                var newCol =  {name: '',  type: "", criteria: '', codemap: '', value: ''};
                element.detail.splice(colIndex+1, 0, newCol);
            }); 

            this.headerEdit.splice(colIndex+1, 0, { name: '',  type: ""}); 
            this.$nextTick(() => {
                this.doEditHeader(colIndex+1);
            });
            
            //alert(JSON.stringify(this.headerEdit));
      },

      doAddRow(rowIndex){
            var newRow = {id: "", detail: []};

            this.headerEdit.forEach(element=>{
                var newCol =  {name: element.name,  type: element.type, criteria: '', codemap: '', value: ''};
                newRow.detail.push(newCol);
            });            

            this.tableData.splice(rowIndex+1, 0, newRow);
      },

      doDeleteColumn(colIndex){
            this.tableData.forEach(element=>{
                element.detail.splice(colIndex, 1);
            }); 

            this.headerEdit.splice(colIndex, 1); 
            this.$nextTick(() => {
              this.$forceUpdate();
            });
      },

      doDeleteRow(rowIndex){
            this.tableData.splice(rowIndex, 1);
      },

      doBack(){
            let lastRouter = this.$route.params.rule.lastRouter;
            let link = "rule_summary";
            if(lastRouter=="master_information"){
                link = "master_information";
            }else{
                link = "rule_summary";
            }
            
            this.$router.replace({name: link, params: {rule: this.ruleGroupModel }});
      },

      doSave(){
            this.generateRuleDetail();
      },

      doVerify(){
          var verify = "rule_verify";
          this.$router.push({name: verify, params: {tableData: this.tableData, rule: this.ruleGroupModel } });
      },

      convertRuleDetail(row, colIndex){
          return rulejs.convertRuleDetail(row, colIndex,this,this.ruleGroupModel.summaryType);
      },

   },
};
</script>

<style lang="scss" scoped>
.el-button--text {
    color: #fff;
}
.dropdown-pos{
    text-align: right;
    width: auto;
    right: 0px;
    bottom: 0px;
    position: absolute;
}

.header-pos{
    // display: block;
    // line-height: 25px;
    display: inline-block;
    line-height: 25px;
    padding-left: 0px;
}
.dropdown-header-pos{
    // text-align: right;
    // vertical-align: bottom;
    // width: auto;
    // right: 0px;
    // bottom: 0px;
    // position: relative;
    // display: block;
    // height: 25px;
    width: auto;
    right: 0px;
    bottom: 0px;
    position: absolute;
    height: 25px;
}
</style>
