<template>
    <div class="content-wrap">
            <section class="content-fluid margin-left-3xl margin-right-3xl">
                <aia-form
                ref="ruleForm"
                class="responsive-form"
                alias="rule_verify"
                >
                    <template slot="scroll">
                        <gl-object-table :data="tableData"  :span-method="spanMethod" >
                            <el-table-column  v-for="(column, colIndex) in headerEdit" :key="column.id" width="auto">
                                <template slot="header" slot-scope="scope">
                                    <span>{{column.name}}</span>
                                </template>

                                <template slot-scope="scope"> 
                                    <div v-if="scope.$index % 2==0">
                                       <span v-if="scope.row.detail[colIndex].type!='result'" class="bt5">{{convertRuleDetail(scope.row, colIndex)}}</span>
                                       <span v-else-if="scope.row.detail[colIndex].type=='result'" class="bt5">{{scope.row.detail[colIndex].value}}</span>
                                    </div>
                                    <div v-else-if="scope.$index % 2 ==1">
                                        <el-input v-if="scope.row.detail[colIndex].type!='result'
                                                     && scope.row.detail[colIndex].type!='formula'
                                                     && scope.row.detail[colIndex].summarySelected.type == 'input'" 
                                                     v-model="scope.row.detail[colIndex].valueData">
                                        </el-input>
                                         <gl-select  v-else-if="scope.row.detail[colIndex].type!='result'
                                                     && scope.row.detail[colIndex].type!='formula'
                                                     && scope.row.detail[colIndex].summarySelected.type == 'select'" 
                                                     type="other"
                                                     v-model="scope.row.detail[colIndex].valueData"
                                                     :valueData="scope.row.detail[colIndex].valueData"
                                                     :optionList="scope.row.detail[colIndex].summarySelected.optionList">
                                         </gl-select>    

                                         <el-date-picker v-else-if="scope.row.detail[colIndex].type!='result'
                                                     && scope.row.detail[colIndex].type!='formula'
                                                     && scope.row.detail[colIndex].summarySelected.type == 'date'" 
                                                     v-model="scope.row.detail[colIndex].valueData"
                                                     type="date"
                                                     placeholder="Please select"
                                                     value-format="yyyy-MM-dd"
                                                     clearable
                                                     :editable="true">
                                         </el-date-picker>

                           
                                    </div>
                                </template>

                            </el-table-column>
                        </gl-object-table >  
                    </template>

                    <template slot="buttons">   
                            <button class="btn-primary" @click.prevent="doVerify">{{$t('label.verify_result')}}</button>
                            <button class="btn-secondary" @click.prevent="doBack">{{$t('label.back')}}</button>
                    </template>
                </aia-form>
             </section>
        </div>
</template>


<script>
import util from "@/models/Utility";
import rulejs from "./Rule";
export default {
    data(){
        return{
            tableDataInput: [],
            tableData: [],
            

            headerEdit:  [],
            ruleGroupModel: null,
            ruleGroupModelId: null,
        };

    },
    created() {   
        this.prepare();
        //this.getTitle();
        
    },


  methods: {
      getTitle(){
          if(!util.isEmpty(this.ruleGroupModel.name)){
             this.$emit("getTitle", this.ruleGroupModel.name);
          }
      },

      prepare(){
            if(this.ruleGroupModelId == null){
                 this.ruleGroupModelId = this.$route.params.rule.ruleGroupModelId;
            }
            this.getRuleDetail();
            // //alert(this.convertRuleDetail(this.tableData[0], 0));
            // this.$route.params.tableData.forEach((rowElement, rowIndex) =>{

            //         this.tableData.push({id: rowElement.id, detail: []}); //1st row
            //         this.tableData.splice(rowIndex+2, 0, {id: rowElement.id, detail: []}); //2nd row
                                      
            //         rowElement.detail.forEach((colElement,colIndex) =>{                        
            //             //1st row
            //             this.tableData[this.tableData.length-2].detail.push({
            //                 name: colElement.name,
            //                 type: colElement.type,
            //                 criteria: colElement.criteria,
            //                 codemap: colElement.codemap,
            //                 value: colElement.value
            //             }); 

            //             //2nd row
            //             this.tableData[this.tableData.length-1].detail.splice(colIndex+1, 0, {
            //                 type: colElement.type,
            //                 criteria: colElement.criteria, 
            //                 summarySelected: rulejs.getSummarySelected(colElement.criteria, this), 
            //                 valueData: colElement.value
            //             }); 
                          
            //         });

              
            //     var resultCol =  {name: 'Result', type: "result", code: '', value: '', valueData: ''};    

            //     this.tableData[this.tableData.length-2].detail.push(resultCol); 
            //     this.tableData[this.tableData.length-1].detail.push(resultCol); 
            // });
        
            // this.tableData[0].detail.forEach(element =>{
            //     this.headerEdit.push({name: element.name});
            // });

            // //alert(JSON.stringify(this.tableData[0].detail));
      },

      async getRuleDetail(){

            var param = {
                startPage: "1",
                pageSize: "1",
                ruleGroupModelId: this.ruleGroupModelId,
                action: 'GET',
            }; 
            try{

                var res = await util.getRuleSummaryList(this,1,1,param);    

                if (res.responseCode =="000"){
                    
                    this.ruleGroupModel = res.ruleGroupModel[0];
                    this.getTitle();
                    if(!this.$isEmpty(this.ruleGroupModel.ruleDetailModelList)){

                        //each row
                        this.ruleGroupModel.ruleDetailModelList.forEach(row =>{

                            this.tableData.push({id: row.ruleDetailModelId, detail: []}); //1st row
                            this.tableData.push({id: row.ruleDetailModelId, detail: []}); //2nd row
 
                            row.ruleModelList.forEach(col =>{
                                //1st row
                                this.tableData[this.tableData.length-2].detail.push({
                                    name: col.name,
                                    type: "condition",
                                    codemap: col.ruleTemplateId,
                                    criteria: col.criteriaKey,
                                    value: col.criteriaValue,
                                }); 

                                //2nd row
                                this.tableData[this.tableData.length-1].detail.push({
                                    type: "condition",
                                    criteria: col.criteriaKey, 
                                    summarySelected: rulejs.getSummarySelected(col.criteriaKey, this), 
                                    valueData: col.criteriaValue,
                                }); 
                            });

                            //variable type
                            row.calculateModel.parameters.forEach(col =>{

                               //1st row
                                this.tableData[this.tableData.length-2].detail.push({
                                    name: col.name,
                                    type: "variable",
                                    codemap: "",
                                    criteria: col.criteriaKey,
                                    value: col.criteriaValue,
                                }); 

                                //2nd row
                                this.tableData[this.tableData.length-1].detail.push({
                                    type: "variable",
                                    criteria: col.criteriaKey, 
                                    summarySelected: rulejs.getSummarySelected(col.criteriaKey, this), 
                                    valueData: col.criteriaValue,
                                }); 
                            });  

                            //formula type
                            //if(!this.$isEmpty(row.calculateModel.algorithm)){
                                //1st row
                                this.tableData[this.tableData.length-2].detail.push({
                                    name: row.calculateModel.name,
                                    type: "formula",
                                    codemap: "",
                                    criteria: "",
                                    value: row.calculateModel.algorithm,
                                }); 

                                //2nd row
                                this.tableData[this.tableData.length-1].detail.push({
                                    type: "formula",
                                    criteria: "",
                                    summarySelected: null, 
                                    valueData: row.calculateModel.algorithm,
                                }); 
                            //};
                           // alert(JSON.stringify(this.tableData));
                            var resultCol =  {name: 'Result', type: "result", code: '', value: '', valueData: ''};    
                            this.tableData[this.tableData.length-2].detail.push(resultCol); 
                            this.tableData[this.tableData.length-1].detail.push(resultCol); 
                        });//each row                       
                    }
                }
            }catch(e){

            }

            if(this.tableData.length > 0) {
                this.tableData[0].detail.forEach(element =>{
                    this.headerEdit.push({name: element.name});
                });
            }      
            else if(this.tableData.length==0){ //it is a new rule
                this.headerEdit.push({name: "Relationship"});
                this.headerEdit.push({name: "Variable"});
                this.headerEdit.push({name: "Formula"});
            }



      },

      spanMethod({ row, column, rowIndex, columnIndex }) {
               if(rowIndex % 2 ==0){
               //alert(JSON.stringify(column));
                    if(row.detail[columnIndex].type == "formula" || row.detail[columnIndex].type == "result"){
                        return{
                            rowspan: 2,
                            colspan: 1,
                        }
                    }
               }

               return;

      },
      doBack(){
            var link = "rule_detail";
            this.$router.replace({name: link, params: {rule: this.ruleGroupModel} });
      },

      doVerify(){

            for(var rowIndex=0; rowIndex<this.tableData.length-1; rowIndex +=2 ){
                 var rowElement = this.tableData[rowIndex];

                 let formulaObj = {};               
                 formulaObj = rowElement.detail.find((item) =>{
                     return item.type === "formula";
                 });

                 let resultObj = {}; 
                 resultObj = rowElement.detail.find((item) =>{
                     return item.type === "result";
                 });

                 let valueObj = {}; 
                 var colIndex = 0;
                 rowElement.detail.find((item, index) =>{
                     colIndex = index;
                     return item.type === "variable";
                 });

                 valueObj = this.tableData[rowIndex+1].detail[colIndex];


                 var rate = formulaObj.value.split("*");
                 var rateFloat = parseFloat(rate[1].trim());
                 //alert(rateFloat);

                 if(!util.isEmpty(valueObj.valueData.trim())){
                    var valueFloat = parseFloat(valueObj.valueData.trim());
                    var result = valueFloat*rateFloat;
                    resultObj.value = result.toFixed(2);
                 }else{
                     resultObj.value="";
                 }             
                 

            }

      },

      convertRuleDetail(row, colIndex){
            return rulejs.convertRuleDetail(row, colIndex,this);
      },

   },
};
</script>

<style lang="scss" scoped>
.el-button--text {
    color: #fff;
}
.dropdown-pos{
    text-align: right;
    width: auto;
    right: 0px;
    bottom: 0px;
    position: absolute;
}
</style>
