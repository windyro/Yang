<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="ruleForm" class="responsive-form" alias="rule_summary" :rules="$formValidator.rules" :model="ruleForm">

            <template slot="scroll">

                <div>
                    <gl-search :headerList="headerListSearch" @doSearch="doSearch" ref='glSearch'>
                    </gl-search>
                </div>

                <!--span class="h6 float-right add-btn cursor-p" @click="addNew">+ add new</span-->
                <gl-object-table :data="ruleForm.tableData" ref="tableData">
                    <el-table-column :label="$t(headerList[0].name)" width="auto">
                        <template slot-scope="scope">
                            <el-form-item v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.name'"  :rules="$formValidator.rules.required">
                                <el-input v-model="scope.row.name" :id="'nameid' + scope.$index" :ref="'nameref' + scope.$index"></el-input>   
                            </el-form-item>

                            <gl-link type="primary" v-if="!scope.row.edit"  @click="toRuleDetail(scope.row, scope.$index)">{{scope.row.name}}</gl-link>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[1].name)" width="auto">
                        <template slot-scope="scope">
                            <el-form-item  v-if="scope.row.edit" :prop="'tableData.' + scope.$index + '.description'" >
                                <el-input v-model="scope.row.description"></el-input>                                           
                            </el-form-item>
                            <span v-if="!scope.row.edit" class="bt5">{{scope.row.description}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[2].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.company'"  :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.company" :valueData="scope.row.company" :optionList="headerList[2].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[3].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.channel'" :edit="scope.row.edit" v-model="scope.row.channel" :valueData="scope.row.channel" :optionList="headerList[3].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <!--<el-table-column :label="$t(headerList[10].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.city'" 
                            
                            :edit="scope.row.edit" 
                            v-model="scope.row.city" 
                            :valueData="scope.row.city" 
                            :optionList="headerList[10].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>-->

                    <el-table-column :label="$t(headerList[4].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.summaryType'" :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.summaryType" :valueData="scope.row.summaryType" :optionList="headerList[4].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[5].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.frequency'" :rules="$formValidator.rules.required" :edit="scope.row.edit" v-model="scope.row.frequency" :valueData="scope.row.frequency" :optionList="headerList[5].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[6].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.paymentFlag'":rules="$formValidator.rules.required" type="yesNo" :edit="scope.row.edit" v-model="scope.row.paymentFlag" :valueData="scope.row.paymentFlag">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t((headerList[7].name))" width="auto">
                        <template slot-scope="scope">
                            <gl-select :prop="'tableData.' + scope.$index + '.activeFlag'" :rules="$formValidator.rules.required" type="yesNo" :edit="scope.row.edit" v-model="scope.row.activeFlag" :valueData="scope.row.activeFlag">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[8].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-date :prop="'tableData.' + scope.$index + '.effectedStartDate'" :rules="$formValidator.rules.required" :edit="scope.row.edit"   v-model="scope.row.effectedStartDate" :value="scope.row.effectedStartDate" type="date" :endDateStr ="scope.row.effectedEndDate"></gl-date>
                        </template>
                    </el-table-column>

                     <el-table-column :label="$t(headerList[9].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-date :prop="'tableData.' + scope.$index + '.effectedEndDate'"  :rules="$formValidator.rules.required" :edit="scope.row.edit"   v-model="scope.row.effectedEndDate" :value="scope.row.effectedEndDate" type="date" :beginDateStr ="scope.row.effectedStartDate"></gl-date>
                        </template>
                    </el-table-column>
                    
                    <el-table-column v-if="isModify" :label="$t('label.operation')">
                        <template slot-scope="scope">
                            <gl-button type="text" @click="editRow(scope.row,scope.$index)" v-show="!scope.row.edit" >{{$t('label.edit')}}</gl-button>
                            <gl-button type="text" @click="copyRow(scope.row,scope.$index)" v-show="!scope.row.edit" >{{$t('label.copy')}}</gl-button>
                            <gl-button type="text" @click="saveRow(scope.row,scope.$index, 'ruleForm')" v-show="scope.row.edit">{{$t('label.save')}}</gl-button>
                            <gl-button type="text" @click="editRowCancel(scope.row,scope.$index)" v-show="scope.row.edit">{{$t('label.cancel')}}</gl-button>
                        </template>
                    </el-table-column>
                </gl-object-table>
            </template>

            <template slot="pages">
                <gl-page :total="total" :currentPage="currentPage" :pageSize="pageSize" ref="glPage" :changePage="changePage" :changeSize="changeSize">
                </gl-page>
            </template>

        </aia-form>
    </section>
</div>
</template>

<script>
import {
    mapState
} from "vuex";
import util from "@/models/Utility";
export default {
    props: ["title"],
    data() {
        return {
            showPdf: false,
            name: "",
            pdfId: "",
            selectDate: [],
            headerList: [{
                    code: 'Name',
                    name: 'label.name',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'Description',
                    name: 'label.description',
                    type: "input",
                    select: "",
                    optionList: [],
                },
                {
                    code: 'Company',
                    name: 'label.company',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("company", this),
                },
                {
                    code: 'Channel',
                    name: 'label.channel',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("channel", this), //util.getChannelList(this)
                },
                {
                    code: 'SummaryType',
                    name: 'label.summaryType',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("summarytype", this),
                },
                {
                    code: 'Frequency',
                    name: 'label.frequency',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("frequency", this),
                },

                {
                    code: 'Payment',
                    name: 'label.payment',
                    type: "select",
                    select: "yesNo",
                    optionList: [],
                },
                {
                    code: 'Active',
                    name: 'label.active',
                    type: "select",
                    select: "yesNo",
                    optionList: [],
                },
                {
                    code: 'EffectedStartDate',
                    name: 'label.effectedStartDate',
                    type: "date",
                    select: "other",
                    optionList: [],
                },
                {
                    code: 'EffectedEndDate',
                    name: 'label.effectedEndDate',
                    type: "date",
                    select: "other",
                    optionList: [],
                },
            ],
            headerListSearch: [],

            ruleForm: {
            tableData: [],
            },

    
            currentEdit: {},
            currentIndex: null,
            currentPage:1,
            pageSize:10,
            total:0,
            isModify:this.$checkPageModify(this.$route.name),
        };
    },

    created() {
        // alert(this.$route.name);
        this.headerListSearch.push(this.headerList[0]);
        this.headerListSearch.push(this.headerList[1]);
        this.headerListSearch.push(this.headerList[2]);
        this.headerListSearch.push(this.headerList[3]);
        this.headerListSearch.push(this.headerList[4]);
        this.headerListSearch.push(this.headerList[5]);
        this.headerListSearch.push(this.headerList[6]);
        this.headerListSearch.push(this.headerList[7]);
        this.$emit("getTitle", "");
    },
    mounted: function () {
        this.prepare();
        this.doSearch({});
    },
    // computed:{

    // },
    beforeDestroy() {
        //this.$emit("getTitle", "");
    },
    methods: {
        prepare() {
            this.ruleForm.tableData.push({ //add a new row
                name: "",
                description: "",
                company: "",
                channel: "",
                frequency: "",
                paymentFlag: "",
                summaryType: "",
                activeFlag: "",
                effectedStartDate: util.data().defaultStartDate,
                effectedEndDate:  util.data().defaultEndDate,
                edit: false,
            });

            this.total = this.ruleForm.tableData.length;
            this.currentPage = this.$refs.glPage.currentPage;
            this.pageSize = this.$refs.glPage.pageSize;
        },

        editRow(row, index) {
            //this.$refs.ruleForm.testChild(row.name);
            if (this.currentIndex != null) {
                this.$alert(this.$t("message.singleRowEdit"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }

            if (row.edit == false) {
                this.currentEdit = JSON.parse(JSON.stringify(row));
                this.currentIndex = index;
                row.edit = true;
                this.$set(this.ruleForm.tableData, index, row);
            }

            this.$nextTick(() => {
              this.$forceUpdate();
            });
           
        },

        editRowCancel(row, index) {

            this.$confirm(this.$t("message.notToSave"), this.$t("message.warning"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                })
                .then(() => {
                    row = JSON.parse(JSON.stringify(this.currentEdit));
                    row.edit = false;
                    this.$set(this.ruleForm.tableData, index, row);
                    // if (this.currentIndex >= this.ruleForm.tableData.length - 1) {
                    //     this.$set(this.selectDate, index, []);
                    // }
                    this.currentEdit = {};
                    this.currentIndex = null;
                })
                .catch(() => {});

            this.$nextTick(() => {
              this.$forceUpdate();
            });
        },

        saveRow(row, index, formName) {

            if(!this.$refs.ruleForm.validate()){
                return;
            }

            if(row.paymentFlag==='N'){
                let invalidNames=this.$getGeneralList("invalidRuleName", this);
                let isInvalid=invalidNames.some(x=>x.code===row.name);
                this.$alert(this.$t("message.invalidRuleName"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }
                    
            var opt = 'INSERT';
            var obj = Object.assign({}, row);
            obj.periodType=util.data().periodTypeList[0].code;
            obj.periodIndex=util.data().periodIndexList[0].code;
            delete obj.type;
            delete obj.edit;
            // delete obj.city;
            
            if (this.currentIndex < this.ruleForm.tableData.length - 1) {
                opt = 'UPDATE';
            }
            this.$confirm(this.$t("message.toSave"), this.$t("message.confirm"), {
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    type: "Error",
                    closeOnClickModal: false,
                })
                .then(() => {

                    var param = {
                        action: opt,
                        ruleGroupModel: obj,
                    }

                    this.$caller.rule_summary_query(param).then(res => {
                        row.edit = false;
                        this.$set(this.ruleForm.tableData, index, row);
                        this.currentEdit = {};
                        this.currentIndex = null;
                        this.doSearch(this.$refs.glSearch.searchList, 1, false);
                    });
                })
                .catch((e) => {
                    this.$alert(this.$t(e), this.$t("message.error"), {
                        confirmButtonText: "OK",
                    });
                    return;
                });
        },

        copyRow(val, index) {
            if (this.currentIndex != null) {
                this.$alert(this.$t("message.singleRowEdit"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }
            let indexLast = this.ruleForm.tableData.length - 1;
            this.currentEdit = JSON.parse(JSON.stringify(this.ruleForm.tableData[indexLast]));
            this.currentIndex = indexLast;

            this.ruleForm.tableData.splice(indexLast, 1, JSON.parse(JSON.stringify(val)));
            this.ruleForm.tableData[indexLast].edit = true;
        },

        toRuleDetail(row, index) {
            var detail = "rule_detail";

            let canRead=util.checkPageAuthority(detail);
            if(canRead){
                this.$router.push({
                    name: detail,
                    params: {
                        rule: row,
                    },
                });
            }else{
                this.$alert(this.$t('message.noPermissionPrompt'), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
            }
        },

        async doSearch(searchList,page, firstClick = true) {
         
            this.selectDate = [];
            var param = {
                action: 'GET',
                name: '',
                company: '',
                channel: '',
                paymentFlag: '',
                description: '',
                frequency: '',
                summaryType: '',
                activeFlag: '',
                //effectedStartDate: '',
                //effectedEndDate: '',
            };
            
            let {processingunit,businessunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';
            param.channel=businessunit?businessunit:'';


            
            for (var s in searchList) {
                if (searchList[s].name == 'Name') {
                    param.name = searchList[s].value;
                } else if (searchList[s].name == 'Company') {
                    param.company = searchList[s].value?searchList[s].value:param.company;
                } else if (searchList[s].name == 'Channel') {
                    param.channel = searchList[s].value?searchList[s].value:param.channel;
                } else if (searchList[s].name == 'Payment') {
                    param.paymentFlag = searchList[s].value;
                } else if (searchList[s].name == 'Description') {
                    param.description = searchList[s].value;
                } else if (searchList[s].name == 'Frequency') {
                    param.frequency = searchList[s].value;
                } else if (searchList[s].name == 'SummaryType') {
                    param.summaryType = searchList[s].value;
                }else if (searchList[s].name == 'Active') {
                    param.activeFlag = searchList[s].value;
                }
                // else if (searchList[s].name == 'EffectedStartDate') {
                //     param.effectedStartDate = searchList[s].value;
                // }else if (searchList[s].name == 'EffectedEndDate') {
                //     param.effectedEndDate = searchList[s].value;
                //}

              

            }
            try {
                if(firstClick){
                    this.currentPage = 1;
                }else{
                    this.currentPage = this.$refs.glPage.currentPage;
                }
                this.currentPage=page;
                var res = await util.getRuleSummaryList(this, this.currentPage, this.$refs.glPage.pageSize, param);
                
                // this.ruleForm.tableData = res.ruleGroupModel.filter(model=>this.headerList[2].optionList.some(company=>company.code==model.company)&&this.headerList[3].optionList.some(channel=>channel.code==model.channel));
                this.ruleForm.tableData = res.ruleGroupModel;
                this.total = res.total;
                this.ruleForm.tableData.forEach((element,index) =>{
                    element["edit"] = false;                   
                });
                this.ruleForm.tableData.push({ //add a new row
                    name: "",
                    description: "",
                    company: "",
                    channel: "",
                    // city: "",
                    frequency: "",
                    paymentFlag: "",
                    summaryType: "",
                    activeFlag: "",
                    effectedStartDate: util.data().defaultStartDate,
                    effectedEndDate:  util.data().defaultEndDate,
                    edit: false,
                });
                //Make sure can edit row again
                this.currentEdit = {};
                this.currentIndex = null;

            } catch (e) {
                this.$alert(this.$t(e), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return;
            }

        },

        changePage(page) {
            this.doSearch(this.$refs.glSearch.searchList,page,false);
        },

        changeSize(size) {
            this.pageSize=size;
            this.doSearch(this.$refs.glSearch.searchList,1,false);
        },
    },
};
</script>

<style lang="scss" scoped>
.view-Form {
    background: none;
    border: 0;
}

.email-style {
    width: 100%;

    span {
        display: inline-block;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        width: 100%;
    }
}
</style>
