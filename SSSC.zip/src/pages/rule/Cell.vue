<template>

  <gl-dialog
    @doCloseDialog="doCloseDialog"
    :dialogTableVisible = "dialogTableVisible"
  >
         <template slot="dialog-title">
                <gl-object-table :data="conditionData">
                    <el-table-column  :label="$t('label.name')" width="auto">
                    <template slot-scope="scope">
                            <span class="bt5">{{scope.row.name}}</span>
                    </template>
                    </el-table-column>

                    <el-table-column  :label="$t('label.type')" width="auto">
                    <template slot-scope="scope">
                            <gl-select :edit="false" 
                                        v-model="scope.row.type" 
                                        :valueData="scope.row.type" 
                                        :optionList="typeOptionList">
                            </gl-select>
                    </template>
                    </el-table-column>
                </gl-object-table>
         </template>
                
        <template slot="dialog-content">
            <div v-if="editData.type=='condition'">
                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                    <el-col :xs="8" :sm="8" :md="8" :lg="8" style="padding-right: 5px; padding-left: 0px;">
                        <gl-select type="other" 
                                    :edit="true" 
                                    v-model="editData.criteria" 
                                    :valueData="editData.criteria"
                                    :optionList="summaryList"
                                    @change="changeSelect()">
                        </gl-select>
                    </el-col>

                    <el-col :xs="4" :sm="4" :md="4" :lg="4" style="padding-right: 5px; padding-left: 0px;">
                            <gl-select type="comparisonName" 
                                    :edit="true" 
                                    v-model="editData.codemap" 
                                    :valueData="editData.codemap"
                                    :optionList="comparisonNameList"
                                    @change="changeOperator()"> 
                            </gl-select>
                    </el-col>

                    <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 0px; padding-left: 0px;">
                            <el-input v-if="inputType=='input'" v-model="editData.value"></el-input>

                            <gl-select v-else-if="inputType=='select'"
                                    :type="summarySelected.type" 
                                    :edit="true" 
                                    v-model="editData.value" 
                                    :valueData="editData.value"
                                    :optionList="summarySelected.optionList">
                            </gl-select>  

                             <gl-select-multiple v-else-if="inputType=='select_multiple'"
                                    :type="summarySelected.type" 
                                    :edit="true" 
                                     v-model="select_multiple_list" 
                                    :valueData="select_multiple_list"
                                    :optionList="summarySelected.optionList"
                                    @change="test">
                            </gl-select-multiple> 
                             
                             <gl-date v-else-if="inputType=='date' || inputType=='month'"
                                    :type="inputType"
                                    v-model="editData.value"
                                    :editable="true">
                            </gl-date>

                            <div v-else-if="inputType=='date_between'">
                                <gl-date type="date" 
                                        v-model="beginDateStr"
                                        :endDateStr ="endDateStr"
                                        :editable="true" 
                                        style="width: 45%;display: inline-block;">
                                </gl-date>
                                <span>~</span>
                                <gl-date type="date"
                                        v-model="endDateStr"
                                        :beginDateStr="beginDateStr"
                                        :editable="true" 
                                        style="width: 45%;display: inline-block;">
                                </gl-date>
                            </div>

                    </el-col>

                    <!--el-col :xs="4" :sm="1" :md="1" :lg="1" style="padding-right: 2px; padding-left: 2px; width: 35px;">
                            <span class="iconfont cursor-p"  v-if="index==0" id="addBtn" @click="addCondition">&#xe612;</span>
                            <span class="iconfont cursor-p"  v-if="index!=0" id="delBtn" @click="delCondition(index)">&#xe651;</span>
                            
                    </el-col-->

                </el-row>

                <!--function parameters-->
                <el-row v-if="summarySelected.needParameter"  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                    <el-col v-for="(parameter,index) in this.summarySelected.parameterList" :key="index"  :xs="6" :sm="6" :md="6" :lg="6" style="padding-right: 2px; padding-left: 0px;">
                        <gl-autocomplete v-if="parameter.type=='autoInput'"      
                             :suggestionList = "parameter.optionList"
                             v-model = "functionParametersList[index]"
                             :value ="functionParametersList[index]" 
                             :suggestionType = "parameter.suggestionType"
                             :placeholder = "parameter.placeholder"
                            >
                
                        </gl-autocomplete>

                         <gl-select v-else-if="parameter.type=='select'"   
                                    :edit="true" 
                                    v-model="functionParametersList[index]" 
                                    :valueData="functionParametersList[index]"
                                    :optionList="parameter.optionList"
                                    :placeholder = "parameter.placeholder"
                                    >
                        </gl-select>

                        <el-input v-else-if="parameter.type=='input'" v-model="functionParametersList[index]" :placeholder = "parameter.placeholder"></el-input>
                    </el-col>
                </el-row>
                <!--function parameters end-->
            </div>

            <div v-else-if="editData.type=='label'">
                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                    <el-col :xs="10" :sm="10" :md="10" :lg="10" style="padding-right: 5px; padding-left: 0px;">
                        <el-input  v-model="editData.value"></el-input>
                    </el-col>
                </el-row>
            </div>

            <div v-else-if="editData.type=='variable'">
                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                    <el-col :xs="10" :sm="10" :md="10" :lg="10" style="padding-right: 5px; padding-left: 0px;">
                        <gl-select type="other" 
                                    :edit="true" 
                                    v-model="editData.criteria" 
                                    :valueData="editData.criteria"
                                    :optionList="summaryList"
                                    @change="changeVariable()">
                        </gl-select>
                    </el-col>

                    <el-col v-if="summarySelected.needParameter"  :xs="10" :sm="10" :md="10" :lg="10" style="padding-right: 5px; padding-left: 0px;">
                        <el-input  v-model="editData.value" ></el-input>
                    </el-col>
                </el-row>
            </div>

             <div v-else-if="editData.type=='formula'">
                <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                    <el-col :xs="4" :sm="4" :md="4" :lg="4" style="padding-right: 5px; padding-left: 0px;">

                        <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                            <gl-select type="other" 
                                        :edit="true" 
                                        v-model="selectedOperator" 
                                        :optionList="operatorList"
                                        placeholder="Available operator"
                                        @change="changeFormula(selectedOperator)">
                            </gl-select>
                         </el-row>   
                         <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 10px">
                                 <gl-select type="other" 
                                    :edit="true" 
                                    v-model="selectedVariable" 
                                    :optionList="variableList"
                                     placeholder="Available variable"
                                    @change="changeFormula(selectedVariable)">
                                </gl-select>
                         </el-row>   
                    </el-col>

                    <el-col :xs="20" :sm="20" :md="20" :lg="20" style="padding-right: 5px; padding-left: 0px;">
                         <el-input type="textarea" :rows="6" v-model="editData.value"></el-input>
                    </el-col>

                </el-row>  
            </div>

        </template>

        <template slot="dialog-summary">
            <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px;">
                <el-col :xs="24" :sm="24" :md="24" :lg="24" style="padding-right: 0px; padding-left: 0px;">
                        <span class="bt5">{{convertRuleDetail()}}</span>
                </el-col>
            </el-row>   
        </template>

        <template slot="buttons">   
             <button class="btn-primary"  @click.prevent="doneEdit">{{$t('label.done')}}</button>
             <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
        </template>
  </gl-dialog>

</template>
<script>
import util from "@/models/Utility";
import rulejs from "./Rule";
export default {
  name: 'RuleCell',
  props: ["dialogTableVisible", "conditionData", "variableList", "ruleGroupModel"],
  data() {
    return {
      typeOptionList: util.data().cellTypeList,
      operatorList: util.data().operatorList,
      ruleGroupModel: this.$props.ruleGroupModel,
      summaryList: null,
      comparisonNameList: util.data().comparisonNameList,

      editData: JSON.parse(JSON.stringify(this.$props.conditionData[0])),
      summarySelected: {code: "", name:'', type:'', optionList: [] },

      searchNameClass: "search-name",
      className: "cell-edit",
      dialogTable: this.dialogTableVisible,
    
      selectedOperator: String,
      selectedVariable: String,

      inputType: "input",
      select_multiple_list: [],
      functionParametersList: [],

      beginDateStr: String,
      endDateStr:  String,
    };
  },
  mounted() {

  },
  created() {  
      
      this.editData = JSON.parse(JSON.stringify(this.$props.conditionData[0]));
      if(this.editData.type==='condition'||this.editData.type==='variable'){
        this.summaryList = this.ruleGroupModel.summaryType == "MEASUREMENT"?this.$getGeneralList("measurement", this):this.$getGeneralList("summary", this);
        this.summaryList = this.summaryList.concat(this.$getGeneralList("function", this));
        this.summaryList = this.ruleGroupModel.summaryType == "MEASUREMENT"?this.summaryList.concat(this.$getGeneralList("functionMeasurement", this)):this.summaryList;
      }

      if(this.editData.type==='condition'){
         this.summaryList = this.summaryList.filter(item => item.isCondition!=false);
      }
      if(this.editData.type==='variable'){
         this.summaryList = this.summaryList.filter(item => item.isVariable);
      }

      this.init();
      this.changeParameters();
      //alert(JSON.stringify(this.editData));
      //alert(JSON.stringify(this.summarySelected));
  },
  methods: {
    
    init(){
        this.summarySelected = this.summaryList.find((item)=>{
            return item.code === this.editData.criteria; 
        });

        //brand new
        if(this.$isNull(this.summarySelected)){
            this.summarySelected= {code: "", name:'', type:'input', needParameter: false, optionList: [] };
        }

        if(this.summarySelected.type=="input"){
            this.inputType= "input";
        }
        else if(this.summarySelected.type=="select"){
            if(this.editData.codemap=="T_IN" || this.editData.codemap =="T_NOT_IN"){
                this.inputType = "select_multiple";

                if(!this.$isEmpty(this.editData.value)){
                    this.select_multiple_list = this.editData.value.split(",");
                }else{
                    this.select_multiple_list=[];
                }
                
            }else{
                this.inputType = "select";
            }
        }
        else if(this.summarySelected.type=="date" || this.summarySelected.type=="month"){
            if(this.editData.codemap=="T_BETWEEN" ){
                this.inputType = "date_between";

                if(!this.$isEmpty(this.editData.value)){
                    this.beginDateStr = this.editData.value.split(",")[0];
                    this.endDateStr = this.editData.value.split(",")[1];
                }else{
                    this.beginDateStr="";
                    this.endDateStr="";
                }
                this.$nextTick(() => {
                    this.$forceUpdate();
                });

            }else{
                this.inputType= this.summarySelected.type;
            }
        }

    },
    
    changeSelect(){
        this.editData.value="";
        this.editData.functionParameters="";
        this.editData.complicatedModelInd="";
        this.init();
        this.changeParameters();
    },

    changeOperator(){
        this.editData.value="";
        this.init();
    },

    changeParameters(){
        //if function need parameters
        if(this.summarySelected.needParameter){
            this.functionParametersList =[];
            if(!this.$isEmpty(this.editData.functionParameters)){
                this.functionParametersList = this.editData.functionParameters.split(",");

                for(let i=0; i<this.functionParametersList.length; i++){
                    if(this.summarySelected.parameterList[i].type ==="autoInput"){
                        if(this.functionParametersList[i].charAt(0)!='"' && this.functionParametersList[i].charAt(this.functionParametersList.length-1)!='"'){
                            this.functionParametersList[i] = rulejs.codeToName(this.functionParametersList[i], this.summarySelected.parameterList[i].optionList);
                        }
                    }
                }
                
            }
            else{
                this.summarySelected.parameterList.forEach(param=>{
                    this.functionParametersList.push("");
                }); 
            }
        }
    },

    changeVariable(){
        this.editData.value="";
        this.summarySelected = this.summaryList.find((item)=>{
            return item.code === this.editData.criteria; 
        });
    },

    changeComparision(){
        //alert(codemap + "   " + summarySelected.type);


    },
    changeFormula(str){
        this.editData.value= this.editData.value + str;
    },

    convertRuleDetail(){
        var row={id: "", detail: []};
        if(this.editData.type=='condition' && this.inputType == "select_multiple"){
            this.editData.value = this.select_multiple_list.join(",");
        }
        else if(this.editData.type=='condition' && this.inputType == "date_between"){
            this.editData.value = this.beginDateStr + "," + this.endDateStr;
        }

        if(this.editData.type=='condition' && this.summarySelected.needParameter){
            this.editData.functionParameters = this.functionParametersList.join(",");
        }
        row.detail.push(this.editData);
        return rulejs.convertRuleDetail(row, 0,this, this.$props.ruleGroupModel.summaryType);
    },

    doCloseDialog(){
        this.$emit("doCloseDialog", this.dialogTable);
    },

    doneEdit(){
        if(!this.validate()){
            return;
        }
        this.$emit("doDoneEdit", this.editData);
       // alert(JSON.stringify(this.editData.value));

        //alert(JSON.stringify(this.editData.value.join(',').split(',')));
    },

    validate(){

        //validate fomula type
        if(this.editData.type=='formula'){

            var str = this.editData.value;//.replace(/\s+/g, '');
            //Variable list
            if(this.$props.variableList.length >0){
                this.$props.variableList.forEach(element=>{
                    var regVariable=new RegExp(element.name, "g");
                    str = str.replace(regVariable, "");
                }); 
            }

            //Operator List
            if(this.operatorList.length >0){
                this.operatorList.forEach(element=>{
                    var regOperator=new RegExp("\\"+element.name, "g");
                    str = str.replace(regOperator, "");
                }); 
            }
         
            //Numbers
            str = str.replace(/\s+/g, '');
            var regNum = new RegExp("^[0-9\.\+\-]*$");;
            if(!regNum.test(str)){
                this.$alert(this.$t("message.formulaError"), this.$t("message.error"), {
                    confirmButtonText: "OK",
                });
                return false;
            }
            
            return true;
        }
        //validate condition type
        else if(this.editData.type=='condition'){

            if(this.$isEmpty(this.editData.criteria)){
                this.editData.value = "";
                this.editData.codemap = "";
                this.editData.functionParameters="";
                return true;
            }

            if(this.inputType == "select_multiple"){
                this.editData.value = this.select_multiple_list.join(",");
            }
            else if(this.inputType == "date_between"){
                this.editData.value = this.beginDateStr + "," + this.endDateStr;
            }
            //if selected conditon, must input all
            if(!this.$isEmpty(this.editData.criteria)){
                if(this.$isEmpty(this.editData.codemap) || this.$isEmpty(this.editData.value)){
                     this.$alert("Please complete the condition!", this.$t("message.error"), {
                                 confirmButtonText: "OK",
                          });
                     return false;
                }
            }

            //if function need parameters
            let checkParam = true;
            if(this.summarySelected.needParameter){
                let resultStr ="";
                this.functionParametersList.forEach((param,index)=>{
                    
                    if(this.$isEmpty(param)){
                        this.$alert("Please complete the condition!", this.$t("message.error"), {
                                    confirmButtonText: "OK",
                            });
                        checkParam = false;
                        return false;
                    }

                    if(this.summarySelected.parameterList[index].type ==="autoInput"){
                        if(param.charAt(0)=='"' && param.charAt(param.length-1 )=='"'){                        
                            resultStr += param;
                        }
                        else{
                            let code = rulejs.nameToCode(param, this.summarySelected.parameterList[index].optionList);

                            if(this.$isEmpty(code)){
                                this.$alert("Parameter input error!", this.$t("message.error"), {
                                    confirmButtonText: "OK",
                                });
                                checkParam = false;
                                return false;
                            }
                            resultStr += code;
                        }
                    }else{
                        resultStr += param;
                    }

                    if(index < this.functionParametersList.length-1){
                        resultStr += ",";
                    }
                    
                });
                this.editData.functionParameters = resultStr;
                this.editData.complicatedModelInd = "RULE_MODEL_API";
            }

            return checkParam;
        }
        return true;
    },

  },
};
</script>

<style lang="scss">

</style>


