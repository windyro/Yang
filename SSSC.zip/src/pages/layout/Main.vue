<template>
  <section>
    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInLeft"
      leave-active-class="animated slideOutLeft"
    >
      <side-bar
        v-if="showSidebar"
        :nowComp="nowComp"
        :class="{'show':showSidebar,'hide':animate&&!showSidebar}"
        v-outside="hideSidebar"
        @hide="hideSidebar"
      >
        <router-link
          replace
          class="cursor-p agent-name"
          tag="span"
          :to="{name:'agent'}"
        >welcome {{$store.state.agent.agentName?$store.state.agent.agentName:$store.state.agent.agentCode}}</router-link>
      </side-bar>

    </transition>
  
    <!-- <transition name="custom-classes-transition" enter-active-class="animated fadeInLeft" leave-active-class="animated slideOutLeft"> -->
    <section class="main-wrap">
      <top-bar ref="topBar" @toggleSidebar="toggleSidebar" :title="newTitle" @menuConfig="getMenuConfig"></top-bar>

      <router-view :clearSearchVal="clearSearchVal"  @getTitle="getTitle"></router-view>
    </section>
    <!-- </transition> -->
  </section>
</template>
<script>
export default {
  data() {
    return {
      clearSearchVal: "",
      newTitle: null,
      showSidebar: false,
      animate: false, //initial no animate

      nowIndex: 0,
      nowComp:"",
      menuConfig:[],
    };
  },
  created() {
    let stoken = sessionStorage.getItem("token");
    let ctoken = this.$cookies.get("token");
    if (stoken != ctoken) {
      this.$router.replace("/");
    }
  },
  methods: {

    toggleSidebar() {
      this.showSidebar = !this.showSidebar;
      //this.animate = true;
    },

    hideSidebar() {
      if (this.showSidebar) {
        this.showSidebar = false;
        this.clearSearchVal = true;
      } else {
        this.clearSearchVal = false;
      }
    },

    getTitle(value) {
      this.newTitle = value;
      //alert("fa "+this.newTitle);
    },

    changeComp(comp){
      this.$refs.topBar.changeComp(comp);
      this.nowComp=comp;
    },
    getMenuConfig(config){
      this.menuConfig=config;
    }
  },
};
</script>
<style lang="scss" scoped>
.agent-name {
  display: inline-block;
  float: right;
  width: 85%;
  height: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
}

</style>


