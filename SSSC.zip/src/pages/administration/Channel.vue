<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="channel" class="responsive-form" alias="channel">

            <template slot="scroll">

                <div>
                    <gl-search :headerList="headerListReal" @doSearch="doSearch" ref='glSearch'>
                    </gl-search>
                </div>

                <!--span class="h6 float-right add-btn cursor-p" @click="addNew">+ add new</span-->
                <gl-object-table :data="tableData">
                    <el-table-column :label="$t(headerList[0].name)" width="auto">
                        <template slot-scope="scope">                        
                            <gl-link type="primary"  @click="toChannelDetail(scope.row, scope.$index)">{{scope.row.code}}</gl-link>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[1].name)" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.name}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[2].name)" width="auto">
                        <template slot-scope="scope">
                            <gl-select :edit="false" v-model="scope.row.company" :valueData="scope.row.company" :optionList="headerList[2].optionList">
                            </gl-select>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[3].name)" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.description}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[4].name)" width="auto">
                        <template slot-scope="scope">                        
                            <gl-date :edit="false"  v-model="scope.row.lastUpdatedDate" :value="scope.row.lastUpdatedDate" type="datetime" ></gl-date>
                        </template>
                    </el-table-column>

                </gl-object-table>

                <channel-detail
                :headerList="headerList"
                :selectedChannel="selectedChannel"
                :dialogTableVisible = "dialogTableVisible"
                v-if="dialogTableVisible"
                @doCloseDialog="doCloseDialog"
                @doSave = "doSave"
                >
                </channel-detail>               
 

            </template>

            <template slot="pages">
                <gl-page :total="total" :currentPage="currentPage" :pageSize="pageSize" ref="glPage" :changePage="changePage">
                </gl-page>
            </template>

            <template slot="buttons">   
                 <button class="btn-primary" @click.prevent="toChannelDetail(null,null)">{{$t('label.add')}}</button>
            </template>

        </aia-form>
    </section>
</div>
</template>

<script>
import ChannelDetail from "./ChannelDetail";
import util from "@/models/Utility";
export default {
    components:{
        ChannelDetail,
    },

    data() {
        return {
   
            dialogTableVisible: false,
            selectedChannel: null,
            headerList: [{
                    code: 'name',
                    name: 'label.name',
                    type: "input",
                },
                {
                    code: 'code',
                    name: 'label.code',
                    type: "input",
                },
                {
                    code: 'company',
                    name: 'label.company',
                    type: "select",
                    select: "other",
                    optionList: this.$getGeneralList("company", this).filter(option=>!option.disabled),
                },

                {
                    code: 'description',
                    name: 'label.description',
                    type: "input",
                },
                {
                    code: 'lastUpdatedDate',
                    name: 'label.lastUpdatedDate',
                    type: "datetime",
                },
            ],

            headerListReal: [],
            tableData: [],
            total:0,
            currentPage: 1,
            pageSize:10,
            searchList:[],
        };
    },



    created() {
        this.headerListReal.push(this.headerList[0],this.headerList[1],this.headerList[2],this.headerList[3]);
        this.$emit("getTitle", "");
        this.prepare();
       // this.doSearch(this.searchList);
    },
    mounted: function () {
        //this.doSearch({});
    },

    methods: {

        prepare() {
            this.tableData.push({ code: "MMAGY",  name:"MMAGY",   company:"MM_BU",  description: "MM Agency Channel",     lastUpdatedDate: "2019-01-05 55:33:00",});
            this.tableData.push({ code: "CNBA",   name:"CNBA",    company:"CN_BU",  description: "China Banca Channel",  lastUpdatedDate: "2019-01-05 55:33:00",});

            this.total = this.tableData.length;
            // this.currentPage = this.$refs.glPage.currentPage;
            // this.pageSize = this.$refs.glPage.pageSize;
        },


        async doSearch(searchList=[],page=1) {
            this.searchList=searchList;
            let param={
                action:"GET",
                startPage: page,
                pageSize: 10,
            };

            let {processingunit}=this.$store.state.user.userInfo;
            param.company=processingunit?processingunit:'';


            searchList.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.code;
                    param[prop]=x.value;
                }
            });
            this.currentPage=page;
            let response=await this.$caller.pipeline_detail(param);

            if(response.responseCode=="000"){
                let {pipelineResult,total}={...response};
                this.total=total;
                this.tableData=pipelineResult;
            }
            else{
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });
                if(!this.$isEmpty(response.reasonCode)){
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },


        changePage(page) {
            this.doSearch(this.searchList, page)
        },

        doSave(editData){
           //alert(JSON.stringify(editData));
           this.dialogTableVisible = false;
        //    var param = {
        //         compensationType: editData.stage,
        //         period: editData.period,
        //         company: editData.company,
        //         action:"POST",
        //    };

        //    this.$caller.pipeline_trigger(param).then(res => {
        //         if(res.responseCode != "000"){

        //             this.$alert("Response Code: " + res.responseCode, "Attention", {
        //                 confirmButtonText: "OK",
        //             });
        //             if(!this.$isEmpty(res.reasonCode)){
        //                 this.$alert("Reason Code: " + res.reasonCode + " - " + res.reasonDesc, "Attention", {
        //                     confirmButtonText: "OK",
        //                 });
        //             }

        //         }
        //         else{
        //             this.doSearch(this.$refs.glSearch.searchList, 1);
        //         }
        //    });

        },

        doCloseDialog(){
           this.dialogTableVisible = false;
        },

        toChannelDetail(row, index){
            //this.$refs.ruleForm.childTest();
            this.selectedChannel = row;
            this.dialogTableVisible = true;
        },

    },
};
</script>

<style lang="scss" scoped>
.view-Form {
    background: none;
    border: 0;
}

.email-style {
    width: 100%;

    span {
        display: inline-block;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        width: 100%;
    }
}
</style>
