<template>
   <aia-el-form alias="compForm" ref="compForm"  :model="compForm" :rules="$formValidator.rules">

        <gl-dialog
            @doCloseDialog="doCloseDialog"
            :dialogTableVisible = "dialogTableVisible"
        >
            
                <template slot="dialog-content">
                    <div>
                        <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6 class="label_required">{{$t(headerList[0].name)}}</h6></label>
                                <el-form-item prop="name" :rules="$formValidator.rules.required">
                                    <el-input v-model="compForm.name"  :disabled="!newStatus"></el-input>   
                                </el-form-item>
                            </el-col>   

                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 0px; padding-left: 0px;">
                                <label><h6>{{$t(headerList[1].name)}}</h6></label>
                                <el-form-item  prop="code" >
                                    <el-input v-model="compForm.code" ></el-input>   
                                </el-form-item>
                            </el-col>   
                        </el-row>

                        <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;">
                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 100px; padding-left: 0px;">
                                <label><h6>{{$t(headerList[2].name)}}</h6></label>
                                <el-form-item prop="description">
                                    <el-input v-model="compForm.description" ></el-input>   
                                </el-form-item>
                            </el-col>   

                            <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 0px; padding-left: 0px;">
                                <label><h6>{{$t(headerList[3].name)}}</h6></label>
                                <el-form-item prop="lastUpdatedDate" >
                                    <el-input v-model="compForm.lastUpdatedDate"  :disabled="true"></el-input>   
                                </el-form-item>
                            </el-col>                  
                        </el-row>               
                    </div>
                </template> 

                <template slot="buttons">   
                    <button class="btn-primary"  @click.prevent="doSave">{{$t('label.save')}}</button>
                    <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
                </template>
        </gl-dialog>

   </aia-el-form>
</template>
<script>
export default {
  name: 'CompanyDetail',
  props: ["dialogTableVisible", "headerList", "selectedComp"],
  data() {
    return {
        newStatus: false,

        compForm:  {code: '',
                    name: '',
                    description: '',
                    lastUpdatedDate: '',
                    },
        dialogTable: this.dialogTableVisible,


    };
  },

  created() {  
        this.prepare();
  },
  methods: {
    prepare() {

        if(!this.$isEmpty(this.$props.selectedComp)){
            this.compForm= this.$cloneObject(this.$props.selectedComp);
            this.newStatus=false;
        }else{
            this.newStatus=true;
        }

    },
    doCloseDialog(){
        this.$emit("doCloseDialog", this.dialogTable);
    },

    doSave(){
    
        if(!this.$refs.compForm.validate()){
            return;
        }
        this.$emit("doSave", this.compForm);
    },

    doChange(){
        this.searchCompensation();
    },


  },
};
</script>

<style lang="scss">

</style>


