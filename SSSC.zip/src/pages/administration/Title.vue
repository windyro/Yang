<template>
<div class="content-wrap">
    <section class="content-fluid margin-left-3xl margin-right-3xl">
        <aia-form ref="companty" class="responsive-form" alias="calculation_job">

            <template slot="scroll">

                <div>
                    <gl-search :headerList="headerList" @doSearch="doSearch" ref='glSearch'>
                    </gl-search>
                </div>

                <!--span class="h6 float-right add-btn cursor-p" @click="addNew">+ add new</span-->
                <gl-object-table :data="tableData">

                    <el-table-column :label="$t(headerList[0].name)" width="auto">
                        <template slot-scope="scope">                        
                            <gl-link type="primary"  @click="modify(scope.row, scope.$index)">{{scope.row.companyCode}}</gl-link>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t(headerList[1].name)" width="auto" prop="channelCode"></el-table-column>

                    <el-table-column :label="$t(headerList[2].name)" width="auto" prop="title"></el-table-column>

                    <el-table-column :label="$t(headerList[3].name)" width="auto" prop="titleCode"></el-table-column>

                    <el-table-column :label="$t(headerList[4].name)" width="auto" prop="lastUpdatedDate"></el-table-column>

                </gl-object-table>

            </template>

            <template slot="pages">
                <gl-page :total="total" :currentPage="currentPage" :pageSize="pageSize" ref="glPage" :changePage="changePage">
                </gl-page>
            </template>

            <template slot="buttons">   
                <button class="btn-primary" @click.prevent="add(null,null)">{{$t('label.add')}}</button>
                <Add :headerList="headerList" :display="display" :form="form" @save="save" @close="close"/>
            </template>

        </aia-form>
    </section>
</div>
</template>

<script>
import Add from "../authority/Add";
import util from "@/models/Utility";
export default {
    components:{
        Add,
    },
    data() {
        return {
            display: false,
            headerList: [
                {
                    code: 'companyCode',
                    name: 'label.companyCode',
                    type: "select",
                    select: "other",
                    optionList:this.$getGeneralList("company", this),
                    required:true,
                },
                {
                    code: 'channelCode',
                    name: 'label.channelCode',
                    type: "select",
                    select: "other",
                    optionList:this.$getGeneralList("channel", this),
                    required:true,
                },
                {
                    code: 'title',
                    name: 'label.title',
                    type: "input",
                    required:true,
                },
                {
                    code: 'titleCode',
                    name: 'label.titleCode',
                    type: "input",
                    required:true,
                },
                {
                    code: 'lastUpdatedDate',
                    name: 'label.lastUpdatedDate',
                    type: "date",
                    select: "other",
                    optionList: [],
                    required:true,
                    noDisplay:true,
                },
            ],
            tableData: [
                { companyCode: "AIA_MM", channelCode:"MMAGY",title:'Chongqing',titleCode: "chafling dish",lastUpdatedDate: "2019-01-05 55:33:00",},
                { companyCode: "AIA_CN", channelCode:"CNBA",title:'Beijing',titleCode: "roast duck",lastUpdatedDate: "2019-01-05 55:33:00",},
                { companyCode: "AIA_PH", channelCode:"MMAGY",title:'Shanghai',titleCode: "chafling dish",lastUpdatedDate: "2019-01-05 55:33:00",},
            ],
            total:0,
            currentPage: 1,
            pageSize:10,
            searchList:[],
            form:{},
        };
    },
    created() {
        this.$emit("getTitle", "");
        this.prepare();
    },
    methods: {

        prepare() {
            this.total = this.tableData.length;
        },

        async doSearch(searchList=[],page=1) {
            this.searchList=searchList;
            let param={
                action:"GET",
                startPage: page,
                pageSize: 10,
            };

            searchList.forEach(x=>{
                if(!this.$isEmpty(x.value)){
                    let prop=x.headerSelected.code;
                    param[prop]=x.value;
                }
            });
            this.currentPage=page;
            let response=await this.$caller.pipeline_detail(param);

            if(response.responseCode=="000"){
                let {pipelineResult,total}={...response};
                this.total=total;
                this.tableData=pipelineResult;
            }
            else{
                this.$alert("Response Code: " + response.responseCode, "Attention", {
                    confirmButtonText: "OK",
                });
                if(!this.$isEmpty(response.reasonCode)){
                    this.$alert("Reason Code: " + response.reasonCode + this.$responseDesc(response.reasonDesc), "Attention", {
                        confirmButtonText: "OK",
                    });
                }
            }
        },

        changePage(page) {
            this.currentPage=page;
            // this.doSearch(this.searchList, page);
        },

        add(row, index){
            this.form={};
            this.display = true;
        },
        modify(row,index){
            this.form={...row};
            this.display = true;
        },
        save(form){
            this.form=form;
        },
        close(){
            this.display=false;
        },
    },
};
</script>
