export default [
  {
      path: '/',
      name: 'Agent Main',
      meta: {
        title: 'main',
        requireAuth: false,
      },
      component: () =>
        import('@/pages/layout/Main.vue'),

      children:[
        {
          path: 'agent/maintain',
          name: 'agent_maintain',
          meta: {
            title: 'Agent Maintenance',
            requireAuth: true,
          },
          component: () =>
            import('@/pages/agent/Agent.vue'),
        },
        {
          path: 'agent/detail',
          name: 'agent_detail',
          meta: {
            title: 'Agent Detail',
            requireAuth: true,
          },
          component: () =>
            import('@/pages/agent/Detail.vue'),
        },
      ],
    },
];