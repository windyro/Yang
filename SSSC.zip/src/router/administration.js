export default [
    {
        path: '/',
        name: 'Administration Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
          {
            path: 'administration/company',
            name: 'administration_company',
            meta: {
              title: 'Company Administration',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/administration/Company.vue'),
          },
          {
            path: 'administration/channel',
            name: 'administration_channel',
            meta: {
              title: 'Channel Administration',
              requireAuth: true,
            },
            component: () => 
              import('@/pages/administration/Channel.vue'),
          },
          {
            path: 'administration/city',
            name: 'administration_city',
            meta: {
              title: 'City Administration',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/administration/City.vue'),
          },
          {
            path: 'administration/location',
            name: 'administration_location',
            meta: {
              title: 'Location Administration',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/administration/Location.vue'),
          },
          {
            path: 'administration/cashier',
            name: 'administration_cashier',
            meta: {
              title: 'Cashier Administration',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/administration/Cashier.vue'),
          },
          {
            path: 'administration/title',
            name: 'administration_title',
            meta: {
              title: 'Title Administration',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/administration/Title.vue'),
          },      
          {
            path: 'administration/class',
            name: 'administration_class',
            meta: {
              title: 'Class Administration',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/administration/Class.vue'),
          },                              
        ],
      },
];