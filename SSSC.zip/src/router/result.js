export default [
    {
        path: '/',
        name: 'Result Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
          {
            path: 'result/payment',
            name: 'result_payment',
            meta: {
              title: 'Payment Result',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/result/Payment.vue'),
          },
          {
            path: 'result/compensation',
            name: 'result_compensation',
            meta: {
              title: 'Compensation Result',
              requireAuth: true,
            },
            component: () => 
              import('@/pages/result/Compensation.vue'),
          },
          {
            path: 'result/transaction',
            name: 'result_transaction',
            meta: {
              title: 'Transaction Result',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/result/Transaction.vue'),
          },
        ],
      },
];