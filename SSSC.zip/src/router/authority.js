export default [
    {
        path: '/',
        name: 'Authority Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
          {
            path: 'authority/user',
            name: 'authority_user',
            meta: {
              title: 'User Management',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/authority/User.vue'),
          },
          {
            path: 'authority/role',
            name: 'authority_role',
            meta: {
              title: 'Role Management',
              requireAuth: true,
            },
            component: () => 
              import('@/pages/authority/Role.vue'),
          },               
        ],
      },
];