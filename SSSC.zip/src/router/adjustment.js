export default [
    {
        path: '/',
        name: 'Adjustment Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
          {
            path: 'adjustment/adjustment',
            name: 'manual_adjustment',
            meta: {
              title: 'Manual Adjustment',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/adjustment/Adjustment.vue'),
          },
        ],
      },
];