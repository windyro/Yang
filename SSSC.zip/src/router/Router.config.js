 /* jshint esversion: 6 */ 

const PageLogin = r => require.ensure([], () => r(require('@/pages/PageLogin.vue')), 'PageLogin');

const constantRouterMap = [
    {
      path: '/',
      name: 'Login',
      component: PageLogin,
      hidden: false,
    },
    {
    path: '/main',
    name: 'Main',
    redirect:'home',
    meta: {
      title: 'main',
      requireAuth: false,
    },
    component: () =>
      import('@/pages/layout/Main.vue'),
    children:[
      {
        path: 'index',
        name: 'Home',
        meta: {
          title: 'Home Page',
          requireAuth: true,
        },
        component: () =>
          import('@/pages/home/Home.vue'),
      },
      {
        path: 'test',
        name: 'test',
        meta: {
          title: 'test',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/home/Test.vue'),
      },
    ],
  },
];

const mainPage = 'PageLogin';

export default {
  constantRouterMap:constantRouterMap,
  mainPage:mainPage,
};