export default [
    {
        path: '/',
        name: 'Hierarchy Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
            {
                path: 'hierarchy/district',
                name: 'hierarchy_district',
                meta: {
                    title: 'District Management',
                    requireAuth: true,
                },
                component: () => 
                    import('@/pages/hierarchy/District.vue'),
            }, 
            {
                path: 'hierarchy/agency',
                name: 'hierarchy_agency',
                meta: {
                title: 'Sales Entity',
                requireAuth: true,
                },
                component: () =>
                import('@/pages/hierarchy/Agency.vue'),
            },
            {
              path: 'hierarchy/agency_detail',
              name: 'hierarchy_agency_detail',
              meta: {
              title: 'Sales Entity Detail',
              requireAuth: true,
              },
              component: () =>
              import('@/pages/hierarchy/AgencyDetail.vue'),
            },
            {
                path: 'hierarchy/relationship',
                name: 'hierarchy_relationship',
                meta: {
                title: 'Relationship Maintenance',
                requireAuth: true,
                },
                component: () =>
                import('@/pages/hierarchy/Relationship.vue'),
            },
            {
                path: 'hierarchy/relationship_detail',
                name: 'hierarchy_relationship_detail',
                meta: {
                  title: 'Relationship Detail',
                  requireAuth: true,
                },
                component: () =>
                  import('@/pages/hierarchy/RelationshipDetail.vue'),
            },
        ],
      },
];