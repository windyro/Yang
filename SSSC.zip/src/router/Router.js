 /* jshint esversion: 6 */ 

 import Vue from 'vue';
 import Router from 'vue-router';
 import routerConfig from './router.config';
 import rule from './rule';
 import result from './result';
 import calculation from './calculation';
 import adjustment from './adjustment';

 import agent from './agent';
 import hierarchy from './hierarchy';
 import administration from './administration';
 import authority from './authority';
 import contest from './contest';
 import cookies from 'vue-cookies';
//  import configPermission from '@/models/permission';
 
  const config = require('../../config');

 Vue.use(Router);
 
 let router = new Router({
 
   // zzx test only for package-testing
   //base:'/camglorweb',
 
   //mode: 'history',
   mode: 'hash',
   linkActiveClass: 'router-active',
   routes: [
     ...routerConfig.constantRouterMap,
     ...rule,
     ...result,
     ...calculation,
     ...adjustment,

     ...agent,
     ...hierarchy,
     ...administration,

     ...contest,

     ...authority,
   ],
 });
 var docUrl;
  router.beforeEach((to, from, next) => { 
      // console.log('beforeEach:',cookies.get('token'),to.path,process.env.NODE_ENV);
      let assetsPublicPath=process.env.NODE_ENV==='development'?config.dev.assetsPublicPath:config.build.assetsPublicPath;
      if(to.path===assetsPublicPath){
        next({'path':'/'});
      }


      if(to.path !== '/'&&!cookies.get('token')){
        next({'path':'/'});
      }else{
        next();
      }
      docUrl = document.location.protocol + "//" + document.location.host + 'glory' + to.path;
      history.pushState(null,null,docUrl);
      window.onpopstate = function(){
        history.pushState(null,null,docUrl);
      }
    },
  );
 
 export default router;
 