export default [
    {
        path: '/',
        name: 'Calculation Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
          {
            path: 'compensation/calculation',
            name: 'compensation_calculation',
            meta: {
              title: 'Compensation Calculation',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/calculation/Calculation.vue'),
          },
        ],
      },
];