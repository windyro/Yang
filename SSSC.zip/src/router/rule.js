export default [
    {
        path: '/',
        name: 'Rule Main',
        meta: {
          title: 'main',
          requireAuth: false,
        },
        component: () =>
          import('@/pages/layout/Main.vue'),

        children:[
          {
            path: 'rule/summary',
            name: 'rule_summary',
            meta: {
              title: 'Rule Summary',
              requireAuth: false,
            },
            component: () =>
              import('@/pages/rule/Summary.vue'),
          },
          {
            path: 'rule/detail',
            name: 'rule_detail',
            meta: {
              title: 'Rule Detail',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/rule/Detail.vue'),
          },
          {
            path: 'rule/cell',
            name: 'rule_cell',
            meta: {
              title: 'Cell Edit',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/rule/Cell.vue'),
          },
          {
            path: 'rule/verify',
            name: 'rule_verify',
            meta: {
              title: 'Rule Verify',
              requireAuth: true,
            },
            component: () =>
              import('@/pages/rule/Verify.vue'),
          },
        ],
      },
]