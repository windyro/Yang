export default [
    {
        path:'/',
        name:'Contest Administration',
        meta:{
            title:'main',
        },
        component:()=>import('@/pages/layout/Main.vue'),
        children:[
            {
                path:'contest/master',
                name:'master_information',
                meta:{
                    title:'Master Information',
                },
                component:()=>import('@/pages/contest/Master.vue'),
            },
            {
                path:'contest/criteria',
                name:'contest_criteria',
                meta:{
                    title:'Contest Criteria',
                },
                component:()=>import('@/pages/contest/Criteria.vue'),
            },
            {
                path:'contest/detail',
                name:'criteria_detail',
                meta:{
                    title:'Criteria Detail',
                },
                component:()=>import('@/pages/contest/criteriaDetail.vue'),
            },
        ],
    },
];
