<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "App",
  created() {
    this.cacheVuexWhenRefresh();
    sessionStorage.setItem("versionNumber", globalConfig.versionNumber+new Date().formatDate("yyyyMMddHH"));
    if(!this.$cookies.get('token')){//response has no token
      this.$router.replace({path:'/'});
    }
  },
  beforeCreate(){
    history.pushState(null,null,document.URL);
    window.onpopstate = function(){
      history.pushState(null,null,document.URL);
    }
  },
  methods:{
    cacheVuexWhenRefresh(){
      if(this.$cookies.get("token")){
        // when page load
        // if (this.$cookies.get("store") ) {
        sessionStorage.getItem('store')&&this.$store.replaceState(Object.assign({}, this.$store.state,JSON.parse(sessionStorage.getItem('store'))));
        // } 

	// when page refresh
      /*  if ("onpagehide" in window) {
          window.addEventListener("pagehide",()=>{
          localStorage.setItem("store",JSON.stringify(this.$store.state))
        })
        } else  if ("onbeforeunload" in window) {
        window.addEventListener("beforeunload",()=>{
          localStorage.setItem("store",JSON.stringify(this.$store.state))
        })
        }else{
         window.addEventListener("visibilitychange", function() {
         localStorage.setItem("store",JSON.stringify(this.$store.state))
        });
        }*/
     
      
      }
    },
  },
};
</script>
<style lang="scss">
#app{
  min-width: 768px;
  overflow-x: auto;
};
</style>

