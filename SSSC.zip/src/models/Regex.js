export default{ 
  deleteSBC:function (){
    var $regex = this;
    var inps = document.getElementsByTagName('input');
    for(let i=0;i<inps.length;i++){
      inps[i].onkeyup = function(){
        if($regex.SBC.test(inps[i].value)){
          inps[i].value = inps[i].value.replace($regex.SBC,"");
        }
      }
    }
  },
  SBC: /[　，。、！？：“”［］——（）…！＠＃￥＆＊＋＞＜；：‘《》……\u4e00-\u9fa5]+/,
  fullName:/^([ A-z]|[@\/'\s])*$/g,
  countryCode:[
    {
      required: true,
      type: "string",
      trigger: "change",
      message: " ",
    },
    {
      pattern: /^\d+$/,
      trigger: "change",
      message: "not number",
    },
    {
      pattern: /^\d{3}$/,
      trigger: "change",
      message: " ",
    },
  ],
  areaCode:[
    {
      required: true,
      type: "string",
      trigger: "change",
      message: " ",
    },
    {
      pattern: /^\d+$/,
      trigger: "change",
      message: "not number",
    },
    {
      pattern: /^\d{2}$/,
      trigger: "change",
      message: " ",
    },
  ],
  mobileNo:[
    {
      required: true,
      type: "string",
      trigger: "change",
      message: " ",
    },
    {
      pattern: /^\d+$/,
      trigger: "change",
      message: "not number",
    },
    {
      pattern: /^\d{6,7}$/,
      trigger: "change",
      message: " ",
    },
  ],
};