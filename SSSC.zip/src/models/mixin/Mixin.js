import {mapState,mapMutations} from 'vuex';
let MIXIN = {
  data() {
      return {
      }
  },
  computed:{
    ...mapState({
      agentCode:state=>state.agentCode,
      contactId:state=>state.contactId,
      quotationId:state=>state.quotationId,
      applicationId:state=>state.applicationId,
      beneficiaryId:state=>state.beneficiaryId,
    }),
  },
};
export default MIXIN;