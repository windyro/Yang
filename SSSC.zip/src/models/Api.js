/* jshint esversion: 6 */
 export const rule_summary_query='ruleservice/ruleGroup';
 export const general_infor_query='ruleservice/generalInfomation';
 export const frequency_infor_query='ruleservice/frequency';

 export const adjustment_batch='calculationresultservice/adjustmentBatch';
 export const adjustment_query='calculationresultservice/adjustmentresult';
 export const transaction_query='calculationresultservice/transactionSummry';
 export const transaction_detail="calculationresultservice/transactionDetail";
 export const transaction_trace_detail="calculationresultservice/transactiondetailDepositTrace";
 export const compensation_query="calculationresultservice/depositSummary";
 export const compensation_trace="calculationresultservice/transactionDepositTrace";
 export const payment_query="calculationresultservice/paymentSummary";
 export const payment_trace="calculationresultservice/depositPaymentTrace";
 export const pipeline_detail="calculationresultservice/pipelineresult";

 export const pipeline_trigger="pipelineservice/pipelinetrigger";
 export const login_validate="userservice/token";
 export const user_query="userservice/user";
 export const role_query="userservice/role";
 export const users_query="userservice/users";
 export const roles_query="userservice/roles";

 export const agent_query="channeladminservice/agent";
 export const agent_insert="channeladminservice/agents";
 export const version_query="channeladminservice/version";
 export const agency_query="channeladminservice/entity";

 export const relation_query="channeladminservice/positionRelation";
 export const position_query="channeladminservice/positionNode";

 export const const_master="contestservice/contestMaster";
 export const const_criteria="contestservice/contestCriteria";