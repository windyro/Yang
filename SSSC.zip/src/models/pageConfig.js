export default {
    pages:[
        {code:"rule_summary",name:"Rule Summary",radioValue:'(NoAuth)'},
        {code:"rule_detail",name:"Rule Detail",radioValue:'(NoAuth)'},
        {code:"rule_cell",name:"Cell Edit",radioValue:'(NoAuth)'},
        {code:"rule_verify",name:"Rule Verify",radioValue:'(NoAuth)'},
        {code:"result_payment",name:"Payment Result",radioValue:'(NoAuth)'},
        {code:"result_compensation",name:"Compensation Result",radioValue:'(NoAuth)'},
        {code:"result_transaction",name:"Transaction Result",radioValue:'(NoAuth)'},
        {code:"compensation_calculation",name:"Compensation Calculation",radioValue:'(NoAuth)'},
        {code:"manual_adjustment",name:"Manual Adjustment",radioValue:'(NoAuth)'},
        {code:"agent_maintain",name:"Agent Maintenance",radioValue:'(NoAuth)'},
        {code:"administration_company",name:"Company Administration",radioValue:'(NoAuth)'},
        {code:"administration_channel",name:"Channel Administration",radioValue:'(NoAuth)'},
        {code:"administration_city",name:"City Administration",radioValue:'(NoAuth)'},
        {code:"administration_location",name:"Location Administration",radioValue:'(NoAuth)'},
        {code:"administration_cashier",name:"Cashier Administration",radioValue:'(NoAuth)'},
        {code:"administration_title",name:"Title Administration",radioValue:'(NoAuth)'},
        {code:"administration_class",name:"Class Administration",radioValue:'(NoAuth)'},
        {code:"hierarchy_agency",name:"Sales Entity",radioValue:'(NoAuth)'},
        {code:"hierarchy_relationship",name:"Relationship Maintenance",radioValue:'(NoAuth)'},
        {code:"master_information",name:"Master Information",radioValue:'(NoAuth)'},
        {code:"contest_criteria",name:"Contest Criteria",radioValue:'(NoAuth)'},
    ],
    radioValue:{
        NoPermission:'(NP)',
        Read:'(R)',
        Modify:'(M)',
    },
    adminRole:'System Admin',
    returnAuthNumber:function(auth){
        let authNumber=0;
        switch(auth){
            case this.radioValue.NoPermission:authNumber=0;
            break;
            case this.radioValue.Read:authNumber=1;
            break;
            case this.radioValue.Modify:authNumber=2;
            break;
        }
        return authNumber;
    }
}