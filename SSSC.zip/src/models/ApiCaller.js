/* jshint esversion: 6 */

// import apiConnector from '@/models/ApiConnector';
import util from "@/models/Utility";
import ajax from "@/models/Facade";
import * as apis from './Api';
import vue from "../main.js";

import { Loading } from 'element-ui';
import router from '@/router/Router';
import checkTimeInterval from './checkTimeInterval';

class InterfaceApis_basic {
    constructor() { }
    stagingCaller(caller, param) {
      let isShowLoading = true;
      let isStopLoading=true;
      let loadinginstace=null;
      let getResult = false;
      if(globalConfig.httpMethod == "GET") {
        util.checkParams(caller, param, "Request");
        param = null;
      }
      //  isShowLoading=(param !=null&&void 0 !=param.isShowLoading)?false:true
      if(param !=null&&void 0 !=param.isShowLoading){
        isShowLoading = param.isShowLoading;
        delete param.isShowLoading;
      }
      isStopLoading=(param !=null&&void 0 !=param.isStopLoading)?false:true;
      /* if set isShowLoading param true, Loading when not finish request after 0.2 seconds*/
      if(isShowLoading){
        setTimeout(()=>{
          if(!getResult){
            loadinginstace= Loading.service({ 
              fullscreen: true,
              lock: true,
              spinner:'el-icon-loading',
            })
          }
        },200)
      }

      let isOutdated=checkTimeInterval(new Date());
      if(isOutdated){
        router.replace("/");
      }
      let callerPro = ajax.run_GET_POST(caller, globalConfig.httpMethod, param)
      .then(function (response) {
        getResult = true;
        if(void 0!=loadinginstace&&isStopLoading){
          loadinginstace.close()
        }

        let result = response.data;

        if(!util.isEmpty(result)) {
            // result = result.data;
            
            // check response Json structure only for sit
            // if(globalConfig.httpMethod == 'POST') {
            //     util.checkParams(caller, param, 'Response');
            // }


            if(result.responseCode!="000"){// There is error
              if(!util.isEmpty(result.reasonCode) || !util.isEmpty(result.reasonDesc)){
                  const h = vue.$createElement;

                  let errMsg = [];
                  result.reasonCode.forEach((reson,index)=>{
                      let msg = reson + "-" + result.reasonDesc[index];
                      errMsg.push(h("p",null, msg));
                  });
                  vue.$msgbox({
                    message: h("div", null,errMsg),
                    title: "ERROR",
                    confirmButtonText: "OK",
                    closeOnClickModal: false,
                  }).then(() => {
                  });
              }else{
                vue.$alert("UNKNOW ERROR REPONSE CODE-" + result.responseCode, "ERROR", {
                  confirmButtonText: "OK"
                });
              }
            }
           
            return result;
        }
        else{//No result response.
          vue.$alert("NO RESPONSE-"+caller, "ERROR", {
            confirmButtonText: "OK"
          });
          return null;
        }
      })
      .catch(function (error) {
        if(void 0!=loadinginstace){
          loadinginstace.close()
        }
        getResult = true;
        vue.$alert("UNKNOW ERROR-"+caller, "ERROR", {
          confirmButtonText: "OK"
        });
        return error;
      });
      callerPro._disableMsg = false
      return callerPro
  }

}

// set api url
function buildUrl(url) {
  let apiUrl;
  // if(globalConfig.httpMethod === "GET"){

  //api url transfer 2020.03.12
  // apiUrl = `${globalConfig.serverUrl}${url}`;
  apiUrl=`${url}`;

  // }else {
  //   apiUrl = '/api'+`${url}`
  // }
  return apiUrl
}

let http =  new InterfaceApis_basic();
let APIs = {};

//api url transfer 2020.03.12
// set api caller
// Object.keys(apis).forEach(apiName => {
//   APIs[`${apiName}`] = (data) => {
//     return http.stagingCaller(buildUrl(apis[`${apiName}`]),data);
//   }
// })
let configApis=globalConfig.apis;
Object.keys(configApis).forEach(apiName=>{
  APIs[`${apiName}`]=(data)=>{
    return http.stagingCaller(buildUrl(configApis[`${apiName}`]),data);
  }
})

export default APIs;

