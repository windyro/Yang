function includeSpace(rule, value, callback) {

    var pattern = new RegExp(/\s+/g);
    if(pattern.test(value)){
        callback(new Error("Can't include blank space"));
    }
    callback();
};

export default{ 



    rules: {required: [{ required: true, message: "Can't be empty", trigger: "change" }],
            detailHeader: [
                             { required: true, message: "Can't be empty", trigger: "change" },
                             { validator: includeSpace, message: "Can't include blank space", trigger: "change" },
                          ],
           },
    
}