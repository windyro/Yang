// Please do not delete
var pdfJS = require('pdfjs-dist').PDFJS;
PDFJS.workerSrc = require('pdfjs-dist/build/pdf.worker.min');