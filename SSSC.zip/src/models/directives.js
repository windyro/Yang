
const outside = {
  bind(el, binding, vnode) {
      function documentHandler(e) {
        var event =e|| window.event||arguments.callee.caller.arguments[0];
        var target = event.target||event.srcElement;
        var menuIgent = document.getElementById('menuIgent');
        if(target==menuIgent) return false;
        var menuIgentIcon = document.getElementById('menuIgentIcon');
        if(target==menuIgentIcon) return false;
        var menuIgentImage = document.getElementById('menuIgentImage');
        if(target==menuIgentImage) return false;

        var menuGlory = document.getElementById('menuGlory');
        if(target== menuGlory) return false;
        var menuGloryIcon = document.getElementById('menuGloryIcon');
        if(target== menuGloryIcon) return false;
        var menuGloryImage = document.getElementById('menuGloryImage');
        if(target== menuGloryImage) return false;
        var addBth = document.getElementById('addBtn');
        if(target== addBth) return false;
        if(binding.expression){
          binding.value(e,binding.arg);
        }

      }
      document.addEventListener('click',function(e){
        documentHandler(e)
      },true);
  },
  unbind(el, binding) {
      document.removeEventListener('click', el.__vueClickOutside__);
      delete el.__vueClickOutside__;
  },
}

const dialogDrag={
  bind(el, binding, vnode, oldVnode) {
      const dialogHeaderEl = el.querySelector('.el-dialog__header');
      const dragDom = el.querySelector('.el-dialog');
      dialogHeaderEl.style.cursor = 'move';

      const sty = dragDom.currentStyle || window.getComputedStyle(dragDom, null);
      
      dialogHeaderEl.onmousedown = (e) => {
          var event = e || window.event;
          const disX = event.clientX - dialogHeaderEl.offsetLeft;
          const disY = event.clientY - dialogHeaderEl.offsetTop;
          
          let styL, styT;

          if(sty.left.includes('%')) {
              styL = +document.body.clientWidth * (+sty.left.replace(/\%/g, '') / 100);
              styT = +document.body.clientHeight * (+sty.top.replace(/\%/g, '') / 100);
          }else {
              styL = +sty.left.replace(/\px/g, '');
              styT = +sty.top.replace(/\px/g, '');
          };
          
          document.onmousemove = function (e) {
              const l = event.clientX - disX;
              const t = event.clientY - disY;

              dragDom.style.left = `${l + styL}px`;
              dragDom.style.top = `${t + styT}px`;

              //binding.value({x:e.pageX,y:e.pageY})
          };

          document.onmouseup = function (e) {
              document.onmousemove = null;
              document.onmouseup = null;
          };
      }  
  },
}


exports.outside = outside;  
exports.dialogDrag = dialogDrag ;
// exports.dialogDragWidth;