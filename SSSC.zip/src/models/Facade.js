/* jshint esversion: 6 */

import axios from 'axios';
import VueCookies from 'vue-cookies';
import util from './Utility';
import router from '@/router/Router';
import Vue from 'vue'
import { MessageBox } from 'element-ui'



// if(code >= 300 && code < 400) {
//   alert(Vue.$t("message.connectFail300"));
// }
// else if(code >= 400 && code < 500) {
//   alert(_this.$t("message.connectFail400"));
// }
// else {
//   alert(_this.$t("message.connectFail500"));
// }

axios.defaults.withCredentials = false;

class Facade {
  constructor() {
    //this.interceptors();
   }
  execute(config) {
    //console.log("---------- Facade : execute : config.url = " + config.url + ", VueCookies.get(token) = " + VueCookies.get("token"));  
    
    var seq = VueCookies.get('sequence');
    if(false == util.isEmpty(seq)) {
      var newseq = new Number(seq);
      newseq = newseq + 1;
      VueCookies.set('sequence', newseq);
    }
    // var header = {
    //   // 'Accept': 'application/json',
    //   'Content-Type': 'application/json',
    //   'token':VueCookies.get('token'),
    //   'timestamp':VueCookies.get('sequence'),
    // }
    var header_login = {
      'Content-Type': 'application/json',
      //'Content-Type': 'application/x-www-form-urlencoded',
      'token':VueCookies.get('token'),
      //'timestamp':'0'
    }
    return axios({
      url: config.url,
      method: config.method,
      params: config.params,
      data: config.data,
      timeout: 120000, // 2 minutes
      withCredentials: false,
      headers: header_login,
    });
  }

  post(url, params) {
    return this.execute({
      url: url,
      method: 'POST',
      data: params,
    });
  }

  put(url, params) {
    return this.execute({
      url: url,
      method: 'PUT',
      data: params,
    });
  }

  get(url, params) {
    return this.execute({
      url: url,
      method: 'GET',
      params: params,
    });
  }

  delete(url, params) {
    return this.execute({
      url: url,
      method: 'DELETE',
      data: params,
    });
  }

  run_GET_POST(url, method, params) {
    if(method == 'GET') {
      return this.execute({
        url: url,
        method: 'GET',
        data: params,
      });
    }
    else if(method == 'POST') {
      return this.execute({
        url: url,
        method: 'POST',
        data: params,
      });
    }
    //console.log("--------- Facade : run_GET_POST : error  method = " + method);
  }

  interceptors(fncallback) {
    alert("interceptors");
    axios.interceptors.response.use(
      response => {
        if(response.status===200){
          //this is temp test code
          if(response.data.errorCode){
            console.log(
            ">>Error"
            + "\n\n" 
            + "request url: "
            + "\n"
            + response.config.url
            + "\n\n" 
            + "Params: "
            + "\n"
            + response.config.data
            + "\n\n" 
            + "Error Code: " 
            + response.data.errorCode 
            + "\n"
            + "errorMessage:"
            + response.data.errorMessage
            + "\n\n" 
            + "--------------------------------------------------"
            )
            /* ---------- should screen for UAT ---------- */
            // let exception=[101, 102, 103, 104,105,106,107,108,109]
            // if(!exception.includes(response.data.errorCode)){
            //   alert("Error Code: " 
            //   + response.data.errorCode 
            //   + "\n" 
            //   + response.data.errorMessage
            //   + "\n" 
            //   + "request url: " + response.config.url)
            // }
          }
          return response;
        }
      },
      error => {
        if (error.response) {
          var token = VueCookies.get('token');
          if(!token) return Promise.reject(error.response);
          switch (error.response.status) {
            case 401:
              VueCookies.remove('token');
              VueCookies.remove('sequence');
              VueCookies.remove('userId');
              sessionStorage.removeItem("token");
              MessageBox.alert("Timeout after 30 minutes inactive or the account has logged on other place, glory will automatically logout now.", "Error", {
                confirmButtonText: "OK",
                callback: action => {
                  router.replace('/')
                },
              });
              break;
            default:
            MessageBox.alert('Server side error', "Error", {
              confirmButtonText: "OK",
            });
          }
          console.log('Facade : interceptors : response : error.response.status = ' + error.response.status);
          // fncallback(error.response.status);
          return Promise.reject(error.response.status);
        }
        else{
          console.log('Facade : interceptors : response : error = ' + error);
          // fncallback(-1);
          if(error.message==='Network Error'){
            router.replace('/');
          }
          return Promise.reject(error);
        }
      }
    );
  }

}

export default new Facade();
