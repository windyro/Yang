
var previousTime;//(Unit/Millisecond)
var intervalStandard=0.5*60*60;  //(Unit/Second)

function checkTimeInterval(currentDate) {
    let currentTime=currentDate.valueOf();

    let isOutdated=false;
    if(previousTime){
        let intervalTime=(currentTime-previousTime)/1000;
        // console.log('intervalTime:',intervalTime,currentTime,previousTime);
        isOutdated=intervalTime>=intervalStandard?true:false;
    }
    previousTime=currentTime;
    return isOutdated;
}

export default checkTimeInterval;