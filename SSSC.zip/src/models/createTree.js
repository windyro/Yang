function createTree(arr,nodeKey,label,children,excessFields){
    var tree=[];
    arr.forEach(item => {
        let nodes=createNode(item,nodeKey,label,children,excessFields);
        tree.push(nodes);
    });
    return tree;
}

function createNode(item,nodeKey,label,children,excessFields){
    var node={
        id:Number(item[nodeKey]),
        label:item[label],
        children:[],
    }
    excessFields.forEach(field=>{
        node[field]=item[field];
    })

    if(item[children]){
        node.children=createTree(item[children],nodeKey,label,children,excessFields);
    }

    return node;
}



export default createTree;