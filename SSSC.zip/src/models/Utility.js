/* jshint esversion: 6 */

import $ from 'jquery';
import _ from 'lodash';
import globalConstants from "@/constants/ConstantConfig";
import { JSEncrypt } from 'jsencrypt';
import hex_sha1 from './sha';
import pageConfig from './pageConfig';
import store from '../store/Store';
import * as desEncrypt from './des';
import createTree from './createTree';

class Utility {

    constructor() {

        Utility.prototype.freqList = [];
        Utility.prototype.companyList = [];
        Utility.prototype.channelList = [];
        Utility.prototype.titleList = [];
        Utility.prototype.agencyTitleList = [];
        Utility.prototype.summarytypeList = [];
        Utility.prototype.cityList = [];
        Utility.prototype.SummaryList =  [];
        Utility.prototype.measurementList =  [];
        Utility.prototype.relationshipList =  [];
        Utility.prototype.functionList =  [];
        Utility.prototype.functionMeasurementList =  [];

        Utility.prototype.entityList =  [];
        Utility.prototype.hierarchyTree = null;   

        Utility.prototype.kpiList=[];
        Utility.prototype.segmentList=[];
        Utility.prototype.productList=[];
    }

    data() {
        return {
            yesNoList: [
                {code:"Y",name:'label.yes'},
                {code:"N",name:'label.no'},
            ],

            yesNoList2: [
                {code:"Y",name:'Yes'},
                {code:"N",name:'No'},
            ],

            cellTypeList: [
                {code:"condition",name:'label.condition'},
                {code:"variable",name:'label.variable'},
                {code:"formula",name:'label.formula'},
                {code:"label",name:'label.name'},
            ],

            jobStageList: [
                {code:"COMP_AND_PAY",name:'label.compensation'},
                {code:"POST",name:'label.payment'},
                {code:"FINALIZE",name:'label.finalize'},
            ],
        
            comparisonList: [
				{code:'T_EQUAL'        ,    name:'='  },         
                {code:'T_NOT_EQUAL'    ,    name:'!=' },
                {code:'T_GREATER'      ,    name:'>'  },
                {code:'T_GREATER_EQUAL',    name:'>=' },
                {code:'T_SMALLER'      ,    name:'<'  },
                {code:'T_SMALLER_EQUAL',    name:'<=' },
            ],
        
            comparisonNameList: [
				{code:'T_EQUAL'        ,    name:'label.is'               },         
                {code:'T_NOT_EQUAL'    ,    name:'label.is_not'           },
                {code:'T_GREATER'      ,    name:'label.greater'          },
                {code:'T_GREATER_EQUAL',    name:'label.greater_or_equal' },
                {code:'T_SMALLER'      ,    name:'label.less'             },
                {code:'T_SMALLER_EQUAL',    name:'label.less_or_equal'    },
                {code:'T_IN'           ,    name:'label.in'               },
                {code:'T_NOT_IN'       ,    name:'label.not_in'           },
                {code:'T_BETWEEN'      ,    name:'label.between'          },
            ],
        
            comparisonDateList: [
				{code:'T_EQUAL'        ,    name:'label.on'        },         
                {code:'T_NOT_EQUAL'    ,    name:'label.not_on'    },
                {code:'T_GREATER'      ,    name:'label.after'     },
                {code:'T_GREATER_EQUAL',    name:'label.on_after'  },
                {code:'T_SMALLER'      ,    name:'label.before'    },
                {code:'T_SMALLER_EQUAL',    name:'label.on_before' },
            ],

            summaryTypeList: [
                {code:"basic",   name:'Summary basic'},
            ],

            operatorList: [
				{code:'+'    ,    name:'+'  },         
                {code:'-'    ,    name:'-'  },
                {code:'*'    ,    name:'*'  },
                {code:'/'    ,    name:'/'  },
                {code:'('    ,    name:'('  },
                {code:')'    ,    name:')'  },
            ],

            periodTypeList: [
				{code:'MONTHLY',        name:'label.monthly'  },         
                {code:'QUARTERLY',      name:'label.quarterly'  },
                {code:'YEARLY',         name:'label.yearly'  },
                {code:'THREE_YEARLY',   name:'label.three_yearly'  },
            ],

            periodTypeList2: [
				{code:'date',        name:'label.date'  },         
                {code:'month',       name:'label.month'  },
                {code:'year',         name:'label.year'  },
            ],

            periodIndexList: [
				{code:'0',       name:'0'  },         
                {code:'-1',      name:'-1'  },
                {code:'-2',      name:'-2'  },
                {code:'-3',      name:'-3'  },
            ],

            holdList: [
				{code:'0',      name:'No Hold'  },         
                {code:'1',      name:'Hold Anyway'  },
                {code:'2',      name:'Terminated Payee '  },
            ],

            agentStateList: [
                {code:'Active',name:'Active'},
                {code:'Pending',name:'Pending'},
                {code:'Terminated',name:'Terminated'},
            ],

            defaultEndDate: "2200-01-01",
            defaultStartDate: "1900-01-01",
        }

    }
    
    getNowDate(){
        let day = new Date();
        //day.setTime(day.getTime());
        let result = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        return result;
    }

    calculateAge(dob) {
        if (typeof dob == "undefined" || dob == null || dob == "") {
            return 0;
        }
        var curdob = dob;
        var isdate = false === (typeof dob === "string");
        if(isdate) {
            curdob = curdob.formatDate("dd/MM/yyyy");
        }
        var curdobsplit = curdob.split('/');
        var birthYear = curdobsplit[2];
        var birthMonth = curdobsplit[1];
        var birthDay = curdobsplit[0];

        var now = new Date();
        var nowYear = now.getFullYear();
        var nowMonth = now.getMonth() + 1;
        var nowDay = now.getDate();

        if(birthYear === nowYear) {
            return 0;
        }
        var ages = new Number(nowYear) - new Number(birthYear);
        var monthdeta = new Number(nowMonth) - new Number(birthMonth);
        if(monthdeta < 0) {
            ages--; 
        }
        else if(monthdeta == 0){
            if(new Number(nowDay) - new Number(birthDay) < 0) {
                ages--; 
            }
        }
        return ages;
    }

    cloneObject(obj) {
        return _.cloneDeep(obj);
    }

    isNull(obj) {
        if (typeof obj == "undefined" || obj == null) {
            return true;
        }
        return false;
    }

    isEmpty(obj) {
        if (typeof obj == "undefined" || obj == null || obj == "") {
            return true;
        }
        return false;
    }

    stringFormat (formatted, args) {
        for (let i = 0; i < args.length; i++) {
          let regexp = new RegExp('\\{' + i + '\\}', 'gi')
          formatted = formatted.replace(regexp, args[i])
        }
        return formatted;
      }
      
    sleep(milliseconds) {
        var start = new Date().getTime();
        while (true) {
            if (new Date().getTime() - start > milliseconds) {
                break;
            }
        }
    }

    checkParams(api, params, type) {
        if (type == 'Request' || type == 'Response') {
            var url = (type == 'Request') ? api + "-Required" : api;
            var local_response = this.readMockupJson(url);
            if (null == local_response) {
                //alert('TempTest ---- ss Could not find Api [' + api + ']');
                return false;
            }
            var errmsg = this.sameJsonStructure(local_response, params);
            if (null !== errmsg) {
                //alert('TempTest ---- ' + type + ' : Parameter Mismatch! Api [' + api + '] : ' + errmsg);
                return false;
            }
        }
        return true;
    }

    readMockupJson(apiurl) {

        var ret = null;
        $.ajax({
            url: apiurl,
            type: "GET",
            async: false,
            data: {},
            timeout: 1000,
            dataType: 'json',
            success: function (data, status, xhr) {
                ret = data.data;
            },
            error: function (xhr, status) {
            },
            complete: function () {
            },
        });
        return ret;
    }

    sameJsonStructure(standard, compare) {
        /*for (var key in standard) {
            if (!(key in compare)) {
                return "Lack of parameter [" + key + "]";
            }
            var val = compare[key];
            if (null == val) {
                return "Lack of value for parameter [" + key + "]";
            }
            var sval = standard[key];
            if (val instanceof Array) {
                if (!(sval instanceof Array)) {
                    return "Parameter [" + key + "] is mis-match";
                }
                if (val.length <= 0) {
                    return null;
                }
                var ret = this.sameJsonStructure(sval[0], val[0]);
                if (null != ret) {
                    return ret;
                }
            }
            else if (val instanceof Object) {
                if (sval instanceof Array || true == ((typeof sval) == 'string')) {
                    return "Parameter [" + key + "] is mis-match";
                }
                var ret = this.sameJsonStructure(sval, val);
                if (null != ret) {
                    return ret;
                }
            }
            else if (false == ((typeof val) == 'string')) {
                return "Parameter [" + key + "] is not string";
            }
        }*/
        return null;
    }
    //input num add ThousandsNoZero
    toThousandsNoZero(num) {
        if(num === '-') {
            return num;
        }
      return num
        ? (isNaN(parseFloat(num.toString().replace(/,/g, "")))
            ? 1
            : parseFloat(num.toString().replace(/,/g, ""))
          )
            .toFixed(2)
            .toString()
            .replace(/(\d)(?=(\d{3})+\.)/g, function($0, $1) {
              return $1 + ",";
            })
        : "";
    }
    //valdate
    validateOnInput(val) {
        switch (val) {
          case "idNo":
            val = val
              .replace(/[^\.\d]/g, "");
            return val;
          case "passNo":
          case "birthNo":
            val = val
              .replace(/[^\.\dA-z]/g, "")
              return val;
          case "yearSupport":
            val = val
              .replace(/[^\.\d]/g, "")
              .replace(".", "");
              return val;
        }
      }
      //Determine if the objects are equal
    objectDiff(obj1,obj2){
            var o1 = obj1 instanceof Object;
        var o2 = obj2 instanceof Object;
        if (!o1 || !o2) {
            return obj1 === obj2;
        }
        if (Object.keys(obj1).length !== Object.keys(obj2).length) {
            return false;
        }
 
        for (var o in obj1) {
            var t1 = obj1[o] instanceof Object;
            var t2 = obj2[o] instanceof Object;
            if (t1 && t2) {
                return objectDiff(obj1[o], obj2[o]);
            } else if (obj1[o] !== obj2[o]) {
                return false;
            }
        }
        return true;

    }
    encryptData(val){
        let publicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC2un/wd0+CN8V+QVDlSFzVmakjJdufeRrx36WffIBD4PbT8DUgZ5nE0jRSJW7mO+n/QKo4EQZliny9IOKU34CiCD+j06U9Xqj5oe448s0F/yQMjxDjLrUK7FNfzgKq7P1vbCvbhLijDVWDAOGxHsZNebTHP0cTb3ocgskDb1peewIDAQAB';
        let encryptor = new JSEncrypt();
        encryptor.setPublicKey('-----BEGIN PUBLIC KEY-----' +publicKey+ '-----END PUBLIC KEY-----');
        return encryptor.encrypt(val);
    }

    encryptDataSHA(val){
       let encrypted = hex_sha1(val);
       return encrypted;
    }

    encryptByDES(message) {
        let key = "refy5678";
        //let encrypted = desEncrypt.default.des(key,message,1,0);
        let encrypted = desEncrypt.default.des (key, message, 1, 0, "", 1);
        

        return desEncrypt.default.stringToHex(encrypted);
    }

    decryptByDES(message) {
        let key = "refy5678";
        let decrypted = desEncrypt.default.hexToString(message);
        return  desEncrypt.default.des(key,decrypted,0);
    }

    decryptData(val){
        let publicKey = globalConstants.publicKey;// get public key  from server
        let encryptor = new JSEncrypt(); 
        encryptor.setPrivateKey(publicKey); 
        return  encryptor.decrypt(val);
    }

    decryptData(val) {
        let publicKey = globalConstants.publicKey;
        let encryptor = new JSEncrypt();  
        encryptor.setPrivateKey(publicKey); 
        return encryptor.decrypt(val);
      }


    ruleConditionMap(){
        return ruleconmap;
    }
    
    async getFreqList(instance){
        //To do
        var param = {};
        let {processingunit,businessunit}=store.state.user.userInfo;
        param.company=processingunit?processingunit:'';
        param.channel=businessunit?businessunit:'';        

        if(Utility.prototype.freqList.length>0){
            return;
        }

        instance.$caller.frequency_infor_query(param).then(res => {
            //alert(res);
            if(Utility.prototype.freqList.length>0){
                return;
            }
            if (res.responseCode =="000"){
                if(res.rule_frequency.length >0){
                    res.rule_frequency.forEach((element, index)=>{
                        Utility.prototype.freqList.push({code: element.name, name: element.description});
                    });
                }
            }
            
        });  
    }

    async getGeneralTypeList(key, instance){
        //To do-

        var param = {
            "key": key,
        };
 
        if(Utility.prototype[key+'List'].length>0){
            return;
        }
        instance.$caller.general_infor_query(param).then(res => { 
            if (res.responseCode =="000"){
                let resKey=key=="agencyTitle"?"title":key;
                if(res[resKey].length >0){
                    Utility.prototype.initGeneralList(Utility.prototype[key+'List'],res[resKey]);
                }
            } 
        });  
    }

    async getHierarchyTree(instance){        
        
        var param = {
            action:"GET", 
            recordType: "AGY",
            nodeType: "CHILDREN",
            isLast: "1",
            code: "AIA Top Level",
        };

        let {processingunit,businessunit}=store.state.user.userInfo;
        param.company=processingunit?processingunit:'';
        param.channel=businessunit?businessunit:'';


        Utility.prototype.hierarchyTree ={};

        var resultPromise = instance.$caller.position_query(param).then(res=>{
            if (res.responseCode =="000"){
                if(res.positionNodeModel.length >0){
                    Utility.prototype.hierarchyTree=createTree(res.positionNodeModel,'participantSeq','code','childNodeModel',['recordType','title','leaderCode','leaderTitle']);
                    return Utility.prototype.hierarchyTree;
                }
            } 
        });
        return resultPromise;
    }

    getCityList(instance){
        Utility.prototype.cityList = [
            {code:"Yangon",     name:'Yangon',     type:'select',  needParameter:false, optionList: null          },
            {code:"Naypyitaw",  name:'Naypyitaw',  type:'select',  needParameter:false, optionList: null          },			
            {code:"Mandalay",   name:"Mandalay",   type:'select',  needParameter:false, optionList: null         },
           ];
    }
    getSummaryData(instance){

        Utility.prototype.SummaryList = [
            {code:"Relationship",                 name:'Relationship',                  isVariable:false,       type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("relationship", instance)     },
            {code:"FYC",                          name:'FYC',                           isVariable:true,        type:'input',   needParameter:false, optionList: null                                  },
            {code:"RYC",                          name:'RYC',                           isVariable:true,        type:'input',   needParameter:false, optionList: null                                  },
            {code:"FYP",                          name:'FYP',                           isVariable:true,        type:'input',   needParameter:false, optionList: null                                  },
            {code:"RYP",                          name:'RYP',                           isVariable:true,        type:'input',   needParameter:false, optionList: null                                  },
            {code:"ManPower",                     name:"Man Power",                     isVariable:true,        type:'input',   needParameter:false, optionList: null                                  },
            {code:"MA",                           name:'Manual Adjustment',             isVariable:true,        type:'input',   needParameter:false, optionList: null                                  },
            {code:"Contributor_Title",            name:'Contributor Title',             isVariable:false,       type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("title", instance)           },
            {code:"Contributor_Classcode",        name:'Contributor Class Code',        isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Contributor_LeaderTitle",      name:'Contributor Leader Title',      isVariable:false,       type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("title", instance)           },			
            {code:"Contributor_AgentCode",        name:"Contributor Agent Code",        isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Contributor_LeaderCode",       name:"Contributor Leader Code",       isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Contributor_AgencyCode",       name:"Contributor Agency Code",       isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Contributor_ContractDate",     name:"Contributor Contract Date",     isVariable:false,       type:'date',    needParameter:false, optionList: null                                  },
            {code:"Contributor_TerminatedDate",   name:"Contributor Terminated Date",   isVariable:false,       type:'date',    needParameter:false, optionList: null                                  },			
            {code:"Receiver_Title",               name:'Receiver Title',                isVariable:false,       type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("title", instance)           },
            {code:"Receiver_Classcode",           name:'Receiver Class Code',           isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_LeaderTitle",         name:'Receiver Leader Title',         isVariable:false,       type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("title", instance)           },			
            {code:"Receiver_AgentCode",           name:"Receiver Agent Code",           isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_LeaderCode",          name:"Receiver Leader Code",          isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_AgencyCode",          name:"Receiver Agency Code",          isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_ContractDate",        name:"Receiver Contract Date",        isVariable:false,       type:'date',    needParameter:false, optionList: null                                  },
            {code:"Receiver_TerminatedDate",      name:"Receiver Terminated Date",      isVariable:false,       type:'date',    needParameter:false, optionList: null                                  },
            {code:"Period",                       name:"System Period",                 isVariable:false,       type:'date',    needParameter:false, optionList: null                                  },
            {code:"Product",                      name:'Product',                       isVariable:false,       type:'input',   needParameter:false, optionList: null                                  },
        ];
    }

    getMeasurementData(instance){

        Utility.prototype.measurementList = [
            {code:"Receiver_Title",               name:'Receiver Title',               isVariable:false,         type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("title", instance)           },
            {code:"Receiver_LeaderTitle",         name:'Receiver Leader Title',        isVariable:false,         type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("title", instance)           },			
            {code:"Receiver_AgentCode",           name:"Receiver Agent Code",          isVariable:false,         type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_LeaderCode",          name:"Receiver Leader Code",         isVariable:false,         type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_AgencyCode",          name:"Receiver Agency Code",         isVariable:false,         type:'input',   needParameter:false, optionList: null                                  },
            {code:"Receiver_ContractDate",        name:"Receiver Contract Date",       isVariable:false,         type:'date',    needParameter:false, optionList: null                                  },
            {code:"Receiver_TerminatedDate",      name:"Receiver Terminated Date",     isVariable:false,         type:'date',    needParameter:false, optionList: null                                  },
            {code:"Period",                       name:"System Period",                isVariable:false,         type:'date',    needParameter:false, optionList: null                                  },
        ];
    }

    getFunctionList(instance){
        Utility.prototype.functionList = [
            {code:"T_MONTH_DIFF",    name:"Function Month Different",  isVariable:false,   type:'input',  needParameter: true,    
            parameterList: [
                    {type: "autoInput", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), suggestionType: "date", placeholder: "<Begin Date>"}, 
                    {type: "autoInput", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), suggestionType: "date", placeholder: "<End Date>"}, 
                ],
            },

            {code:"T_DATE_DIFF",    name:"Function Day Different",   isVariable:false,  type:'input',  needParameter: true,    
            parameterList: [
                    {type: "autoInput", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), suggestionType: "date", placeholder: "<Begin Date>"}, 
                    {type: "autoInput", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), suggestionType: "date", placeholder: "<End Date>"}, 
                ],
            },
            
            // {code:"T_YEAR_DIFF",    name:"Function Year Different",    type:'input',  needParameter: true,    
            // parameterList: [
            //         {type: "autoInput", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), suggestionType: "date", placeholder: "<Begin Date>"}, 
            //         {type: "autoInput", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), suggestionType: "date", placeholder: "<End Date>"}, 
            //     ],
            // },            
            {code:"T_ISBLANK",    name:"Function Is Blank",  isVariable:false,   type:'select',   optionList: Utility.prototype.data().yesNoList2,   needParameter: true,
            parameterList: [
                    {type: "select", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), placeholder: "<Select Field>",}, 
                ],
            },

            {code:"T_CONTAIN",    name:"Function Is Contain",  isVariable:false,  type:'select',   optionList: Utility.prototype.data().yesNoList2,    needParameter: true,
            parameterList: [
                {type: "select", optionList:instance.ruleGroupModel.summaryType == "MEASUREMENT"?Utility.prototype.getGeneralList("measurement", instance):Utility.prototype.getGeneralList("summary", instance), placeholder: "<Select Field>",}, 
                {type: "input", placeholder: "<Input a check list>",}, 
                ],
            },

            // {code:"T_IS_PAID",    name:"Function Is Paid",   isVariable:false,  type:'select',   optionList: Utility.prototype.data().yesNoList2,      needParameter: true,
            // parameterList: [
            //         {type: "input", placeholder: "<Rule Name>",}, 
            //         {type: "input", placeholder: "<Offset>",},
            //     ],
            // },
        ];
    }

    getFunctionMeasurementList(instance){
        Utility.prototype.functionMeasurementList = [
            {code:"T_MEASUREMENT_VALUE",    name:"Function Get Measurement", isVariable:false,    type:'input',   needParameter: true,
            parameterList: [
                    {type: "input", placeholder: "<Measurement Name>",},
                ],
            },

            {code:"measurementValue",    name:"Function Get Measurement", isVariable:true, isCondition:false,   type:'input',   needParameter: true,
            parameterList: [
                    {type: "input", placeholder: "<Measurement Name>",},
                ],
            },
        ];
    }

    getEntityList(instance){
        Utility.prototype.entityList = [
            {code:"AGY",  name:'Agency',       },
            {code:"DIS",  name:'District',    },			
            {code:"SDIS", name:"Super District ",     },
        ];
    }

    getGeneralList(name, instance){
        if(name=="summary"){
            if(Utility.prototype.SummaryList.length ==0){
                Utility.prototype.getSummaryData(instance);
            }
            return Utility.prototype.SummaryList;
        }
        else if(name=="measurement"){
            if(Utility.prototype.measurementList.length ==0){
                Utility.prototype.getMeasurementData(instance);
            }
            return Utility.prototype.measurementList;
        }
        else if(name=="function"){
            if(Utility.prototype.functionList.length ==0){
                Utility.prototype.getFunctionList(instance);
            }
            return Utility.prototype.functionList;
        }
        else if(name=="functionMeasurement"){
            if(Utility.prototype.functionMeasurementList.length ==0){
                Utility.prototype.getFunctionMeasurementList(instance);
            }
            return Utility.prototype.functionMeasurementList;
        }       
        else if(name=="frequency"){
            if(Utility.prototype.freqList.length ==0){
                Utility.prototype.getFreqList(instance);
            }
            return Utility.prototype.freqList;
        }
        else if(name=="city"){
            if(Utility.prototype.cityList.length ==0){
                Utility.prototype.getCityList(instance);
            }
            return Utility.prototype.cityList;
        }
        else if(name=="entity"){
            if(Utility.prototype.entityList.length ==0){
                Utility.prototype.getEntityList(instance);
            }
            return Utility.prototype.entityList;
        }
        else if(name=="hierarchyTree"){
            if(Utility.prototype.isEmpty(Utility.prototype.hierarchyTree)){
                return Utility.prototype.getHierarchyTree(instance);
            }
            return Utility.prototype.hierarchyTree;
        }
        else if(name=='kpi'){
            if(Utility.prototype.kpiList.length==0){
                Utility.prototype.getKpiList();
            }
            return Utility.prototype.kpiList;
        }
        else if(name=="segment"){
            if(Utility.prototype.segmentList.length ==0){
                Utility.prototype.getSegmentList(instance);
            }
            return Utility.prototype.segmentList;
        }
        else if(name=="product"){
            if(Utility.prototype.productList.length ==0){
                Utility.prototype.getProductList(instance);
            }
            return Utility.prototype.productList;
        }
        else {
            if(Utility.prototype[name+'List'].length==0){  
                Utility.prototype.getGeneralTypeList(name, instance);
            }
            return Utility.prototype[name+'List'];
        }
    }

    getKpiList(){
        Utility.prototype.kpiList=[
            {code:"FYC",                          name:'FYC',},
            {code:"RYC",                          name:'RYC',},
            {code:"FYP",                          name:'FYP',},
            {code:"RYP",                          name:'RYP',},
            {code:"ManPower",                     name:"Man Power",},
            {code:"MA",                           name:'Manual Adjustment',},
        ]
    }



    getSegmentList(instance){
        Utility.prototype.segmentList=[
            {code:"TRANSACTION_PROCESSINGUNIT",           name:'Company',           isVariable:false,       type:'select',   needParameter:false, optionList: Utility.prototype.getGeneralList("company", instance)},
            {code:"TRANSACTION_BUSINESSUNIT",         name:'Channel',         isVariable:false,       type:'select',  needParameter:false, optionList: Utility.prototype.getGeneralList("channel", instance)},			
            {code:"TRANSACTION_GENERICDATE5",           name:"Coverage Submit Date",           isVariable:false,       type:'date',   needParameter:false, optionList: null},
            {code:"MANAGER_TITLESEQ",          name:"Entity Type",          isVariable:false,       type:'select',   needParameter:false, optionList: Utility.prototype.getGeneralList("agencyTitle", instance)},
            {code:"POSITION_TITLESEQ",          name:"Agent Title",          isVariable:false,       type:'select',   needParameter:false, optionList: Utility.prototype.getGeneralList('title',instance)},
            {code:"POSITION_ManagerAgency",        name:"Manager Agency",        isVariable:false,       type:'input',    needParameter:false, optionList: null},
            {code:"PARTICIPANT_HIREDATE",      name:"Hire Date",      isVariable:false,       type:'date',    needParameter:false, optionList: null},           
        ];
    }

    getProductList(instance){
        Utility.prototype.productList=[
            {code:"PRODUCTID",        name:"Product ID",        isVariable:false,       type:'input',    needParameter:false, optionList: null},
            {code:"PRODUCTNAME",      name:"Product Name",      isVariable:false,       type:'input',    needParameter:false, optionList: null},       
            {code:"PRODUCTDESCRIPTION",        name:"Product Description",        isVariable:false,       type:'input',    needParameter:false, optionList: null},
            {code:"PRODUCTCATEGORY",      name:"Product Category",      isVariable:false,       type:'input',    needParameter:false, optionList: null},                                     
        ];
    }

    async initGeneralInformation(instance){
        try{
            if(Utility.prototype.companyList.length ==0){
                await Utility.prototype.getGeneralTypeList('company', instance);
            }
            if(Utility.prototype.channelList.length ==0){
                await Utility.prototype.getGeneralTypeList('channel',instance);
            }
            if(Utility.prototype.titleList.length ==0){
                await Utility.prototype.getGeneralTypeList('title',instance);
            }
            if(Utility.prototype.freqList.length ==0){
                await Utility.prototype.getFreqList(instance);
            }
            if(Utility.prototype.relationshipList.length ==0){
                await Utility.prototype.getGeneralTypeList('relationship',instance);
            }
            if(Utility.prototype.summarytypeList.length ==0){
                await Utility.prototype.getGeneralTypeList('summarytype',instance);
            }
        }catch(e){

        }

    }

    async initGeneralInformationChannelAdmin(instance){
        try{
            if(Utility.prototype.companyList.length ==0){
                await Utility.prototype.getGeneralTypeList('company', instance);
            }
            if(Utility.prototype.channelList.length ==0){
                await Utility.prototype.getGeneralTypeList('channel',instance);
            }
            if(Utility.prototype.titleList.length ==0){
                await Utility.prototype.getGeneralTypeList('title',instance);
            }
            if(Utility.prototype.agencyTitleList.length ==0){
                await Utility.prototype.getGeneralTypeList('agencyTitle',instance);
            }
            if(Utility.prototype.relationshipList.length ==0){
                await Utility.prototype.getGeneralTypeList('relationship',instance);
            }
            if(Utility.prototype.entityList.length ==0){
                await Utility.prototype.getEntityList(instance);
            }
            if(Utility.prototype.isEmpty(Utility.prototype.hierarchyTree)){
                await Utility.prototype.getHierarchyTree(instance);
            }
        }catch(e){

        }


    }

    async initGeneralInformationContest(instance){
        try{
            if(Utility.prototype.companyList.length ==0){
                await Utility.prototype.getGeneralTypeList('company', instance);
            }    
            if(Utility.prototype.channelList.length ==0){
                await Utility.prototype.getGeneralTypeList('channel',instance);
            }
        }catch(e){
            console.log(e);
        }
    }


    initGeneralList(tarGetList,sourceList){
       // alert(" initGeneralList: " + JSON.stringify(sourceList));
        if(sourceList.length ==0 ){
            return;
        }

        if(tarGetList.length >0 ){
            return;
        }

        //var tarGetList = [];
        sourceList.forEach((element, index)=>{
            tarGetList.push({code: element.name, name: element.name});
        });

        if(tarGetList==Utility.prototype.companyList){
            Utility.prototype.configGeneralList(Utility.prototype.companyList,'processingunit');
        }
        if(tarGetList==Utility.prototype.channelList){
            Utility.prototype.configGeneralList(Utility.prototype.channelList,'businessunit');
        }
        //return tarGetList;
    }

    configGeneralList(list,field){
        let name=store.state.user.userInfo[field];
        if(name){
            list.forEach(x=>{
                x.disabled=true;            
                if(x.code==name){
                    x.disabled=false;
                }
            })            
        }else{//name=null
            list.forEach(x=>{
                x.disabled=false; 
            })             
        }
    }


    resetGeneralList(name){
        Utility.prototype[name+'List']=[];
    }

    async getRuleSummaryList(instance,currentPage,pageSize,queryParam){
          var param = {
            startPage: currentPage,
            pageSize: pageSize,
            action: 'GET',
            name: queryParam.name,
            company: queryParam.company,
            channel: queryParam.channel,
            paymentFlag: queryParam.paymentFlag,
            description: queryParam.description,
            frequency: queryParam.frequency,
            activeFlag: queryParam.activeFlag,
            summaryType:queryParam.summaryType,
            //effectedStartDate: queryParam.effectedStartDate,
            //effectedEndDate: queryParam.effectedEndDate,
            ruleGroupModelId: queryParam.ruleGroupModelId,
          }; 

          var res = await instance.$caller.rule_summary_query(param);
          return res;
       
    }
    
    pending(milSec) { 
        return new Promise((resolve, reject) => { 
     
            setTimeout(() => { 
     
                resolve("timeout"); 
     
            }, milSec); 
     
        }) 
     
    }

    checkPageAuthority(page){
        let {authority}={...store.state.user};
        let {radioValue}={...pageConfig};
        let temp=authority.find(p=>p.code===page);

        let canRead=false;
        if(temp){
            switch(temp.radioValue){
                case radioValue.NoPermission:canRead=false;
                break;
                case radioValue.Read:canRead=true;
                break;
                case radioValue.Modify:canRead=true;
                break;
            }
        }
        return canRead;
    }

    checkEditPermission(page){
        let isModify=false;
        let temp=store.state.user.authority.find(x=>x.code==page);
        if(temp){
            isModify=temp.radioValue==pageConfig.radioValue.Modify?true:false;
        }
        return isModify;
    }

    responseDesc(reasonDesc){
        let desc='Reason description: \n ';
        if(reasonDesc instanceof Array){
            reasonDesc.forEach(x=>{
                desc+=x+' \n ';
            });
        }else{
            desc=reasonDesc;
        }
        return desc;
    }
}


export default new Utility();