import EXIF from 'exif-js';

Promise.prototype.disableMsg = function () {
  this._disableMsg = true
  return this
}
Date.prototype.getAge = function (fmt) {
  var birthdays = new Date(fmt);
  var d = new Date();
  var age =
    d.getFullYear() -
    birthdays.getFullYear() -
    (d.getMonth() < birthdays.getMonth() ||
      (d.getMonth() == birthdays.getMonth() &&
        d.getDate() < birthdays.getDate()) ?
      1 :
      0);
  return age;
}
Date.prototype.formatDate = function (fmt) {
  var o = {
    'M+': this.getMonth() + 1, // 月
    'd+': this.getDate(), // 日
    'h+': this.getHours() % 12 == 0 ? 12 : this.getHours() % 12, // 时
    'H+': this.getHours(), // 小时
    'm+': this.getMinutes(), // 分
    's+': this.getSeconds(), // 秒
    'q+': Math.floor((this.getMonth() + 3) / 3), // 季
    'S': this.getMilliseconds(), // 毫秒
  }
  var week = {
    '0': '\u65e5',
    '1': '\u4e00',
    '2': '\u4e8c',
    '3': '\u4e09',
    '4': '\u56db',
    '5': '\u4e94',
    '6': '\u516d',
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  if (/(E+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? '\u661f\u671f' : '\u5468') : '') + week[this.getDay() + ''])
  }
  for (var k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }
  return fmt
}
String.prototype.getDate = function () {
    let arr, d, m, y, date;
    arr = this.split("/");
    if (arr.length === 3) {
      d = arr[0] - 0;
      m = arr[1] - 1;
      y = arr[2] - 0;
      date = new Date(y, m, d);
    }
    return date
  };
  String.prototype.getSelectObj = function () {
    // let reg = /([A-Za-z|\s]+)_(\d*)/;
    // let res = reg.exec(this)
    // // console.log(res)
    let res = this.split('_')
    return {
      name: res[0],
      code: res[1],
    }
  };
// delete array element by value

Array.prototype.removeByValue = function (val) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == val) {
      this.splice(i, 1)
      break
    }
  }
}

export default {
  // compareVal
  isFunction,
  isArray,
  isPlainObject,
  photoCompress,
  offset,
  throttle,
}

function isFunction(it) {
  return toString.call(it) === '[object Function]';
}

function isArray(it) {
  return toString.call(it) === '[object Array]';
}

function isPlainObject(obj) {
  return toString.call(obj) === "[object Object]";
}

function photoCompress(file, w, objDiv, rotate) {

  var ready = new FileReader();
  ready.readAsDataURL(file);
  ready.onload = function () {
    var re = this.result;
    canvasDataURL(re, w, objDiv, rotate)
  }
}
//rotate img
function rotateImg(img, Orientation, canvas, obj) {
  var height = img.height;
  var width = img.width;
   var degree ;
   var ctx = canvas.getContext('2d');
  switch (Orientation) {
    case 6:
      //  alert('1.1');
      canvas.width = height;
      canvas.height = width;
      degree =  90 * Math.PI / 180;
      ctx.rotate(degree);
      ctx.drawImage(img, 0, -height);
      if (obj.time) {
        let waterCa = createWaterCanvas(canvas.width, canvas.height);
        ctx.rotate(-degree)
        ctx.drawImage(waterCa, 0, 0)
      }
      break;
    case 3:
      // alert(2.1)
      canvas.width = width;
      canvas.height = height;
      degree = 180 * Math.PI / 180;
      ctx.rotate(degree);
      ctx.drawImage(img, -width, -height);
      if (obj.time) {
        let waterCa = createWaterCanvas(canvas.width, canvas.height);
        ctx.rotate(-degree)
        ctx.drawImage(waterCa, 0, 0)
      }
      break;
    case 8:
      //  alert(3.1)
      canvas.width = height;
      canvas.height = width;
      degree = 3 * 90 * Math.PI / 180;
      ctx.rotate(degree);
      ctx.drawImage(img, -width, 0);
      if (obj.time) {
        let waterCa = createWaterCanvas(canvas.width, canvas.height);
        ctx.rotate(-degree)
        ctx.drawImage(waterCa, 0, 0)
      }
      break;
  }
}

function createWaterCanvas(w, h) {
  var canvas = document.createElement('canvas');
  var watermarkCtx = canvas.getContext('2d');
  var anw = document.createAttribute("width");
  anw.nodeValue = w;
  var anh = document.createAttribute("height");
  anh.nodeValue = h;
  canvas.setAttributeNode(anw);
  canvas.setAttributeNode(anh);
  var fontSize = w > 1000?50:w>250? 22 : w < 249 ? 12 : w * 0.055;
  watermarkCtx.font = fontSize + "px AIABody";
  watermarkCtx.lineWidth = "1";
  watermarkCtx.fillStyle = "rgba(0, 0, 0, 0.2)"
  watermarkCtx.fillRect(0, 0, w, h)
  watermarkCtx.fillStyle = "rgba(0, 0, 0, 1)"
  const monthMap = {
    "Jan": "January",
    "Feb": "February",
    "Mar": "March",
    "Apr": "April",
    "May": "May",
    "Jun": "June",
    "Jul": "July",
    "Aug": "August",
    "Sep": "September",
    "Oct": "October",
    "Nov": "November",
    "Dec": "December",
  }
  let dataText = new Date().toString().split(" ");
  dataText[0] = dataText[0] + ",";
  dataText[1] = monthMap[dataText[1]];
  dataText = "Date: " + " " + dataText.slice(0, 5).join(" ");
  watermarkCtx.fillText(dataText, 20, 40);
  return canvas;
}
function canvasDataURL(path, obj, callback, Orientation) {
  var img = new Image();
  img.src = path;

  img.onload = function () {
    var that = this;

    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    var w = that.width,h = that.height;
    var scale = w / h;
    w = obj.width || w;
    w = w < 1280 ? w : 1280;
    h = obj.height || (w / scale);
    canvas.width = w;
    canvas.height = h;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    var quality = 0.7; // defult quality 0.7

    if (Orientation&&Orientation != "" && Orientation != 1) {
      switch (Orientation) {
        case 6:
        case 8:
        case 3:
          // alert('need  rotate 180 ');
          rotateImg(this, Orientation, canvas, obj);  
          break;
      }
    } else {
      if (obj.time) {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        let waterCa = createWaterCanvas(canvas.width, canvas.height);
        ctx.drawImage(waterCa, 0, 0)
      }else{
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      }
    }


    // image quality
    if (obj.quality && obj.quality <= 1 && obj.quality > 0) {
      quality = obj.quality;
    }

    var base64 = canvas.toDataURL('image/jpeg', quality);
    callback(base64);

  }
}

function convertBase64UrlToBlob(urlData) {
  var arr = urlData.split(','),
    mime = arr[0].match(/:(.*?);/)[1],
    bstr = atob(arr[1]),
    n = bstr.length,
    u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], {
    type: mime,
  });
}

function offset(target) {
  var top = 0,
    left = 0

  while (target.offsetParent) {
    top += target.offsetTop
    left += target.offsetLeft
    target = target.offsetParent
  }

  return {
    top: top,
    left: left,
  }
}

function throttle(method, delay) {
  var timer = null;
  return function () {
    var context = this,
      args = arguments;
    clearTimeout(timer);
    timer = setTimeout(function () {
      method.apply(context, args);
    }, delay);
  }
}