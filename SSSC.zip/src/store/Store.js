import Vue from 'vue'
import Vuex from 'vuex'
import * as Cookies from 'vue-cookies'
import createPersistedState from 'vuex-persistedstate'
// import contact from './Contact.js'
// import quotation from './Quotation.js'
// import application from './Application.js'
import user from './User.js'
import role from './Role.js'

Vue.use(Vuex)
export default new Vuex.Store({
  modules: {
    // contact: contact,
    // quotation:quotation,
    // application:application,
    user:user,
    role:role,
  },
  state: {
    // agent:{},
    // agentCode:'',
    // contactId:'',
    // quotationId:'',
    // applicationId:'',
    // beneficiaryId:'',
    // steps:[],
    // planType:'',
    // payorFormData:{},
    // search:false,
    // contactName:"",
    // searchVal:"",
    // searchContactId:"",
    // searchContactName:"",
  },
  mutations: {
    setSearchContactId(state,data){
      state.searchContactId = data
    },
    setSearchContactName(state,data){
      state.searchContactName = data
    },
    setSearchVal(state,data){
      state.searchVal = data
    },
    setSearch(state,data){
      state.search = data
    },
    setContactName(state,data){
     state.contactName = data
    },
    setPayorForm(state,data){
      state.payorFormData = {...data};
    },
    loginStatus(state,data){
      state.agent = data;
      state.agentCode = data.agentCode;
    },
    resetIds(state){
      state.contactId = '';
      state.quotationId = '';
      state.applicationId = '';
      state.beneficiaryId = '';
      state.steps = [];
    },
    reset(state,type){
      switch (type){
        case 'application':
          state.applicationId = '';
          break
        case 'quotation':
          state.quotationId = '';
          break
        case 'contact':
          state.contactId = '';
          break
        case 'beneficiary':
          state.applicationId = '';
          break
        case 'steps':
          state.steps = []
          break
        default:
          return;
      }
    },
    setContactId(state,id){
      state.contactId = id;
    },
    setQuotationId(state,id){
      state.quotationId = id;
    },
    setApplicationId(state,id){
      state.applicationId = id;
    },
    setbeneficiaryId(state,id){
      state.beneficiaryId = id;
    },
    setPlanType(state,data){
      // console.log(data.toLowerCase)
      if(data && data.toLowerCase().indexOf('special')>-1)
       {state.planType = 'special';}
      else{
        state.planType = 'flex'
      }
    },
    setSteps(state,steps){
      for(let index=0;index<steps.length;index++){
        if(steps[index].completedStatus=='1'||steps[index].completedStatus=='2'){
          steps[index].clickable = '1';
          if(steps[index+1]&&steps[index+1].item!=='E-SUBMIT'){
            switch(steps[index+1].completedStatus){
              case '1':
                steps[index+1].clickable = '1';
                break;
              default:
                steps[index+1].clickable = '2';
            }
          }
        } else if(steps[index].completedStatus=='0'){
          for(let i=index+1;i<steps.length;i++){
            steps[i].clickable = '0';  
          }
          break;
        }
      }
      state.steps = steps;
    },
    setFinishStep(state,data){
      let curStep = data.step?data.step.toUpperCase():data.toUpperCase();
      if(state.steps.length!==0&&curStep){
        for(let index=0;index<state.steps.length;index++){
          if(state.steps[index].item === curStep){
            state.steps[index].completedStatus = data.status?data.status:"1";
            state.steps[index].clickable = data.status?data.status:"1";
          }
          if(state.steps[index].completedStatus=='1'||state.steps[index].completedStatus=='2'){
            state.steps[index].clickable = '1';
            if(state.steps[index+1]&&state.steps[index+1].item!=='E-SUBMIT'){
              switch(state.steps[index+1].completedStatus){
                case '1':
                  state.steps[index+1].clickable = '1';
                  break;
                default:
                  state.steps[index+1].clickable = '2';
              }
            }
          } else if(state.steps[index].completedStatus=='0'){
            for(let i=index+1;i<state.steps.length;i++){
              state.steps[i].clickable = '0';  
            }
            break;
          }
        } 
      }
    },
    setNotFinishStep(state,data){
      let curStep = data.toUpperCase()
      if(state.steps.length!==0&&curStep){
        state.steps.forEach((step,index)=>{
          if(step.item === curStep){
            step.completedStatus = "0";
            for(let i=index+1;i<state.steps.length;i++){
              state.steps[i].clickable = '0';
            }
          }
        })
      }
    },
    setStepStatus(state,data){
      let curStep = data.step?data.step.toUpperCase():data.toUpperCase();
      state.steps.forEach((step,index)=>{
        if(curStep===step.item){
          step.completedStatus = data.status?data.status:"1";
        }
      })
    },
  },
  getters:{
    
  },
  actions:{

  },
  plugins: [createPersistedState({
    key:"store",
    storage: {
      getItem: key => Cookies.get(key),
      // Please see https://github.com/js-cookie/js-cookie#json, on how to handle JSON.
      setItem: (key, value) => Cookies.set(key, value, { expires: 3, secure: true }),
      removeItem: key => Cookies.remove(key),
    },
  })],
})
