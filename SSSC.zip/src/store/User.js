import caller from '@/models/ApiCaller'

const user={
    namespaced:true,
    state: {
        userInfo:null,
        allUsers:[],
        authority:[],
        isAdmin:false,
    },
    mutations:{
        assignAllUsers(state,list){
            if(list){
                state.allUsers=list.map(user=>{
                    let newUser={
                        loginId:user.loginId,
                        username:user.username,
                    };
                    return newUser;
                });
            }
        },
        addUser(state,newUser){
            state.allUsers.push(newUser);
        },
        deleteUser(state,loginId){
            let index=state.allUsers.findIndex(x=>x.loginId==loginId);
            state.allUsers.splice(index,1);
        },
    },
    actions:{
        async queryUsers({commit}){
            let param={actions:"GET"};
            let res=await caller.users_query(param);
            if(res.responseCode==="000"){
                commit("assignAllUsers",res.data);
            }
        },
    },
}

export default user;