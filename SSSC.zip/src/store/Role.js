import caller from '@/models/ApiCaller'

const role={
    namespaced:true,
    state:{
        allRoles:[],
    },
    mutations:{
        assignAllRoles(state,list){
            if(list){
                state.allRoles=list.map(role=>{
                    return role.roleName;
                });
            }
        },
        addRole(state,newRole){
            state.allRoles.push(newRole);
        },
        deleteRole(state,roleId){
            let index=state.allRoles.findIndex(x=>x.roleId==roleId);
            state.allRoles.splice(index,1);
        },
    },
    actions:{
        async queryRoles({commit}){
            let param={actions:"GET"};
            let res=await caller.roles_query(param);
            if(res.responseCode==="000"){
                commit("assignAllRoles",res.rolelist);
            }
        }
    },
}

export default role;
