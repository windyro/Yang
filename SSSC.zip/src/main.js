 /* jshint esversion: 6 */ 
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill';
import Vue from 'vue';
import App from '@/App';
import cookies from 'vue-cookies';
import router from '@/router/Router';
import i18n from '@/models/i18n';
import caller from '@/models/ApiCaller';
import utility from  '@/models/Utility';
import ext from '@/models/Ext';
import EXIF from 'exif-js';
import mixin from '@/models/mixin/Mixin';
import store from '@/store/Store';
import iRegex from '@/models/Regex';
import formValidator from '@/models/FormValidator';
// iconfont
import '@/assets/iconfont/iconfont.js';
import '@/assets/iconfont/iconfont.css';
//vue drag
import VueDND from 'awe-dnd';
// css style
import '@/assets/css/index.scss';
import 'element-ui/lib/theme-chalk/icon.css';
 //import 'element-ui/lib/theme-chalk/index.css';
 // import ElementUI as required

import VueSignaturePad from 'vue-signature-pad';
import {
  Scrollbar,
  Pagination,
  Dialog,
   Autocomplete,
   Dropdown,
   DropdownMenu,
   DropdownItem,
  // Menu,
  // Submenu,
  // MenuItem,
  // MenuItemGroup,
  Input,
  // InputNumber,
  Radio,
  RadioGroup,
  RadioButton,
  Checkbox,
  // CheckboxButton,
  CheckboxGroup,
  // Switch,
  Select,
  Option,
  OptionGroup,
  Button,
  // ButtonGroup,
  Table,
  TableColumn,
   DatePicker,
  // TimeSelect,
  // TimePicker,
 Popover,
  // Tooltip,
  // Breadcrumb,
  // BreadcrumbItem,
  Form,
  FormItem,
  Tabs,
  TabPane,
  // TabPane,
   Tag,
  Tree,
  // Alert,
  // Slider,
  // Icon,
   Row,
   Col,
  Upload,
  // Progress,
  // Badge,
  // Card,
  // Rate,
  Steps,
  Step,
  // Carousel,
  // CarouselItem,
  Collapse,
  CollapseItem,
  // Cascader,
  // ColorPicker,
  Transfer,
  // Container,
  // Header,
  // Aside,
  // Main,
  // Footer,
   Loading,
   Link,
  MessageBox,
  // Message,
  // Notification
}  from 'element-ui';
Vue.use(Pagination);
Vue.use(Scrollbar); 
Vue.use(Dialog);
Vue.use(Autocomplete);
Vue.use(Dropdown);
Vue.use(DropdownMenu);
Vue.use(DropdownItem);
// Vue.use(Menu);
// Vue.use(Submenu);
// Vue.use(MenuItem);
// Vue.use(MenuItemGroup);
Vue.use(VueDND);
Vue.use(Input);
// Vue.use(InputNumber);
 Vue.use(Radio);
Vue.use(RadioGroup);
Vue.use(RadioButton);
Vue.use(Checkbox);
// Vue.use(CheckboxButton);
Vue.use(CheckboxGroup);
// Vue.use(Switch);
Vue.use(Select);
Vue.use(Option);
Vue.use(OptionGroup);
Vue.use(Button);
// Vue.use(ButtonGroup);
Vue.use(Table);
Vue.use(TableColumn);
Vue.use(DatePicker);
// Vue.use(TimeSelect);
// Vue.use(TimePicker);
 Vue.use(Popover);
// Vue.use(Tooltip);
// Vue.use(Breadcrumb);
// Vue.use(BreadcrumbItem);
Vue.use(Form);
Vue.use(FormItem);
Vue.use(DatePicker);
 Vue.use(Tabs);
 Vue.use(TabPane);
// Vue.use(TabPane);
 Vue.use(Tag);
Vue.use(Tree);
// Vue.use(Alert);
// Vue.use(Slider);
// Vue.use(Icon);
 Vue.use(Row);
 Vue.use(Col);
Vue.use(Upload);
// Vue.use(Progress);
// Vue.use(Badge);
// Vue.use(Card);
// Vue.use(Rate);
Vue.use(Steps);
Vue.use(Step);
 Vue.use(VueSignaturePad);
// Vue.use(Carousel);
// Vue.use(CarouselItem);
Vue.use(Collapse);
Vue.use(CollapseItem);
// Vue.use(Cascader);
// Vue.use(ColorPicker);
Vue.use(Transfer);
// Vue.use(Container);
// Vue.use(Header);
// Vue.use(Aside);
// Vue.use(Main);
// Vue.use(Footer);
Vue.use(Loading.directive);
Vue.use(Link);


import JsonExcel from 'vue-json-excel'
Vue.component('downloadExcel',JsonExcel)

/* regist common UI Components*/
import * as CommonComponents from '@/components'
const components = CommonComponents.default || CommonComponents
Object.keys(components).forEach(component => {
  Vue.component(component, components[component])
})

Vue.prototype.$cookies = cookies;
Vue.prototype.$caller = caller;
Vue.prototype.$stringFormat = utility.stringFormat;
Vue.prototype.$isEmpty = utility.isEmpty;
Vue.prototype.$isNull = utility.isNull;
Vue.prototype.$cloneObject = utility.cloneObject;
Vue.prototype.$calculateAge = utility.calculateAge;
Vue.prototype.$toThousandsNoZero = utility.toThousandsNoZero;
Vue.prototype.$validateOnInput = utility.validateOnInput;
Vue.prototype.$objectDiff = utility.objectDiff;
Vue.prototype.$pending = utility.pending;

Vue.prototype.$ext = ext;
Vue.prototype.$exif = EXIF;
Vue.prototype.$regex = iRegex;
Vue.prototype.$formValidator = formValidator;
Vue.prototype.$loading = Loading.service;
Vue.prototype.$msgbox = MessageBox;
Vue.prototype.$alert = MessageBox.alert;
Vue.prototype.$confirm = MessageBox.confirm;
Vue.prototype.$prompt = MessageBox.prompt;

Vue.prototype.$getGeneralList = utility.getGeneralList;
Vue.prototype.$getGeneralTypeList = utility.getGeneralTypeList;
Vue.prototype.$initGeneralInformation = utility.initGeneralInformation;
Vue.prototype.$initGeneralInformationChannelAdmin = utility.initGeneralInformationChannelAdmin;
Vue.prototype.$initGeneralInformationContest=utility.initGeneralInformationContest;

Vue.prototype.$checkPageAuthority=utility.checkPageAuthority;
Vue.prototype.$checkPageModify=utility.checkEditPermission;
Vue.prototype.$responseDesc=utility.responseDesc;

const configEnv = require('../config').build;
Vue.prototype.$configEnv = configEnv; 

Vue.config.productionTip = false

// regist filters
import filters from '@/models/filters';
Object.keys(filters).forEach(key =>
  Vue.filter(key, filters[key])
)

// regist directives
import * as directives from '@/models/directives'
Object.keys(directives).forEach(k => Vue.directive(k, directives[k]))

// regist dialog begin
Vue.directive('dialogDrag', {

  bind(el, binding, vnode, oldVnode) {

      let minWidth = 400;

      let minHeight = 300;

      let isFullScreen = false;

      let nowWidth = 0;

      //let nowHight = 0;

      let nowMarginTop = 0;


      const dialogHeaderEl = el.querySelector('.el-dialog__header');


      const dragDom = el.querySelector('.el-dialog');


      dragDom.style.overflow = "auto";


      dialogHeaderEl.style.cursor = 'move';

      const sty = dragDom.currentStyle || window.getComputedStyle(dragDom, null);

      let moveDown = (e) => {

          const disX = e.clientX - dialogHeaderEl.offsetLeft;

          const disY = e.clientY - dialogHeaderEl.offsetTop;

          let styL, styT;


          if (sty.left.includes('%')) {

              styL = +document.body.clientWidth * (+sty.left.replace(/\%/g, '') / 100);

              styT = +document.body.clientHeight * (+sty.top.replace(/\%/g, '') / 100);

          } else {

              styL = +sty.left.replace(/\px/g, '');

              styT = +sty.top.replace(/\px/g, '');

          };

          document.onmousemove = function (e) {


              const l = e.clientX - disX;

              const t = e.clientY - disY;


              dragDom.style.left = `${l + styL}px`;

              dragDom.style.top = `${t + styT}px`;

          };

          document.onmouseup = function (e) {

              document.onmousemove = null;

              document.onmouseup = null;

          };

      }

      dialogHeaderEl.onmousedown = moveDown;


      dialogHeaderEl.ondblclick = (e) => {

          if (isFullScreen == false) {

              //nowHight = dragDom.clientHeight;

              nowWidth = dragDom.clientWidth;

              nowMarginTop = dragDom.style.marginTop;

              dragDom.style.left = 0;

              dragDom.style.top = 0;

              dragDom.style.height = "100VH";

              dragDom.style.width = "100VW";

              dragDom.style.marginTop = 0;

              isFullScreen = true;

              dialogHeaderEl.style.cursor = 'initial';

              dialogHeaderEl.onmousedown = null;

          } else {

              dragDom.style.height = "auto";

              dragDom.style.width = nowWidth + 'px';

              dragDom.style.marginTop = nowMarginTop;

              isFullScreen = false;

              dialogHeaderEl.style.cursor = 'move';

              dialogHeaderEl.onmousedown = moveDown;

          }

      }

      dragDom.onmousemove = function (e) {

          //let moveE = e;

          if (e.clientX > dragDom.offsetLeft + dragDom.clientWidth - 10 || dragDom.offsetLeft + 10 > e.clientX) {

              dragDom.style.cursor = 'w-resize';

          } else if (el.scrollTop + e.clientY > dragDom.offsetTop + dragDom.clientHeight - 10) {

              dragDom.style.cursor = 's-resize';

          } else {

              dragDom.style.cursor = 'default';

              dragDom.onmousedown = null;

          }

          dragDom.onmousedown = (e) => {

              const clientX = e.clientX;

              const clientY = e.clientY;

              let elW = dragDom.clientWidth;

              let elH = dragDom.clientHeight;

              let EloffsetLeft = dragDom.offsetLeft;

              let EloffsetTop = dragDom.offsetTop;

              dragDom.style.userSelect = 'none';

              let ELscrollTop = el.scrollTop;


              if (clientX > EloffsetLeft && clientX < EloffsetLeft + elW && clientY > EloffsetTop && clientY < EloffsetTop + 100) {

              }else{

                  document.onmousemove = function (e) {

                      e.preventDefault(); 

                      if (clientX > EloffsetLeft && clientX < EloffsetLeft + 10) {


                          if (clientX > e.clientX) {

                              dragDom.style.width = elW + (clientX - e.clientX) * 2 + 'px';

                          }


                          if (clientX < e.clientX) {

                              if(dragDom.clientWidth >= minWidth){
                                  dragDom.style.width = elW - (e.clientX - clientX) * 2 + 'px';
                              }

                          }

                      }


                      if (clientX > EloffsetLeft + elW - 10 && clientX < EloffsetLeft + elW) {


                          if (clientX > e.clientX) {

                              if (dragDom.clientWidth >= minWidth) {
                                  dragDom.style.width = elW - (clientX - e.clientX) * 2 + 'px';

                              }

                          }

                          if (clientX < e.clientX) {

                              dragDom.style.width = elW + (e.clientX - clientX) * 2 + 'px';

                          }

                      }

                      if (ELscrollTop + clientY > EloffsetTop + elH - 20 && ELscrollTop + clientY < EloffsetTop + elH) {

                          if (clientY > e.clientY) {

                              if (dragDom.clientHeight >= minHeight) {
                                  dragDom.style.height = elH - (clientY - e.clientY) * 2 + 'px';

                              }

                          }
                          if (clientY < e.clientY) {

                              dragDom.style.height = elH + (e.clientY - clientY) * 2 + 'px';

                          }

                      }

                  };
                  document.onmouseup = function (e) {

                      document.onmousemove = null;

                      document.onmouseup = null;
                  };
              }
          }
      }
  },
})
// regist dialog end

Vue.mixin(mixin)
/* eslint-disable no-new */
var vue = new Vue({
  el: '#app',
  i18n,
  router,
  store,
  components: { App },
  template: '<App/>',
});

export default vue;
