// ElementUI Components
import AiaButton from './element/button/button';
import AiaSelect from './element/select/select';
import AiaSteps from './element/steps/steps';
import AiaInput from './element/input/input';
import AiaForm from './element/form/form';
import AiaElForm from './element/elform/form';
import AiaRadio from './element/radio/radio';
import AiaTabs from './element/tabs/tabs';
import AiaCheckbox from './element/checkbox/checkbox';
import AiaDialog from "./element/dialog/Dialog.vue";
import AiaToggle from './element/toggleyesno/toggleyesno.vue';
import AiaPopover from "./element/popover/popover";

import GlObjectTable from './element/table/glObjectTable.vue';
import GlElementTable from './element/table/GlElementTable.vue';
import GlSelect from './element/select/glSelect.vue';
import GlSelectMultiple from './element/select/glSelectMultiple.vue';
import GlButton from './element/button/glButton.vue';
import GlLink from './element/link/glLink.vue';
import GlPage from './element/pagination/glPage.vue';
import GlDropdown from './element/dropdown/glDropdown.vue';
import GlDialog from './element/dialog/glDialog.vue';
import GlDate from './element/date/glDate.vue';
import GlTabs from './element/tabs/glTabs';
import GlAutocomplete from './element/autocomplete/glAutocomplete';
// Common Coponents
import TopBar from './common/TopBar';
import SideBar from './common/SideBar';
import TopMenu from './common/TopMenu'; 
import GlSearch from "./common/GlSearch";
import GlVersion from "./common/GlVersion";
import GlSelectSearch from "./common/GlSelectSearch";
import GlUser from "./common/GlUser";
import GlTree from "./element/tree/glTree.vue";
export default {
    AiaButton,
    AiaSelect,
    AiaSteps,
    AiaInput,
    AiaForm,
    AiaElForm,
    AiaRadio,
    AiaTabs,
    AiaCheckbox,
    AiaDialog,
    AiaToggle,
    AiaPopover,
    TopBar,
    SideBar,
    TopMenu,

    GlObjectTable,
    GlElementTable,
    GlSelect,
    GlSelectMultiple,
    GlButton,
    GlLink,
    GlSearch,
    GlPage,
    GlDropdown,
    GlDialog,
    GlDate,
    GlVersion,
    GlTabs,
    GlSelectSearch,
    GlAutocomplete,
    GlUser,
    GlTree,
}