<template>
    
    <el-link v-bind="$attrs" v-on="$listeners" :type="type" :target="targetStr" :href="hrefStr" :underline="true">
        <slot>Button</slot>
    </el-link>
</template>
<script>
export default {
    props:{
        type:String,
        hrefStr: {type: String, default:null},
        targetStr: {type: String, default:null},
    },

}
</script>
<style scoped>
@import 'link.css';
</style>