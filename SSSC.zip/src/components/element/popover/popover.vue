<template>
  <el-popover popper-class="aia-pop" :disabled="isDisabled" v-bind="$attrs" v-on="$listeners">
    <el-button type="text" slot="reference">
        <slot name="pop-btn"></slot>
    </el-button>
    <slot name="pop-content"></slot>
  </el-popover>
</template>

<script>
export default {
  props:['isDisabled'],
  data() {
    return {};
  },
};
</script>

<style lang="scss">
@import "popover";

</style>
<style lang="scss" scoped>
.el-button--text{
    border: none;
    background: none;
}


</style>
