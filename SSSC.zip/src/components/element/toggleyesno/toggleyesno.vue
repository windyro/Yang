<template>
  <div v-bind="$attrs" v-on="$listeners">
    <div data-target="toggle-group" class="btn-toggle-group" style="margin-right:0px">
      <button
        type="button"
        v-bind:class="yesvisual"
        :disabled="disabled"
        style="width:50%"
        @click="yesSelected"
      >YES</button>
      <button
        type="button"
        v-bind:class="novisual"
        :disabled="disabled"
        style="width:50%"
        @click="noSelected"
      >NO</button>
    </div>
  </div>
</template>

<script>
export default {
  created: function() {
    if (this.option === "YES") {
      this.yesvisual = "btn btn-toggle btn-selected";
      this.novisual = "btn btn-toggle";
    } else if (this.option === "NO") {
      this.yesvisual = "btn btn-toggle";
      this.novisual = "btn btn-toggle btn-selected";
    } else {
      if (this.disabled) {
        this.yesvisual = "btn btn-toggle";
        this.novisual = "btn btn-toggle";
      } else {
        this.yesvisual = "btn btn-toggle btn-required";
        this.novisual = "btn btn-toggle btn-required";
      }
    }
  },
  watch: {
    enabled(val) {
      this.disabled = this.enabled === "0";
      if (this.quesnumber === "H.10.c") {
        if (true === this.disabled) {
          this.yesvisual = "btn btn-toggle";
          this.novisual = "btn btn-toggle";
        }
        else{
          this.yesvisual = "btn btn-toggle btn-required";
          this.novisual = "btn btn-toggle btn-required";
        }
      }
    },
  },
  props: {
    option: String,
    enabled: String,
    planId: String,
    quesnumber: String,
  },
  methods: {
    yesSelected(event) {
      if (this.planId === "plan.a.special") {
        this.$emit("toggleSelected", "SPECIALYES", "YES");
        return;
      }
      if (this.option === "YES") {
        this.ynoption = "";
        this.yesvisual = "btn btn-toggle  btn-required";
        this.novisual = "btn btn-toggle  btn-required";
        this.$emit("toggleSelected", this.ynoption, "");
        return;
      }
      this.ynoption = "YES";
      this.yesvisual = "btn btn-toggle btn-selected";
      this.novisual = "btn btn-toggle";
      this.$emit("toggleSelected", this.ynoption, "YES");
    },
    noSelected(event) {
      if (this.option === "NO") {
        this.ynoption = "";
        this.yesvisual = "btn btn-toggle  btn-required";
        this.novisual = "btn btn-toggle  btn-required";
        this.$emit("toggleSelected", this.ynoption, "");
        return;
      }
      this.ynoption = "NO";
      this.yesvisual = "btn btn-toggle";
      this.novisual = "btn btn-toggle  btn-selected";
      this.$emit("toggleSelected", this.ynoption, "NO");
    },
  },
  data() {
    return {
      yesvisual: "",
      novisual: "",
      disabled: this.enabled === "0",
      ynoption: this.option,
    };
  },
};
</script>

<style scoped>
@import "../../../assets/css/dls.css";

.btn {
  font-size: 16px;
}
.btn-toggle-group{
  width: 160px;
}
.btn-toggle-group .btn-required {
  color: #606266;
  background-color: #d4edf1;
  background-size: 28px;
  background-repeat: no-repeat;
  background-position: 10% 40%;
  border: 1px solid #dcdfe6;
}

.btn-toggle-group .btn-required:last-of-type {
  border: 1px solid #dcdfe6;
}
</style>