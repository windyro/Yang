<template>
<div class="">
            <el-pagination
                :total="total"
                :current-page="currentPage"
                :page-size="pageSize"
                :page-sizes="pageSizes"
                :pager-count="pagerCount"
                :page-count="5"
                @current-change="handleCurrentChange"
                @size-change="handleSizeChange"
                layout="total, sizes, prev, pager, next">
            </el-pagination>


</div>
</template>

<style lang="scss">
    @import 'pagination.css';
</style>

<script>
export default {
  props: {
    total: {type: Number, default: 0},
    currentPage: {type: Number, default: 1}, 
    pageSize: {type: Number, default: 10},
    pageSizes: {type: Array, default:function(){return [10, 20, 30, 50] }},
    pagerCount: {type: Number, default: 5},
    changePage: {
        type: Function,
        default: null,
    },
    changeSize: {
        type: Function,
        default: null,
    },
  },

    data(){
        return{
           // optionList: [],
            //total: 0,
            //currentPage: 1,
            //pageSize: 10

        }
    },

    methods: {
        handleCurrentChange(val){
            // this.currentPage = val;
            // this.$parent.$parent.$parent.nextPage();
            
            if (this.changePage) {
              this.changePage(val);
            }
            
        },

        handleSizeChange(val){
            this.pageSize = val;
            // this.$parent.$parent.$parent.nextPage();
            if (this.changeSize) {
              this.changeSize(val);
            }
        },
    },
}
</script>