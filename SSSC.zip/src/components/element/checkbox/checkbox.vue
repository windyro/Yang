<template>
    <el-checkbox  v-bind="$attrs" v-on="$listeners" :value="value">
        <slot></slot>
    </el-checkbox>
</template>
<script>
export default {
  props: ['value'],
    data(){
        return {
        }
    },
}
</script>
<style lang="scss">
@import "./checkbox";
@import "./checkboxChange";
</style>

