<template>
   <el-form-item  v-if="edit" :prop="prop"  :rules="rules" >
        <el-date-picker :type="type"
                        v-bind="$attrs" 
                        v-on="$listeners" 
                        placeholder="Please select"
                        v-model="value"
                        :value-format="valueFormat"
                        :picker-options="pickerOptions"
                        clearable
                        :editable="true"
                        style="width:100%" 
                        >
        </el-date-picker>
    </el-form-item>    
    <span v-else-if="!edit" class="bt5">{{displayValue()}}</span>
</template>

<script>
export default {
    props: {
        type: {type: String, default: "date"},
        edit: {type: Boolean, default: true}, 
        value: {type: String},
        beginDateStr: {type: String, default: null},
        endDateStr: {type: String, default: null},
        prop: {type: String, default: null},
        rules:  null,
    },
    data(){
        return{
            pickerOptions: this.pickerOptionsFunc(),
            valueFormat:  "yyyy-MM-dd",
        }
    },

    created () {
            this.pickerOptions = this.pickerOptionsFunc();
            this.valueFormatFunc();
    },


    watch:{
          beginDateStr:{
              handler:function(){
                  this.$set(this, 'pickerOptions', this.pickerOptionsFunc());
              },
          deep:true,
          immediate: true,
          },

          endDateStr:{
              handler:function(){
                  this.$set(this, 'pickerOptions', this.pickerOptionsFunc());
              },
          deep:true,
          immediate: true,
          },    

          edit:{
              handler:function(){
                  this.$set(this, 'pickerOptions', this.pickerOptionsFunc());
              },
          deep:true,
          immediate: true,
          },   

          type:{
              handler:function(){
                  this.valueFormatFunc();
              },
          deep:true,
          },
    },

    methods: {
        displayValue(){
            var result= this.$props.value;
            if(this.$props.type == "year"){
                result = result.substring(0, 4);
            }
            else if (this.$props.type == "month"){
                result = result.substring(0, 7);
            }
            else if (this.$props.type == "date"){
                result = result.substring(0, 10);
            }
            // else if this.$props.type == "datetime"){
            // }
            return result;
        },

        valueFormatFunc(){

            this.valueFormat = "yyyy-MM-dd";
            if(this.$props.type == "year"){
                this.valueFormat = "yyyy";
            }
            else if (this.$props.type == "month"){
                this.valueFormat = "yyyy-MM";
            }
            else if (this.$props.type == "date"){
                this.valueFormat = "yyyy-MM-dd";
            }
             else if (this.$props.type == "datetime"){
                this.valueFormat = "yyyy-MM-dd HH:mm:ss";
            }

        },

        pickerOptionsFunc(){
            let _this = this;
            if(!_this.$props.edit) {
                return;
            }
            return{
            　　disabledDate(time) {
                    if(_this.$props.beginDateStr){
                　　　　return time.getTime() < new Date(_this.$props.beginDateStr.substring(0,10)).getTime()
                    }
                    else if(_this.$props.endDateStr){
                       return time.getTime() > new Date(_this.$props.endDateStr.substring(0,10)).getTime();
                    }
            　　},
            }
        },
    },
}
</script>
<style lang="scss">
  @import 'date-picker.css';
</style>


