<template>
  <el-dialog
    :visible.sync="dialogTable"
    @close="closeDialog"
    append-to-body
    :custom-class="searchNameClass"
  >
    <div class="seaInput">
      <el-input
        placeholder="Search"
        @change="sendInputVal(this.ruleForm.name)"
        @input="searchName(searchVal)"
        clearable
        v-model="searchVal"
      >
        <el-button slot="prepend" icon="el-icon-search"></el-button>
      </el-input>
    </div>
    <div class="sea-list cursor-p">
      <ul v-for="(item,index) in dialogData" :key="index">
        <span class="bt3" :id="item.sort">{{item.sort}}</span>
        <li
          class="bt4"
          @click="sendVal(val)"
          v-for="(val,index) in item.business"
          :key="index"
        >{{val.name}}</li>
      </ul>
      <div class="seaval">
        <a :href="'#' + item.sort" v-for="(item,index) in dialogData" :key="index">{{item.sort}}</a>
      </div>
    </div>
  </el-dialog>
</template>
<script>
export default {
  props: ["dialogTableVisible", "data"],
  data() {
    return {
      searchNameClass: "search-name",
      dialogTable: this.dialogTableVisible,
      searchVal: "",
      dialogData: this.data,
      searchNameData: this.data,
    };
  },
  mounted() {
    this.dialogData = this.data; 
    this.searchNameData = this.data;
  },
  methods: {
    sendVal(val, code) {
      this.$emit("getVal", val);
    },
    sendInputVal(val) {
      code = "";
      this.$emit("getVal", val);
    },
    closeDialog() {
      this.dialogTable = false;
      this.$emit("closeDia", this.dialogTable);
    },
    searchName(val) {
      if (val !== "") {
        let seaResult = [];
        this.searchNameData.forEach(data => {
          var names = data.business.filter(item => {
            return item.name.toLowerCase().indexOf(val.toLowerCase()) > -1;
          });
          if (names.length > 0) {
            seaResult.push({
              business: names,
              sort: data.sort,
            });
          }
          this.dialogData = seaResult;
        });
      } else {
        this.dialogData = this.searchNameData;
      }
    },
  },
};
</script>

<style lang="scss">
@import '@/assets/css/variable.scss';
@import "dialog";
@import "dialogChange";
@import '@/assets/css/variable.scss';

//addDialog
.addDialog{
  @include phone {
    width: 100%;
  }
}
.search-name {
  .el-dialog__close:before {
    content: "Close" !important;
    color: white !important;
    font-weight: bold !important;
    line-height: 24px !important;
  }
  .el-dialog__body {
    padding: 0 !important;
    box-sizing: border-box !important;
    height: auto !important;
  }
  .el-button {
    background: none;
    border: 0;
  }

}
.el-dialog{
  @include sm {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  @include xs {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  @include ipadPro {
    width: 60% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  
  @include phone {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  @include ss {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
}
</style>


