<template>
  <el-dialog
    :visible.sync="dialogTable"
    @close="closeDialog"
    v-dialogDrag
    append-to-body
    custom-class="dialog-window"
  >
        <div class="margin-top-3xl margin-bottom-s margin-left-3xl margin-right-3xl "> 
            <div class="dialog-title">
                <slot name="dialog-title"></slot>
            </div>
            <div class="dialog-content">
                <slot name="dialog-content"></slot>
            </div>
            <div class="dialog-summary">
                <slot name="dialog-summary"></slot>
            </div>
            <div class="dialog-button" >
                <div class="btn-group">
                    <slot name="buttons"></slot>
                </div>
            </div>
       </div>
  </el-dialog>
</template>
<script>

export default {
  props: {
    dialogTableVisible:{
      type:Boolean,
      default:false,
    },
  },
  data() {
    return {
      dialogTable: this.dialogTableVisible,
    };
  },

  created() {  

      // this.dialogTable= this.$props.dialogTableVisible
      //alert("gl "+ this.dialogTable);
      // this.editData = JSON.parse(JSON.stringify(this.$props.conditionData[0]));
      // this.summarySelected = this.getSummary(this.editData.criteria);

  },
  watch:{
    dialogTableVisible(val){
      this.dialogTable=val;
    }
  },
  methods: {

    closeDialog() {
      // this.dialogTable = false;
      this.$emit("doCloseDialog", false);
    },
  },
};
</script>

<style lang="scss">
@import '@/assets/css/variable.scss';
@import "dialog";
@import "dialogChange";
.dialog-title{
    width: 60%
}
.dialog-content{
    width: 100%;
    margin-top: 50px;
    .el-input.is-disabled .el-input__inner {
        color: #828282;
        cursor: auto;
    }
}
.dialog-summary{
    width: 100%;
    margin-top: 50px;
    color: blue;
}
.dialog-button{
    width: 100%;
    margin-top: 50px;
    margin-bottom: 100px;
}

//addDialog
.addDialog{
  @include phone {
    width: 100%;
  }
}

.search-name {
  .el-dialog__close:before {
    content: "Close" !important;
    color: white !important;
    font-weight: bold !important;
    line-height: 24px !important;
  }
  .el-dialog__body {
    padding: 0 !important;
    box-sizing: border-box !important;
    height: auto !important;
  }
  .el-button {
    background: none;
    border: 0;
  }

}

.dialog-window {
   width:60%;

  .el-dialog__header {
      height: 7vh;
      background: #d31145;
      padding-bottom: 30px;
  }

  .el-dialog__close:before {
    content: "Close" !important;
    color: white !important;
    font-weight: bold !important;
    line-height: 24px !important;
  }
  .el-dialog__body {
    padding: 0 !important;
    box-sizing: border-box !important;
    height: auto !important;
  }
  .el-button {
    background: none;
    border: 0;
  }

}
.el-dialog{
  @include sm {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  @include xs {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  @include ipadPro {
    width: 60% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  
  @include phone {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
  @include ss {
    width: 70% !important;
    .el-radio-button__orig-radio:checked+.el-radio-button__inner::before {
      left: 4% !important;
     
    }
  }
}
</style>


