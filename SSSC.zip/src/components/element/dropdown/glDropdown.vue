<template>

    <el-dropdown type="primary" class="dropdown-wrap" >
            <!--span>dropdown</span-->
            <span :class="className" >&#xe62f;</span>
            <el-dropdown-menu slot = "dropdown">
                <el-dropdown-item  v-if="Edit!=null" @click.native="doEdit">                                                 
                {{Edit}}                                              
                </el-dropdown-item>

                <el-dropdown-item v-if="Copy!=null" @click.native="doCopy">
                {{Copy}}   
                </el-dropdown-item > 

                <el-dropdown-item v-if="Paste!=null" @click.native="doPaste">
                {{Paste}} 
                </el-dropdown-item> 

                <el-dropdown-item v-if="Add!=null" @click.native="doAdd">
                {{Add}} 
                </el-dropdown-item>      

                <el-dropdown-item v-if="Add2!=null" @click.native="doAdd2">                                                 
                {{Add2}}
                </el-dropdown-item>

                 <el-dropdown-item v-if="Delete!=null" @click.native="doDelete">                                                 
                {{Delete}}
                </el-dropdown-item>

                 <el-dropdown-item v-if="Delete2!=null" @click.native="doDelete2">                                                 
                {{Delete2}}
                </el-dropdown-item>

                <slot></slot>                                                                                     
            </el-dropdown-menu>
    </el-dropdown>

</template>
<script>


export default {
    props: {
        Edit:  {type: String, default: null},
        Copy:  {type: String, default: null},
        Paste:  {type: String, default: null},
        Add:    {type: String, default: null},
        Add2:    {type: String, default: null},
        Delete:    {type: String, default: null},
        Delete2:    {type: String, default: null},
        className:  {type: String, default: "iconfont cursor-p"},
    },

    data() {
      return {

      };
    },
    created() {   
        //alert(this.$props.className);
    },
    methods: {
        doEdit(){
            this.$emit("doEdit");
        },

        doCopy(){
            this.$emit("doCopy");
        },

        doPaste(){
            this.$emit("doPaste");
        },

        doAdd(){
            this.$emit("doAdd");
        },

        doAdd2(){
            this.$emit("doAdd2");
        },

        doDelete(){
            this.$emit("doDelete");
        },

        doDelete2(){
            this.$emit("doDelete2");
        },

    },
  };
</script>
<style lang="scss">
@import "dropdown.css";

.dropdown-wrap {

  .iconfont{
    font-size: 10px;
    color: rgba($color: #6F6E68, $alpha: 0.5);
    &:hover{
      color: rgba($color: #6F6E68, $alpha: 1);
    }
  }

  .iconfont-white{
      font-size: 10px;
    color: rgba($color: white, $alpha: 0.7);
    &:hover{
      color: rgba($color: white, $alpha: 1);
    }
  }
}
</style>