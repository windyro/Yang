<template>
    <el-radio-group v-bind="$attrs" v-on="$listeners"  :value="value">
     <slot></slot>
    </el-radio-group>
</template>
<script>
export default {
  props: {
    value: {
      default: '',
    },
  },
  data(){
      return{
       
      }
  },
}
</script>
<style lang="scss">
@import 'radio';
@import 'radio-group';
@import 'radio-button';
@import 'radioChange';
@import "@/assets/css/variable.scss";


</style>


