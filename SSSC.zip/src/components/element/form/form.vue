<template>
  <el-form :ref="alias" :more="more" v-bind="$attrs" v-on="$listeners">
    <div class="scroll-wrap" @click="clickOutside">
      <div class="form-layout">
        <slot name="scroll"></slot>
      </div>
    </div>

    <div class="btn-wrap" >
        <div class="page-group">
            <slot name="pages"></slot>
        </div>
        <div class="btn-group">
            <slot name="buttons"></slot>
        </div>
    </div>

    <!--div class="btn-wrap" @click="clickOutside">
      <transition name="custom-classes-transition" enter-active-class="animated fadeIn">
        <div class="btn-group" v-if="showbtn&&mount">
          <button class="btn-secondary" @click.prevent="cancel">back1</button>
          <button class="btn-primary" @click.prevent="submit(alias)" :disabled="!finish">
            <slot name="next">next</slot>
          </button>
        </div>
      </transition>
      <div class="floating-wrap" v-if="more">
        <span class="iconfont cursor-p" id="addBtn" @click.stop="show">&#xe612;</span>
        <transition
          name="custom-classes-transition"
          enter-active-class="animated fadeInUp"
          leave-active-class="animated fadeOutDown"
        >
          <div class="popover-link bg-w" v-show="showPopover" v-outside="clickOutside">
            <ul class="link-list">
              <slot name="links"></slot>
            </ul>
          </div>
        </transition>
      </div-->

    </div>
  </el-form>
</template>

<script>
import { setTimeout } from "timers";
export default {
  name: "BaseForm",
  props: {
    alias: {
      type: String,
      default: "form",
    },
    more: {
      type: Boolean,
      default: false,
    },
    showbtn: {
      type: Boolean,
      default: true,
    },
    single: {
      type: Boolean,
      default: false,
    },
    step: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      showPopover: false,
      showFloating: true,
      finish: false,
      clicked: false,
      mount: false,
      validating: false,
    };
  },
  mounted() {
    let _this = this;
    //this.$regex.deleteSBC();
    setTimeout(() => {
      if (!this.validating) {
        _this.mount = true;
      }
    }, 500);
  },
  methods: {
    show() {
      this.showPopover = !this.showPopover;
    },
    clickOutside() {
      if (this.showPopover) {
        this.showPopover = false;
      }
    },
    cancel() {
      this.$emit("back");
    },
    submit(formName = this.alias) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$emit("quosubmit");
          this.finish = false;
        } else {
          return false;
        }
      });
      this.$emit("save");
    },
    validate() {
      

     //alert(JSON.stringify(this.$parent.ruleForm.tableData));
     //alert(this.$refs[this.alias].prop);
      //this.$parent.ruleForm.validate(valid => {
     var result = false;
     this.$refs[this.alias].validate(valid => {
        if (valid) {
          result = true;
        }
         else {
            this.$alert(this.$t("message.requiredFields"), this.$t("message.error"), {
              confirmButtonText: "OK",
            });
            result = false;
        }
      });

      return result;
      // this.validating = true;
      // let _this = this;
      // this.$refs[this.alias].validate(valid => {
      //   if (valid) {
      //     if (!this.single) {
      //       let steps = this.$store.state.steps;
      //       steps.forEach((step, index) => {
      //         if (step.item === _this.step && step.completedStatus !== "0") {
      //           _this.finish = true;
      //           // _this.$store.commit('setFinishStep',steps[index+1].item)
      //         } else {
      //           // how to deal with just finish
      //         }
      //       });
      //     } else {
      //       this.finish = true;
      //     }
      //     this.$emit("finish");
      //     this.validating = false;
      //     this.mount = true;
      //   } else {
      //     this.finish = false;
      //     this.$emit("notFinish");
      //     this.validating = false;
      //     this.mount = true;
      //   }
      // });
    },
    validateElement(val) {
      this.$refs[this.alias].validateElement(val);
    },
    validateField(val) {
      this.$refs[this.alias].validateField(val);
    },
    resetFields(formName = this.alias) {
      this.$refs[formName].resetFields();
    },
    clearValidate(val) {
      this.$refs[this.alias].clearValidate(val);
    },
  },
};
</script>

<style lang="scss">
@import "@/assets/css/variable.scss";
@import "form";
@import "responsive-form";
@import "datepicker";
//@import "formChange";
.mobile {
  @media (max-width: 800px) {
    .el-input__inner {
      padding: 0;
      text-align: center;
    }
  }
}
.form-layout {
  @include phone {
    margin-right: 0;
    padding: 0;
    padding-top: 10px;
  }

  .el-form-item__error {
    padding-top: 0px;
  }
}
.el-form {
  @include ss {
    .el-col-xs-12 {
      width: 100%;
    }
  }
}
.content-center {
  .el-input--suffix .el-input__inner {
    padding-right: 22px;
  }
}



</style>
