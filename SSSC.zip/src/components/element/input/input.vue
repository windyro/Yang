<template>
  <el-input v-bind="$attrs" v-on="$listeners"  @keypress.enter.native.prevent="()=>{}">
    <slot></slot>
  </el-input>
</template>

<script>
export default {
  props: {
    data: {
      default () {
        return []
      },
      type: Array,
    },
  },
    data(){
        return{
        }
    },
    // change(){
    //   this.$emit('change',)
    // }

}
</script>
<style lang="scss">
@import 'input.css';
</style>