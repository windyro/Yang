<template>
        <el-autocomplete v-bind="$attrs" 
                         v-on="$listeners" 
                         v-model = "value"
                         :placeholder="placeholder" 
                         :fetch-suggestions="querySearch"   
                         @select="handleSelect"
                         style="width:100%" 
        >
            
        </el-autocomplete>
</template>

<script>
export default {
    props: {
        value: {type: String},
        placeholder: {type: String},
        suggestionList: null,
        suggestionType: {type: String},
    },
    data(){
        return{
            myList: [{value: "", type: ""}],
        }
    },

    created (){
        this.prepare();
    },


    watch:{

    },

    methods: {
        prepare(){
            if(this.$props.suggestionList.length>0){
                this.$props.suggestionList.forEach(param=>{

                    if(this.$isEmpty(this.$props.suggestionType) || (!this.$isEmpty(this.$props.suggestionType) && this.$props.suggestionType===param.type)){
                        this.myList.push({value: param.name, type: param.type,});
                    }
                });
            }
        },

        querySearch(queryString, callback) {
            let list = this.myList;
            var results = queryString ? list.filter(this.createFilter(queryString)) : list;
            callback(results);
        },

        createFilter(queryString) {
            return (result) => {
                return (result.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
            };
        },

        handleSelect(){

        },
        
    },
}
</script>

<style lang="scss">
  @import './autocomplete';
</style>
