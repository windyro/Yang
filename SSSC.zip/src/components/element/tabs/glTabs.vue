<template>
      <el-tabs :tab-position="tabPosition" type="border-card" v-bind="$attrs" v-on="$listeners">
          <slot>
          </slot>
      </el-tabs>
</template>
<script>
export default {
    props:{
        tabPosition:{
            type: String,
            default: '',
        },
        data:{
        },
    },
    data(){
        return {
           
        }
    },
    methods:{
    },
    
}
</script>
<style lang="scss">
@import '@/assets/css/variable.scss';
@import "tabs.css";
//@import "tabsChange.scss";

.el-tabs__content {
  @include phone {
    .scroll-wrap {
      padding: 0 !important;
    }
  }
}
.policy-tab{
  .el-tabs__content{
    overflow-y:auto!important;
    height:calc(100vh - 260px); 
    @include ipad {
      height:calc(100vh - 300px);
    }
    @include ipadPro{
      height:calc(100vh - 250px);
    }
     @include ipad {
      height:calc(100vh - 300px);
    }
    @include xs{
      height:calc(100vh - 300px);
    }
  }
}
</style>


