<template>
  <el-steps  v-bind="$attrs" v-on="$listeners" class="h6">
    <slot></slot>
  </el-steps>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>
<style lang="scss">
@import "step";
@import "steps";
@import "left";
</style>


