<template>
  <el-table v-bind="$attrs" 
            v-on="$listeners" 
            :header-cell-style="{background:'#FFFFF', align: 'center', color: '#000'}" 
            :highlight-current-row="isHighLight"
            @current-change="handleCurrentChange"
            :row-class-name="rowClassName"
            >
    <slot></slot>
  </el-table>
</template>
<script>
export default {
  props: {
    // data: {
    //   default () {
    //     return []
    //   },
    //   type: Array
    // },
    //#c0c3ca

    tableData: {
      type: Array,
      default() {
        return [];
      },
    },
    changeClass: {
      type: "function",
    },
    arraySpanMethod: {
      type: "function",
      default() {},
    },
    isHighLight:{
      type:Boolean,
      default:false,
    },
    hightLightIndex:{
      type:Number,
      default: null,
    },
  },
  data(){
    return{
      headerCellStyle:{
        background:'#D31145',
        align: 'center',
        color: '#fff',
      },
      // cellStyle:{
      //   background:'#faf9f3', 
      //   align: 'center'
      // }
    }
  },
  methods:{
    handleCurrentChange(current){
      this.$emit('currentChange',current);
    },
    rowClassName({row,rowIndex}){
      if(this.$props.hightLightIndex != null && rowIndex === this.$props.hightLightIndex){
        return 'highlight-row';
      }
      return '';
    },
  },
};
</script>
<style lang="scss">
.el-table__body .el-table__row{
  //background:#faf9f3;
  background:#fffff;
  .cell{
    font-family: "AIABody", Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-size: 14px;
    line-height: 16px;
  }
}


.el-table__body tr:hover>td{
  background:#f1f1f1;
}

.current-row td{
  background:#f1f1f1 !important;
}

.highlight-row td{
  background: #f1f1f1 !important;
}

@import "@/assets/css/variable.scss";
@import "table.css";
@import "table-column.scss";
@import "tableChange.scss";
</style>
