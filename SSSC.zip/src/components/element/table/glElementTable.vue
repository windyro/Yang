<template>
  <div class="element-table">

      <aia-el-form v-if="edit" alias="elementTableForm" ref="elementTableForm" :model="elementTableForm" :rules="$formValidator.rules">
          <el-row v-show="addNew" :gutter="36">
                <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6" v-for="(item,colIndex) in headerList" :key="colIndex">
                    <label :class=" {'bt5': true, 'label_required': item.required}">{{$t(item.name)}}</label>
                    <el-form-item v-if="item.type==='input'" :prop="'valueData.' + item.code" :rules="item.rules">
                          <el-input v-model="elementTableForm.valueData[item.code]"></el-input>
                    </el-form-item> 
                    <gl-select v-else-if="item.type==='select'" v-model="elementTableForm.valueData[item.code]" :optionList="item.optionList" :valueData="elementTableForm.valueData[item.code]" :prop="'valueData.' + item.code" :rules="item.rules"></gl-select>     
                    <gl-select-multiple v-else-if="item.type==='selectMultiple'" v-model="elementTableForm.valueData[item.code]" :optionList="item.optionList" :valueData="elementTableForm.valueData[item.code]" :prop="'valueData.' + item.code" :rules="item.rules"></gl-select-multiple>
                    <gl-select-search v-else-if="item.type==='selectSearch'" :apiName="item.apiName" :apiInput="item.apiInput" :apiParm="item.apiParm" :apiResult="item.apiResult" v-model="elementTableForm.valueData[item.code]" :valueData="elementTableForm.valueData[item.code]" :prop="'valueData.' + item.code" :rules="item.rules" :ref="'selection'+colIndex"></gl-select-search>
                    <gl-date v-else-if="item.type==='date'" :prop="'valueData.' + item.code" :rules="item.rules" :edit="true"  v-model="elementTableForm.valueData[item.code]" :value="elementTableForm.valueData[item.code]" type="date" ></gl-date>
                </el-col>

                <el-col :xs="12" :sm="8" :md="6" :lg="6" :xl="6">
                    </br>
                    </br>
                    <span class="iconfont cursor-p"  id="saveBtn" @click="saveRow">&#xe629; {{$t("label.done")}}</span>
                </el-col>
          </el-row>
      </aia-el-form>

      <div v-if="edit">    
        </br>
        </br>
      </div>
      <el-row v-if="edit" :gutter="36">
            <el-col  :xs="6" :sm="4" :md="5" :lg="5" :xl="5">
                <span v-show="!addNew" class="iconfont cursor-p"  id="addBtn" @click="addRow" style="padding-right: 20px;">&#xe627; {{$t("label.add")}}</span>
                <span v-show="addNew" class="iconfont cursor-p"  id="cancelBtn" @click="cancelRow" style="padding-right: 20px;">&#xe62b; {{$t("label.cancel")}}</span>
                <span class="iconfont cursor-p"  id="delBtn" @click="delRow">&#xe6aa; {{$t("label.delete")}}</span>
            </el-col>
      </el-row>
      <div v-if="edit">
      </br>
      </div>
      <el-table :header-cell-style="headerCellStyle" 
                :highlight-current-row="isHighLight"
                :data="tableDataEdit"
                @selection-change="selectChange"
                ref="elementTable">
                <el-table-column type="selection" width="55">   
                </el-table-column>
               
                <el-table-column  v-for="(column, colIndex) in headerList" v-if="column.type!='hidden'" :key="colIndex" width="auto" >
                      <template  slot="header" slot-scope="scope">
                            <span>{{$t(column.name)}}</span>
                      </template>

                      <template slot-scope="scope">
                            <span class="bt5">{{scope.row[headerList[colIndex].code]}}</span>
                      </template>
                </el-table-column>

      </el-table>
      
  </div>
</template>
<script>
export default {
  props: {
    headerList:{
        type:Array,
        default:[],
    },

    tableData: {
      type: Array,
      default() {
        return [];
      },
    },
    changeClass: {
      type: "function",
    },
    arraySpanMethod: {
      type: "function",
      default() {},
    },
    isHighLight:{
      type:Boolean,
      default:false,
    },
    edit:{
      type:Boolean,
      default:false,
    },
  },
  data(){
    return{
      headerCellStyle:{
        background:'#FFFFF',
        align: 'center',
        color: '#000',
      },
      addNew:  false,
      elementTableForm:  {valueData: {},},
      selectedRow: [],
      tableDataEdit: [],
      
      // cellStyle:{
      //   background:'#faf9f3', 
      //   align: 'center'
      // }
    }
  },
  watch:{
    edit:{
      handler:function(){
          this.cancelRow();
      },
      deep:true,
    },
    tableData(val){
      if(val&&this.tableDataEdit.length==0){
        this.tableDataEdit=[];
        val.forEach((element,index) =>{
              let item = element;
              item.index = index;
              this.tableDataEdit.push(item);
        });
      }
    },
  },
  created(){
      this.prepare();
  },
  methods:{

      prepare(){
          this.$props.headerList.forEach(x=>{
              if(!this.$isEmpty(x.defaultValue)){
                this.$set(this.elementTableForm.valueData, x.code, x.defaultValue);
              }else{
                this.$set(this.elementTableForm.valueData, x.code, "");
              }
              
          });
          //alert(JSON.stringify (this.elementTableForm.valueData));
          this.$props.tableData.forEach((element,index) =>{
              let item = element;
              item.index = index;
              this.tableDataEdit.push(item);
          });


      },

      selectChange(sels){
          this.selectedRow = sels;
      },
      addRow(){           
         this.addNew = true;
      },
      cancelRow(){
        this.addNew = false;
        this.$props.headerList.forEach(x=>{
            if(!this.$isEmpty(x.defaultValue)){
              this.$set(this.elementTableForm.valueData, x.code, x.defaultValue);
            }else{
              this.$set(this.elementTableForm.valueData, x.code, "");
            }
            
        });
      },
      delRow(){
        this.selectedRow.forEach(row=>{
            this.tableDataEdit.splice(row.index, 1);
            this.tableDataEdit.forEach((element, index)=>{
                element.index = index;
            }); 
        }); 

        this.selectedRow=[];
      },

      saveRow(){
        if(!this.$refs.elementTableForm.validate()){
            return;
        }

        let newItem = this.$cloneObject(this.elementTableForm.valueData);
        newItem.index = this.tableDataEdit.length;

        this.$props.headerList.forEach((x,index)=>{
          
              if(x.type==="selectSearch"){
                 newItem[x.hidden]=newItem[x.code];
                 newItem[x.code] = this.$refs['selection'+index][0].getOptionName(newItem[x.code]);

                 //alert(this.$refs['selection'+index][0].getOptionName(newItem[x.code]))
                
              }
              if(!this.$isEmpty(x.defaultValue)){
                this.$set(this.elementTableForm.valueData, x.code, x.defaultValue);
              }else{
                this.$set(this.elementTableForm.valueData, x.code, "");
              }
        });

        this.tableDataEdit.push(newItem);
        this.$emit('saveRow',this.tableDataEdit);
      },

  },
};
</script>
<style lang="scss">
.element-table{
  .el-table__body .el-table__row{
    //background:#faf9f3;
    background:#fffff;
    .cell{
      font-family: "AIABody", Arial, "Helvetica Neue", Helvetica, sans-serif;
      font-size: 14px;
      line-height: 16px;
    }
  }


  .el-table__body tr:hover>td{
    background:#f1f1f1;
  }

  .current-row td{
    background:#f1f1f1 !important;
  }

    .iconfont{
    font-size: 16px;
    color: rgba($color: #554344, $alpha: 0.7);
    &:hover{
      color: rgba($color: #554344, $alpha: 1);
    }
  }
  .el-button {
    font-size: 16px;
    font-weight: bold;
  }
}


@import "@/assets/css/variable.scss";
@import "table.css";
@import "table-column.scss";
@import "tableChange.scss";
</style>
