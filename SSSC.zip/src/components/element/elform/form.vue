<template>
  <el-form :ref="alias" v-bind="$attrs" v-on="$listeners">
      <slot></slot>
  </el-form>
</template>

<script>
export default {
  name: 'ElementForm',
  props: {
    alias: {
      type: String,
      default: 'form',
    },
  },
  mounted(){
    //this.$regex.deleteSBC()
  },
  methods:{
    validate() {
      var result = false;
      this.$refs[this.alias].validate(valid => {
        if (valid) {
          result = true;
        }
          else {
            this.$alert(this.$t("message.requiredFields"), this.$t("message.error"), {
              confirmButtonText: "OK",
            });
            result = false;
        }
      });

      return result;
    },
    
    validateElement(val) { this.$refs[this.alias].validateElement(val) },
    validateField(val) { this.$refs[this.alias].validateField(val) },
    resetFields(formName = this.alias) { this.$refs[formName].resetFields() },
    clearValidate(val) { this.$refs[this.alias].clearValidate(val) },
    childTest(){
      alert("childTest");
    },
  },
}
</script>

<style lang="scss">
@import "form";
@import "responsive-form";
@import 'datepicker';
@import 'formChange';
</style>
