<template>
  <div>
    <el-form-item  v-if="edit" :prop="prop"  :rules="rules">
        <el-select  multiple
                    :value="valueData"
                    v-bind="$attrs" 
                    v-on="$listeners" 
                    filterable
                    :stretch="stretch" 
                    :placeholder="placeholder"
                    ref="fieldSelect"
                    :class="{'btn-stretch':stretch}">
            <slot>
                <el-option
                    v-for="option in this.optionList" 
                    :key="option.code"
                    :label="getI18Name(option.name)"
                    :value="option.code"
                >
                </el-option>
            </slot>
        </el-select>
    </el-form-item>
    <span v-if="!edit" class="bt5">{{getOptionName(valueData)}}</span>
  </div>
</template>

<script>
import util from "@/models/Utility";
export default {
  props: {
    type: {type: String, default: "other"},
    edit: {type: Boolean, default: true}, 
    stretch:{type:Boolean,default:true},
    multiple:{type:Boolean,default:false},
    valueData: {type: Array},
    placeholder: {type: String},
    //optionList: {type: Array},
    optionList: {type: Array, default: null},
    prop: {type: String, default: null},
    rules: null,
    data: {
      default () {
        return []
      },
     
    },

  },
    data(){
        return{
            myOptionList: this.$props.optionList,
        }
    },

    created () {
        this.myOptionList = this.$props.optionList;
        this.setOptionList();               
    },

    mounted() {
        this.$nextTick(function() {
        this.$refs.fieldSelect.$refs.scrollbar.$el.classList.add(
            "scroll-opacity"
            );
        });
    },

    watch:{
          type:{
              handler:function(){
                  this.setOptionList();
              },
          deep:true,
      },
    },

    methods: {
        setOptionList(){
            if(this.type=="other"){
              return;
            }

            if(this.type=="yesNo"){
                this.optionList = util.data().yesNoList;
            }
            else if(this.type=="comparison"){
                this.optionList = util.data().comparisonList;
            }
            else if(this.type=="comparisonName"){
                this.optionList = util.data().comparisonNameList;
            }  
            else if(this.type=="comparisonDate"){
                this.optionList = util.data().comparisonDateList;
            }   
        },
        getOptionName(code){
            if(!this.optionList){
                return;
            }   
          
            if(code==""){
                return"";
            }
 
            let obj = {};  
            obj = this.optionList.find((item)=>{
            return item.code === code;      }); 

            return this.getI18Name(obj.name);
        },
        getI18Name(name){
            var result = name;
            // if(this.type=="yesNo" 
            // || this.type=="comparison" 
            // || this.type=="comparisonName" 
            // || this.type=="comparisonDate"){
            //     result = this.$t(result);
            // }
            result = this.$t(result);
            return result;
        },

    },
}
</script>
<style lang="scss">
  @import 'select.css';
  @import 'option.css';
  @import 'selectChange'；
</style>


