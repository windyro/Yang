<template>
    <el-select :value="valueData" v-bind="$attrs" v-on="$listeners" :stretch="stretch" :class="{'btn-stretch':stretch}">
        <slot></slot>
    </el-select>
</template>
<script>
export default {
  props: {
    data: {
      default () {
        return []
      },
     
    },
    stretch:{
      type:Boolean,
      default:false,
    },
    valueData: {
      default () {
      },
    },
  },
    data(){
        return{}
    },
}
</script>
<style lang="scss">
  @import 'select.css';
  @import 'option.css';
  @import 'selectChange'
</style>


