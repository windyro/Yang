export default{

    data() {
        return {
            testCommon: "testCommon",

            yesNoList: [
                {code:"Y",name:'label.yes'},
                {code:"N",name:'label.no'},
            ],
        
            comparisonList: [
                    {code:"=",name:'='},
                    {code:"!=",name:'!='},
                    {code:">",name:'>'},
                    {code:">=",name:'>='},
                    {code:"<",name:'<'},
                    {code:"<=",name:'<='},
            ],
        
            comparisonNameList: [
                {code:"=",name:'label.is'},
                {code:"!=",name:'label.is_not'},
                {code:">",name:'label.greater'},
                {code:">=",name:'label.greater_or_equal'},
                {code:"<",name:'label.less'},
                {code:"<=",name:'label.less_or_equal'},
            ],
        
            comparisonDateList: [
                {code:"=",name:'label.on'},
                {code:"!=",name:'label.not_on'},
                {code:">",name:'label.after'},
                {code:">=",name:'label.on_after'},
                {code:"<",name:'label.before'},
                {code:"<=",name:'label.on_before'},
            ],
        
        }

    },

}