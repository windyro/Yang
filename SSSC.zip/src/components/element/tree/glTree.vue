<template>    
    <el-tree ref="tree" v-bind="$attrs" v-on="$listeners" highlight-current :current-node-key="currentKey" :node-key="nodeKey" :default-expanded-keys="defaultExpandKeys">
        <span slot-scope="{node,data}" style="display:flex;">
            <img v-if="data.children.length>0" :src="parentSrc" alt class="node-img"/>
            <img v-else :src="childrenSrc" alt class="node-img"/>
            <gl-link type="primary" @click.prevent="clickNode(data)">{{data.label}}-{{data.title}}</gl-link >
            <span v-if="data.leaderCode" class="leader-span">
                （{{$t("label.leader")}}：<gl-link type="primary" style="margin-top:2px;" @click.prevent="clickNode(data,true)">{{data.leaderCode}}-{{data.leaderTitle?data.leaderTitle:'none'}}</gl-link>）
            </span>
        </span>
    </el-tree>
</template>
<script>

export default {
    props:['nodeKey','parentSrc','childrenSrc','currentKey','defaultExpandKeys'],
    inheritAttrs:false,
    watch:{
        'currentKey':{
            handler:function(val){
                if(val){
                    this.$refs['tree'].setCurrentKey(val);
                }
            }
        },
    },
    created(){
        this.$nextTick(()=>{
            this.$refs['tree'].setCurrentKey(this.currentKey);
        });
    },
    methods:{
        clickNode(data,isLeader=false){
            data.isLeader=isLeader;
            this.$emit('goToDetail',data);
        }
    },
}
</script>
<style lang="scss">
@import 'tree.css';
.node-img{
    width: 19px;
    margin: 0 6px;
}
.leader-span{
    font-size: 14px;
    display: flex;
    align-items: center;
}
</style>