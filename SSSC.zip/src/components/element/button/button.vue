<template>
    <el-button v-bind="$attrs" v-on="$listeners">
        <slot>Button</slot>
    </el-button>
</template>
<script>
export default {
    props:{
        size:String,
        type:String,
        plain:Boolean,
        round:Boolean,
        circle:Boolean,
        loading:Boolean,
        disabled:Boolean,
    },
//   data () {
//       return {
//           config: {}
//       }
//   },
//   mounted () {
//       this.config.type = this.type
//   }
}
</script>
<style scoped>
@import 'button.css'
</style>