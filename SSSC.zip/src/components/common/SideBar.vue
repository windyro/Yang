<template>
  <section class="sidebar">
    <div class="agent">
      <h6>
        <svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
          <use xlink:href="#signin-menu" />
        </svg>
        <slot></slot>
      </h6>
    </div>

    <div class="side-menu menuHead menu-border-top"  v-for="(item, index) in menu">
      <ul class="side-menu menuHead" v-if="item.comp ==nowComp">
        <li class="h5" id="menuGlory">
          <img :src="item.icon" alt class="logoIcon">
           {{$t(item.title)}}
          <i :class="!spread?'':'el-icon-arrow-down'" id="menuGloryIcon"></i>

        </li>
      </ul>

                <!-- Submenu -->
        <ul v-if="item.comp ==nowComp">
          <li tag="li" v-for="subItem in item.childen" :key="subItem.title" @click="toPage(subItem.link)">
            <h6>
              <img :src="subItem.icon" alt class="logoIconSub">
              
               <!--svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
                  <use :xlink:href="subItem.icon" />
               </svg-->
               {{$t(subItem.title)}}
            </h6>
          </li>
        </ul>
      </div>
    <!--ul class="side-menu menuHead" >
      <li class="h5" id="menuIpos1" @click="showList">
        <img src="../../assets/images/iposIcon.png" alt class="logoIcon" id="menuIposImage" />
        Channel admin2
        <i :class="spread?'':'el-icon-arrow-down'" id="menuIgentIcon"></i>


    <ul :class="spread?'iagent-ul':''" v-if="spread">
      <li tag="li" v-for="item in menu" :key="item.title" @click="toPage(item.link)">
        <h6>
          <svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
            <use :xlink:href="item.icon" />
          </svg>
          {{item.title}}
        </h6>
      </li>
    </ul>


      </li>
    </ul-->


    <!-- logiout -->
    <ul class="side-menu logout">
      <li @click="logout">
        <h6>
          <svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
            <use xlink:href="#signout-menu" />
          </svg>
          logout
        </h6>
      </li>
    </ul>
  </section>
</template>
<script>
import MenuData from "./TopBar";
import VueCookies from 'vue-cookies';
import { setTimeout } from 'timers';
export default {
  props: ["nowComp"],
  data() {
    return {
      clearSearchVal:true,
      spread: false,
      menu: MenuData.data().menu,
      myNowComp: "",
    };
  },

  watch: {
      nowComp:{
          handler:function(newVal){
              this.myNowComp = newVal;
          },
          deep:true,
      },
  },

  methods: {
    logout() {
      let agentcode = this.$store.state.agent.agentCode;
      if (!this.$isEmpty(agentcode)) {
        var param = {
          "userId": agentcode,
        };
        console.log("LOG OUT : Request : " + JSON.stringify(param));
        this.$caller.agent_token_disable(param).then(res => {
          console.log("LOG OUT : Response : " + JSON.stringify(res));
          VueCookies.remove('token');
          VueCookies.remove('sequence');
          VueCookies.remove('store');
          this.$cookies.remove("token");
          this.$cookies.remove("sequence");
          this.$cookies.remove("userId");
          this.$cookies.remove('store');
          sessionStorage.removeItem("token");
        });
      }
      this.$router.replace("/");
    },
    toPage(path){
      let _this = this;
      this.$emit("hide");
      this.$store.commit("setContactSubSteps", []);
      this.$store.commit("setQuotationSubSteps", []);
      this.$store.commit("setApplicationSubSteps", []);
      setTimeout(()=>{
        _this.$router.push({name: path}).catch(err=>{
        });
        _this.$store.commit("setSearchContactId", "");
        _this.$store.commit("setSearchContactName", "");
      },100)
    },
    showList() {
      this.spread = !this.spread;
      return false;
    },
    changeComp(comp){
      this.nowComp = comp;
      //alert(this.nowComp );
    },
  },
};
</script>
<style lang="scss">
.iagent {
  position: relative;
  padding-top: 0;
}
.logoIcon {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  vertical-align: middle;
  margin-right: 5px;
}

.logoIconSub {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  vertical-align: middle;
  margin-right: 5px;
}
.menuHead {
  padding: 0;
}
// .side-menu{
//   #
// }
</style>


