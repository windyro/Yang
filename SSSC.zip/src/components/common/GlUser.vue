<template>
    <aia-el-form alias="userForm" ref="userForm"  :model="userForm" :rules="$formValidator.rules">
        <gl-dialog
            @doCloseDialog="doCloseDialog"
            :dialogTableVisible = "dialogTableVisible"
        >
            <template slot="dialog-content">
                <div>
                    <el-row  :gutter="20" style="margin-right: 0px; margin-left: 0px; margin-top: 0px; margin-bottom: 20px;" >
                        <el-col :xs="12" :sm="12" :md="12" :lg="12" style="padding-right: 50px; padding-left: 0px; padding-bottom: 20px; padding-top: 0px;"  v-for="item in headerList" :key="item.code">
                            <label><h6>{{$t(item.name)}}</h6></label>
                            <div v-if="item.type =='inputPassword'" >
                                <el-form-item prop="password" :rules="$formValidator.rules.required" style="width:49%; display: inline-block;">
                                    <el-input v-model="userForm.password"  type="password" placeholder="New password"></el-input>
                                </el-form-item>

                                <el-form-item prop="passwordConfirm" :rules="$formValidator.rules.required" style="width:49%; display: inline-block;">
                                    <el-input v-model="userForm.passwordConfirm"  type="password" placeholder="Confirm new password"></el-input>
                                </el-form-item>
                            </div>
                            <el-input v-else v-model="userInfo[item.code]" :disabled="true"></el-input>
                        </el-col>     
                    </el-row>
                </div>
            </template> 

            <template slot="buttons">   
                <button class="btn-primary"  @click.prevent="doSave">{{$t('label.save')}}</button>
                <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
            </template>
        </gl-dialog>
    </aia-el-form>
</template>
<script>
import User from '../../pages/authority/User';
import util from "@/models/Utility";
export default {
  props: ["dialogTableVisible"],
  data() {
    return {
        userForm: {password: null, passwordConfirm: null},
        headerList: User.data().headerList,
        dialogTable: this.$props.dialogTableVisible,
        userInfo: this.$cloneObject(this.$store.state.user.userInfo),
    };
  },

  created() {  
        this.prepare();
  },
  methods: {
    prepare() {
        //alert(JSON.stringify(this.$store.state.user.userInfo));
        this.userInfo = this.$cloneObject(this.$store.state.user.userInfo);
        this.userInfo.rolelist = this.userInfo.rolelist.map(role=>{
            return role.roleName;
        });
        this.userInfo.rolelist = this.userInfo.rolelist.join(",");
    },
    doCloseDialog(){
        this.$emit("doCloseDialog");
    },

    doSave(){
        if(!this.$refs.userForm.validate()){
            return;
        }
        if(this.userForm.password != this.userForm.passwordConfirm){
            this.$alert(this.$t("message.confirmPwd"), this.$t("message.error"), {
                confirmButtonText: "OK"
            });
            return;
        }

        this.$confirm(this.$t("message.changePwd"), this.$t("message.confirm"), {
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
            type: "Error",
            closeOnClickModal: false,
        })
        .then(() => {
            let param={
                action:'UPDATE',
                ...this.$store.state.user.userInfo,
                password: util.encryptData(this.userForm.password),
            }
            this.$caller.user_query(param).then(res=>{
                if(res.responseCode =="000"){
                    this.$emit("doSave");

                }else{
                    return;
                }
            });
        })
        .catch(() => {
            return;
        });


    },

  },
};
</script>

<style lang="scss">

</style>