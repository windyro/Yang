<template>
  <section class="topmenu"             
    @mouseenter="toggleInTopMenu" 
    @mouseleave="hideTopMenu">

    <!-- menu -->
    <!--ul class="side-menu margin-bottom-l" >
      <li tag="li" v-for="item in menu" :key="item.title" @click="toPage(item.link)">
        <h6>
          <svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
            <use :xlink:href="item.icon" />
          </svg>
          {{item.title}}
        </h6>
      </li>
    </ul-->


    <div class="container-fluid margin-bottom-xxl">
        <div class="row">
            <div class="col-sm-3  margin-top-3xl left-part">
                <h4>{{$t(menuName)}}</h4>
                <p>{{$t(menuDec)}}.</p>
            </div>
            <div class="col-sm-9  border-left margin-top-4xl right-part">
                <div class="row">

                    <div class="col-sm-4" v-for="item in menu" >
                        <ul class="list-unstyled">
                            <li class="list-ele">
                                <a @click="toPage(item.link)"  target="_blank">
                                    <div class="thumbnail">
                                        <!--svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
                                        <use :xlink:href="item.icon" />
                                        </svg-->
                                        <img :src="item.icon" alt class="logoIcon">
                                    </div>
                                    <div class="content">
                                        <h6 class="p3">{{$t(item.title)}}</h6>
                                        <p class="p3 bt5">{{$t(item.dec)}}</p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>   

  </section>
</template>
<script>
import MenuData from "./TopBar";
import VueCookies from 'vue-cookies';
import { setTimeout } from 'timers';

export default {
    props: ['nowIndex'],
  data() {
    return {
      clearSearchVal:true,
      nowIndex: this.nowIndex,
      menu: MenuData.data().menu[this.nowIndex].childen,
      menuName: MenuData.data().menu[this.nowIndex].name,
      menuDec: MenuData.data().menu[this.nowIndex].description,
    };
  },


  methods: {

    toPage(path){
      let _this = this;
      this.$emit("hide");
      this.$store.commit("setContactSubSteps", []);
      this.$store.commit("setQuotationSubSteps", []);
      this.$store.commit("setApplicationSubSteps", []);
      setTimeout(()=>{
        _this.$router.push({name: path}).catch(err=>{
        });
        _this.$store.commit("setSearchContactId", "");
        _this.$store.commit("setSearchContactName", "");
      },100)
    },

    toggleInTopMenu(){
			 //alert("TopMenu: " +  index);
       alert("in");
        this.$emit('toggleInTopMenu') ;
		},

    hideTopMenu(){
			//alert(this.$route.name);
        this.$emit('toggleInTopMenu') ;
        this.$emit('hideTopMenu') ;
		},
  },
};
</script>
<style lang="scss">
.iagent {
  position: relative;
  padding-top: 0;
}
.logoIcon {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  vertical-align: middle;
  margin-right: 5px;
}
.menuHead {
  padding: 0;
}

.list-unstyled {
    padding-left: 0px;
    list-style: none;
}


.margin-bottom-xxl {
    margin-bottom: 40px;
}
/*@media all and (min-width:768px)*/
.container-fluid {
    padding-left: 40px;
    padding-right: 40px;
    margin-right: auto;
    margin-left: auto;
}

/*@media all and (min-width:768px)*/
.row {
    margin-left: -28px;
    margin-right: -28px;
}
.margin-top-3xl {
    margin-top: 48px;
}


a:hover{
  cursor:pointer
}
</style>


