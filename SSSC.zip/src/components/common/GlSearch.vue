<template>
  <div class="search-wrap">
      <el-row class="row margin-bottom-xxs" :gutter="20" v-for="(search,index) in this.searchList"  :key="index">
          <el-col :xs="6" :sm="4" :md="4" :lg="4">
              <gl-select type="other" 
                          :edit="true" 
                          v-model="search.name" 
                          :valueData="search.name"
                          :optionList="headerList"
                           @change="headerSelect(search.name, index)">
                </gl-select>
          </el-col>
          <!--el-col :xs="2" :sm="3" :md="3" :lg="3">
                <gl-select type="comparisonName" 
                          :edit="true" 
                          v-model="search.comparison" 
                          :valueData="search.comparison"> 
                </gl-select>
          </el-col-->
          <el-col :xs="8" :sm="6" :md="6" :lg="6" style="padding-right: 0px; padding-left: 0px;">
                <el-input v-if="search.headerSelected.type=='input'" v-model="search.value"></el-input>
                <el-input v-else-if="search.headerSelected.type=='selectRadio'" v-model="search.value"></el-input>

                <gl-select v-else-if="search.headerSelected.type=='select' && search.headerSelected.select=='other'"  
                          :type="search.headerSelected.select" 
                          :edit="true" 
                          v-model="search.value" 
                          :valueData="search.value"
                          :optionList="search.headerSelected.optionList">
                </gl-select>     

                 <gl-select v-else-if="search.headerSelected.type=='select' && search.headerSelected.select!='other'" 
                          :type="search.headerSelected.select" 
                          :edit="true" 
                          v-model="search.value" 
                          :valueData="search.value">
                </gl-select>    

                <gl-date v-else-if="search.headerSelected.type=='date' || search.headerSelected.type=='month' || search.headerSelected.type=='year'"
                        :type="search.headerSelected.type"
                        v-model="search.value"
                        :value="search.value"
                        :editable="true"
                        class="input-class">
                </gl-date>                      
         </el-col>

          <el-col :xs="4" :sm="1" :md="1" :lg="1" style="padding-right: 2px; padding-left: 2px; width: 35px;">
                 <span class="iconfont cursor-p"  v-if="index==0" id="addBtn" @click="addCondition">&#xe612;</span>
                 <span class="iconfont cursor-p"  v-if="index!=0" id="delBtn" @click="delCondition(index)">&#xe651;</span>
                 <!--span class="iconfont cursor-p" id="searchBtn" @click="saveName">&#xe688;</span-->
                 
          </el-col>

          <el-col :xs="4" :sm="2" :md="2" :lg="2" style="padding-right: 0px; padding-left: 0px;" v-if="index==0">
                 <button class="btn-primary" @click.prevent="doSearch" >go</button>
                 <!--span class="iconfont cursor-p" id="addBtn" @click.stop="show" style="padding-right: 5px;">&#xe612;</span-->
                 <!--span class="iconfont cursor-p" id="searchBtn" @click="saveName">&#xe688;</span-->
                 
          </el-col>
        </el-row>
  </div>
</template>
<script>
export default {
  props: {
    headerList: {type: Array, default:function(){return [] }},
    //headerList: [],
    
    // [
    // "info",
    // "searchType",
    // "loaded",
    // "valueData",
    // "clearSearchVal"
    
    // ],
  },

  data() {
    return {
      value: "",
      isactive: true,
      conInfo: [],
      targetName: "",
      
      //headerSelected: {},
      searchList: [{name: 'Name', comparison: '=', value: '', headerSelected: {},},],

      optionList: [],
      optionData: [],
      optionResultData: [],
      optionClass: "optionClass",
    };
  },
  created() {
    this.searchList[0].name=this.headerList[0].code;
    this.searchList[0].headerSelected=this.headerList[0];
    this.searchList[0].value="";
    this.headerList[0].disabled=true;
    
  
    // if (
    //   this.$props.searchType == "quotation" ||
    //   this.$props.searchType == "application"
    // ) {
    //   console.log(this.$props.info.length);
    //   this.$props.info.forEach(data => {
    //     this.optionData.push({ value: data.insuredName });
    //     this.optionData.push({ value: data.payorName });
    //   });
    // } else if (this.$props.searchType == "contact") {
    //   this.$props.info.forEach(data => {
    //     this.optionData.push({ value: data.name });
    //   });
    // } else {
    //   this.$props.info.forEach(data => {
    //     this.optionData.push({ value: data.name });
    //     data.quotationList.forEach(item => {
    //       if (item.insuredName && item.insuredName != "") {
    //         this.optionData.push({ value: item.insuredName });
    //       }
    //     });
    //   });
    // }
    // console.log(this.valueData);
    // this.value = void 0 != this.valueData ? this.valueData : "";
    // console.log(this.value);
  },

  watch: {
    value() {
      if (this.value == "") {
        this.optionResultData = [];
        this.$emit("searchName", "");
      }
    },

  },
  methods: {
    headerSelect(searchName, index){
      this.searchList[index].value ="";

      this.searchList[index].headerSelected = this.headerList.find((item)=>{
          return item.code === this.searchList[index].name; }); 

      this.headerList.forEach(x=>{
        x.disabled=this.searchList.some(s=>s.name===x.code)?true:false
      })
    },

    addCondition(){
      this.searchList.push({name: '', comparison: '', value: '', headerSelected: {type: 'input'}});
    },

    delCondition(index){
      let code=this.searchList[index].name
      if(code){
        this.headerList.find(x=>x.code===code).disabled=false
      }
      this.searchList.splice(index, 1);
    },

    doSearch() {
     // this.targetName = this.value;
     // this.searchName(this.targetName);

      // var param = {
      //       startPage: "1",
      //       pageSize: "10" 
      // };

      // this.$caller.rule_summary_query(param).then(res => {
      //     alert(res.errorCode);
      //     alert(res.result);

      // });

       this.$emit("doSearch", this.searchList);
    },

  },
};
</script>
<style >
@import "../../assets/css/autocomplete.css";

</style>
<style lang="scss" scoped>
@import "@/assets/css/variable.scss";
@import "../element/form/form";
@import "../element/form/responsive-form";
@import "../element/form/datepicker";
@import "../element/form/formChange";
.search-wrap {
  min-width: 170px;
  @include ss {
    margin-bottom: 10px;
  }
  .search-input {
    width: calc(100% - 72px);
    min-width: 100px;
    margin-right: -2px;
    display: inline-block;
  }
  .search-input::-webkit-calendar-picker-indicator {
    display: none;
    -webkit-appearance: none;
  }
  .searchUl {
    position: absolute;
    z-index: 99;
    background: white;
    width: calc(100% - 144px);
    border: 1px solid #dbdad4;
    padding: 0;
    //  border-radius: 5px;
    display: none;
  }

  .btn-primary {
    width: 70px;
    min-width: 70px;
    vertical-align: bottom;
  }

  .iconfont{
    font-size: 30px;
    color: rgba($color: #6F6E68, $alpha: 0.5);
    &:hover{
      color: rgba($color: #6F6E68, $alpha: 1);
    }
  }

    .input-class {
    width: 100%;
  }
}
</style>