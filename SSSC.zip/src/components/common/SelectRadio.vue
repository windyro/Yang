<template>
    <el-select multiple v-model="optionValue" :placeholder="$t('message.pleaseConfigPermission')" @remove-tag="removeTag">
        <el-option
            v-for="item in selectOptionList"
            :key="item.code"
            :label="item.name"
            :value="item.code">
                <div @click.stop class="radio-div">
                    <span>{{ $t(item.name) }}</span>
                    <el-radio-group v-model="item.radioValue" @change="radioChange(item)">
                        <el-radio v-for="sub in radioGroup" :key="sub.code" :label="sub.code">{{$t(sub.name)}}</el-radio>
                    </el-radio-group>
                </div>
        </el-option>
    </el-select> 
</template>
<script>
export default {
    props:{
        optionValue:{
            type:Array,
            default:()=>[],
        },
        optionList:{
            type:Array,
            default:null,
        },
        radioGroup:{
            type:Array,
            default:null,
        },
        optionCode:{
            type:String,
            default:null,
        },
    },
    data(){
        return {
            selectOptionList:[],
        }
    },
    watch:{
        optionValue(){
            this.setOptionList();
        },
    },
    created(){
        this.setOptionList();
    },
    methods:{
        setOptionList(){
            this.selectOptionList=this.optionList.map(x=>{
                let newX={...x}
                let name=newX.name;
                let optionValueIndex=this.optionValue.findIndex(y=>{
                    return y.includes(name);
                });
                if(optionValueIndex>-1){
                    let index=this.optionValue[optionValueIndex].indexOf('(');
                    newX.radioValue=this.optionValue[optionValueIndex].substring(index);
                }
                return newX;
            });
        },
        radioChange(item){
            let radio={
               ...item,
               optionCode:this.optionCode,
            } 
            this.$emit('selectRadio',radio);
        },
        removeTag(tag){
            this.$emit('removeTag',tag);
        },
    },
}
</script>
<style lang="scss">
.el-select-dropdown__item{
    display:flex;
    .radio-div{
        display:flex;
        width: 100%;
        .el-radio-group{
            margin-left:auto;
        }
    }

    .el-radio-group .el-radio{
        margin-left: 10px;
        .el-radio__label{
            margin-left:3px;
        }
    }
}
</style>