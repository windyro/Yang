<template>
    <section>
        
        <section  class="topbar">
          <div class="canvas-leftbar">
              <button class="navbar-btn hide-sd-up" v-if="!getIsHome" @click="toggle">
                  <span class="icon-xs iconfont cursor-p " >&#xe602;</span>
              </button>
              <a class="navbar-brand cursor-p" @click="toHome">
                  <img class="navbar-brand-img hidden-xs" src="./../../assets/images/AIA-white-logo.png" >
                  <!--v-if="!defaultTitle||$route.path.indexOf('agent')>-1"-->
                  <!--a  class="margin-top-xs h5">{{defaultTitle}}</a-->
              </a>
          </div>

          <div class = "canvas-topmenu">		
              <a class="navbar-brand-left  cursor-p"   @click="toHome">
                  <img class="navbar-brand-img hidden-xs" src="./../../assets/images/AIA-white-logo.png" >
                  <!--a  class="margin-top-xs h5">{{defaultTitle}}</a  -->
              </a>

              <ul class="nav navbar-nav" data-user-menu="individual" v-if="!getIsHome" >

                <li class="dropdown" 
                    v-for="(item, index) in menu" 
                    v-if="item.auth"
                    @mouseenter="toggleTopMenu(index)" 
                    @mouseleave="hideTopMenu(index)"
                    :class="{'open':showTopMenuList[index]}"
                    >
                    <a v-if="item.comp ==nowComp" tabindex="100" class="dropdown-toggle h6"   aria-expanded="false" href="javascript:void(0)" data-delay="100" data-hover="dropdown">{{$t(item.title)}}</a>	

                        <section class="topmenu" v-if="showMenu(index)" >

                            <div class="container-fluid margin-bottom-xxl">
                                <div class="row">
                                    <div class="col-sm-3  margin-top-3xl left-part">
                                        <h4>{{$t(item.name)}}</h4>
                                        <p>{{$t(item.description)}}</p>
                                    </div>
                                    <div class="col-sm-9  border-left margin-top-4xl right-part">
                                        <div class="row">

                                            <div class="col-sm-4" v-for="subItem in item.childen">
                                                <ul class="list-unstyled">
                                                    <li class="list-ele" v-if="subItem.auth">
                                                        <a  @click="toPage(subItem.link)" target="_blank">
                                                            <div class="thumbnail">
                                                                <!--svg class="icon icon-xs hide-on-fallback" aria-hidden="true">
                                                                <use :xlink:href="item.icon" />
                                                                </svg-->
                                                                <img :src="subItem.icon" alt class="logoIcon">
                                                            </div>
                                                            <div class="content">
                                                                <h6 class="p3">{{$t(subItem.title)}}</h6>
                                                                <p class="p3">{{$t(subItem.title)}}</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>   
                    </section>		
                  </a>
                </li>
              </ul>


              <a class="nav navbar-brand-right">
                <h6 class="navbar-brand-user">
                  <!--span class="icon span" @click.prevent="displayUser">{{userId}}</span-->
                  <svg class="icon icon-xs icon-ahead cursor-p"  aria-hidden="true" @click.prevent="viewUser">
                      <use xlink:href="#signin-menu" />                     
                  </svg>

                  <svg class="icon icon-xs cursor-p" aria-hidden="true" @click.prevent="logout">
                    <use xlink:href="#signout-menu" />
                  </svg>
                </h6>
                <gl-user  :dialogTableVisible="displayUser"  @doSave="saveUser" @doCloseDialog="closeUser">
                </gl-user>
              </a>
            </div>


        </section>			 
        <!--button class="navbar-btn hide-sd-up" style="position:absolute;right:20px;" v-if="icon" @click="locationSearch">
            <span class="icon-xs iconfont cursor-p">&#xe688;</span>
        </button-->
      	<section  class="navbar-three navbar-sub">
            <div class="padding-top-m padding-bottom-m margin-left-3xl margin-right-3xl">
                <h5 class="inline-block">{{$t(getRouterTitle)}}</h5>	
            </div>
       </section>



    </section>

</template>


<script>
import img0 from '../../assets/images/home.png'; 
import img12 from '../../assets/images/sicm_rule.png';
import img13 from '../../assets/images/sicm_rule_conf.png';

import img14 from '../../assets/images/sicm_result.png';
import img15 from '../../assets/images/sicm_payment.png';
import img16 from '../../assets/images/sicm_compensation.png';
import img17 from '../../assets/images/sicm_transaction.png';

import img18 from '../../assets/images/sicm_calculation.png';
import img19 from '../../assets/images/sicm_calculation_run.png';
import img20 from '../../assets/images/sicm_adjustment.png';

import img_sys_user from '../../assets/images/sys_user.png';
import img_sys_role from '../../assets/images/sys_role.png';

import img_channel_agent from '../../assets/images/channel_agent.png';
import img_channel_district from '../../assets/images/channel_district.png';
import img_channel_agency from '../../assets/images/channel_agency.png';
import img_channel_relationship from '../../assets/images/channel_relationship.png';
import img_channel_company from '../../assets/images/channel_company.png';
import img_channel_channel from '../../assets/images/channel_channel.png';
import img_channel_location from '../../assets/images/channel_location.png';
import img_channel_cashier from '../../assets/images/channel_cashier.png';
import img_channel_title from '../../assets/images/channel_title.png';

import { setTimeout } from 'timers';
import util from "@/models/Utility";
import pageConfig from '@/models/pageConfig';

export default {
	  data() {
    return {
      showTopMenu: false,
      showTopMenuList: [],
      nowIndex: 0,
      nowComp: sessionStorage.getItem('comp'),
      displayUser: false,

			home: [
				{
				  icon: img0,
          title: "home",
          link: "Home",   
			  },
			],
     menu: [
       //SICM Menu
        {
          icon: img12,
          comp: "menu.sicm",
          title: "menu.rule",
					name: "menu.rule_name",
					description: "menu.rule_des",
          link: "rule_configuration",
          auth:false,
          childen: [
              {
                icon: img13,
                title: "menu.summary",
                link: "rule_summary",
                auth:this.$checkPageAuthority('rule_summary'),
              },
          ],    
        },
        {
          icon: img14,
          comp: "menu.sicm",
          title: "menu.result",
					name: "menu.result_name",
					description: "menu.result_des",
          link: "result_payment",
          auth:false,
          childen: [
              {
                icon: img15,
                title: "menu.payment",
                link: "result_payment",
                auth:this.$checkPageAuthority('result_payment'),
              },
              {
                icon: img16,
                title: "menu.compensation",
                link: "result_compensation",
                auth:this.$checkPageAuthority('result_compensation'),
              },   
              {
                icon: img17,
                title: "menu.transaction",
                link: "result_transaction",
                auth:this.$checkPageAuthority('result_transaction'),
              },                         
          ],
        },
        {
          icon: img18,
          comp: "menu.sicm",
          title: "menu.calculation",
					name: "menu.calculation_name",
					description: "menu.calculation_des",					
          link: "compensation_calculation",
          auth:false,
          childen: [
              {
                icon: img19,
                title: "menu.calculation",
                link: "compensation_calculation",
                auth:this.$checkPageAuthority('compensation_calculation'),
              },
          ],         
        },
        {
          icon: img20,
          comp: "menu.sicm",
          title: "menu.adjustment",
					name: "menu.adjustment_name",
					description: "menu.adjustment_des",						
          link: "manual_adjustment",
          auth:false,
          childen: [
              {
                icon: img17,
                title: "menu.adjustment",
                link: "manual_adjustment",
                auth:this.$checkPageAuthority('manual_adjustment'),
              },
          ],        
        },

        //Channel Admin Menu
        {
          icon: img20,
          comp: "menu.channel",
          title: "menu.agent",
					name: "menu.agent_name",
					description: "menu.agent_des",						
          link: "agent_maintain",
          auth:false,
          childen: [
              {
                icon: img_channel_agent,
                title: "menu.agent",
                link: "agent_maintain",
                auth:this.$checkPageAuthority('agent_maintain'),
              },
          ],         
        },
        {
          icon: img20,
          comp: "menu.channel",
          title: "menu.hierarchy",
					name: "menu.hierarchy_name",
					description: "menu.hierarchy_des",						
          link: "hierarchy_agency",
          auth:false,
          childen: [
              {
                icon: img_channel_agency,
                title: "menu.agency",
                link: "hierarchy_agency",
                auth:this.$checkPageAuthority('hierarchy_agency'),
              },
              {
                icon: img_channel_relationship,
                title: "menu.relationship",
                link: "hierarchy_relationship",
                auth:this.$checkPageAuthority('hierarchy_relationship'),
              },
          ],        
        },
    
        {
          icon: img20,
          comp: "menu.channel",
          title: "menu.administration",
					name: "menu.administration_name",
					description: "menu.administration_des",						
          link: "administration_company",
          auth:false,
          childen: [
              {
                icon: img_channel_company,
                title: "menu.company",
                link: "administration_company",
                auth:this.$checkPageAuthority('administration_company'),
              },
              {
                icon: img_channel_channel,
                title: "menu.channel",
                link: "administration_channel",
                auth:this.$checkPageAuthority('administration_channel'),
              },
              {
                icon: img_channel_location,
                title: "menu.city",
                link: "administration_city",
                auth:this.$checkPageAuthority('administration_city'),
              },
              {
                icon: img_channel_location,
                title: "menu.location",
                link: "administration_location",
                auth:this.$checkPageAuthority('administration_location'),
              },
              {
                icon: img_channel_cashier,
                title: "menu.cashier",
                link: "administration_cashier",
                auth:this.$checkPageAuthority('administration_cashier'),
              },
              {
                icon: img_channel_title,
                title: "menu.title",
                link: "administration_title",
                auth:this.$checkPageAuthority('administration_title'),
              },
              {
                icon: img_channel_title,
                title: "menu.class",
                link: "administration_class",
                auth:this.$checkPageAuthority('administration_class'),
              },
          ],         
        }, 

        //Performance Menu
        {
          icon: img20,
          comp: "menu.performance",
          title: "menu.contest",
					name: "menu.contest",
					description: "menu.contest_des",						
          link: "master_information",
          auth:false,
          childen: [
              {
                icon: img_sys_user,
                title: "menu.master",
                link: "master_information",
                auth:this.$checkPageAuthority('master_information'),
              },
              {
                icon: img_sys_role,
                title: "menu.criteria",
                link: "contest_criteria",
                auth:this.$checkPageAuthority('contest_criteria'),
              },
              {
                icon: img_sys_role,
                title: "menu.trackMonitor",
                link: "tracking_monitoring",
                auth:this.$checkPageAuthority('tracking_monitoring'),
              },              
          ],         
        }, 

        //System Menu
        {
          icon: img20,
          comp: "menu.system",
          title: "menu.authority",
					name: "menu.authority_name",
					description: "menu.authority_des",						
          link: "authority_user",
          auth:this.$store.state.user.isAdmin,
          childen: [
              {
                icon: img_sys_user,
                title: "menu.user",
                link: "authority_user",
                auth:this.$store.state.user.isAdmin,
              },
              {
                icon: img_sys_role,
                title: "menu.role",
                link: "authority_role",
                auth:this.$store.state.user.isAdmin,
              },
          ],         
        }, 
      //  {
      //     icon: img20,
      //     title: "Testing",
			// 		name: "Testing",
			// 		description: "Testing",						
      //     link: "test",
      //     childen: [
      //         {
      //           icon: img17,
      //           title: "test",
      //           link: "test"
      //         }
      //     ]         
      //   },             
        
      ],
    };
  },
  props:{
      title:{
      default:'',
      type:String,
    },icon:{
      default:true,
      type:Boolean,
    },
  },
  computed:{
    defaultTitle(){
      // console.log(this.title)
			return this.$route.name;

      // if(this.title){
      //   return this.title;
      // } else if (this.$route.path.indexOf('contact')>-1){
      //   return "contact";
      // } else if (this.$route.path.indexOf('quotation')>-1
      //           &&this.$route.path.indexOf('application')<0){
      //   return "quotation";
      // } else if (this.$route.path.indexOf('application')>-1){
      //   return "application";
      // } else {
      //   return "";
      // }
    },
		getRouterTitle(){
      var titleStr = this.$route.meta.title;
      if(this.title && this.title!=''){
         titleStr += " - " + this.title;
      }
			return titleStr;
		},
		getIsHome(){
				if(this.$route.name=="Home"){
					return true;
				}
				return false;
		},
  },

  created() {
    this.menuAuth();
    this.prepare();
  },

  methods:{
    menuAuth(){
      let eventInfo=[];
      this.menu.forEach(menuItem=>{
        let canReadChilds=menuItem.childen.filter(child=>child.auth);
        if(canReadChilds.length>0){
          menuItem.auth=true;
          let isRepeat=eventInfo.some(e=>e==menuItem.comp);
          if(!isRepeat){
            eventInfo.push({comp:menuItem.comp,default:canReadChilds[0].link});
          }
        }
      });
      this.$emit('menuConfig',eventInfo);
    },
    prepare(){
      this.menu.forEach(element => {
          this.showTopMenuList.push(false);
      });

    },

    toggle(){
     this.$emit('toggleSidebar');
    },
    locationSearch(){
      this.$store.state.search=true;
     this.$router.replace({ name: "contact",params:{
       isSearch:true,
     }, },);
  
    },
    toHome(){
	    //alert(this.$route.name);
      let _this = this;
      this.hideTopMenu(this.nowIndex);
      //this.$store.commit("setContactSubSteps", []);
      //this.$store.commit("setQuotationSubSteps", []);
      //this.$store.commit("setApplicationSubSteps", []);
      setTimeout(()=>{
        _this.$router.push({name: "Home" });
        //_this.$store.commit("setSearchContactId", "");
        //_this.$store.commit("setSearchContactName", "");
      },100)
    },
		toggleTopMenu(index){
      if(!this.showTopMenuList[index]){
          this.$set(this.showTopMenuList, index, true); 
      }
      this.nowIndex = index;
       // this.$emit('toggleTopMenu', index) ;
		},

    hideTopMenu(index){
      if(this.showTopMenuList[index]){
          this.$set(this.showTopMenuList, index, false); 
      }
       //this.$emit('hideTopMenu', index) ;
		},

    showMenu(index){
        return this.showTopMenuList[index];
    },

    toPage(path){
      let _this = this;
      this.hideTopMenu(this.nowIndex);

      setTimeout(()=>{
        _this.$router.push({name: path})
      },100)
    },

    changeComp(comp){
      this.nowComp = comp;
    },

    viewUser(){
        this.displayUser = true;
    },
    saveUser(){
        this.displayUser = false;
        this.$cookies.remove("token");
        sessionStorage.removeItem("token");
        this.$router.replace("/");
    },
    closeUser(){
        this.displayUser = false;
    },

    logout() {
      this.$confirm(this.$t("message.logout"), this.$t("message.confirm"), {
          confirmButtonText: "OK",
          cancelButtonText: "Cancel",
          type: "Error",
          closeOnClickModal: false,
      })
      .then(() => {
           this.$cookies.remove("token");

           sessionStorage.removeItem("token");
           sessionStorage.removeItem("store");

           this.$resetGeneralList('company');
           this.$resetGeneralList('channel');

           this.$router.replace("/");
      })
    },

  },
}
</script>
<style lang="scss"  >
@import "@/assets/css/variable.scss";
.topbar{
  height:88px;
  a{
     cursor:default;
.h5{
   line-height: 40px;
   cursor:default;
  }
  }
  
}


ul{
    -webkit-margin-before: 0em;
    -webkit-margin-after: 1em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    -webkit-padding-start: 0px;
}

/*@media all and (min-width:1025px)*/
.nav {
    margin-bottom: 0px;
    padding-left: 0px;
    list-style: none;
}

.navbar-nav {
	  padding-left: 30px;
    display: inline-block;
    margin-left: 100px;
}

.nav > li {
    position: relative;
    display: block;
		color: #fff;
		float: left;
}

.nav > li > a {
    font-family: "AIATitle";
    font-size: 20px;
    line-height: 20px;
    color: white;
    margin: 0;
		position: relative;
}

.navbar-nav > li > a {
    padding-top: 24px;
    padding-bottom: 24px;
    padding-left: 28px;
    padding-right: 24px;
    text-decoration: none;
		display: table-cell;
    vertical-align: bottom;
		height: 88px;
    width: 100px;
}


.h6{
    font-family: "AIASans", "Calibri", sans-serif;
    font-weight: inherit;
    text-transform: uppercase;
    margin-top: 0px;
    margin-bottom: 0px;
  }


.navbar-nav > .dropdown.open {
    position: static;
}

.navbar-nav > li.open {
    background-color: #B8123E;
    background-repeat: no-repeat;
    background-position: 50% 100%;
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAIAgMAAAH6H6eSAAAADFBMVEX////////////////1pQ5zAAAAA3RSTlMAfX7XWp9eAAAANElEQVQI1wXB0Q1AUAwAwMOHhCXeBhYQRq9ROoIBpHVn4MJpSXeZzNvjeMXHmohi707RXT/7CQ+qIm3ujgAAAABJRU5ErkJggg==);
}


.logoIcon {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  vertical-align: middle;
  margin-right: 5px;
}





.margin-bottom-xxl {
    margin-bottom: 40px;
}
/*@media all and (min-width:768px)*/
.container-fluid {
    padding-left: 40px;
    padding-right: 40px;
    margin-right: auto;
    margin-left: auto;
}

/*@media all and (min-width:768px)*/
.row {
    margin-left: -28px;
    margin-right: -28px;
}
.margin-top-3xl {
    margin-top: 48px;
}



a:hover{
  cursor:pointer
}



</style>
<style lang="scss">
@import "../../assets/css/menubar.scss";
//@import "../../assets/css/dls.css";
</style>

