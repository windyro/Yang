<template>
  <div class="version-wrap">
      <el-row :gutter="20" >

          <el-col class="version-block cursor-p" :xs="12" :sm="12" :md="12" :lg="6" @click.native="doOpenDialog">
                 <!--span class="iconfont cursor-p"  id="version" @click="versionDialog">&#xe617;</span-->
                 
                 <img :src="img_folder" alt class="versionicon">
                 <span class="versionfont">Version: {{effectiveStartDate}}~{{effectiveEndDate}}</span>
          </el-col>
       </el-row>

        <gl-dialog :dialogTableVisible="display" @doCloseDialog="doCloseDialog">
            <template slot="dialog-title">
                  <h6>Version Management</h6>
            </template>
            
            <template slot="dialog-content">
                <gl-object-table :data="versionData" :hightLightIndex="hightLightIndex">
                    <el-table-column :label="$t('label.effectedStartDate')" width="auto">
                        <template slot-scope="scope">
                            <gl-date :edit="false" v-model="scope.row.effectiveStartDate" :value="scope.row.effectiveStartDate" type="date" ></gl-date>
                        </template>
                    </el-table-column>
                    <el-table-column :label="$t('label.effectedEndDate')" width="auto">
                        <template slot-scope="scope">
                            <gl-date :edit="false" v-model="scope.row.effectiveEndDate" :value="scope.row.effectiveEndDate" type="date" ></gl-date>
                        </template>
                    </el-table-column>
                    <el-table-column label="Version Log" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.versionLog}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :label="$t('label.createDate')" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.createDate|convertDate}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.removedate')" width="auto">
                        <template slot-scope="scope">
                            <span class="bt5">{{scope.row.removeDate|convertDate}}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="$t('label.operation')" min-width="100%">
                        <template slot-scope="scope">
                            <gl-button type="text" @click="viewVersion(scope.row,scope.$index)" :disabled="hightLightIndex==scope.$index">{{$t('label.view')}}</gl-button>
                        <!--    <span v-else-if="currentVersion.seq==scope.row.seq" class="bt5">{{$t('label.view')}}</span>
                            <gl-button type="text" @click="copyVersion(scope.row,scope.$index)" >{{$t('label.copy')}}</gl-button>-->
                            <gl-button type="text" @click="removeVersion(scope.row,scope.$index)" :disabled="hightLightIndex==scope.$index||!isModify">{{$t('label.remove')}}</gl-button>
                        </template>
                    </el-table-column>
                </gl-object-table>
            </template>

            <template slot="buttons">   
                 <button class="btn-secondary" @click.prevent="doCloseDialog">{{$t('label.close')}}</button>
            </template>
        </gl-dialog>
  </div>
</template>
<script>
import img_folder from '../../assets/images/folder.png';
export default {
  props: ["currentVersion","versionData","isModify"],

  data() {
    return {
       effectiveStartDate: this.$props.currentVersion.effectiveStartDate,
       effectiveEndDate: this.$props.currentVersion.effectiveEndDate,
       versionLog: this.$props.currentVersion.versionLog,
       img_folder: img_folder,
       display:false,
       hightLightIndex: null,
    };
  },
  watch:{
    currentVersion:{
      handler:function(){
          this.prepare();
      },
      deep:true,
      immediate:true,
    },

    versionData:{
      handler:function(){
          this.prepare();
      },
      deep:true,
      immediate:true,
    },
  },

  methods: {
      prepare(){
         // console.log(JSON.stringify(this.$props.currentVersion));
          // console.log(JSON.stringify(this.$props.versionData));
        let {effectiveStartDate,effectiveEndDate}={...this.currentVersion};
        this.effectiveStartDate=effectiveStartDate;
        this.effectiveEndDate=effectiveEndDate;

          this.versionData.forEach((element,index) =>{
                if(element.effectiveStartDate === this.effectiveStartDate && element.effectiveEndDate === this.effectiveEndDate){
                    this.hightLightIndex = index;
                }
          });
          //console.log(this.hightLightIndex);
      },
      doOpenDialog(){
          this.display=true;
      },
      doCloseDialog(){
          this.display=false;
      },

      viewVersion(row, index){
          this.effectiveStartDate=row.effectiveStartDate;
          this.effectiveEndDate=row.effectiveEndDate;
          this.versionLog=row.versionLog;
          this.$emit("viewVersion", row);         
          this.doCloseDialog();      
      },

      removeVersion(row, index){
          this.$confirm(this.$t("message.removeVersion"), this.$t("message.warning"), {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
              closeOnClickModal: false,
          })
          .then(() => {
              this.$emit("removeVersion", row);
              this.doCloseDialog();
          })
          .catch(() => {});
          
      },

      copyVersion(row, index){
          this.$confirm(this.$t("message.copyVersion"), this.$t("message.warning"), {
              confirmButtonText: "OK",
              cancelButtonText: "Cancel",
              type: "Error",
              closeOnClickModal: false,
          })
          .then(() => {
              this.$emit("copyVersion", row);
              this.doCloseDialog();
          })
          .catch(() => {});
          
      },
  },
};
</script>
<style >
@import "../../assets/css/autocomplete.css";

</style>
<style lang="scss" scoped>
@import "@/assets/css/variable.scss";
@import "../element/form/form";
@import "../element/form/responsive-form";
@import "../element/form/datepicker";
@import "../element/form/formChange";
.version-wrap {
  min-width: 170px;

  .version-block{
    right: 0px;
    text-align: right;
    position: absolute;
  }
  .iconfont{
    font-size: 15px;
    color: rgba($color: #6F6E68, $alpha: 0.7);
    &:hover{
      color: rgba($color: #6F6E68, $alpha: 1);
    }
  }
  .versionicon {
  width: 25px;
  height: 25px;
  border-radius: 50%;
  padding-bottom: 5px;
}
  .versionfont{
    font-family: "AIABody", Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-size:14px;
  }

    .input-class {
    width: 100%;
  }
}
</style>