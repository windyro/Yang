<template>
    <gl-select   
            type="other" 
            :edit="true" 
            v-model="valueData" 
            :valueData="valueData"
            :optionList="myOptionList"
            :prop="prop"  
            :rules="rules"
            :filter-method="filterMethod"
            :placeholder="placeholder"
            @keyup.native="keyupMethod"
            @change="handleCurrentChange"
             v-bind="$attrs" 
             v-on="$listeners" 
             
             >
    </gl-select> 
</template>

<script>
export default {
//@keydown.enter.native="handleEnter"
    props: {
        apiName:{type: String,},
        apiInput:{type: String,},
        apiParm:{type: Object,},
        apiResult:{type: Object,},
        prop:{type: String,},
        rules:{type: Array,},
        valueData:{type: String,},
        getSelectedObj: {
            type: Function,
            default: null,
        },
        itemName: {type: String,},
    },
    data() {
        return {
            myOptionList: [],
            counter: 0,
            placeholder: "Type in to search",
            inputKey: "",
        }

    },

    created() {
        //this.prepare();
    },
    methods: {
        filterMethod(inputKey){
            this.inputKey = inputKey;
        },

        async keyupMethod(key){
            // if(key.keyCode == 8){
            //     return;
            // }
            await this.$pending(1500);
            if( this.counter >0 || this.$isEmpty(this.inputKey)){
                return;
            }
            this.counter++;
            let param = {};
            param=this.$props.apiParm;
            param[this.$props.apiInput] = this.inputKey;

            this.myOptionList = [];

            let response=await this.$caller[this.$props.apiName](param);
            if(response.responseCode=="000"){
                let resultList=response[this.$props.apiResult.resultList];
                resultList.forEach(result=>{
                    let code = result[this.$props.apiResult.code];
                    let name = result[this.$props.apiResult.name];
                    let obj = result;
                    this.myOptionList.push({code:code, name:name, obj:obj});
                });
              //alert(JSON.stringify(this.myOptionList));
                // if(this.inputKey.startsWith('A')){
                //     this.myOptionList = [
                //         {code:"A0001",name:'A0001'},
                //         {code:"A0002",name:'A0002'},
                //         {code:"A0003",name:'A0003'},
                //     ];
                // }        
            }

            await this.$pending(1500);
            this.counter--;
        },

        prepare(){
            alert("inff");
        },

        getOptionName(code){
            if(!this.myOptionList){
                return;
            }   
          
            if(code==""){
                return"";
            }
 
            let obj = {};  
            obj = this.myOptionList.find((item)=>{
                return item.code === code;      }); 
            if(obj){
                return obj.name;
            }
        },

         handleCurrentChange(){
 
            if (this.getSelectedObj) {
                let option = {};  
                option = this.myOptionList.find((item)=>{
                    return item.code === this.$props.valueData;}); 
                this.getSelectedObj(this.$props.itemName, option.obj);
            }
            
        },
    },
}

</script>