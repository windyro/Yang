package com.aia.glory.userservice.service;

import java.util.List;

import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.Role;
import com.aia.glory.userservice.model.request.RoleSummary;

public interface RoleService {

	default Response addRole(Role role) {
		return null;
	}
	
	default Response updateRole(Role role) {
		return null;
	}
	
	default Response deleteRole(Role role) {
		return null;
	}
	
	default Response inquireRole(RoleSummary role) {
		return null;
	}
	
	default boolean roleIsExist(String roleName) {
		return true;
	}
	
	default Response  getRoleList() {
		return null;
	}
	
	default List<Role>  getUserRoleList(String loginId) {
		return null;
	}
}
