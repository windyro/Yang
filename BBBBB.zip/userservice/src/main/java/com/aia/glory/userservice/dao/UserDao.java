package com.aia.glory.userservice.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.aia.glory.userservice.model.SecurityUser;
import com.aia.glory.userservice.model.User;
import com.aia.glory.userservice.model.request.UserSummary;

public interface UserDao {

	@Insert("INSERT INTO USERS(USERNAME,[PASSWORD],[ENABLED],[EMAIL],[REMARK],[LOGINID]) "
			+ "VALUES(#{username}, #{password}, #{enabled}, #{email}, #{remark}, #{loginId})")
	public void insertUser(User user);
	
	@Update("Update USERS set USERNAME=#{username},[ENABLED]=#{enabled},[EMAIL]=#{email},[REMARK]=#{remark} "
			+ "where LOGINID=#{loginId}")
	public void updateUser(User user);
	
	@Update("Update USERS set PASSWORD=#{password} "
			+ "where LOGINID=#{loginId}")
	public void updateUserPassword(User user);
	
	@Delete("DELETE FROM USERS WHERE LOGINID=#{loginId}")
	public void deleteUser(User user);
	
	@Select("<script>SELECT TOP ${pageSize} * from ( " + 
			"	 " + 
			"	  select ROW_NUMBER() OVER( ORDER BY u.loginId) AS RowNumber,u.* " +
			"      from [dbo].[USERS] u  " + 
			"	  where 1=1  " + 
			"		<if test=\"loginId!=null and loginId!=''\"> " + 
			"			AND u.LOGINID = #{loginId} " + 
			"		</if> " + 
			"		<if test=\"username!=null and username!=''\"> " + 
			"			AND u.USERNAME = #{username} " + 
			"		</if> " + 
			"		<if test=\"remark!=null and remark!=''\"> " + 
			"			AND u.REMARK = #{remark} " + 
			"		</if> " + 
			"		<if test=\"enabled!=null and enabled!=''\"> " + 
			"			AND u.ENABLED = #{enabled} " + 
			"		</if> " + 
			"		<if test=\"email!=null and email!=''\"> " + 
			"			AND u.EMAIL = #{email} " + 
			"		</if> " + 
			"	)AS DE " + 
			"	WHERE DE.RowNumber > (${pageSize}*(${startPage}-1))</script>")
	public List<UserSummary> userSummary(UserSummary userSummary);
	
	@Insert("INSERT INTO USER_ROLES(LOGINID,[ROLENAME]) "
			+ "VALUES(#{loginId}, #{roleName})")
	@Options(useGeneratedKeys=true,keyProperty="userRoleId")
	public void relatedUserAndRole(@Param("loginId")String  loginId,@Param("roleName")String roleName); 
	
	@Delete("DELETE FROM USER_ROLES WHERE LOGINID=#{loginId}")
	public void deleteRelForUserAndRole(User user);
	
	@Select("<script>"
   			+" SELECT u.loginId,u.enabled,u.email,u.remark,u.username from USERS u "
   			+ "left join USER_ROLES ur on u.loginId = ur.loginId "
   			+ "where 1=1 "
			+"<if test= \"roleName!=null and roleName!=''\">"
			+" AND ur.ROLENAME=#{roleName}"
			+"</if>"
   			+"</script>")
	public List<SecurityUser> getUserRoleList(@Param("roleName")String roleName);
	
	@Select("<script>"
   			+" SELECT * from USERS "
   		
   			+ "where "
			+"<if test= \"loginId!=null and loginId!=''\">"
			+" loginId=#{loginId} "
			+"</if>"
   			+"</script>")
	public User checkUser(User user);
	
	@Select("<script>  select count(1) " +
			"      from [dbo].[USERS] u  " + 
			"	  where 1=1  " + 
			"		<if test=\"loginId!=null and loginId!=''\"> " + 
			"			AND u.LOGINID = #{loginId} " + 
			"		</if> " + 
			"		<if test=\"username!=null and username!=''\"> " + 
			"			AND u.USERNAME = #{username} " + 
			"		</if> " + 
			"		<if test=\"remark!=null and remark!=''\"> " + 
			"			AND u.REMARK = #{remark} " + 
			"		</if> " + 
			"		<if test=\"enabled!=null and enabled!=''\"> " + 
			"			AND u.ENABLED = #{enabled} " + 
			"		</if> " + 
			"		<if test=\"email!=null and email!=''\"> " + 
			"			AND u.EMAIL = #{email} " + 
			"		</if></script>")
	public int userTotal(UserSummary user);
	
	@Select("<script>"
   			+" SELECT * from USERS "
   			+"</script>")
	public List<SecurityUser> allUsers();
}


