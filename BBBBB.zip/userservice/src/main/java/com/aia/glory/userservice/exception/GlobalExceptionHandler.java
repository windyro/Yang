package com.aia.glory.userservice.exception;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.userservice.model.response.ExceptionResponse;

@ControllerAdvice 
public class GlobalExceptionHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<ExceptionResponse> violationHandler(MethodArgumentNotValidException ex) throws Exception {
    	List<String> defaultMsg = ex.getBindingResult().getAllErrors()
                .stream()
                .map(ObjectError::getDefaultMessage)
                .collect(Collectors.toList());
    	
    	ExceptionResponse res = new ExceptionResponse();
    	res.setResponseCode(ResponseCode.ERROR.getCode());
    	res.setReasonCode(Arrays.asList(ReasonCode.GENERIC_ERROR.getCode()));
    	res.setReasonDesc(Arrays.asList(defaultMsg.toString()));
        logger.error("catch MethodArgumentNotValidException:",ex);
        return new ResponseEntity<ExceptionResponse>(res, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity<ExceptionResponse> violation2Handler(ConstraintViolationException ex) throws Exception {
    	List<String> defaultMsg = ex.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.toList());
    	
    	ExceptionResponse res = new ExceptionResponse();
    	res.setResponseCode(ResponseCode.ERROR.getCode());
    	res.setReasonCode(Arrays.asList(ReasonCode.GENERIC_ERROR.getCode()));
    	res.setReasonDesc(Arrays.asList(defaultMsg.toString()));
        logger.error("catch ConstraintViolationException:",ex);
        return new ResponseEntity<ExceptionResponse>(res, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<ExceptionResponse> defaultHandler(Exception ex) throws Exception {
                
    	ExceptionResponse res = new ExceptionResponse();
    	res.setResponseCode(ResponseCode.ERROR.getCode());
    	res.setReasonCode(Arrays.asList(ReasonCode.GENERIC_ERROR.getCode()));
    	res.setReasonDesc(Arrays.asList(ex.getMessage()));
        logger.error("catch exception:",ex);
        return new ResponseEntity<ExceptionResponse>(res, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
