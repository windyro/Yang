package com.aia.glory.userservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(ignoreUnknownFields = false,prefix = "data-source")
public class DataSourceConfig {
	
	    private String jndiName;
	    private String factory;
	    private String driverClassName;
	    private String url;
	    private String username;
	    private String password;
	    private String maxActive;
	    private String maxIdle;
	    private String maxWait;
	    
}
