package com.aia.glory.userservice.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.hibernate.validator.constraints.NotEmpty;

import com.aia.glory.common.model.request.PageRequest;

import lombok.Data;

@Data
public class User extends PageRequest {

	@NotEmpty(message="loginid cannot input null or spaces")
	private String loginId;
	
	private String username;
	
	private String password;

	private String remark;
	
	private String enabled = "1";
	
	private String email;
	
	private List<Role> rolelist;
	
	public List<Role> getRolelist(){
		Optional<List<Role>> rl = Optional.ofNullable(this.rolelist);
		if(rl.isPresent()) {
			return this.rolelist.stream()
					.collect(Collectors
							.collectingAndThen(Collectors
									.toCollection(
											()->new TreeSet<>(Comparator.comparing(Role::getRoleName))
									), ArrayList::new));
		}else {
			return this.rolelist;
		}
		
	}
}
