package com.aia.glory.userservice.controller;

import java.io.IOException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.GloryValidatorUtil;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.userservice.model.Role;
import com.aia.glory.userservice.model.request.RoleSummary;
import com.aia.glory.userservice.model.response.ExceptionResponse;
import com.aia.glory.userservice.service.RoleService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@CrossOrigin
@RestController
public class RoleController {
	@Autowired
    private RoleService roleService;

	@PostMapping("/role")
	public Response managerRole(@RequestBody String requestBody) throws JsonParseException, JsonMappingException, IOException {
		HashMap<?, ?> requestMap = JsonToObjectUtil.jsonToObj(new HashMap<Object, Object>(), requestBody);
		String action = (String) requestMap.get("action");
		Response response = null;
		Role role = null;
		String errorMsg = "";
		switch (action) {
		case "POST":
			role = JsonToObjectUtil.jsonToObj(new Role(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(role);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = roleService.addRole(role);
			break;
		case "UPDATE":
			role = JsonToObjectUtil.jsonToObj(new Role(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(role);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = roleService.updateRole(role);
			break;
		case "DELETE":
			role = JsonToObjectUtil.jsonToObj(new Role(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(role);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = roleService.deleteRole(role);
			break;
		case "GET":
			RoleSummary roleSummary = JsonToObjectUtil.jsonToObj(new RoleSummary(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(roleSummary);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = roleService.inquireRole(roleSummary);
			break;
		default:
			break;
		}
		return response;

	}
	
	@PostMapping("/roles")
	public Response getAllRole() throws JsonParseException, JsonMappingException, IOException {
		
		Response response = null;
		response = roleService.getRoleList();
		return response;

	}

}
