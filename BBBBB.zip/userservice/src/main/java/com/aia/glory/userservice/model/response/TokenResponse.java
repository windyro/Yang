package com.aia.glory.userservice.model.response;

import java.util.Arrays;

import lombok.Data;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.Token;

@Data
public class TokenResponse extends Response{

	private Token token;
	
	public static TokenResponse success(ResponseCode responseCode,Token token) {   
		
		TokenResponse tokenResponse = new TokenResponse();        
		tokenResponse.setResponseCode(responseCode.getCode());
		tokenResponse.setReasonCode(Arrays.asList("0000"));
		tokenResponse.setReasonDesc(Arrays.asList(""));
		tokenResponse.setToken(token);
		return tokenResponse;    
		 
	 }
	
	public static TokenResponse fail(ResponseCode responseCode,String errorMsg) 
	 {        
		TokenResponse tokenResponse = new TokenResponse();        
		tokenResponse.setResponseCode(responseCode.getCode());
		tokenResponse.setReasonCode(Arrays.asList("0000"));
		tokenResponse.setReasonDesc(Arrays.asList(errorMsg));
		 return tokenResponse;    
		 
	 }
}
