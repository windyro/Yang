package com.aia.glory.userservice.model;

import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

import com.aia.glory.common.model.request.Request;

import lombok.Data;

@Data
public class Role extends Request{

	private int roleId;
	
	@NotBlank
	private String roleName;
	
	private String authority;
	
	private String remark;
	
	private List<SecurityUser> userlist;
}
