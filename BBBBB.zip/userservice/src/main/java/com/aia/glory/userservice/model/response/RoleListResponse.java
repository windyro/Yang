package com.aia.glory.userservice.model.response;

import java.util.Arrays;
import java.util.List;

import lombok.Data;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.Role;

@Data
public class RoleListResponse extends Response{

	private List<Role> rolelist;
	
	public static RoleListResponse success(ResponseCode responseCode,List<Role> rolelist) {   
		
		RoleListResponse userSummaryResponse = new RoleListResponse();  
		userSummaryResponse.setResponseCode(responseCode.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList("0000"));
		userSummaryResponse.setReasonDesc(Arrays.asList(""));
		userSummaryResponse.setRolelist(rolelist);
		return userSummaryResponse;    
		 
	 }
}
