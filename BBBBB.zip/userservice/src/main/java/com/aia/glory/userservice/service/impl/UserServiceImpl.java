package com.aia.glory.userservice.service.impl;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JwtUtil;
import com.aia.glory.userservice.dao.UserDao;
import com.aia.glory.userservice.model.Role;
import com.aia.glory.userservice.model.SecurityUser;
import com.aia.glory.userservice.model.Token;
import com.aia.glory.userservice.model.User;
import com.aia.glory.userservice.model.request.UserSummary;
import com.aia.glory.userservice.model.response.TokenResponse;
import com.aia.glory.userservice.model.response.UserSummaryResponse;
import com.aia.glory.userservice.model.response.VoidResponse;
import com.aia.glory.userservice.service.RoleService;
import com.aia.glory.userservice.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private RoleService roleService;
	
	@Override
	public User findByUsername(User user) {
		//TokenResponse tokenResponse  = 
		
		return null;
	}
	
	@Override
	public Response generateResponseToken(User user) {
		
		
		User loginUser = null;
		
		if(user == null || user.getLoginId()==null || user.getPassword() == null || "".equals(user.getPassword())) {
			return TokenResponse.fail(ResponseCode.ERROR, "please input value! ");
		}else {
			loginUser = userDao.checkUser(user);
		}
		
		if(loginUser == null || loginUser.getLoginId() == null) {
			return TokenResponse.fail(ResponseCode.ERROR, "please check loginid! ");
		}
		
		if(!user.getPassword().equalsIgnoreCase(loginUser.getPassword())) {
			return TokenResponse.fail(ResponseCode.ERROR, "please check password! ");
		}
		
		SecurityUser sUser= new SecurityUser();
		BeanUtils.copyProperties(loginUser, sUser);
		sUser.setRolelist(roleService.getUserRoleList(sUser.getLoginId()));
		
		Token token = new Token();
		token.setAud(sUser.getLoginId());
		token.setUser(sUser);
		token.setIss("auth0");
		token.setSub("login");
		token.setExp((Timestamp.valueOf(LocalDateTime.now()).getTime()+1000*60*30)+"");
		token.setIat(Timestamp.valueOf(LocalDateTime.now()).getTime()+"");
		token.setJwtToken(generateToken(sUser));
		
		return Optional.ofNullable(sUser).map(u->TokenResponse.success(ResponseCode.NORMAL, token))
					.orElseGet(()->TokenResponse.fail(ResponseCode.ERROR, "login fail"));
	}
	private String generateToken(SecurityUser user) {
		
		String token = JwtUtil.createJWT(1000*60*60*24L, user.getLoginId(),user.getUsername(),user.getRolelist().toString());
	    return token;
	}
	
	@Override
	@Transactional
	public Response addUser(User user) {
		if(user.getPassword() == null || user.getPassword().equals("")) {
			return GeneryResponse.fail( "please input password! ");
		}
		if(userDao.checkUser(user) !=null) {
			return GeneryResponse.fail( "user is existed! ");
		}
		userDao.insertUser(user);
		
		Optional.ofNullable(user.getRolelist()).ifPresent(list->
			list.stream()
				.filter(role->roleService.roleIsExist(role.getRoleName()))
				.forEach(role->{
					userDao.relatedUserAndRole(user.getLoginId(),role.getRoleName());
				})

		);
		SecurityUser sUser = new SecurityUser();
		BeanUtils.copyProperties(user, sUser);
		return GeneryResponse.success(ResponseCode.NORMAL,sUser);
	}
	
	@Override
	@Transactional
	public Response updateUser(User user) {
		
		userDao.updateUser(user);
		userDao.deleteRelForUserAndRole(user);
		Optional.ofNullable(user.getRolelist()).ifPresent(list->
		list.stream()
			.filter(role->roleService.roleIsExist(role.getRoleName()))
			.forEach(role->{
				userDao.relatedUserAndRole(user.getLoginId(),role.getRoleName());
			})

		);
		updateUserPassword(user);
		SecurityUser sUser = new SecurityUser();
		BeanUtils.copyProperties(user, sUser);
	
		return GeneryResponse.success(ResponseCode.NORMAL,sUser);
	}
	
	private void updateUserPassword(User user) {
		if(user!=null && user.getPassword()!=null && !"".equals(user.getPassword())) {
			userDao.updateUserPassword(user);
		}
	}
	
	@Override
	@Transactional
	public Response deleteUser(User user) {
		
		userDao.deleteRelForUserAndRole(user);
		userDao.deleteUser(user);
		
		return VoidResponse.success(ResponseCode.NORMAL);
	}
	
	@Override
	public Response inquireUser(UserSummary userSummary) {
		
		List<UserSummary> list= userDao.userSummary(userSummary);
		list.stream().forEach(user->{
			user.setRolelist(roleService.getUserRoleList(user.getLoginId()));
		});
		int total = userDao.userTotal(userSummary);
		return UserSummaryResponse.success(ResponseCode.NORMAL, list,total);
	}
	@Override
	public List<SecurityUser> getRoleUserList(String roleName) {
		List<SecurityUser> list = userDao.getUserRoleList(roleName);
		return list;
	}
	
	@Override
	public Response getAllUsers() {
		return GeneryResponse.success(ResponseCode.NORMAL, userDao.allUsers());
	}
	
	@Override
	public boolean userHasRole(String loginId,String rolename) {
		if(loginId ==null || rolename == null) {
			return false;
		}
		List<Role> roleList = roleService.getUserRoleList(loginId);
		if(roleList != null && !roleList.isEmpty()) {
			for(Role role:roleList) {
				if(rolename.equalsIgnoreCase(role.getRoleName())) {
					return true;
				}
			}
		}else {
			return false;
		}
		return false;
	}
	
	@Override
	public void relatedUserAndRole(String loginId,String rolename) {
		
		userDao.relatedUserAndRole(loginId,rolename);
		
	}
}
