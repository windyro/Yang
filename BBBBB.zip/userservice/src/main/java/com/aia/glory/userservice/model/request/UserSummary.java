package com.aia.glory.userservice.model.request;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.userservice.model.Role;

import lombok.Data;

@Data
public class UserSummary extends Request{

	private String loginId;
	
	private String username;

	private String remark;
	
	private String enabled;
	
	private String email;
	
	private int pageSize = 0;
	
	private int startPage = 0;
	
	private List<Role> rolelist;
	
	public void setPageSize(int pageSize) {
		if(pageSize < 1) {
			pageSize = 5;
		}
		this.pageSize = pageSize;
	}
	
	public void setStartPage(int startPage) {
		if(startPage < 1) {
			startPage = 1;
		}
		this.startPage = startPage;
	}
	
	public void setRolelist(List<Role> rolelist){
		this.rolelist =  rolelist.stream()
							.collect(Collectors
									.collectingAndThen(Collectors
											.toCollection(
													()->new TreeSet<>(Comparator.comparing(Role::getRoleName))
											), ArrayList::new));
	}
}