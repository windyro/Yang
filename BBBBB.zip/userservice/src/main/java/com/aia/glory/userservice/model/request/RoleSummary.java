package com.aia.glory.userservice.model.request;

import java.util.List;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.userservice.model.SecurityUser;

import lombok.Data;

@Data
public class RoleSummary extends Request{

	private int roleId;
	
	private String roleName;
	
	private String authority;
	
	private String remark;
	
	private List<SecurityUser> userlist;
	
	private int pageSize = 0;
	
	private int startPage = 0;
	
	public void setPageSize(int pageSize) {
		if(pageSize < 1) {
			pageSize = 5;
		}
		this.pageSize = pageSize;
	}
	
	public void setStartPage(int startPage) {
		if(startPage < 1) {
			startPage = 1;
		}
		this.startPage = startPage;
	}
}