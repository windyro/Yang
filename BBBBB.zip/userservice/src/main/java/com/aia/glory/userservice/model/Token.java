package com.aia.glory.userservice.model;

import lombok.Data;

@Data
public class Token {

	private String sub;
	
	private SecurityUser user;
	
	private String exp;
	
	private String aud;
	
	private String iss;
	
	private String iat;
	
	private String jwtToken;
}
