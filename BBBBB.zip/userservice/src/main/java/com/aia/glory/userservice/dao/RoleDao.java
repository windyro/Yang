package com.aia.glory.userservice.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.aia.glory.userservice.model.Role;
import com.aia.glory.userservice.model.request.RoleSummary;

public interface RoleDao {
	
	@Insert("INSERT INTO ROLES(ROLENAME,[AUTHORITY],[REMARK]) "
			+ "VALUES(#{roleName}, #{authority}, #{remark})")
	@Options(useGeneratedKeys=true,keyProperty="roleId")
	public void insertrole(Role role);
	
	@Update("Update ROLES set ROLENAME=#{roleName},[AUTHORITY]=#{authority},[REMARK]=#{remark} "
			+ "where [ROLEID] = #{roleId}")
	public void updaterole(Role role);
	
	@Delete("DELETE FROM ROLES WHERE [ROLEID] = #{roleId}")
	public void deleterole(Role role);
	
	@Select("<script>"
   			+" SELECT * from ROLES "
   			+"</script>")
	public List<Role> roleList();
	
	@Select("<script>"
   			+" SELECT r.* from ROLES r "
   			+ "left join USER_ROLES ur on r.ROLENAME = ur.ROLENAME "
   			+ "where 1=1 "
			+"<if test= \"loginId!=null and loginId!=''\">"
			+" AND ur.LOGINID=#{loginId}"
			+"</if>"
   			+"</script>")
	public List<Role> getUserRoleList(@Param("loginId")String loginId);
	
	@Select("<script>SELECT TOP ${pageSize} * from ( " + 
			"	 " + 
			"	  select ROW_NUMBER() OVER( ORDER BY r.rolename) AS RowNumber,r.* " +
			"      from [dbo].[ROLES] r  " + 
			"	  where 1=1  " + 
			"		<if test=\"authority!=null and authority!=''\"> " + 
			"			AND r.AUTHORITY = #{authority} " + 
			"		</if> " + 
			"		<if test=\"roleName!=null and roleName!=''\"> " + 
			"			AND r.ROLENAME = #{roleName} " + 
			"		</if> " + 
			"		<if test=\"remark!=null and remark!=''\"> " + 
			"			AND r.REMARK = #{remark} " + 
			"		</if> " +  
			"	)AS DE " + 
			"	WHERE DE.RowNumber > (${pageSize}*(${startPage}-1))</script>")
	public List<RoleSummary> roleSummary(RoleSummary role);
	
	@Select("<script> select count(1) " +
			"      from [dbo].[ROLES] r  " + 
			"	  where 1=1  " + 
			"		<if test=\"authority!=null and authority!=''\"> " + 
			"			AND r.AUTHORITY = #{authority} " + 
			"		</if> " + 
			"		<if test=\"roleName!=null and roleName!=''\"> " + 
			"			AND r.ROLENAME = #{roleName} " + 
			"		</if> " + 
			"		<if test=\"remark!=null and remark!=''\"> " + 
			"			AND r.REMARK = #{remark} " + 
			"		</if> " +  
			"	</script>")
	public int getRoleSummaryTotal(RoleSummary role);
	
	@Select("<script>"
   			+" SELECT * from ROLES where 1=1"
			+"<if test= \"roleName!=null and roleName!=''\">"
			+" AND ROLENAME=#{roleName}"
			+"</if>"
   			+"</script>")
	public List<Role> getRoleDetail(@Param("roleName")String roleName);
	
	
	@Delete("DELETE FROM USER_ROLES WHERE [ROLENAME] = #{roleName}")
	public void deleteRoleRelUser(Role role);
}
