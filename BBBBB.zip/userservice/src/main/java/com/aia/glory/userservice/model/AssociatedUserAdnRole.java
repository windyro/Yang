package com.aia.glory.userservice.model;

import lombok.Data;

@Data
public class AssociatedUserAdnRole {

	private String loginId;
	
	private String userRoleId;
	
	private String roleName;
}
