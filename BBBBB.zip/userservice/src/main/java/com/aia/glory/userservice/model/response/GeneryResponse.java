package com.aia.glory.userservice.model.response;

import java.util.Arrays;
import java.util.List;

import lombok.Data;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.request.UserSummary;

@Data
public class GeneryResponse extends Response{

	private Object data;
	
	private int total;
	
	public static GeneryResponse success(ResponseCode responseCode,Object obj) {   
		
		GeneryResponse userSummaryResponse = new GeneryResponse();  
		userSummaryResponse.setResponseCode(responseCode.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList("0000"));
		userSummaryResponse.setReasonDesc(Arrays.asList(""));
		userSummaryResponse.setData(obj);
		return userSummaryResponse;    
		 
	 }

	public static GeneryResponse success(ResponseCode responseCode,List<UserSummary> userlist,int total) {   
		
		GeneryResponse userSummaryResponse = new GeneryResponse();  
		userSummaryResponse.setResponseCode(responseCode.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList("0000"));
		userSummaryResponse.setReasonDesc(Arrays.asList(""));
		userSummaryResponse.setData(userlist);
		userSummaryResponse.setTotal(total);
		return userSummaryResponse;    
		 
	 }
}
