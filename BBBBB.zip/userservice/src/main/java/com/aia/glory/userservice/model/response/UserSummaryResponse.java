package com.aia.glory.userservice.model.response;

import java.util.Arrays;
import java.util.List;

import lombok.Data;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.request.UserSummary;

@Data
public class UserSummaryResponse extends Response{

	private List<UserSummary> userlist;
	
	private int total;
	
	public static UserSummaryResponse success(ResponseCode responseCode,List<UserSummary> userlist,int total) {   
		
		UserSummaryResponse userSummaryResponse = new UserSummaryResponse();  
		userSummaryResponse.setResponseCode(responseCode.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList("0000"));
		userSummaryResponse.setReasonDesc(Arrays.asList(""));
		userSummaryResponse.setUserlist(userlist);
		userSummaryResponse.setTotal(total);
		return userSummaryResponse;    
		 
	 }
}
