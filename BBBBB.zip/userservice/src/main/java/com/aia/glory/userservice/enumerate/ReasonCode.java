package com.aia.glory.userservice.enumerate;

public enum ReasonCode {
	
	ROLE_EXIST_ERROR("30004","The user-id is existing!");
	
	private String code;
	
	private String desc;
	
	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	private ReasonCode(String code, String desc){
		this.code=code;
		this.desc=desc;
	}
	
}
