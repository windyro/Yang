package com.aia.glory.userservice.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class VoidResponse extends Response{
	
	public static VoidResponse success(ResponseCode responseCode) {   
		
		VoidResponse voidResponse = new VoidResponse();        
		voidResponse.setResponseCode(responseCode.getCode());
		voidResponse.setReasonCode(Arrays.asList("0000"));
		voidResponse.setReasonDesc(Arrays.asList(""));
		return voidResponse;    
		 
	 }

}
