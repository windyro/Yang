package com.aia.glory.userservice.service;

import java.util.List;

import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.SecurityUser;
import com.aia.glory.userservice.model.User;
import com.aia.glory.userservice.model.request.UserSummary;

public interface UserService {

	default Response addUser(User user) {
		return null;
	}
	
	default Response updateUser(User user) {
		return null;
	}
	
	default Response deleteUser(User user) {
		return null;
	}
	
	default Response inquireUser(UserSummary userSummary) {
		return null;
	}
	
	default User findByUsername(User user) {
		return null;
	}
	
	default Response generateResponseToken(User user) {
		return null;
	}
	
	default List<SecurityUser> getRoleUserList(String roleName) {
		return null;
	}
	
	default Response getAllUsers() {
		return null;
	}
	
	default boolean userHasRole(String loginId,String rolename) {
		return false;
	}
	
	default void relatedUserAndRole(String loginId,String rolename) {
		
	}
	
}
