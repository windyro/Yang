package com.aia.glory.userservice.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.ExceptionResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.GloryValidatorUtil;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.userservice.model.User;
import com.aia.glory.userservice.model.request.UserSummary;
import com.aia.glory.userservice.service.UserService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@CrossOrigin
@RestController
public class UserController {
	@Autowired
	private UserService userService;

	@PostMapping("/token")
	public Response login(@RequestBody @Valid User user) {
		
		return userService.generateResponseToken(user);
	}
	
	@PostMapping("/users")
	public Response getAllUsers() {
		
		return userService.getAllUsers();
	}

	/*@PostMapping("/users/{loginId}")
	public Response doUsersAction(@PathVariable("loginId") String loginId) {
		
		return userService.getuser();
	}*/
	
	@PostMapping("/user")
	public Response addUser(@RequestBody String requestBody) throws JsonParseException, JsonMappingException, IOException {
		HashMap requestMap = JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		// String action = user.getAction();
		Response response = null;
		User user = null;
		String errorMsg ="";
		switch (action) {
		case "POST":
			user = JsonToObjectUtil.jsonToObj(new User(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(user);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			
			response = userService.addUser(user);
			break;
		case "UPDATE":
			user = JsonToObjectUtil.jsonToObj(new User(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(user);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = userService.updateUser(user);
			break;
		case "DELETE":
			user = JsonToObjectUtil.jsonToObj(new User(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(user);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = userService.deleteUser(user);
			break;
		case "GET":
			UserSummary userSummary = JsonToObjectUtil.jsonToObj(new UserSummary(),requestBody);
			errorMsg = GloryValidatorUtil.dovBeenValidate(userSummary);
			if(!errorMsg.isEmpty()) {
				return ExceptionResponse.fail(ResponseCode.WARNING, errorMsg);
			}
			response = userService.inquireUser(userSummary);
			break;
		default:
			break;
		}
		return response;

	}
}
