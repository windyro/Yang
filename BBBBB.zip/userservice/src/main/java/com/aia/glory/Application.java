package com.aia.glory;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.aia.glory.common.filter.LoginValidateFilter;

@SpringBootApplication
@EnableTransactionManagement
@MapperScan("com.aia.glory.userservice.dao")
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
   
	@Bean
	public FilterRegistrationBean LoginFilter() {
		FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
		filterRegistrationBean.setFilter(new LoginValidateFilter());
		filterRegistrationBean.setName("LoginValidateFilter");
		filterRegistrationBean.addUrlPatterns("/*");
		filterRegistrationBean.setOrder(0);
		return filterRegistrationBean;
	}
}
