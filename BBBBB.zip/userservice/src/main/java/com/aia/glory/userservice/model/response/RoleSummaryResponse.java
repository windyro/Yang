package com.aia.glory.userservice.model.response;

import java.util.Arrays;
import java.util.List;

import lombok.Data;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.model.request.RoleSummary;

@Data
public class RoleSummaryResponse extends Response{

	private List<RoleSummary> rolelist;
	private int total;
	public static RoleSummaryResponse success(ResponseCode responseCode,List<RoleSummary> rolelist,int total) {   
		
		RoleSummaryResponse userSummaryResponse = new RoleSummaryResponse();  
		userSummaryResponse.setResponseCode(responseCode.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList("0000"));
		userSummaryResponse.setReasonDesc(Arrays.asList(""));
		userSummaryResponse.setRolelist(rolelist);
		userSummaryResponse.setTotal(total);
		return userSummaryResponse;    
		 
	 }
}
