package com.aia.glory.userservice.model;

import java.util.List;

import lombok.Data;

@Data
public class SecurityUser {

	private String loginId;
	
	private String username;

	private String remark;
	
	private String enabled;
	
	private String email;
	
	private List<Role> rolelist;
}
