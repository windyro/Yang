package com.aia.glory.userservice.service.impl;

import java.util.List;
import java.util.Optional;

import org.aspectj.apache.bcel.generic.ReturnaddressType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.dao.RoleDao;
import com.aia.glory.userservice.model.Role;
import com.aia.glory.userservice.model.request.RoleSummary;
import com.aia.glory.userservice.model.response.ExceptionResponse;
import com.aia.glory.userservice.model.response.RoleListResponse;
import com.aia.glory.userservice.model.response.RoleSummaryResponse;
import com.aia.glory.userservice.model.response.VoidResponse;
import com.aia.glory.userservice.service.RoleService;
import com.aia.glory.userservice.service.UserService;

@Service
public class RoleServiceImpl implements RoleService{

	@Autowired
	private RoleDao roleDao;
	
	@Autowired
	private UserService userService;
	
	@Override
	@Transactional
	public Response addRole(Role role) {
		
		if(this.roleIsExist(role.getRoleName())) {
			return ExceptionResponse.fail(ResponseCode.ERROR, "role has exist");
		}
		roleDao.insertrole(role);
		
		Optional.ofNullable(role.getUserlist()).ifPresent(list->
		list.stream().forEach(user->{
				userService.relatedUserAndRole(user.getLoginId(),role.getRoleName());
			}

		));
		
		return VoidResponse.success(ResponseCode.NORMAL);
	}
	
	@Override
	@Transactional
	public Response updateRole(Role role) {
		
		roleDao.updaterole(role);
		roleDao.deleteRoleRelUser(role);
		Optional.ofNullable(role.getUserlist()).ifPresent(list->
		list.stream()
			.filter(user->!userService.userHasRole(user.getLoginId(),role.getRoleName()))
			.forEach(user->{
				userService.relatedUserAndRole(user.getLoginId(),role.getRoleName());
			}

		));
		
		return VoidResponse.success(ResponseCode.NORMAL);
	}
	
	@Override
	@Transactional
	public Response deleteRole(Role role) {
		
		roleDao.deleterole(role);
		roleDao.deleteRoleRelUser(role);
		
		return VoidResponse.success(ResponseCode.NORMAL);
	}
	
	@Override
	public Response inquireRole(RoleSummary role) {
		
		List<RoleSummary> list = roleDao.roleSummary(role);
		Optional.ofNullable(list.stream()).ifPresent(l->l.forEach(r->{
			r.setUserlist(userService.getRoleUserList(r.getRoleName()));
		}));
		int total = roleDao.getRoleSummaryTotal(role);
		return RoleSummaryResponse.success(ResponseCode.NORMAL, list,total);
	}
	
	@Override
	public boolean roleIsExist(String roleName) {
		
		List<Role> rolelist = roleDao.getRoleDetail(roleName);
		if(rolelist == null || rolelist.isEmpty()) {
			return false;
		}
		return true;
	}
	
	@Override
	public Response  getRoleList() {
		
		List<Role> list = roleDao.roleList();
		return RoleListResponse.success(ResponseCode.NORMAL,list);
	}
	
	
	@Override
	public List<Role>  getUserRoleList(String loginId) {
		
		List<Role> list = roleDao.getUserRoleList(loginId);
		
		return list;
	}
}
