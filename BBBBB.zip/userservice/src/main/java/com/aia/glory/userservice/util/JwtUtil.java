/*package com.aia.glory.userservice.util;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.aia.glory.userservice.model.SecurityUser;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;

public class JwtUtil {
	
	private JwtUtil() {
	    throw new IllegalStateException("Utility class");
	}

	public static String createJWT(long ttlMillis, SecurityUser user) {
    	
    	try {
    		
    	    Algorithm algorithm = Algorithm.HMAC256("123456");
    	    Map<String, Object> headerClaims = new HashMap();
    	    headerClaims.put("alg", "RS256");
    	    headerClaims.put("typ", "JWT");
    	    
    	    String token = JWT.create().withIssuer("userservice")
    	    		.withExpiresAt(new Date(Timestamp.valueOf(LocalDateTime.now()).getTime()+ttlMillis))
    	    		.withSubject("login")
    	    		.withAudience(user.getUsername())
    	    		.withIssuedAt(new Date())
    	    		
    	    		//.withClaim("admin", "true")
    	    		.withClaim("roleList", user.getRolelist()==null?"":user.getRolelist().toString())
    	    		.withHeader(headerClaims)
    	        .withIssuer("auth0")
    	        .sign(algorithm);
    	    
    	    return token;
    	} catch (JWTCreationException exception){
    	    //Invalid Signing configuration / Couldn't convert Claims.
    	}
    	
		return null;
    	
    }

	public static String refreshJWT(long ttlMillis, SecurityUser user) {
    	
    	try {
    		
    	    Algorithm algorithm = Algorithm.HMAC256("123456");
    	    Map<String, Object> headerClaims = new HashMap();
    	    headerClaims.put("alg", "RS256");
    	    headerClaims.put("typ", "JWT");
    	    
    	    String token = JWT.create().withIssuer("userservice")
    	    		.withExpiresAt(new Date(Timestamp.valueOf(LocalDateTime.now()).getTime()+ttlMillis))
    	    		.withSubject("login")
    	    		.withAudience(user.getUsername())
    	    		.withIssuedAt(new Date())
    	    		
    	    		//.withClaim("admin", "true")
    	    		.withClaim("roleList", user.getRolelist()==null?"":user.getRolelist().toString())
    	    		.withHeader(headerClaims)
    	        .withIssuer("auth0")
    	        .sign(algorithm);
    	    
    	    return token;
    	} catch (JWTCreationException exception){
    	    //Invalid Signing configuration / Couldn't convert Claims.
    	}
    	
		return null;
    	
    }

    public static Boolean isVerify(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC256("123456");
            JWTVerifier verifier = JWT.require(algorithm)
                .withIssuer("auth0")
                .build(); //Reusable verifier instance
            // DecodedJWT jwt = verifier.verify(token);
            
        } catch (JWTVerificationException exception){
            //Invalid signature/claims
        	System.out.println(exception.getMessage());
        	return false;
        }
        return true;
    }
   
}
*/