package com.aia.glory.userservice.config;

import javax.annotation.Resource;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiObjectFactoryBean;

import com.aia.glory.common.util.EncryptUtil;

@Configuration	
public class TomcatConfig {

	@Resource
	private DataSourceConfig dataSourceConfig;
	
	// @ConditionalOnProperty(name = "spring.profiles.active", havingValue = "dev")
	@Bean
    public TomcatEmbeddedServletContainerFactory servletContainer() {
		TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory() {
            @Override
            protected TomcatEmbeddedServletContainer getTomcatEmbeddedServletContainer(Tomcat tomcat) {
                tomcat.enableNaming();
                return super.getTomcatEmbeddedServletContainer(tomcat);
            }
            @Override
            protected void postProcessContext(Context context) {
                ContextResource resource = new ContextResource();
                resource.setName(dataSourceConfig.getJndiName());
                resource.setType(DataSource.class.getName());
                resource.setProperty("factory", dataSourceConfig.getFactory());
                resource.setProperty("driverClassName", dataSourceConfig.getDriverClassName());
                resource.setProperty("url", dataSourceConfig.getUrl());
                resource.setProperty("username", dataSourceConfig.getUsername());
                resource.setProperty("password",EncryptUtil.AESdecode(dataSourceConfig.getPassword(),dataSourceConfig.getUsername()));
                resource.setProperty("maxActive", dataSourceConfig.getMaxActive()); 
                resource.setProperty("maxIdle", dataSourceConfig.getMaxIdle()); 
                resource.setProperty("maxWait", dataSourceConfig.getMaxWait()); 
                context.getNamingResources().addResource(resource);
                
            }
            
        };
        return tomcat;
    }
}
