package com.aia.glory.userservice.Controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.userservice.ApplicationTest;
import com.aia.glory.userservice.model.User;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApplicationTest.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class UserControllerTest {

	@Autowired
    private WebApplicationContext context;

	@Autowired
    private MockMvc mockMvc;
    
 
 	
 	@Test
 	@Transactional
    public void createUserTest() throws Exception {
 		User user = new User();
		user.setUsername("alan");
		user.setLoginId("bsnpsstestdf3fddd");
		user.setPassword("xXYLW123");
		user.setAction("POST");
 		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/user")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(user))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
    }
 	
 	@Test
 	@Transactional
    public void updateUserTest() throws Exception {
 		User user = new User();
		user.setUsername("alan");
		user.setLoginId("bsnpbss");
		user.setPassword("xXYLW123");
		user.setAction("UPDATE");
 		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/user")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(user))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
    }
 	
 	@Test
 	@Transactional
    public void deleteUserTest() throws Exception {
 		User user = new User();
		user.setUsername("alan");
		user.setLoginId("bsnpbss");
		user.setPassword("xXYLW123");
		user.setAction("DELETE");
 		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/user")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(user))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
    }
 	
 	@Test
    public void getUserTest() throws Exception {
		
 		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/user")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content("{\"action\":\"GET\", \"pageSize\":10,\"startPage\":1}")
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
    }
}
