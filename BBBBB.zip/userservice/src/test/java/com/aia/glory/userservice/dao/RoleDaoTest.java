package com.aia.glory.userservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.ApplicationTest;
import com.aia.glory.userservice.model.Role;
import com.aia.glory.userservice.model.response.RoleListResponse;
import com.aia.glory.userservice.service.RoleService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class },webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RoleDaoTest {

	@Autowired
	RoleService roleServiceImpl;

	@Test
	@Transactional
	public void addRoleTest() {
		Role role = new Role();
		role.setAction("GET");
		role.setRoleName("Customized User");
		role.setAuthority("R");
		role.setRemark("test add");
		Response rs = roleServiceImpl.addRole(role);
		
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	
	@Test
	@Transactional
	public void updateRoleTest() {
		RoleListResponse rr = (RoleListResponse)roleServiceImpl.getRoleList();
		Role r = rr.getRolelist().get(0);
		r.setRemark("test update");
		
		Response rs = roleServiceImpl.updateRole(r);

		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	
	@Test
	@Transactional
	public void deleteRoleTest() {
		
		RoleListResponse rr = (RoleListResponse)roleServiceImpl.getRoleList();
		
		Response rs = roleServiceImpl.deleteRole(rr.getRolelist().get(0));

		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	@Test
	public void getRoleListTest() {
		
		Response rs = roleServiceImpl.getRoleList();
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	
}