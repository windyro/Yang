package com.aia.glory.userservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.userservice.ApplicationTest;
import com.aia.glory.userservice.model.User;
import com.aia.glory.userservice.model.request.UserSummary;
import com.aia.glory.userservice.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class },webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserDaoTest {

	@Autowired
	UserService userServiceImpl;

	@Test
	@Transactional
	@Rollback(value = true)
	public void createUserTest() {
		User user = new User();
		user.setUsername("alan");
		user.setLoginId("bsnpsstestdf3fddd");
		user.setPassword("xXYLW123");
		//user.setEnabled("0");
		// depositSummary.setPeriod("2020-01");
		GeneryResponse rs = (GeneryResponse) userServiceImpl.addUser(user);
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}

	@Test
	@Transactional
	@Rollback(value = true)
	public void updateUserTest() {
		User user = new User();
		user.setUsername("aland");
		user.setLoginId("bsnpbss");
		//user.setEnabled("0");
		// depositSummary.setPeriod("2020-01");
		Response rs =  userServiceImpl.updateUser(user);
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	
	@Test
	@Transactional
	@Rollback(value = true)
	public void updateUserPasswordTest() {
		User user = new User();
		user.setUsername("alan");
		user.setLoginId("bsnpbss");
		user.setPassword("xXYLW123");
		//user.setEnabled("0");
		// depositSummary.setPeriod("2020-01");
		GeneryResponse rs = (GeneryResponse) userServiceImpl.updateUser(user);
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}

	@Test
	@Transactional
	//@Rollback(value = true)
	public void deleteUserTest() {
		User user = new User();
		//user.setUsername("alan");
		user.setLoginId("bsnpbss");
		//user.setEnabled("0");
		// depositSummary.setPeriod("2020-01");
		Response rs = userServiceImpl.deleteUser(user);
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	
	@Test
	public void loginTest() {
		User user = new User();
		//user.setUsername("alan");
		user.setLoginId("bsnpbss");
		user.setPassword("d033e22ae348aeb5660fc2140aec35850c4da997");
		//user.setEnabled("");
		// depositSummary.setPeriod("2020-01");
		Response rs = userServiceImpl.generateResponseToken(user);
		Assert.assertEquals("t", "000", rs.getResponseCode());
	}
	
	@Test
	public void quertUserTest() {
		UserSummary user = new UserSummary();
		user.setAction("GET");
		user.setPageSize(11);
		user.setStartPage(1);
		user.setLoginId("asnpiio");
		//user.setLoginId("bsnpbyy");
		user.setEnabled("");
		// depositSummary.setPeriod("2020-01");
		Response rs = userServiceImpl.inquireUser(user);

		Assert.assertEquals("t", "000", rs.getResponseCode());
	}

}
