
package com.aia.glory.contestservice.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.contestservice.model.ContestMasterModel;
import com.aia.glory.contestservice.service.ContestCriteriaService;
import com.aia.glory.contestservice.service.ContestMasterService;
import com.aia.glory.model.request.ConstestMasterActionRequest;
import com.aia.glory.model.request.ContestCriteriaRequest;
import com.aia.glory.model.request.ContestMasterRequest;
import com.aia.glory.model.response.GetContestCriteriaResponse;
import com.aia.glory.model.response.GetContestMasterResponse;


@RestController
public class ContestMasterController {
	
	@Autowired
	@Qualifier(value = "contestMasterService")
	private ContestMasterService contestMasterService;
	
	@RequestMapping(value = "/contestMaster", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Response entity(@Valid  HttpServletRequest request, @RequestBody String requestBody) throws IOException{
	
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		Response response = null;
		
		switch (action) {
		case "GET":
			response = retrieveContestMaster(requestBody);
			break;	
		case "INSERT":
			response = insertContestMaster(requestBody);
			break;	
		case "UPDATE":
			response = updateContestMaster(requestBody);
			break;
		default:
			break;
		}
		
		return response;
	}

	private Response retrieveContestMaster(String requestBody) throws IOException{
		ContestMasterRequest contestMasterRequest= (ContestMasterRequest) JsonToObjectUtil.jsonToObj(new ContestMasterRequest(), requestBody);
		Response response = contestMasterService.retrieveContestMaster(contestMasterRequest);
		return response;
	}
	
	private Response insertContestMaster(String requestBody) throws IOException{
		
		ConstestMasterActionRequest constestMasterActionRequest= (ConstestMasterActionRequest) JsonToObjectUtil.jsonToObj(new ConstestMasterActionRequest(), requestBody);
		ContestMasterModel contestMasterModel= constestMasterActionRequest.getContestMasterModel();
		
		//Check if the Contest Code already used
		ContestMasterRequest contestMasterRequest = new ContestMasterRequest();
		contestMasterRequest.setContestCode(contestMasterModel.getContestCode());
		GetContestMasterResponse getContestMasterResponse = contestMasterService.retrieveContestMaster(contestMasterRequest);
		List<ContestMasterModel> contestMasterModelList = (List<ContestMasterModel>)getContestMasterResponse.getContestMasterModel();
		if(contestMasterModelList != null && !contestMasterModelList.isEmpty()){
			return GeneryResponse.fail("Contest Code alread existed!");
		}
		//Get Criteria
		if(contestMasterModel.getContestCriteriaSeq() == null || contestMasterModel.getContestCriteriaSeq().isEmpty()){
			return GeneryResponse.fail("Must choose Contest Criteria!");
		}

		Response response = null;
		
		//insert rule group
		response = contestMasterService.insertRuleGroup(constestMasterActionRequest);
		
		//insert summary rule

		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			response = contestMasterService.insertRule(constestMasterActionRequest);
		}
		
		//insert contest master
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			response = contestMasterService.insertContestMaster(constestMasterActionRequest);
		}
		return response;
	}
	
	private Response updateContestMaster(String requestBody) throws IOException{
		
		ConstestMasterActionRequest constestMasterActionRequest= (ConstestMasterActionRequest) JsonToObjectUtil.jsonToObj(new ConstestMasterActionRequest(), requestBody);
		ContestMasterModel contestMasterModel= constestMasterActionRequest.getContestMasterModel();
		
		//Check if the Contest Code already used
		ContestMasterRequest contestMasterRequest = new ContestMasterRequest();
		contestMasterRequest.setContestCode(contestMasterModel.getContestCode());
		GetContestMasterResponse getContestMasterResponse = contestMasterService.retrieveContestMaster(contestMasterRequest);
		List<ContestMasterModel> contestMasterModelList = (List<ContestMasterModel>)getContestMasterResponse.getContestMasterModel();
		if(contestMasterModelList != null && !contestMasterModelList.isEmpty()){
			for(ContestMasterModel existContestMasterModel : contestMasterModelList) {
				if(!existContestMasterModel.getContestMasterSeq().equals(contestMasterModel.getContestMasterSeq())){
					return GeneryResponse.fail("Contest Code alread existed!");
				}
			}
		}
		
		Response response = null;
		
		//update rule group
		response = contestMasterService.updateRuleGroup(constestMasterActionRequest);
				
		//update summary rule
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			response = contestMasterService.deleteRule(constestMasterActionRequest);
		}
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			response = contestMasterService.insertRule(constestMasterActionRequest);
		}
		
		//update contest master
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			response = contestMasterService.updateContestMaster(constestMasterActionRequest);
		}
		return response;
	}
	
}
