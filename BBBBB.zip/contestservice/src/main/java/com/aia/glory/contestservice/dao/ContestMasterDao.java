package com.aia.glory.contestservice.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.contestservice.model.ContestMasterModel;
import com.aia.glory.model.request.ContestMasterRequest;;

public interface ContestMasterDao {

	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<ContestMasterModel> selectContestMaster(ContestMasterRequest contestMasterRequest);
		
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectContestMasterTotal(ContestMasterRequest contestMasterRequest);
	
	public void insertContestMaster(ContestMasterModel contestMasterModel);
	
	public void updateContestMaster(ContestMasterModel contestMasterModel);
	
	public void insertRuleGroup(ContestMasterModel contestMasterModel);
	
	public void updateRuleGroup(ContestMasterModel contestMasterModel);
	
	public void insertRule(ContestMasterModel contestMasterModel);
	
	public void deleteRule(ContestMasterModel contestMasterModel);
	
	public void updateRule(ContestMasterModel contestMasterModel);
}
