package com.aia.glory.contestservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(value = "handler") 
public class ContestMasterModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
    private String contestMasterSeq;
	private String contestCriteriaSeq;
	private String processingUnitSeq;
	private String businessUnitSeq;
	private String branchSeq;
	private String locationSeq;
	private String contestCode;
	private String contestName;
	private String contestDescription;
	private String startDate;
	private String endDate;
	private String calculationFrequency;
	private String measurement;
	private String deposit;
	private String active;
	
	private ContestCriteriaModel contestCriteriaModel;
	public String getContestMasterSeq() {
		return contestMasterSeq;
	}


	public void setContestMasterSeq(String contestMasterSeq) {
		this.contestMasterSeq = contestMasterSeq;
	}


	public String getContestCriteriaSeq() {
		return contestCriteriaSeq;
	}


	public void setContestCriteriaSeq(String contestCriteriaSeq) {
		this.contestCriteriaSeq = contestCriteriaSeq;
	}


	public String getProcessingUnitSeq() {
		return processingUnitSeq;
	}


	public void setProcessingUnitSeq(String processingUnitSeq) {
		this.processingUnitSeq = processingUnitSeq;
	}


	public String getBusinessUnitSeq() {
		return businessUnitSeq;
	}


	public void setBusinessUnitSeq(String businessUnitSeq) {
		this.businessUnitSeq = businessUnitSeq;
	}


	public String getBranchSeq() {
		return branchSeq;
	}


	public void setBranchSeq(String branchSeq) {
		this.branchSeq = branchSeq;
	}


	public String getLocationSeq() {
		return locationSeq;
	}


	public void setLocationSeq(String locationSeq) {
		this.locationSeq = locationSeq;
	}


	public String getContestCode() {
		return contestCode;
	}


	public void setContestCode(String contestCode) {
		this.contestCode = contestCode;
	}


	public String getContestName() {
		return contestName;
	}


	public void setContestName(String contestName) {
		this.contestName = contestName;
	}


	public String getContestDescription() {
		return contestDescription;
	}


	public void setContestDescription(String contestDescription) {
		this.contestDescription = contestDescription;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public String getCalculationFrequency() {
		return calculationFrequency;
	}


	public void setCalculationFrequency(String calculationFrequency) {
		this.calculationFrequency = calculationFrequency;
	}


	public String getMeasurement() {
		return measurement;
	}


	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}


	public String getDeposit() {
		return deposit;
	}


	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}

	public String getActive() {
		return active;
	}


	public void setActive(String active) {
		this.active = active;
	}


	public ContestCriteriaModel getContestCriteriaModel() {
		return contestCriteriaModel;
	}


	public void setContestCriteriaModel(ContestCriteriaModel contestCriteriaModel) {
		this.contestCriteriaModel = contestCriteriaModel;
	}


	@Override
	public String toString() {
		return "ContestMasterModel [contestMasterSeq=" + contestMasterSeq
				+ ", contestCriteriaSeq=" + contestCriteriaSeq
				+ ", processingUnitSeq=" + processingUnitSeq
				+ ", businessUnitSeq=" + businessUnitSeq + ", branchSeq="
				+ branchSeq + ", locationSeq=" + locationSeq + ", contestCode="
				+ contestCode + ", contestName=" + contestName
				+ ", contestDescription=" + contestDescription + ", startDate="
				+ startDate + ", endDate=" + endDate
				+ ", calculationFrequency=" + calculationFrequency
				+ ", measurement=" + measurement + ", deposit=" + deposit
				+ ", contestCriteriaModel=" + contestCriteriaModel + "]";
	}

}
