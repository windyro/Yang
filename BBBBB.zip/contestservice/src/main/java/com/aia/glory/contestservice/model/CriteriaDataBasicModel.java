package com.aia.glory.contestservice.model;

import java.util.List;
import com.aia.glory.common.model.rule.RuleModel;

public class CriteriaDataBasicModel{

	private List<RuleModel> kpi;
	private List<RuleModel> segment;
	private List<RuleModel> product;
	
	public List<RuleModel> getKpi() {
		return kpi;
	}
	public void setKpi(List<RuleModel> kpi) {
		this.kpi = kpi;
	}
	public List<RuleModel> getSegment() {
		return segment;
	}
	public void setSegment(List<RuleModel> segment) {
		this.segment = segment;
	}
	public List<RuleModel> getProduct() {
		return product;
	}
	public void setProduct(List<RuleModel> product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "CriteriaDataBasicModel [kpi=" + kpi + ", segment=" + segment
				+ ", product=" + product + "]";
	}

	

	
}
