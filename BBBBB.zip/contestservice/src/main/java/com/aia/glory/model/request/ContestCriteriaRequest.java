package com.aia.glory.model.request;

import javax.validation.constraints.Pattern;

import com.aia.glory.common.model.request.Request;

public class ContestCriteriaRequest extends Request{
	
    private String contestCriteriaSeq;
    
    private String processingUnitSeq;
    
    private String businessUnitSeq;
    
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgent need letters or Numbers")
	private String criteriaCode;
	   
	private String criteriaDescription;

    private int startPage = 0;
	
   	private int pageSize = 0;

	public String getContestCriteriaSeq() {
		return contestCriteriaSeq;
	}

	public void setContestCriteriaSeq(String contestCriteriaSeq) {
		this.contestCriteriaSeq = contestCriteriaSeq;
	}

	public String getProcessingUnitSeq() {
		return processingUnitSeq;
	}

	public void setProcessingUnitSeq(String processingUnitSeq) {
		this.processingUnitSeq = processingUnitSeq;
	}

	public String getBusinessUnitSeq() {
		return businessUnitSeq;
	}

	public void setBusinessUnitSeq(String businessUnitSeq) {
		this.businessUnitSeq = businessUnitSeq;
	}

	public String getCriteriaCode() {
		return criteriaCode;
	}

	public void setCriteriaCode(String criteriaCode) {
		this.criteriaCode = criteriaCode;
	}

	public String getCriteriaDescription() {
		return criteriaDescription;
	}

	public void setCriteriaDescription(String criteriaDescription) {
		this.criteriaDescription = criteriaDescription;
	}

	public void setStartPage(int startPage) {
		if(startPage == 0) {
			startPage =1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(int pageSize) {
		if(pageSize == 0) {
			pageSize =1;
		}
		this.pageSize = pageSize;
	}
	
	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}

}
