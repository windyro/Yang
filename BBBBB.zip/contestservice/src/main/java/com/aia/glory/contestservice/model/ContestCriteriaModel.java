package com.aia.glory.contestservice.model;

public class ContestCriteriaModel{

	private String contestCriteriaSeq;
	private String contestMasterSeq;
	private String processingUnitSeq;
	private String businessUnitSeq;
	private String branchSeq;
	private String locationSeq;
	private String criteriaCode;
	private String criteriaDescription;
	private CriteriaDataModel criteriaData;
	private String criteriaStr;
	private String summaryTypeItem;
	private String executor;
	
	public String getContestCriteriaSeq() {
		return contestCriteriaSeq;
	}



	public void setContestCriteriaSeq(String contestCriteriaSeq) {
		this.contestCriteriaSeq = contestCriteriaSeq;
	}



	public String getContestMasterSeq() {
		return contestMasterSeq;
	}



	public void setContestMasterSeq(String contestMasterSeq) {
		this.contestMasterSeq = contestMasterSeq;
	}



	public String getProcessingUnitSeq() {
		return processingUnitSeq;
	}



	public void setProcessingUnitSeq(String processingUnitSeq) {
		this.processingUnitSeq = processingUnitSeq;
	}



	public String getBusinessUnitSeq() {
		return businessUnitSeq;
	}



	public void setBusinessUnitSeq(String businessUnitSeq) {
		this.businessUnitSeq = businessUnitSeq;
	}



	public String getBranchSeq() {
		return branchSeq;
	}



	public void setBranchSeq(String branchSeq) {
		this.branchSeq = branchSeq;
	}



	public String getLocationSeq() {
		return locationSeq;
	}



	public void setLocationSeq(String locationSeq) {
		this.locationSeq = locationSeq;
	}

	public String getCriteriaCode() {
		return criteriaCode;
	}



	public void setCriteriaCode(String criteriaCode) {
		this.criteriaCode = criteriaCode;
	}



	public String getCriteriaDescription() {
		return criteriaDescription;
	}



	public void setCriteriaDescription(String criteriaDescription) {
		this.criteriaDescription = criteriaDescription;
	}


	public CriteriaDataModel getCriteriaData() {
		return criteriaData;
	}



	public void setCriteriaData(CriteriaDataModel criteriaData) {
		this.criteriaData = criteriaData;
	}



	public String getCriteriaStr() {
		return criteriaStr;
	}



	public void setCriteriaStr(String criteriaStr) {
		this.criteriaStr = criteriaStr;
	}



	public String getSummaryTypeItem() {
		return summaryTypeItem;
	}



	public void setSummaryTypeItem(String summaryTypeItem) {
		this.summaryTypeItem = summaryTypeItem;
	}



	public String getExecutor() {
		return executor;
	}



	public void setExecutor(String executor) {
		this.executor = executor;
	}



	@Override
	public String toString() {
		return "ContestCriteriaModel [contestCriteriaSeq=" + contestCriteriaSeq
				+ ", contestMasterSeq=" + contestMasterSeq
				+ ", processingUnitSeq=" + processingUnitSeq
				+ ", businessUnitSeq=" + businessUnitSeq + ", branchSeq="
				+ branchSeq + ", locationSeq=" + locationSeq
				+ ", criteriaCode=" + criteriaCode + ", criteriaDescription="
				+ criteriaDescription + ", criteriaData=" + criteriaData
				+ ", criteriaStr=" + criteriaStr + ", summaryTypeItem="
				+ summaryTypeItem + ", executor=" + executor + "]";
	}
	
}
