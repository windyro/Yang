package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class ContestCriteriaActionResponse extends Response
 {
	private String contestCriteriaSeq;

	public String getContestCriteriaSeq() {
		return contestCriteriaSeq;
	}

	public void setContestCriteriaSeq(String contestCriteriaSeq) {
		this.contestCriteriaSeq = contestCriteriaSeq;
	}

	public static ContestCriteriaActionResponse success(ResponseCode responseCode) {
		ContestCriteriaActionResponse contestCriteriaActionResponse = new ContestCriteriaActionResponse();
		contestCriteriaActionResponse.setResponseCode(responseCode.getCode());
		contestCriteriaActionResponse.setReasonCode(Arrays.asList("0000"));
		contestCriteriaActionResponse.setReasonDesc(Arrays.asList(""));
		return contestCriteriaActionResponse;
	}

	public static ContestCriteriaActionResponse success(ResponseCode responseCode,String contestCriteriaSeq) 
	 {        
		ContestCriteriaActionResponse contestCriteriaActionResponse = new ContestCriteriaActionResponse();        
		contestCriteriaActionResponse.setResponseCode(responseCode.getCode());
		contestCriteriaActionResponse.setReasonCode(Arrays.asList("0000"));
		contestCriteriaActionResponse.setReasonDesc(Arrays.asList(""));
		contestCriteriaActionResponse.setContestCriteriaSeq(contestCriteriaSeq);
		return contestCriteriaActionResponse;    
		 
	 }
	
	public static ContestCriteriaActionResponse fail(ResponseCode responseCode,String errorMsg) {
		ContestCriteriaActionResponse contestCriteriaActionResponse = new ContestCriteriaActionResponse();
		contestCriteriaActionResponse.setResponseCode(responseCode.getCode());
		contestCriteriaActionResponse.setReasonCode(Arrays.asList("0000"));
		contestCriteriaActionResponse.setReasonDesc(Arrays.asList(errorMsg));
		return contestCriteriaActionResponse;
	}

	@Override
	public String toString() {
		return "ContestCriteriaActionResponse [contestCriteriaSeq="
				+ contestCriteriaSeq + "]";
	}
	
}
