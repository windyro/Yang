package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.contestservice.model.ContestCriteriaModel;

public class ContestCriteriaActionRequest extends Request{
	
	private ContestCriteriaModel contestCriteriaModel;

	public ContestCriteriaModel getContestCriteriaModel() {
		return contestCriteriaModel;
	}

	public void setContestCriteriaModel(ContestCriteriaModel contestCriteriaModel) {
		this.contestCriteriaModel = contestCriteriaModel;
	}

}
