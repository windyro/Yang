package com.aia.glory.model.request;

import javax.validation.constraints.Pattern;

import com.aia.glory.common.model.request.Request;

public class ContestMasterRequest extends Request{
	
    private String contestMasterSeq;
    
    private String processingUnitSeq;
    
    private String businessUnitSeq;
    
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgent need letters or Numbers")
	private String contestCode;
	
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgent need letters or Numbers")
	private String contestName;
	   
	private String contestDescription;
		
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String startDate;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String endDate;
	
	private String active;
	  
    private int startPage = 0;
	
   	private int pageSize = 0;

	public String getProcessingUnitSeq() {
		return processingUnitSeq;
	}

	public void setProcessingUnitSeq(String processingUnitSeq) {
		this.processingUnitSeq = processingUnitSeq;
	}

	public String getBusinessUnitSeq() {
		return businessUnitSeq;
	}

	public void setBusinessUnitSeq(String businessUnitSeq) {
		this.businessUnitSeq = businessUnitSeq;
	}

	public String getContestMasterSeq() {
		return contestMasterSeq;
	}

	public void setContestMasterSeq(String contestMasterSeq) {
		this.contestMasterSeq = contestMasterSeq;
	}

	public String getContestCode() {
		return contestCode;
	}

	public void setContestCode(String contestCode) {
		this.contestCode = contestCode;
	}

	public String getContestName() {
		return contestName;
	}

	public void setContestName(String contestName) {
		this.contestName = contestName;
	}

	public String getContestDescription() {
		return contestDescription;
	}

	public void setContestDescription(String contestDescription) {
		this.contestDescription = contestDescription;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public void setStartPage(int startPage) {
		if(startPage == 0) {
			startPage =1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(int pageSize) {
		if(pageSize == 0) {
			pageSize =1;
		}
		this.pageSize = pageSize;
	}
	
	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}

}
