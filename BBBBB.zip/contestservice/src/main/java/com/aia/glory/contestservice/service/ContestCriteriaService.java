package com.aia.glory.contestservice.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.contestservice.dao.ContestCriteriaDao;
import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.model.request.ContestCriteriaActionRequest;
import com.aia.glory.model.request.ContestCriteriaRequest;
import com.aia.glory.model.response.ContestCriteriaActionResponse;
import com.aia.glory.model.response.GetContestCriteriaResponse;


@Service(value = "contestCriteriaService")
public class ContestCriteriaService {
	@Autowired
	public ContestCriteriaDao contestCriteriaDao;
	
	public GetContestCriteriaResponse retrieveContestCriteria(ContestCriteriaRequest contestCriteriaRequest) {
		
		int total = contestCriteriaDao.selectContestCriteriaTotal(contestCriteriaRequest);
		List<ContestCriteriaModel> contestCriteriaList = contestCriteriaDao.selectContestCriteria(contestCriteriaRequest);
		return GetContestCriteriaResponse.success(ResponseCode.NORMAL, contestCriteriaList, total);
	}
	
	public ContestCriteriaActionResponse insertContestCriteria(ContestCriteriaActionRequest constestCriteriaActionRequest) {
		
		if(constestCriteriaActionRequest != null) {
			contestCriteriaDao.insertContestCriteria(constestCriteriaActionRequest.getContestCriteriaModel());
		}
		return ContestCriteriaActionResponse.success(ResponseCode.NORMAL, constestCriteriaActionRequest.getContestCriteriaModel().getContestCriteriaSeq());
	
	}
	
	public ContestCriteriaActionResponse updateContestCriteria(ContestCriteriaActionRequest constestCriteriaActionRequest) {
		
		if(constestCriteriaActionRequest != null) {
			contestCriteriaDao.updateContestCriteria(constestCriteriaActionRequest.getContestCriteriaModel());
		}
		return ContestCriteriaActionResponse.success(ResponseCode.NORMAL, constestCriteriaActionRequest.getContestCriteriaModel().getContestCriteriaSeq());
	
	}
	
//	public void insertRule(ContestCriteriaModel contestCriteriaModel, String sql){
//		contestCriteriaDao.insertRule(contestCriteriaModel, sql);
//	}
//	
	public void updateRule(ContestCriteriaModel contestCriteriaModel){
		contestCriteriaDao.updateRule(contestCriteriaModel);
	}
	
	
}
