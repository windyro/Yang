package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetContestMasterResponse extends Response
 {
	private Object contestMasterModel;
	
	private int total;

	public Object getContestMasterModel() {
		return contestMasterModel;
	}

	public void setContestMasterModel(Object contestMasterModel) {
		this.contestMasterModel = contestMasterModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetContestMasterResponse success(ResponseCode responseCode) {
		GetContestMasterResponse getContestMasterResponse = new GetContestMasterResponse();
		getContestMasterResponse.setResponseCode(responseCode.getCode());
		getContestMasterResponse.setReasonCode(Arrays.asList("0000"));
		getContestMasterResponse.setReasonDesc(Arrays.asList(""));
		return getContestMasterResponse;
	}

	public static GetContestMasterResponse success(ResponseCode responseCode,Object entityModel,int total) 
	 {        
		GetContestMasterResponse getContestMasterResponse = new GetContestMasterResponse();        
		getContestMasterResponse.setResponseCode(responseCode.getCode());
		getContestMasterResponse.setReasonCode(Arrays.asList("0000"));
		getContestMasterResponse.setReasonDesc(Arrays.asList(""));
		getContestMasterResponse.setContestMasterModel(entityModel);
		getContestMasterResponse.setTotal(total);
		return getContestMasterResponse;    
		 
	 }
	
	public static GetContestMasterResponse fail(ResponseCode responseCode,String errorMsg) {
		GetContestMasterResponse getContestMasterResponse = new GetContestMasterResponse();
		getContestMasterResponse.setResponseCode(responseCode.getCode());
		getContestMasterResponse.setReasonCode(Arrays.asList("0000"));
		getContestMasterResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getContestMasterResponse;
	}

	@Override
	public String toString() {
		return "GetContestMasterResponse [contestMasterModel="
				+ contestMasterModel + ", total=" + total + "]";
	}
	
}
