package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class ContestMasterActionResponse extends Response
 {
	private String contestMasterSeq;

	public String getContestMasterSeq() {
		return contestMasterSeq;
	}

	public void setContestMasterSeq(String contestMasterSeq) {
		this.contestMasterSeq = contestMasterSeq;
	}

	public static ContestMasterActionResponse success(ResponseCode responseCode) {
		ContestMasterActionResponse contestMasterActionResponse = new ContestMasterActionResponse();
		contestMasterActionResponse.setResponseCode(responseCode.getCode());
		contestMasterActionResponse.setReasonCode(Arrays.asList("0000"));
		contestMasterActionResponse.setReasonDesc(Arrays.asList(""));
		return contestMasterActionResponse;
	}

	public static ContestMasterActionResponse success(ResponseCode responseCode,String contestMasterSeq) 
	 {        
		ContestMasterActionResponse contestMasterActionResponse = new ContestMasterActionResponse();        
		contestMasterActionResponse.setResponseCode(responseCode.getCode());
		contestMasterActionResponse.setReasonCode(Arrays.asList("0000"));
		contestMasterActionResponse.setReasonDesc(Arrays.asList(""));
		contestMasterActionResponse.setContestMasterSeq(contestMasterSeq);
		return contestMasterActionResponse;    
		 
	 }
	
	public static ContestMasterActionResponse fail(ResponseCode responseCode,String errorMsg) {
		ContestMasterActionResponse contestMasterActionResponse = new ContestMasterActionResponse();
		contestMasterActionResponse.setResponseCode(responseCode.getCode());
		contestMasterActionResponse.setReasonCode(Arrays.asList("0000"));
		contestMasterActionResponse.setReasonDesc(Arrays.asList(errorMsg));
		return contestMasterActionResponse;
	}

	@Override
	public String toString() {
		return "ContestMasterActionResponse [contestMasterSeq="
				+ contestMasterSeq + "]";
	}
	
}
