
package com.aia.glory.contestservice.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.contestservice.model.CriteriaDataBasicModel;
import com.aia.glory.contestservice.model.CriteriaDataModel;
import com.aia.glory.contestservice.service.ContestCriteriaService;
import com.aia.glory.model.request.ContestCriteriaActionRequest;
import com.aia.glory.model.request.ContestCriteriaRequest;
import com.aia.glory.model.response.GetContestCriteriaResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


@RestController
public class ContestCriteriaController {
	
	public final static String TRANSACTION = "TRANSACTION_";
	public final static String MANAGER = "MANAGER_";
	public final static String POSITION = "POSITION_";
	public final static String PARTICIPANT = "PARTICIPANT_";
	
	@Autowired
	@Qualifier(value = "contestCriteriaService")
	private ContestCriteriaService contestCriteriaService;
	

	
	@RequestMapping(value = "/contestCriteria", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Response entity(@Valid  HttpServletRequest request, @RequestBody String requestBody) throws IOException{
	
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		Response response = null;
		
		switch (action) {
		case "GET":
			response = retrieveContestCriteria(requestBody);
			break;	
		case "INSERT":
			response = insertContestCriteria(requestBody);
			break;	
		case "UPDATE":
			response = updateContestCriteria(requestBody);
			break;
		default:
			break;
		}
		
		return response;
	}

	private Response retrieveContestCriteria(String requestBody) throws IOException{
		ContestCriteriaRequest contestCriteriaRequest= (ContestCriteriaRequest) JsonToObjectUtil.jsonToObj(new ContestCriteriaRequest(), requestBody);
		GetContestCriteriaResponse response = contestCriteriaService.retrieveContestCriteria(contestCriteriaRequest);
		
		//convert String to JSON Object
		List<ContestCriteriaModel> contestCriteriaModelList = (List<ContestCriteriaModel>)response.getContestCriteriaModel();
		if(contestCriteriaModelList != null && !contestCriteriaModelList.isEmpty()){
			for(ContestCriteriaModel contestCriteriaModel : contestCriteriaModelList) {
				String criteriaStr = contestCriteriaModel.getCriteriaStr();
				if(criteriaStr!=null && !"".equals(criteriaStr)){
					try {
						contestCriteriaModel.setCriteriaData(JsonToObjectUtil.jsonToObj(new CriteriaDataModel(), criteriaStr));
						contestCriteriaModel.setCriteriaStr("");
					}catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		
		return response;
	}
	
	private Response insertContestCriteria(String requestBody) throws IOException{
		
		ContestCriteriaActionRequest contestCriteriaActionRequest= (ContestCriteriaActionRequest) JsonToObjectUtil.jsonToObj(new ContestCriteriaActionRequest(), requestBody);
		ContestCriteriaModel contestCriteriaModel= contestCriteriaActionRequest.getContestCriteriaModel();
		
		//Check if the Criteria Code already used
		ContestCriteriaRequest contestCriteriaRequest = new ContestCriteriaRequest();
		contestCriteriaRequest.setCriteriaCode(contestCriteriaModel.getCriteriaCode());
		GetContestCriteriaResponse getContestCriteriaResponse = contestCriteriaService.retrieveContestCriteria(contestCriteriaRequest);
		List<ContestCriteriaModel> contestCriteriaModelList = (List<ContestCriteriaModel>)getContestCriteriaResponse.getContestCriteriaModel();
		if(contestCriteriaModelList != null && !contestCriteriaModelList.isEmpty()){
			return GeneryResponse.fail("Criteria Code alread existed!");
		}
		
		//convert criteria data to string
		String criteriaStr = "";
		if(contestCriteriaModel.getCriteriaData()!=null){
			try {
				criteriaStr = JsonToObjectUtil.objToJson(contestCriteriaModel.getCriteriaData());
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		contestCriteriaModel.setCriteriaStr(criteriaStr);
		String sql = this.generateSQLScript(contestCriteriaModel, criteriaStr);
		contestCriteriaModel.setExecutor(sql);
		
		Response response = null;
		response = contestCriteriaService.insertContestCriteria(contestCriteriaActionRequest);
		
//		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
//			String sql = this.generateSQLScript(contestCriteriaModel, criteriaStr);
//			contestCriteriaService.insertRule(contestCriteriaModel, sql);
//		}
		return response;
	}
	
	private Response updateContestCriteria(String requestBody) throws IOException{
		
		ContestCriteriaActionRequest contestCriteriaActionRequest= (ContestCriteriaActionRequest) JsonToObjectUtil.jsonToObj(new ContestCriteriaActionRequest(), requestBody);
		ContestCriteriaModel contestCriteriaModel= contestCriteriaActionRequest.getContestCriteriaModel();
		
		//Check if the Criteria Code already used
		ContestCriteriaRequest contestCriteriaRequest = new ContestCriteriaRequest();
		contestCriteriaRequest.setCriteriaCode(contestCriteriaModel.getCriteriaCode());
		GetContestCriteriaResponse getContestCriteriaResponse = contestCriteriaService.retrieveContestCriteria(contestCriteriaRequest);
		List<ContestCriteriaModel> contestCriteriaModelList = (List<ContestCriteriaModel>)getContestCriteriaResponse.getContestCriteriaModel();
		if(contestCriteriaModelList != null && !contestCriteriaModelList.isEmpty()){
			for(ContestCriteriaModel existContestCriteriaModel : contestCriteriaModelList) {
				if(!existContestCriteriaModel.getContestCriteriaSeq().equals(contestCriteriaModel.getContestCriteriaSeq())){
					return GeneryResponse.fail("Criteria Code alread existed!");
				}
			}
		}
		
		//convert criteria data to string
		String criteriaStr = "";
		if(contestCriteriaModel.getCriteriaData()!=null){
			try {
				criteriaStr = JsonToObjectUtil.objToJson(contestCriteriaModel.getCriteriaData());
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		contestCriteriaModel.setCriteriaStr(criteriaStr);
		String sql = this.generateSQLScript(contestCriteriaModel, criteriaStr);
		contestCriteriaModel.setExecutor(sql);
		
		Response response = null;
		response = contestCriteriaService.updateContestCriteria(contestCriteriaActionRequest);
		
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			contestCriteriaService.updateRule(contestCriteriaModel);
//			String sql = this.generateSQLScript(contestCriteriaModel, criteriaStr);
//			contestCriteriaService.updateRule(contestCriteriaModel, sql);
		}
		
		return response;
	}
	
	private String generateSQLScript(ContestCriteriaModel contestCriteriaModel, String criteriaStr){
		
		if(criteriaStr==null || "".equals(criteriaStr)){
			return "";
		}
		String insertSql= "insert into CE_SUMMARY("
						+ "SUMMARYSEQ,"
						+ "PERIODSEQ,"
						+ "DIMENSION1,"
						+ "DIMENSION2,"
						+ "DIMENSION1OFVALUE,"
						+ "DIMENSION2OFVALUE,"
						+ "PIPELINERUNSEQ,"
						+ "EVENTTYPESEQ,"
						+ "BUSINESSUNITMAP,"
						+ "VALUE,"
						+ "MODIFICATIONDATE,"
						+ "PROCESSINGUNITSEQ,"
						+ "GENERICDATE1,"
						+ "RULE_TYPE)";
		String selectSql = " select NEXT VALUE FOR CE_SUMMARY_SEQ,"
						+ "@Period,"
						+ "'2' as DIMENSION1,"
						+ "'0' as DIMENSION2,"
						+ "MANAGE.NAME,"
						+ "left(CT.GENERICATTRIBUTE15,3),"
						+ "@Pipeline,"
						+ "CT.EVENTTYPESEQ,"
						+ "CT.BUSINESSUNITMAP,"
						+ "sum(CT.VALUE) ,"
						+ "GETDATE() ,"
						+ "CT.PROCESSINGUNITSEQ ,"
						+ "MANAGE.EFFECTIVESTARTDATE,"
						+ "@MEASUREMENT ";
		
		String groupBySql = "group by MANAGE.NAME,MANAGE.EFFECTIVESTARTDATE,left(CT.GENERICATTRIBUTE15,3),CT.EVENTTYPESEQ,CT.BUSINESSUNITMAP,CT.PROCESSINGUNITSEQ";
		String fromSql = "from CE_TRANSACTION CT, CE_PROCESSINGUNIT PU, CE_BUSINESSUNIT BU, CE_POSITION MANAGE, CE_TITLE MANAGETITLE ";
		String whereSql = "where CT.COMPENSATIONDATE >= @Start And CT.COMPENSATIONDATE <= @End "
				+ "AND CT.PROCESSINGUNITSEQ = PU.PROCESSINGUNITSEQ "
				+ "AND CT.BUSINESSUNITMAP = BU.BUSINESSUNITSEQ "
				+ "AND MANAGE.NAME = CT.WRI_AGENCY AND MANAGE.REMOVEDATE = convert(date, '22000101') "
				+ "AND MANAGE.EFFECTIVESTARTDATE <=  CT.GENERICDATE1 "
				+ "AND MANAGE.EFFECTIVEENDDATE >=  CT.GENERICDATE1 "
				+ "AND MANAGE.TITLESEQ = MANAGETITLE.TITLESEQ ";
		
	
		CriteriaDataModel criteriaData = contestCriteriaModel.getCriteriaData();
		
		String advance = criteriaData.getAdvance();
		if(advance!=null && !"".equals(advance)){
			return advance;
		}
		CriteriaDataBasicModel basic = criteriaData.getBasic();
		
		List<RuleModel>segmentList = basic.getSegment();
		List<RuleModel>productList = basic.getProduct();
			
		if(criteriaStr.contains(ContestCriteriaController.POSITION) || criteriaStr.contains(ContestCriteriaController.PARTICIPANT)){
			fromSql += ", CE_POSITION POS, CE_TITLE POSTITLE, CE_PARTICIPANT PART  ";
			whereSql += "AND POS.NAME = CT.WRI_AGENT AND POS.REMOVEDATE = convert(date, '22000101') "
					+ "AND POS.EFFECTIVESTARTDATE <=  CT.GENERICDATE1 "
					+ "AND POS.EFFECTIVEENDDATE >=  CT.GENERICDATE1 "
					+ "AND POS.TITLESEQ = POSTITLE.TITLESEQ "
					+ "AND POS.PARTICIPANTSEQ = PART.PARTICIPANTSEQ "
					+ "AND CONVERT(DATE,POS.EFFECTIVESTARTDATE)=PART.EFFECTIVESTARTDATE  "
					+ "AND CONVERT(DATE,POS.EFFECTIVEENDDATE)=PART.EFFECTIVEENDDATE ";
		}
		
		//Segment
		for(RuleModel segment : segmentList) {
			//Field name
			//SEQ TO NAME
			if("MANAGER_TITLESEQ".equals(segment.getName())){
				whereSql += "AND MANAGETITLE.NAME";
			}
			else if("POSITION_TITLESEQ".equals(segment.getName())){
				whereSql += "AND POSTITLE.NAME";
			}
			else if("TRANSACTION_PROCESSINGUNIT".equals(segment.getName())){
				whereSql += "AND PU.NAME";
			}
			else if("TRANSACTION_BUSINESSUNIT".equals(segment.getName())){
				whereSql += "AND BU.NAME";
			}
			//SEQ TO NAME END
			else if(segment.getName().contains(ContestCriteriaController.TRANSACTION)){
				String field = segment.getName().substring(ContestCriteriaController.TRANSACTION.length());
				whereSql += "AND CT." + field ;
			}
			else if(segment.getName().contains(ContestCriteriaController.MANAGER)){
				String field = segment.getName().substring(ContestCriteriaController.MANAGER.length());
				whereSql += "AND MANAGE." + field ;
			}
			else if(segment.getName().contains(ContestCriteriaController.POSITION)){
				String field = segment.getName().substring(ContestCriteriaController.POSITION.length());
				whereSql += "AND POS." + field ;
			}
			else if(segment.getName().contains(ContestCriteriaController.PARTICIPANT)){
				String field = segment.getName().substring(ContestCriteriaController.PARTICIPANT.length());
				whereSql += "AND PART." + field ;
			}
			
			//Operator
			if("T_EQUAL".equals(segment.getRuleTemplateId()) ){
				whereSql += " = '" + segment.getCriteriaValue() + "' ";
			}
			else if("T_NOT_EQUAL".equals(segment.getRuleTemplateId()) ){
				whereSql += " <> '" + segment.getCriteriaValue() + "' " ;
			}
			else if("T_GREATER".equals(segment.getRuleTemplateId()) ){
				whereSql += " > '" + segment.getCriteriaValue() + "' " ;
			}
			else if("T_GREATER_EQUAL".equals(segment.getRuleTemplateId()) ){
				whereSql += " >= '" + segment.getCriteriaValue() + "' " ;
			}
			else if("T_SMALLER".equals(segment.getRuleTemplateId()) ){
				whereSql += " < '" + segment.getCriteriaValue() + "' " ;
			}
			else if("T_SMALLER_EQUAL".equals(segment.getRuleTemplateId()) ){
				whereSql += " <= '" + segment.getCriteriaValue() + "' " ;
			}
			else if("T_IN".equals(segment.getRuleTemplateId()) ){				
				whereSql += " in (" + this.strToIn(segment.getCriteriaValue()) + ") " ;
			}
			else if("T_NOT_IN".equals(segment.getRuleTemplateId()) ){				
				whereSql += " not in (" + this.strToIn(segment.getCriteriaValue()) + ") " ;
			}
			else if("T_BETWEEN".equals(segment.getRuleTemplateId()) ){
				whereSql += " " + this.strToBetween(segment.getCriteriaValue()) + " ";
			}
		}
		
		//Product
		for(RuleModel product : productList) {
			//Field name
			String field = product.getName();
			whereSql += "AND CT." + field ;

			//Operator
			if("T_EQUAL".equals(product.getRuleTemplateId()) ){
				whereSql += " = '" + product.getCriteriaValue() + "' ";
			}
			else if("T_NOT_EQUAL".equals(product.getRuleTemplateId()) ){
				whereSql += " <> '" + product.getCriteriaValue() + "' " ;
			}
			else if("T_GREATER".equals(product.getRuleTemplateId()) ){
				whereSql += " > '" + product.getCriteriaValue() + "' " ;
			}
			else if("T_GREATER_EQUAL".equals(product.getRuleTemplateId()) ){
				whereSql += " >= '" + product.getCriteriaValue() + "' " ;
			}
			else if("T_SMALLER".equals(product.getRuleTemplateId()) ){
				whereSql += " < '" + product.getCriteriaValue() + "' " ;
			}
			else if("T_SMALLER_EQUAL".equals(product.getRuleTemplateId()) ){
				whereSql += " <= '" + product.getCriteriaValue() + "' " ;
			}
			else if("T_IN".equals(product.getRuleTemplateId()) ){				
				whereSql += " in (" + this.strToIn(product.getCriteriaValue()) + ") " ;
			}
			else if("T_NOT_IN".equals(product.getRuleTemplateId()) ){				
				whereSql += " not in (" + this.strToIn(product.getCriteriaValue()) + ") " ;
			}
			else if("T_BETWEEN".equals(product.getRuleTemplateId()) ){
				whereSql += " " + this.strToBetween(product.getCriteriaValue()) + " ";
			}
		}

		String result= insertSql + selectSql + fromSql + whereSql + groupBySql;
		return result;
	}
	
	private String strToIn(String value){
		String result = "";
		String[] values =value.split(",");
		for(int i= 0; i<values.length; i++){
			if(!values[i].startsWith("'") && !values[i].endsWith("'")){
				result += "'" + values[i] + "',";
			}else{
				result += values[i] + ",";
			}
			
		}
		result = result.substring(0,result.length()-1);
		return result;
	}
	
	private String strToBetween(String value){
		String result = "";
		String[] values =value.split(",");
		result += "between '" + values[0] + "' and '" + values[1] + "'";
		return result;
	}
}
