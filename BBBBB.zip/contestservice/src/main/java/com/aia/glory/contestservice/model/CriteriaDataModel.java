package com.aia.glory.contestservice.model;

public class CriteriaDataModel{

	private CriteriaDataBasicModel basic;
	private String advance;
	
	public CriteriaDataBasicModel getBasic() {
		return basic;
	}

	public void setBasic(CriteriaDataBasicModel basic) {
		this.basic = basic;
	}

	public String getAdvance() {
		return advance;
	}

	public void setAdvance(String advance) {
		this.advance = advance;
	}

	@Override
	public String toString() {
		return "CriteriaDataModel [basic=" + basic + ", advance=" + advance
				+ "]";
	}
	
	

	
}
