package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetContestCriteriaResponse extends Response
 {
	private Object contestCriteriaModel;
	
	private int total;

	public Object getContestCriteriaModel() {
		return contestCriteriaModel;
	}

	public void setContestCriteriaModel(Object contestCriteriaModel) {
		this.contestCriteriaModel = contestCriteriaModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetContestCriteriaResponse success(ResponseCode responseCode) {
		GetContestCriteriaResponse getContestMasterResponse = new GetContestCriteriaResponse();
		getContestMasterResponse.setResponseCode(responseCode.getCode());
		getContestMasterResponse.setReasonCode(Arrays.asList("0000"));
		getContestMasterResponse.setReasonDesc(Arrays.asList(""));
		return getContestMasterResponse;
	}

	public static GetContestCriteriaResponse success(ResponseCode responseCode,Object contestCriteriaModel,int total) 
	 {        
		GetContestCriteriaResponse getContestCriteriaResponse = new GetContestCriteriaResponse();        
		getContestCriteriaResponse.setResponseCode(responseCode.getCode());
		getContestCriteriaResponse.setReasonCode(Arrays.asList("0000"));
		getContestCriteriaResponse.setReasonDesc(Arrays.asList(""));
		getContestCriteriaResponse.setContestCriteriaModel(contestCriteriaModel);
		getContestCriteriaResponse.setTotal(total);
		return getContestCriteriaResponse;    
		 
	 }
	
	public static GetContestCriteriaResponse fail(ResponseCode responseCode,String errorMsg) {
		GetContestCriteriaResponse getContestMasterResponse = new GetContestCriteriaResponse();
		getContestMasterResponse.setResponseCode(responseCode.getCode());
		getContestMasterResponse.setReasonCode(Arrays.asList("0000"));
		getContestMasterResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getContestMasterResponse;
	}

	@Override
	public String toString() {
		return "GetContestCriteriaResponse [contestCriteriaModel="
				+ contestCriteriaModel + ", total=" + total + "]";
	}
	
}
