package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.contestservice.model.ContestMasterModel;

public class ConstestMasterActionRequest extends Request{
	
	private ContestMasterModel contestMasterModel;

	public ContestMasterModel getContestMasterModel() {
		return contestMasterModel;
	}

	public void setContestMasterModel(ContestMasterModel contestMasterModel) {
		this.contestMasterModel = contestMasterModel;
	}


}
