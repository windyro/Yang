package com.aia.glory;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
@MapperScan("com.aia.glory.contestservice.dao")
public class Application{

	public static void main(String[] args) throws Exception {
    	
		SpringApplication app = new SpringApplication(Application.class);
		ConfigurableApplicationContext ctx = app.run(args);

    }
	

	/*@Bean
	public FilterRegistrationBean LoginFilter() {
		FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
		filterRegistrationBean.setFilter(new LoginValidateFilter());
		filterRegistrationBean.setName("LoginValidateFilter");
		filterRegistrationBean.addUrlPatterns("/*");
		filterRegistrationBean.setOrder(0);
		return filterRegistrationBean;
	}*/
	
}
