package com.aia.glory.contestservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.contestservice.dao.ContestMasterDao;
import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.contestservice.model.ContestMasterModel;
import com.aia.glory.model.request.ConstestMasterActionRequest;
import com.aia.glory.model.request.ContestMasterRequest;
import com.aia.glory.model.response.GetContestMasterResponse;
import com.aia.glory.model.response.ContestMasterActionResponse;

@Service(value = "contestMasterService")
public class ContestMasterService {
	@Autowired
	public ContestMasterDao contestMasterDao;
	
	public GetContestMasterResponse retrieveContestMaster(ContestMasterRequest contestMasterRequest) {
		
		int total = contestMasterDao.selectContestMasterTotal(contestMasterRequest);
		List<ContestMasterModel> contestMasterList = contestMasterDao.selectContestMaster(contestMasterRequest);
		return GetContestMasterResponse.success(ResponseCode.NORMAL, contestMasterList, total);
	}
	
	public ContestMasterActionResponse insertContestMaster(ConstestMasterActionRequest constestMasterActionRequest) {
		
		if(constestMasterActionRequest != null) {
			contestMasterDao.insertContestMaster(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL, constestMasterActionRequest.getContestMasterModel().getContestMasterSeq());
	
	}
	
	public ContestMasterActionResponse updateContestMaster(ConstestMasterActionRequest constestMasterActionRequest) {
		
		if(constestMasterActionRequest != null) {
			contestMasterDao.updateContestMaster(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL, constestMasterActionRequest.getContestMasterModel().getContestMasterSeq());
	
	}
	
	public ContestMasterActionResponse insertRuleGroup(ConstestMasterActionRequest constestMasterActionRequest) {
		
		if(constestMasterActionRequest != null) {
			contestMasterDao.insertRuleGroup(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL);
	
	}
	
	public ContestMasterActionResponse updateRuleGroup(ConstestMasterActionRequest constestMasterActionRequest) {
		
		if(constestMasterActionRequest != null) {
			contestMasterDao.updateRuleGroup(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL);
	
	}	
	
	public ContestMasterActionResponse insertRule(ConstestMasterActionRequest constestMasterActionRequest){
		if(constestMasterActionRequest != null) {
			contestMasterDao.insertRule(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL);
	}
	
	public ContestMasterActionResponse deleteRule(ConstestMasterActionRequest constestMasterActionRequest){
		if(constestMasterActionRequest != null) {
			contestMasterDao.deleteRule(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL);
	}

	public ContestMasterActionResponse updateRule(ConstestMasterActionRequest constestMasterActionRequest){
		if(constestMasterActionRequest != null) {
			contestMasterDao.updateRule(constestMasterActionRequest.getContestMasterModel());
		}
		return ContestMasterActionResponse.success(ResponseCode.NORMAL);
	}
	
}
