package com.aia.glory.contestservice.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.model.request.ContestCriteriaRequest;

public interface ContestCriteriaDao {

	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<ContestCriteriaModel> selectContestCriteria(ContestCriteriaRequest contestCriteriaRequest);
		
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectContestCriteriaTotal(ContestCriteriaRequest contestCriteriaRequest);
	
	public void insertContestCriteria(ContestCriteriaModel contestCriteriaModel);
	
	public void updateContestCriteria(ContestCriteriaModel contestCriteriaModel);
	
	public void insertRule(@Param("contestCriteriaModel")ContestCriteriaModel contestCriteriaModel, @Param("sql")String sql);
	
	public void updateRule(ContestCriteriaModel contestCriteriaModel);
}
