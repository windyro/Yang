package com.aia.glory.contestservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.contestservice.model.ContestMasterModel;
import com.aia.glory.contestservice.service.ContestMasterService;
import com.aia.glory.model.request.ConstestMasterActionRequest;
import com.aia.glory.model.request.ContestMasterRequest;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class ContestMasterTest {
	
	   @Autowired
	   ContestMasterService contestMasterService;

	   @Test
	   public void retrieveContestMaster()
	   {
		   ContestMasterRequest contestMasterRequest = new ContestMasterRequest();
		   contestMasterRequest.setContestMasterSeq("3");
		   Response rs = contestMasterService.retrieveContestMaster(contestMasterRequest);
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   @Transactional
	   public void updateContestMaster()
	   {
		   try {
			   ContestMasterModel contestMasterModel = new ContestMasterModel();
			   contestMasterModel.setContestMasterSeq("3");
			   contestMasterModel.setContestCriteriaSeq("1");
			   contestMasterModel.setProcessingUnitSeq("MM_PU");
			   contestMasterModel.setBusinessUnitSeq("MMBA");
			   contestMasterModel.setContestCode("C00001");
			   contestMasterModel.setContestName("C00001");
			   contestMasterModel.setContestDescription("C00001");
			   contestMasterModel.setStartDate("2010-01-01");
			   contestMasterModel.setEndDate("2010-12-31");
			   contestMasterModel.setActive("Y");
			   
			   ConstestMasterActionRequest constestMasterActionRequest=new ConstestMasterActionRequest();
			   constestMasterActionRequest.setAction("UPDATE");
			   constestMasterActionRequest.setContestMasterModel(contestMasterModel);
			   Response rs = contestMasterService.updateContestMaster(constestMasterActionRequest);

			   System.out.println(contestMasterModel.getContestMasterSeq());
			   Assert.assertNotNull(contestMasterModel);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	   
}