package com.aia.glory.contestservice.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.contestservice.model.CriteriaDataBasicModel;
import com.aia.glory.contestservice.model.CriteriaDataModel;
import com.aia.glory.model.request.ContestCriteriaActionRequest;
import com.aia.glory.model.request.ContestCriteriaRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class} ,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
@AutoConfigureMockMvc
public class ContestCriteriaControllerTest {
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testContestCriteria_GetSuccessfully_ReturnSuccessResponse() throws IOException{
		ContestCriteriaRequest contestCriteriaRequest = new ContestCriteriaRequest();
		contestCriteriaRequest.setAction("GET");
		contestCriteriaRequest.setContestCriteriaSeq("3");
		contestCriteriaRequest.setStartPage(1);
		contestCriteriaRequest.setPageSize(1);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/contestCriteria")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(contestCriteriaRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	@Test   
	@Transactional
	public void createContestCriteria_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		   ContestCriteriaModel contestCriteriaModel = new ContestCriteriaModel();
		   contestCriteriaModel.setProcessingUnitSeq("MM_PU");
		   contestCriteriaModel.setBusinessUnitSeq("MMBA");
		   contestCriteriaModel.setCriteriaCode("TESTTESTC");
		   contestCriteriaModel.setCriteriaDescription("TESTTESTC");
	   
		   ContestCriteriaActionRequest constestCriteriaActionRequest=new ContestCriteriaActionRequest();
		   constestCriteriaActionRequest.setAction("INSERT");
		   constestCriteriaActionRequest.setContestCriteriaModel(contestCriteriaModel);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/contestCriteria")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(constestCriteriaActionRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test   
	@Transactional
	public void updateContestCriteria_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		   ContestCriteriaModel contestCriteriaModel = new ContestCriteriaModel();		  
		   contestCriteriaModel.setContestCriteriaSeq("1");
		   contestCriteriaModel.setProcessingUnitSeq("MM_PU");
		   contestCriteriaModel.setBusinessUnitSeq("MMBA");
		   contestCriteriaModel.setCriteriaCode("TESTTESTC");
		   contestCriteriaModel.setCriteriaDescription("TESTTESTC");
		   
		   ContestCriteriaActionRequest constestCriteriaActionRequest=new ContestCriteriaActionRequest();
		   constestCriteriaActionRequest.setAction("UPDATE");
		   constestCriteriaActionRequest.setContestCriteriaModel(contestCriteriaModel);
		 
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/contestCriteria")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(constestCriteriaActionRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
//	@Test   
//	public void testContestCriteria_generateSQLScript() throws IOException{
//		ContestCriteriaController contestCriteriaController = new ContestCriteriaController();
//		ContestCriteriaModel contestCriteriaModel = new ContestCriteriaModel();
//		String criteriaDataStr = //"{\"Basic\" : \"vas\","+
//	    "{\"Basic\" : {"+
//        "\"Segment\": ["+
//		            "{\"NAME\": \"TRANSACTION_PROCESSINGUNIT\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"MM_PU\"},"+
//		            "{\"NAME\": \"TRANSACTION_BUSINESSUNIT\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"MMAGY\"}, "+
//					"{\"NAME\": \"TRANSACTION_GENERICDATE5\",\"ruleTemplateId\":\"T_BETWEEN\",\"criteriaValue\":\"2016-01-01, 2016-02-02\"}, "+ 
//					"{\"NAME\": \"MANAGER_TITLESEQ\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"AGENCY\"},"+
//					"{\"NAME\": \"POSITION_TITLESEQ\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"AD\"},"+
//					"{\"NAME\": \"POSITION_ManagerAgency\",\"ruleTemplateId\":\"T_IN\",\"criteriaValue\":\"01455,22223\"},"+
//					"{\"NAME\": \"PARTICIPANT_HIREDATE\",\"ruleTemplateId\":\"T_BETWEEN\",\"criteriaValue\":\"2016-01-01, 2016-02-02\"}"+
//					"],"+
//		"\"Product\": [{\"NAME\": \"PRODUCTID\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"IED2\"},"+
//		            "{\"NAME\": \"PRODUCTNAME\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"A-Life Med Regular\"}, "+
//					"{\"NAME\": \"PRODUCTDESCRIPTION\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"LIFE\"}, "+
//					"{\"NAME\": \"PRODUCTCATEGORY\",\"ruleTemplateId\":\"T_EQUAL\",\"criteriaValue\":\"LF\"} "+
//					"] "+				  
//		"},"+
//		"\"Advance\" : \"Select * from xxxxx\"}";
//		
//		ArrayList <RuleModel> segment = new ArrayList();
//		RuleModel segment1 = new RuleModel();
//		segment1.setName("TRANSACTION_PROCESSINGUNIT");
//		segment1.setRuleTemplateId("T_EQUAL");
//		segment1.setCriteriaValue("MM_PU");
//		
//		RuleModel segment2 = new RuleModel();
//		segment2.setName("TRANSACTION_BUSINESSUNIT");
//		segment2.setRuleTemplateId("T_EQUAL");
//		segment2.setCriteriaValue("MMAGY");
//
//		RuleModel segment3 = new RuleModel();
//		segment3.setName("TRANSACTION_GENERICDATE5");
//		segment3.setRuleTemplateId("T_BETWEEN");
//		segment3.setCriteriaValue("2016-01-01, 2016-02-02");
//		
//		RuleModel segment4 = new RuleModel();
//		segment4.setName("MANAGER_TITLESEQ");
//		segment4.setRuleTemplateId("T_EQUAL");
//		segment4.setCriteriaValue("AGENCY");
//		
//		RuleModel segment5 = new RuleModel();
//		segment5.setName("POSITION_TITLESEQ");
//		segment5.setRuleTemplateId("T_EQUAL");
//		segment5.setCriteriaValue("AD");
//		
//		RuleModel segment6 = new RuleModel();
//		segment6.setName("POSITION_ManagerAgency");
//		segment6.setRuleTemplateId("T_IN");
//		segment6.setCriteriaValue("01455,22223");
//		
//		RuleModel segment7 = new RuleModel();
//		segment7.setName("PARTICIPANT_HIREDATE");
//		segment7.setRuleTemplateId("T_BETWEEN");
//		segment7.setCriteriaValue("2016-01-01, 2016-02-02");
//		
//		segment.add(segment1);
//		segment.add(segment2);
//		segment.add(segment3);
//		segment.add(segment4);
//		segment.add(segment5);
//		segment.add(segment6);
//		segment.add(segment7);
//		
//		ArrayList <RuleModel> product = new ArrayList();
//		RuleModel product1 = new RuleModel();
//		product1.setName("PRODUCTID");
//		product1.setRuleTemplateId("T_EQUAL");
//		product1.setCriteriaValue("IED2");
//		
//		RuleModel product2 = new RuleModel();
//		product2.setName("PRODUCTNAME");
//		product2.setRuleTemplateId("T_EQUAL");
//		product2.setCriteriaValue("A-Life Med Regular");
//		
//		RuleModel product3 = new RuleModel();
//		product3.setName("PRODUCTDESCRIPTION");
//		product3.setRuleTemplateId("T_EQUAL");
//		product3.setCriteriaValue("LIFE");
//		
//		RuleModel product4 = new RuleModel();
//		product4.setName("PRODUCTCATEGORY");
//		product4.setRuleTemplateId("T_EQUAL");
//		product4.setCriteriaValue("LF");
//		
//		product.add(product1);
//		product.add(product2);
//		product.add(product3);
//		product.add(product4);
//
//		CriteriaDataBasicModel criteriaDataBasicModel = new CriteriaDataBasicModel();
//		criteriaDataBasicModel.setSegment(segment);
//		criteriaDataBasicModel.setProduct(product);
//		
//		CriteriaDataModel criteriaDataModel = new CriteriaDataModel();
//		criteriaDataModel.setBasic(criteriaDataBasicModel);
//		criteriaDataModel.setAdvance("Select * from xxxxx");
//		
//		contestCriteriaModel.setCriteriaData(criteriaDataModel);
//	    try {
//	    	String result = contestCriteriaController.generateSQLScript(contestCriteriaModel, criteriaDataStr);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
}
