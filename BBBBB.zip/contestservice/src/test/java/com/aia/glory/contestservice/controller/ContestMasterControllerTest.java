package com.aia.glory.contestservice.controller;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.contestservice.model.ContestMasterModel;
import com.aia.glory.model.request.ConstestMasterActionRequest;
import com.aia.glory.model.request.ContestMasterRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class} ,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
@AutoConfigureMockMvc
public class ContestMasterControllerTest {
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testContestMaster_GetSuccessfully_ReturnSuccessResponse() throws IOException{
		ContestMasterRequest contestMasterRequest = new ContestMasterRequest();
		contestMasterRequest.setAction("GET");
		contestMasterRequest.setContestMasterSeq("3");
		contestMasterRequest.setStartPage(1);
		contestMasterRequest.setPageSize(1);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/contestMaster")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(contestMasterRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	@Test   
	@Transactional
	public void createContestMaster_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		   ContestMasterModel contestMasterModel = new ContestMasterModel();
		   contestMasterModel.setContestCriteriaSeq("1");
		   contestMasterModel.setProcessingUnitSeq("MM_PU");
		   contestMasterModel.setBusinessUnitSeq("MMBA");
		   contestMasterModel.setContestCode("TESTCODE");
		   contestMasterModel.setContestName("TESTCODE");
		   contestMasterModel.setContestDescription("TESTCODE");
		   contestMasterModel.setStartDate("2010-01-01");
		   contestMasterModel.setEndDate("2010-12-31");
		   contestMasterModel.setCalculationFrequency("1");
		   contestMasterModel.setMeasurement("1");
		   contestMasterModel.setActive("Y");
		   
		   ConstestMasterActionRequest constestMasterActionRequest=new ConstestMasterActionRequest();
		   constestMasterActionRequest.setAction("INSERT");
		   constestMasterActionRequest.setContestMasterModel(contestMasterModel);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/contestMaster")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(constestMasterActionRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test   
	@Transactional
	public void updateContestMaster_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		   ContestMasterModel contestMasterModel = new ContestMasterModel();
		   contestMasterModel.setContestMasterSeq("3");
		   contestMasterModel.setContestCriteriaSeq("1");
		   contestMasterModel.setProcessingUnitSeq("MM_PU");
		   contestMasterModel.setBusinessUnitSeq("MMBA");
		   contestMasterModel.setContestCode("C00001");
		   contestMasterModel.setContestName("C00001");
		   contestMasterModel.setContestDescription("C00001");
		   contestMasterModel.setStartDate("2010-01-01");
		   contestMasterModel.setEndDate("2010-12-31");
		   contestMasterModel.setActive("Y");
		   
		   ConstestMasterActionRequest constestMasterActionRequest=new ConstestMasterActionRequest();
		   constestMasterActionRequest.setAction("UPDATE");
		   constestMasterActionRequest.setContestMasterModel(contestMasterModel);
		 
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/contestMaster")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(constestMasterActionRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
