package com.aia.glory.contestservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.contestservice.model.ContestCriteriaModel;
import com.aia.glory.contestservice.service.ContestCriteriaService;
import com.aia.glory.model.request.ContestCriteriaActionRequest;
import com.aia.glory.model.request.ContestCriteriaRequest;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class ContestCriteriaTest {
	
	   @Autowired
	   ContestCriteriaService contestCriteriaService;

	   @Test
	   public void retrieveContestCriteria()
	   {
		   ContestCriteriaRequest contestCriteriaRequest = new ContestCriteriaRequest();
		   contestCriteriaRequest.setContestCriteriaSeq("3");
		   Response rs = contestCriteriaService.retrieveContestCriteria(contestCriteriaRequest);
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   @Transactional
	   public void updateContestCriteria()
	   {
		   try {
			   ContestCriteriaModel contestCriteriaModel = new ContestCriteriaModel();
			   contestCriteriaModel.setContestCriteriaSeq("1");
			   contestCriteriaModel.setContestCriteriaSeq("1");
			   contestCriteriaModel.setProcessingUnitSeq("MM_PU");
			   contestCriteriaModel.setBusinessUnitSeq("MMBA");
			   contestCriteriaModel.setSummaryTypeItem("xxxxx");
			   
			   ContestCriteriaActionRequest contestCriteriaActionRequest=new ContestCriteriaActionRequest();
			   contestCriteriaActionRequest.setAction("UPDATE");
			   contestCriteriaActionRequest.setContestCriteriaModel(contestCriteriaModel);
			   Response rs = contestCriteriaService.updateContestCriteria(contestCriteriaActionRequest);

			   System.out.println(contestCriteriaModel.getContestCriteriaSeq());
			   Assert.assertNotNull(contestCriteriaModel);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	   
}