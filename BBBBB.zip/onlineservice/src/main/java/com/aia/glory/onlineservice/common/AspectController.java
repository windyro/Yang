package com.aia.glory.onlineservice.common;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONObject;

@Aspect
@Configuration
public class AspectController {

//  private final  static Logger logger = LoggerFactory.getLogger(AspectController.class);
	 Log infoLog = LogFactory.getLog("sysInfo");

    @Pointcut("execution(* com.aia.glory.onlineservice.controller.*.*(..))")
    public void printMsg(){
    	// implementation ignored
    }

    @Around("printMsg()")
    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();

        String url = request.getRequestURL().toString();
        String method = request.getMethod();
        String uri = request.getRequestURI();
//        String queryString = request.getQueryString();
        ArrayList<Object> argList = new ArrayList<>(); 
        for (Object arg : pjp.getArgs()) {
			if (!(arg instanceof HttpServletRequest) || !(arg instanceof HttpServletResponse) || !(arg instanceof HttpHeaders)) {
				argList.add(arg);
			}
		}
//        logger.info("request start, url: {}, method: {}, uri: {}, params: {}", url, method, uri, queryString);
        infoLog.info("url: " + url + ", " + "method: " + method + ", " + "uri: " + uri);
	    infoLog.info("params: " + argList);
	    Object result = pjp.proceed();
//	      logger.info("response data: {}" , result);
	    infoLog.info("response data: " + result);
	    return result;
    }
}
