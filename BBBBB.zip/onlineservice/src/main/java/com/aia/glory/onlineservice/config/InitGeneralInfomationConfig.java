package com.aia.glory.onlineservice.config;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.aia.glory.common.model.GeneralInfomation;

@Component
@ConfigurationProperties(prefix = "generalInfo")
@PropertySource(value = "classpath:generalInfo.properties")
public class InitGeneralInfomationConfig {

	private Map<String, List<GeneralInfomation>> generalInfoMap = new ConcurrentHashMap<>();

	public  Map<String, List<GeneralInfomation>> getGeneralInfoMap() {
		return this.generalInfoMap;
	}

	public  void setGeneralInfoMap(Map<String, List<GeneralInfomation>> generalInfoMap) {
		this.generalInfoMap = generalInfoMap;
	}
}
