package com.aia.glory.onlineservice.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.model.request.GetRuleGroupRequest;

@Mapper
public interface RuleGroupDao {
	@Insert("INSERT INTO RULE_GROUP_TABLE(NAME,DESCRIPTION,COMPANY,CHANNEL,FREQUENCY,PAYMENTFLAG,ACTIVE,SUMMARYTYPE,EFFECTEDSTARTDATE,EFFECTEDENDDATE,CREATEDATE,PERIODTYPE,PERIODINDEX,HOLDFLAG) VALUES(#{name}, #{description},"
			+ "#{company},#{channel},#{frequency},#{paymentFlag},#{activeFlag},#{summaryType},#{effectedStartDate},#{effectedEndDate},GETDATE(),#{periodType},#{periodIndex},#{holdFlag})")
	@Options(useGeneratedKeys=true,keyProperty="ruleGroupModelId")
    public void insertRuleGroup(RuleGroupModel ruleGroupModel);
	
	public List<RuleGroupModel> selectRuleGroup(GetRuleGroupRequest getRuleGroupRequest);
	
	@Select("<script>"
   			+" SELECT * FROM RULE_GROUP_TABLE A"
   			+" WHERE 1=1"
			+" <if test='ruleName != null and ruleName != \"\"'>"
			+"  AND A.NAME = #{ruleName}"
			+"</if>"
			+" <if test='company != null and company != \"\"'>"
			+"  AND A.COMPANY = #{company}"
			+"</if>"
			+" <if test='chaneel != null and chaneel != \"\"'>"
			+"  AND A.CHANNEL = #{chaneel}"
			+"</if>"
   			+"</script>")
	@Results({
	      @Result(property = "ruleGroupModelId",  column = "RULE_GROUP_ID")
	  })
	public List<RuleGroupModel> selectRuleGroupByName(@Param("ruleName")String ruleName,@Param("company")String company,@Param("chaneel")String chaneel);

	@Update("UPDATE RULE_GROUP_TABLE SET NAME=#{name},DESCRIPTION=#{description},COMPANY=#{company},CHANNEL=#{channel},FREQUENCY=#{frequency},"
			+ "PAYMENTFLAG=#{paymentFlag},ACTIVE=#{activeFlag},SUMMARYTYPE=#{summaryType},EFFECTEDSTARTDATE=#{effectedStartDate},EFFECTEDENDDATE=#{effectedEndDate},UPDATEDATE=GETDATE(),PERIODTYPE=#{periodType},PERIODINDEX=#{periodIndex},HOLDFLAG=#{holdFlag} WHERE RULE_GROUP_ID=#{ruleGroupModelId}")
	public Integer updateRuleGroup(RuleGroupModel ruleGroupModel);
	
	@Delete("DELETE FROM RULE_GROUP_TABLE WHERE RULE_GROUP_ID=#{ruleGroupModelId}")
	public Integer deleteRuleGroup(@Param("ruleGroupModelId")String ruleGroupModelId);
	
	@Select("<script>"
   			+" SELECT COUNT(1)"
   			+" FROM RULE_GROUP_TABLE A"
   			+" WHERE 1=1"
			+" <if test='name != null and name != \"\"'>"
			+"  AND A.NAME like CONCAT(#{name},'%')"
			+"</if>"
			+" <if test='company!=null and company != \"\"'>"
			+"  AND A.COMPANY = #{company}"
			+"</if>"
			+" <if test='channel!=null and channel != \"\"'>"
			+"  AND A.CHANNEL=#{channel}"
			+"</if>"
			+" <if test='paymentFlag!=null and paymentFlag != \"\"'>"
			+" AND A.PAYMENTFLAG=#{paymentFlag}"
			+"</if>"
			+" <if test='frequency!=null and frequency != \"\"'>"
			+"  AND A.FREQUENCY=#{frequency}"
			+"</if>"
			+" <if test='description!=null and description != \"\"'>"
			+" AND A.DESCRIPTION like CONCAT(#{description},'%')"
			+"</if>"
			+" <if test='ruleGroupModelId!=null and ruleGroupModelId != \"\"'>"
			+" AND A.RULE_GROUP_ID=#{ruleGroupModelId}"
			+"</if>"
			+" <if test='summaryType!=null and summaryType != \"\"'>"
			+" AND A.SUMMARYTYPE=#{summaryType}"
			+"</if>"
			+" <if test='activeFlag!=null and activeFlag != \"\"'>"
			+" AND A.ACTIVE=#{activeFlag}"
			+"</if>"
   			+"</script>")
	public Integer selectRuleGroupTotal(GetRuleGroupRequest getRuleGroupRequest);
}
