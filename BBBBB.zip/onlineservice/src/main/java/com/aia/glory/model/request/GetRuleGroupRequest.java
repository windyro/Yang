package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;

public class GetRuleGroupRequest extends Request{
    
	private String ruleGroupModelId;
	
	private String name;
	
    private String channel;
	
    private String company;
	
    private String paymentFlag;
	
    private String frequency;
	
    private String description; 
    
    private String summaryType;
    
    private String activeFlag;
    
    private int startPage = 0;
	
   	private int pageSize = 0;
    
//    private PaginationModel paginationModel;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPaymentFlag() {
		return paymentFlag;
	}

	public void setPaymentFlag(String paymentFlag) {
		this.paymentFlag = paymentFlag;
	}

//	public PaginationModel getPaginationModel() {
//		return paginationModel;
//	}
//
//	public void setPaginationModel(PaginationModel paginationModel) {
//		this.paginationModel = paginationModel;
//	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRuleGroupModelId() {
		return ruleGroupModelId;
	}

	public void setRuleGroupModelId(String ruleGroupModelId) {
		this.ruleGroupModelId = ruleGroupModelId;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getSummaryType() {
		return summaryType;
	}

	public void setSummaryType(String summaryType) {
		this.summaryType = summaryType;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
    
}
