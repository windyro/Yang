package com.aia.glory.onlineservice.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.model.rule.CalculateModel;
import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.common.util.ErrorMessageUtils;
import com.aia.glory.common.util.GloryValidatorUtil;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.common.util.TimeUtils;
import com.aia.glory.common.validator.RuleGroupModelValidator;
import com.aia.glory.model.request.CreateRuleGroupRequest;
import com.aia.glory.model.request.DeleteRuleGroupRequest;
import com.aia.glory.model.request.GetRuleGroupRequest;
import com.aia.glory.model.request.UpdateRuleGroupRequest;
import com.aia.glory.model.response.CreateRuleGroupResponse;
import com.aia.glory.model.response.DeleteRuleGroupResponse;
import com.aia.glory.model.response.GetRuleGroupResponse;
import com.aia.glory.model.response.UpdateRuleGroupResponse;
import com.aia.glory.onlineservice.enumerate.ReasonCode;
import com.aia.glory.onlineservice.service.RuleDetailService;
import com.aia.glory.onlineservice.service.RuleGroupService;

@RestController
public class RuleGroupController {
	
	Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	@Autowired
	public RuleGroupService ruleGroupService;
	
	@Autowired
	public RuleDetailService ruleDetailService;
	
	@RequestMapping(value = "/ruleGroup", method = RequestMethod.POST)
	@ResponseBody
	public Response postRuleGroup(HttpServletRequest request,@RequestBody String requestBody) throws IOException{
		
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		Response response = null;
		
		switch (action) {
		case "INSERT":
			response = insertRuleGroup(requestBody);
			break;
		case "UPDATE":
			response = updateRuleGroup(requestBody);
			break;
		case "GET":
			response = queryRuleGroup(requestBody);
			break;	
		case "DELETE":
			response = deleteRuleGroup(requestBody);
			break;
		default:
			break;
		}
		
		return response;
	}
	
	public CreateRuleGroupResponse insertRuleGroup(String requestBody) throws IOException {
		CreateRuleGroupRequest createRuleGroupRequest= (CreateRuleGroupRequest) JsonToObjectUtil.jsonToObj(new CreateRuleGroupRequest(), requestBody);
		
		RuleGroupModel ruleGroupModel = createRuleGroupRequest.getRuleGroupModel();
		/*String errorMsg = GloryValidatorUtil.dovBeenValidate(ruleGroupModel);
		if(!errorMsg.isEmpty()) {
			return CreateRuleGroupResponse.fail(ResponseCode.WARNING, errorMsg);
		}*/
		Errors errors = new BeanPropertyBindingResult(new RuleGroupModel(), "ruleGroupModel");
		new RuleGroupModelValidator().validate(ruleGroupModel, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 CreateRuleGroupResponse createRuleGroupResponse = CreateRuleGroupResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return createRuleGroupResponse;
		}
		if(ruleGroupService.checkRuleGroupByName(ruleGroupModel.getName(),
				ruleGroupModel.getCompany(),
				ruleGroupModel.getChannel(),
				ruleGroupModel.getRuleGroupModelId())) {
			return CreateRuleGroupResponse.fail(ResponseCode.WARNING, ReasonCode.RULENAME_EXIST_EXCEPTION.getCode(),ReasonCode.RULENAME_EXIST_EXCEPTION.getDesc());
		}
		ruleGroupService.insertRuleGroup(ruleGroupModel);
		
		String ruleGroupModelId = ruleGroupModel.getRuleGroupModelId();
		List<RuleDetailModel> ruleDetailLst = ruleGroupModel.getRuleDetailModelList();
		if(ruleDetailLst != null && !ruleDetailLst.isEmpty()) {
			for (RuleDetailModel ruleDetailModel : ruleDetailLst) 
			{
				List<RuleModel> ruleModeList = ruleDetailModel.getRuleModelList();
				String ruleModeData = JsonToObjectUtil.objToJson(ruleModeList);
				CalculateModel calMode = ruleDetailModel.getCalculateModel();
				String calModeData = JsonToObjectUtil.objToJson(calMode);
				ruleDetailService.insertRuleDetail(ruleModeData, calModeData,ruleGroupModelId);
			}
		}
		
		
		return CreateRuleGroupResponse.success(ResponseCode.NORMAL);
	}
	
	public GetRuleGroupResponse queryRuleGroup(String requestBody) throws IOException
	{
		
	    GetRuleGroupRequest getRuleGroupRequest= (GetRuleGroupRequest) JsonToObjectUtil.jsonToObj(new GetRuleGroupRequest(), requestBody);
	    String errorMsg = GloryValidatorUtil.dovBeenValidate(getRuleGroupRequest);
		if(!errorMsg.isEmpty()) {
			return GetRuleGroupResponse.fail(ResponseCode.WARNING, errorMsg);
		}
	    int total = ruleGroupService.selectRuleGroupTotal(getRuleGroupRequest);;
		List<RuleGroupModel> ruleGroupModelLst = ruleGroupService.selectRuleGroup(getRuleGroupRequest);
		for (RuleGroupModel ruleGroupModel : ruleGroupModelLst) {
			ruleGroupModel.setEffectedStartDate(TimeUtils.getDateString(ruleGroupModel.getEffectedStartDate()));
			ruleGroupModel.setEffectedEndDate(TimeUtils.getDateString(ruleGroupModel.getEffectedEndDate()));

			List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
			List<Map<String, Object>> ruleDetailResList = ruleDetailService
					.selectRuleDetail(ruleGroupModel.getRuleGroupModelId());
			for (Map<String, Object> map : ruleDetailResList) {
				String ruleModelData = (String) map.get("RULE_MODEL_DATA");
				String calculateModelData = (String) map.get("CALCULATE_MODEL_DATA");
				String ruleDetailModelId = Long.toString((Long) map.get("RULE_DETAIL_ID"));
				String ruleGroupModelId = Long.toString((Long) map.get("RULE_GROUP_ID"));
				try {
					List<RuleModel> ruleModeList = (List<RuleModel>) JsonToObjectUtil
							.jsonToObj(new ArrayList<RuleModel>(), ruleModelData);
					CalculateModel calculateModel = (CalculateModel) JsonToObjectUtil.jsonToObj(new CalculateModel(),
							calculateModelData);
					RuleDetailModel ruleDetailModel = new RuleDetailModel();
					ruleDetailModel.setRuleDetailModelId(ruleDetailModelId);
					ruleDetailModel.setRuleGroupModelId(ruleGroupModelId);
					ruleDetailModel.setRuleModelList(ruleModeList);
					ruleDetailModel.setCalculateModel(calculateModel);
					ruleDetailModelList.add(ruleDetailModel);
					ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return GetRuleGroupResponse.success(ResponseCode.NORMAL, ruleGroupModelLst, total);
	} 
	
	public UpdateRuleGroupResponse updateRuleGroup(String requestBody) throws IOException
	{
		UpdateRuleGroupRequest updateRuleGroupRequest= (UpdateRuleGroupRequest) JsonToObjectUtil.jsonToObj(new UpdateRuleGroupRequest(), requestBody);
		
		RuleGroupModel ruleGroupModel = updateRuleGroupRequest.getRuleGroupModel();
		/*String errorMsg = GloryValidatorUtil.dovBeenValidate(ruleGroupModel);
		if(!errorMsg.isEmpty()) {
			return UpdateRuleGroupResponse.fail(ResponseCode.WARNING, errorMsg);
		}*/
		Errors errors = new BeanPropertyBindingResult(new RuleGroupModel(), "ruleGroupModel");
		new RuleGroupModelValidator().validate(ruleGroupModel, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 UpdateRuleGroupResponse updateRuleGroupResponse = UpdateRuleGroupResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return updateRuleGroupResponse;
		}
		if(ruleGroupService.checkRuleGroupByName(ruleGroupModel.getName(),
				ruleGroupModel.getCompany(),
				ruleGroupModel.getChannel(),
				ruleGroupModel.getRuleGroupModelId())) {
			return UpdateRuleGroupResponse.fail(ResponseCode.WARNING, ReasonCode.RULENAME_EXIST_EXCEPTION.getCode(), ReasonCode.RULENAME_EXIST_EXCEPTION.getDesc());
		}
		/*String errorMsg = getErrorMessage(ruleGroupModel);
		if(!errorMsg.isEmpty())
		{
			return UpdateRuleGroupResponse.fail(ResponseCode.WARNING, errorMsg);
		}*/
		int num = ruleGroupService.updateRuleGroup(ruleGroupModel);
		if (num == 0) 
		{
			return UpdateRuleGroupResponse.success(ResponseCode.NORMAL);
		}
		
		String ruleGroupModelId = ruleGroupModel.getRuleGroupModelId();
		List<Map<String, Object>> ruleDetailList = ruleDetailService.selectRuleDetailByRuleGroupId(ruleGroupModelId);
		if (!ruleDetailList.isEmpty()) 
		{
			ruleDetailService.deleteRuleDetailByRuleGroupId(ruleGroupModelId);
		}
		
		List<RuleDetailModel> ruleDetailLst = ruleGroupModel.getRuleDetailModelList();
		if(ruleDetailLst != null && !ruleDetailLst.isEmpty()) {
			for (RuleDetailModel ruleDetailModel : ruleDetailLst) 
			{
				if (ruleDetailModel != null) 
				{
					List<RuleModel> ruleModeList = ruleDetailModel.getRuleModelList();
					String ruleModelData = JsonToObjectUtil.objToJson(ruleModeList);
					CalculateModel calMode = ruleDetailModel.getCalculateModel();
					String calModeData = JsonToObjectUtil.objToJson(calMode);
					ruleDetailService.updateRuleDetailByRuleGroupId(ruleModelData, calModeData, ruleGroupModelId);
				}
			}
		}
		
		
		return UpdateRuleGroupResponse.success(ResponseCode.NORMAL);
	}
	
	public DeleteRuleGroupResponse deleteRuleGroup(String requestBody) throws IOException
	{
		DeleteRuleGroupRequest deleteRuleGroupRequest =  (DeleteRuleGroupRequest) JsonToObjectUtil.jsonToObj(new DeleteRuleGroupRequest(), requestBody);
		String ruleGroupModelId = deleteRuleGroupRequest.getRuleGroupModelId();
		
		ruleGroupService.deleteRuleGroup(ruleGroupModelId);
		
		return DeleteRuleGroupResponse.success(ResponseCode.NORMAL);
	}
	
}
