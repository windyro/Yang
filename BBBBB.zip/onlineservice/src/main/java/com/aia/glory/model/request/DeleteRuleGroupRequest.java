package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;

public class DeleteRuleGroupRequest extends Request{
	
	private String ruleGroupModelId;
	
//	private String ruleDetailModelId;

	public String getRuleGroupModelId() {
		return ruleGroupModelId;
	}

	public void setRuleGroupModelId(String ruleGroupModelId) {
		this.ruleGroupModelId = ruleGroupModelId;
	}

//	public String getRuleDetailModelId() {
//		return ruleDetailModelId;
//	}
//
//	public void setRuleDetailModelId(String ruleDetailModelId) {
//		this.ruleDetailModelId = ruleDetailModelId;
//	}
	
	
	
}
