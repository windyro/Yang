package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class DeleteRuleGroupResponse extends Response
{
	public static DeleteRuleGroupResponse success(ResponseCode responseCode) {
		DeleteRuleGroupResponse deleteRuleGroupResponse = new DeleteRuleGroupResponse();
		deleteRuleGroupResponse.setResponseCode(responseCode.getCode());
		deleteRuleGroupResponse.setReasonCode(Arrays.asList("0000"));
		deleteRuleGroupResponse.setReasonDesc(Arrays.asList(""));
		return deleteRuleGroupResponse;
	}
}
