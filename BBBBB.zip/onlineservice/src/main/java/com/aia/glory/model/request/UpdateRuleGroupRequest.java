package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.common.model.rule.RuleGroupModel;

public class UpdateRuleGroupRequest extends Request{
	
	private RuleGroupModel ruleGroupModel;

	public RuleGroupModel getRuleGroupModel() {
		return ruleGroupModel;
	}

	public void setRuleGroupModel(RuleGroupModel ruleGroupModel) {
		this.ruleGroupModel = ruleGroupModel;
	}
}
