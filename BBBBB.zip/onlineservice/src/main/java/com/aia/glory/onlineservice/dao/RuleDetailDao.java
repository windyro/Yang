package com.aia.glory.onlineservice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface RuleDetailDao {
	@Insert("INSERT INTO RULE_DETAILL_TABLE(RULE_MODEL_DATA,CALCULATE_MODEL_DATA,RULE_GROUP_ID,CREATEDATE) VALUES(#{ruleModelData}, #{calculateModelData}, #{ruleGroupModelId},GETDATE())")
    public void insertRuleDetail(@Param("ruleModelData") String ruleModelData,@Param("calculateModelData") String calculateModelData,@Param("ruleGroupModelId") String ruleGroupModelId);
	
	@Select("SELECT RULE_DETAIL_ID,RULE_MODEL_DATA,CALCULATE_MODEL_DATA,RULE_GROUP_ID FROM RULE_DETAILL_TABLE WHERE RULE_GROUP_ID = #{ruleGroupModelId}")
	public List<Map<String,Object>> selectRuleDetail(@Param("ruleGroupModelId") String ruleGroupModelId);
	
	@Update("UPDATE RULE_DETAILL_TABLE SET RULE_MODEL_DATA=#{ruleModelData},CALCULATE_MODEL_DATA=#{calculateModelData},RULE_GROUP_ID=#{ruleGroupModelId},UPDATEDATE=GETDATE() WHERE RULE_DETAIL_ID=#{ruleDetailModelId}")
	public Integer updateRuleDetail(@Param("ruleModelData") String ruleModelData,@Param("calculateModelData") String calculateModelData,@Param("ruleGroupModelId") String ruleGroupModelId,@Param("ruleDetailModelId") String ruleDetailModelId);
   
	@Delete("DELETE FROM RULE_DETAILL_TABLE WHERE RULE_DETAIL_ID=#{ruleDetailModelId} AND RULE_GROUP_ID=#{ruleGroupModelId}")
	public Integer deleteRuleDetail(@Param("ruleDetailModelId") String ruleDetailModelId,@Param("ruleGroupModelId")String ruleGroupModelId);
	
	@Select("SELECT RULE_DETAIL_ID,RULE_MODEL_DATA,CALCULATE_MODEL_DATA,RULE_GROUP_ID FROM RULE_DETAILL_TABLE WHERE RULE_GROUP_ID = #{ruleGroupModelId}")
	public List<Map<String, Object>> selectRuleDetailByRuleGroupId(@Param("ruleGroupModelId") String ruleGroupModelId);
	
	@Delete("DELETE FROM RULE_DETAILL_TABLE WHERE RULE_GROUP_ID=#{ruleGroupModelId}")
	public Integer deleteRuleDetailByRuleGroupId(@Param("ruleGroupModelId")String ruleGroupModelId);
	
	@Insert("INSERT INTO RULE_DETAILL_TABLE(RULE_MODEL_DATA,CALCULATE_MODEL_DATA,RULE_GROUP_ID,CREATEDATE,UPDATEDATE) VALUES(#{ruleModelData}, #{calculateModelData}, #{ruleGroupModelId},GETDATE(),GETDATE())")
    public Integer updateRuleDetailByRuleGroupId(@Param("ruleModelData") String ruleModelData,@Param("calculateModelData") String calculateModelData,@Param("ruleGroupModelId") String ruleGroupModelId);
}
