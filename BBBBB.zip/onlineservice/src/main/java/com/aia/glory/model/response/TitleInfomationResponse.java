package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class TitleInfomationResponse extends Response{
	
	private Object title;
	
	public Object getTitle() {
		return title;
	}

	public void setTitle(Object title) {
		this.title = title;
	}

	public static TitleInfomationResponse success(ResponseCode responseCode,Object title) 
	 {        
		TitleInfomationResponse generalInfomationResponse = new TitleInfomationResponse();        
		generalInfomationResponse.setResponseCode(responseCode.getCode());
		generalInfomationResponse.setReasonCode(Arrays.asList("0000"));
		generalInfomationResponse.setReasonDesc(Arrays.asList(""));
		generalInfomationResponse.setTitle(title);
		return generalInfomationResponse;    
		 
	 }

	@Override
	public String toString() {
		return "TitleInfomationResponse [title=" + title + "]" + super.toString();
	}
	
}
