package com.aia.glory.onlineservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.model.request.GetRuleGroupRequest;
import com.aia.glory.onlineservice.dao.RuleGroupDao;

@Service
public class RuleGroupService 
{
	@Autowired
    public RuleGroupDao ruleGroupDao;
	
	 public void insertRuleGroup(RuleGroupModel ruleGroupModel)
	 {
		 ruleGroupDao.insertRuleGroup(ruleGroupModel);
	 }
	 
	 public boolean checkRuleGroupByName(String ruleName,String company,String channel,String ruleId)
	 {
		 List<RuleGroupModel> ruleList = ruleGroupDao.selectRuleGroupByName(ruleName,company,channel);
		 if(ruleList == null || ruleList.isEmpty()) {
			 return false;
		 }else if(ruleList.size() == 1 && ruleList.get(0).getRuleGroupModelId().equals(ruleId)){
			 return false;
		 }else {
			 return true;
		 }
	 }
	 
	 public List<RuleGroupModel> selectRuleGroup(GetRuleGroupRequest getRuleGroupRequest){
		 return ruleGroupDao.selectRuleGroup(getRuleGroupRequest);
	 }
	 
	 public Integer updateRuleGroup(RuleGroupModel ruleGroupModel){
		 return ruleGroupDao.updateRuleGroup(ruleGroupModel);
	 }
	 
	 public Integer deleteRuleGroup(String ruleGroupModelId){
		 return ruleGroupDao.deleteRuleGroup(ruleGroupModelId);
	 }
	 
	 public Integer selectRuleGroupTotal(GetRuleGroupRequest getRuleGroupRequest)
	 {
		 return ruleGroupDao.selectRuleGroupTotal(getRuleGroupRequest);
	 }
}
