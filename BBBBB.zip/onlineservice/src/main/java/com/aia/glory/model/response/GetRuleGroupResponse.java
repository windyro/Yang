package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetRuleGroupResponse extends Response
 {
	private Object ruleGroupModel;
	
	private int total;

	public Object getRuleGroupModel() {
		return ruleGroupModel;
	}

	public void setRuleGroupModel(Object ruleGroupModel) {
		this.ruleGroupModel = ruleGroupModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetRuleGroupResponse success(ResponseCode responseCode) {
		GetRuleGroupResponse getRuleGroupResponse = new GetRuleGroupResponse();
		getRuleGroupResponse.setResponseCode(responseCode.getCode());
		getRuleGroupResponse.setReasonCode(Arrays.asList("0000"));
		getRuleGroupResponse.setReasonDesc(Arrays.asList(""));
		return getRuleGroupResponse;
	}

	public static GetRuleGroupResponse success(ResponseCode responseCode,Object ruleGroupModel,int total) 
	 {        
		 GetRuleGroupResponse getRuleGroupResponse = new GetRuleGroupResponse();        
		 getRuleGroupResponse.setResponseCode(responseCode.getCode());
		 getRuleGroupResponse.setReasonCode(Arrays.asList("0000"));
		 getRuleGroupResponse.setReasonDesc(Arrays.asList(""));
		 getRuleGroupResponse.setRuleGroupModel(ruleGroupModel);
		 getRuleGroupResponse.setTotal(total);
		 return getRuleGroupResponse;    
		 
	 }
	
	public static GetRuleGroupResponse fail(ResponseCode responseCode,String msg) {
		GetRuleGroupResponse getRuleGroupResponse = new GetRuleGroupResponse();
		getRuleGroupResponse.setResponseCode(responseCode.getCode());
		getRuleGroupResponse.setReasonCode(Arrays.asList("0000"));
		getRuleGroupResponse.setReasonDesc(Arrays.asList(msg));
		return getRuleGroupResponse;
	}

	@Override
	public String toString() {
		return "GetRuleGroupResponse [ruleGroupModel=" + ruleGroupModel + ", total=" + total + "]" + super.toString();
	}
	
}
