package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class UpdateRuleGroupResponse extends Response
{
	public static UpdateRuleGroupResponse success(ResponseCode responseCode) {
		UpdateRuleGroupResponse updateRuleGroupResponse = new UpdateRuleGroupResponse();
		updateRuleGroupResponse.setResponseCode(responseCode.getCode());
		updateRuleGroupResponse.setReasonCode(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getCode()));
		updateRuleGroupResponse.setReasonDesc(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getDesc()));
		return updateRuleGroupResponse;
	}
	
	public static <T> UpdateRuleGroupResponse fail(ResponseCode responseCode,T reasonCode,T reasonDesc) {
		UpdateRuleGroupResponse updateRuleGroupResponse = new UpdateRuleGroupResponse();
		updateRuleGroupResponse.setResponseCode(responseCode.getCode());
		updateRuleGroupResponse.setReasonCode(Arrays.asList(reasonCode));
		updateRuleGroupResponse.setReasonDesc(Arrays.asList(reasonDesc));
		return updateRuleGroupResponse;
	}
}
