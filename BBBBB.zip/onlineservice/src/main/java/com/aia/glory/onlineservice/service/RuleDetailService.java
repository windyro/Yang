package com.aia.glory.onlineservice.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.onlineservice.dao.RuleDetailDao;

@Service
public class RuleDetailService 
{
	@Autowired
    public RuleDetailDao ruleDetailDao;
	
	 public void insertRuleDetail(String ruleModelData,String calculateModelData,String ruleGroupModelId)
	 {
		 ruleDetailDao.insertRuleDetail(ruleModelData, calculateModelData,ruleGroupModelId);
	 }
	 
	 public List<Map<String,Object>> selectRuleDetail(String ruleGroupModelId)
	 {
		 List<Map<String,Object>> ruleDetailLst = ruleDetailDao.selectRuleDetail(ruleGroupModelId);
		return ruleDetailLst;
	 }
	 
	 public Integer updateRuleDetail(String ruleModelData,String calculateModelData,String ruleGroupModelId,String ruleDetailModelId){
		 return ruleDetailDao.updateRuleDetail(ruleModelData,calculateModelData,ruleGroupModelId,ruleDetailModelId);
	 }
	 
	 public Integer deleteRuleDetail(String ruleDetailModelId,String ruleGroupModelId){
		return ruleDetailDao.deleteRuleDetail(ruleDetailModelId,ruleGroupModelId);
	 }
	 
	 public List<Map<String, Object>> selectRuleDetailByRuleGroupId(String ruleGroupModelId){
		 return ruleDetailDao.selectRuleDetailByRuleGroupId(ruleGroupModelId);
	 }
	 
	 public Integer deleteRuleDetailByRuleGroupId(String ruleGroupModelId)
	 {
		 return ruleDetailDao.deleteRuleDetailByRuleGroupId(ruleGroupModelId);
	 }
	 
	 public Integer updateRuleDetailByRuleGroupId(String ruleModelData,String calculateModelData,String ruleGroupModelId)
	 {
		 return ruleDetailDao.updateRuleDetailByRuleGroupId(ruleModelData, calculateModelData, ruleGroupModelId);
	 }
}
