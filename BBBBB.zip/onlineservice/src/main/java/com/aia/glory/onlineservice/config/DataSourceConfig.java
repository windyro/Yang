package com.aia.glory.onlineservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(ignoreUnknownFields = false,prefix = "data-source")
public class DataSourceConfig {
	
	    private String jndiName;
	    private String factory;
	    private String driverClassName;
	    private String url;
	    private String username;
	    private String password;
	    private String maxActive;
	    private String maxIdle;
	    private String maxWait;
		public String getJndiName() {
			return jndiName;
		}
		public void setJndiName(String jndiName) {
			this.jndiName = jndiName;
		}
		public String getFactory() {
			return factory;
		}
		public void setFactory(String factory) {
			this.factory = factory;
		}
		public String getDriverClassName() {
			return driverClassName;
		}
		public void setDriverClassName(String driverClassName) {
			this.driverClassName = driverClassName;
		}
		public String getUrl() {
			return url;
		}
		public void setUrl(String url) {
			this.url = url;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getMaxActive() {
			return maxActive;
		}
		public void setMaxActive(String maxActive) {
			this.maxActive = maxActive;
		}
		public String getMaxIdle() {
			return maxIdle;
		}
		public void setMaxIdle(String maxIdle) {
			this.maxIdle = maxIdle;
		}
		public String getMaxWait() {
			return maxWait;
		}
		public void setMaxWait(String maxWait) {
			this.maxWait = maxWait;
		}
	    
}
