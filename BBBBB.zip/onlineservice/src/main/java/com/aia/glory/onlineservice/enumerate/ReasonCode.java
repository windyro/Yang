package com.aia.glory.onlineservice.enumerate;

public enum ReasonCode {
	
	RULE_EXCEPTION("10004","Rule Exception"),
	
	RULENAME_EXIST_EXCEPTION("10005","rule name is existed");
	
	private String code;
	
	private String desc;
	
	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	private ReasonCode(String code, String desc){
		this.code=code;
		this.desc=desc;
	}
	
}
