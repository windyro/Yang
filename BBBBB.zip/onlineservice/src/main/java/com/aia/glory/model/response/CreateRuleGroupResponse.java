package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class CreateRuleGroupResponse extends Response
 {

	public static CreateRuleGroupResponse success(ResponseCode responseCode) {
		CreateRuleGroupResponse createRuleGroupResponse = new CreateRuleGroupResponse();
		createRuleGroupResponse.setResponseCode(responseCode.getCode());
		createRuleGroupResponse.setReasonCode(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getCode()));
		createRuleGroupResponse.setReasonDesc(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getDesc()));
		return createRuleGroupResponse;
	}

	public static <T> CreateRuleGroupResponse fail(ResponseCode responseCode,T reasonCode,T reasonDesc) 
	 {        
		 CreateRuleGroupResponse createRuleGroupResponse = new CreateRuleGroupResponse();        
		 createRuleGroupResponse.setResponseCode(responseCode.getCode());
			createRuleGroupResponse.setReasonCode(Arrays.asList(reasonCode));
			createRuleGroupResponse.setReasonDesc(Arrays.asList(reasonDesc));
		 return createRuleGroupResponse;    
		 
	 }
}
