package com.aia.glory.onlineservice.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.onlineservice.ApplicationTest;
import com.aia.glory.onlineservice.service.RuleGroupService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class RuleGroupServiceTest {
	   
	   @Autowired
	   RuleGroupService ruleGroupService;

	   @Test
	   public void insertRuleGroup()
	   {
		   RuleGroupModel ruleGroupModel = new RuleGroupModel();
		   ruleGroupModel.setName("FYC");
		   ruleGroupModel.setDescription("description detail");
		   ruleGroupModel.setCompany("sample company");
		   ruleGroupModel.setChannel("sample channel");
		   ruleGroupModel.setFrequency("M");
		   ruleGroupModel.setPaymentFlag("Y");
		   ruleGroupModel.setEffectedStartDate("2017-01-01");
		   ruleGroupModel.setEffectedEndDate("2020-01-11");
//		   ruleGroupService.insertRuleGroup(ruleGroupModel);
	   }
	   
	   @Test
	   public void checkruleTest()
	   {
		   boolean flag = ruleGroupService.checkRuleGroupByName("FYC","MM_BU","MMAGY","30667");
		   System.out.println(flag);
	   }

	
}