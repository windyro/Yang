package com.aia.glory.onlineservice;


import javax.naming.InvalidNameException;

import org.junit.Assert;
import org.junit.Test;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.aia.glory.model.request.GetRuleGroupRequest;

@SpringBootApplication
@MapperScan("com.aia.glory.onlineservice.dao")
public class ApplicationTest{

	public static void main(String[] args) throws Exception {
    	
		SpringApplication.run(ApplicationTest.class,args);
    }
   
	@Test
    public void findone() throws InvalidNameException {
		GetRuleGroupRequest user = new GetRuleGroupRequest();
    	user.setAction("POST");
    	 Assert.assertEquals("POST", user.getAction());
    	 
    }
}
