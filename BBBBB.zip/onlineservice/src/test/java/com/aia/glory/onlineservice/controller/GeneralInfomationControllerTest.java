package com.aia.glory.onlineservice.controller;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.aia.glory.onlineservice.ApplicationTest;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
@AutoConfigureMockMvc
public class GeneralInfomationControllerTest {

	@Autowired
	GeneralInfomationController generalInfomationController;
	@Autowired
	protected MockMvc mockMvc;
	
	@Test   
	public void testGeneralInfomation_Channel_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String key = "{\"key\":\"channel\"}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/generalInfomation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(key)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	public void testGeneralInfomation_Company_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String key = "{\"key\":\"company\"}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/generalInfomation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(key)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	public void testGeneralInfomation_Title_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String key = "{\"key\":\"title\"}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/generalInfomation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(key)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	public void testGeneralInfomation_Relationship_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String key = "{\"key\":\"relationship\"}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/generalInfomation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(key)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	public void testGeneralInfomation_Summarytype_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String key = "{\"key\":\"summarytype\"}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/generalInfomation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(key)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	public void testRuleFrequency_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/frequency")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}