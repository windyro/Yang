package com.aia.glory.onlineservice.controller;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.DeleteRuleGroupRequest;
import com.aia.glory.model.request.UpdateRuleGroupRequest;
import com.aia.glory.model.response.GetRuleGroupResponse;
import com.aia.glory.onlineservice.ApplicationTest;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
@AutoConfigureMockMvc
public class RuleGroupControllerTest {
	   
	@Autowired
	RuleGroupController ruleGroupController;
	
	@Autowired
	protected MockMvc mockMvc;
	
	@Test 
	@Transactional
	public void testRuleGroup_InsertSuccessfully_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{

		String input= "{\"action\":\"INSERT\",\"ruleGroupModel\":{\"name\":\"FYCtestd\",\"description\":\"description detail\",\"company\":\"sample company\",\"channel\":\"sample channel\",\"frequency\":\"M\",\"paymentFlag\":\"Y\",\"summaryType\":\"COMM_AGENT\",\"effectedStartDate\":\"2017-01-01\",\"effectedEndDate\":\"2020-01-11\",\"periodType\":\"MONTHLY\",\"periodIndex\":\"0\",\"holdFlag\":\"0\",\"ruleDetailModelList\":[{\"ruleModelList\":[{\"name\":\"Leader Title\",\"criteriaKey\":\"Contributor_LeaderTitle\",\"criteriaValue\":\"TEST_TITLE\",\"ruleTemplateId\":\"T_EQUAL\"},{\"name\":\"Contributor Title\",\"criteriaKey\":\"Contributor_Title\",\"criteriaValue\":\"FSM\",\"ruleTemplateId\":\"T_NOT_EQUAL\"}],\"calculateModel\": {\"parameters\": [{\"name\": \"Contributor Value\", \"criteriaKey\": \"Contributor_Value\"},{\"name\": \"Contributor BALANCE\", \"criteriaKey\":\"Contributor_BALANCE\"}],\"algorithm\":\"X1+X2*0.01\"}}]}}";
		
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	@Transactional
	public void testRuleGroup_InsertInvalidStartDate_ReturnErrorResponse() throws JsonParseException, JsonMappingException, IOException{
		
		String input= "{\"action\":\"INSERT\",\"ruleGroupModel\":{\"name\":\"FYC\",\"description\":\"description detail\",\"company\":\"sample company\",\"channel\":\"sample channel\",\"frequency\":\"M\",\"paymentFlag\":\"Y\",\"effectedStartDate\":\"2**&……0101\",\"effectedEndDate\":\"2020-01-11\",\"ruleDetailModelList\":[{\"ruleModelList\":[{\"criteriaKey\":\"Contributor_LeaderTitle\",\"criteriaValue\":\"TEST_TITLE\",\"ruleTemplateId\":\"T_EQUAL\"},{\"criteriaKey\":\"Contributor_Title\",\"criteriaValue\":\"FSM\",\"ruleTemplateId\":\"T_NOT_EQUAL\"}],\"calculateModel\": {\"parameters\": [{\"name\": \"Contributor Value\", \"criteriaKey\": \"Contributor_Value\"},{\"name\": \"Contributor BALANCE\", \"criteriaKey\":\"Contributor_BALANCE\"}],\"algorithm\":\"X1+X2*0.01\"}}]}}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
//			        			.andExpect(MockMvcResultMatchers.jsonPath("reasonDesc").value("Date format error。"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	   
	@Test   
	@Transactional
	public void testRuleGroup_InsertInvalidEndDate_ReturnErrorResponse() throws JsonParseException, JsonMappingException, IOException{
		String input= "{\"action\":\"INSERT\",\"ruleGroupModel\":{\"name\":\"FYC\",\"description\":\"description detail\",\"company\":\"sample company\",\"channel\":\"sample channel\",\"frequency\":\"M\",\"paymentFlag\":\"Y\",\"effectedStartDate\":\"2017-01-01\",\"effectedEndDate\":\"20（*（&200111\",\"ruleDetailModelList\":[{\"ruleModelList\":[{\"criteriaKey\":\"Contributor_LeaderTitle\",\"criteriaValue\":\"TEST_TITLE\",\"ruleTemplateId\":\"T_EQUAL\"},{\"criteriaKey\":\"Contributor_Title\",\"criteriaValue\":\"FSM\",\"ruleTemplateId\":\"T_NOT_EQUAL\"}],\"calculateModel\": {\"parameters\": [{\"name\": \"Contributor Value\", \"criteriaKey\": \"Contributor_Value\"},{\"name\": \"Contributor BALANCE\", \"criteriaKey\":\"Contributor_BALANCE\"}],\"algorithm\":\"X1+X2*0.01\"}}]}}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
//			        			.andExpect(MockMvcResultMatchers.jsonPath("reasonDesc").value("Date format error。"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test   
	@Transactional
	public void testRuleGroup_InsertInvalidRuleGroupName_ReturnErrorResponse() throws JsonParseException, JsonMappingException, IOException{
		String input= "{\"action\":\"INSERT\",\"ruleGroupModel\":{\"name\":\"F<>*YC\",\"description\":\"description detail\",\"company\":\"sample company\",\"channel\":\"sample channel\",\"frequency\":\"M\",\"paymentFlag\":\"Y\",\"effectedStartDate\":\"2017-01-01\",\"effectedEndDate\":\"2020-01-11\",\"ruleDetailModelList\":[{\"ruleModelList\":[{\"criteriaKey\":\"Contributor_LeaderTitle\",\"criteriaValue\":\"TEST_TITLE\",\"ruleTemplateId\":\"T_EQUAL\"},{\"criteriaKey\":\"Contributor_Title\",\"criteriaValue\":\"FSM\",\"ruleTemplateId\":\"T_NOT_EQUAL\"}],\"calculateModel\": {\"parameters\": [{\"name\": \"Contributor Value\", \"criteriaKey\": \"Contributor_Value\"},{\"name\": \"Contributor BALANCE\", \"criteriaKey\":\"Contributor_BALANCE\"}],\"algorithm\":\"X1+X2*0.01\"}}]}}";
		try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
//			        			.andExpect(MockMvcResultMatchers.jsonPath("reasonDesc").value("Name cannot be input '<','>'......"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	@Test
	public void testRuleGroup_getSuccessfully_ReturnSuccessResponse() throws IOException{
	    String input= "{\"action\":\"GET\",\"name\":\"FYC\",\"company\":\"sample company\",\"channel\":\"sample channel\",\"paymentFlag\":\"Y\",\"frequency\":\"W\",\"description\":\"description\",\"startPage\":1,\"pageSize\":5}";
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	@Test
	public void testRuleGroupEmptyValue_getSuccessfully_ReturnSuccessResponse() throws IOException{
	    String input= "{\"action\":\"GET\",\"name\":\"\",\"company\":\"\",\"channel\":\"\",\"paymentFlag\":\"\",\"frequency\":\"\",\"description\":\"\"}";
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	@Test
	public void testRuleGroupNULL_getSuccessfully_ReturnSuccessResponse() throws IOException{
	    String input= "{\"action\":\"GET\",\"startPage\":\"1\",\"pageSize\":\"5\"}";
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	@Test   
	@Transactional
	public void testRuleGroup_UpdateSuccessfully_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String input= "{\"action\":\"GET\",\"startPage\":\"1\",\"pageSize\":\"5\"}";
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
			
			GetRuleGroupResponse getRuleGroupRequest=  JsonToObjectUtil.jsonToObj(new GetRuleGroupResponse(), mrcresult.getResponse().getContentAsString());
			List<RuleGroupModel> dGroupModels = (List<RuleGroupModel>)JsonToObjectUtil.jsonToComplexObject(JsonToObjectUtil.objToJson(getRuleGroupRequest.getRuleGroupModel()),RuleGroupModel.class);
			
			RuleGroupModel updateRule = dGroupModels.get(0);
			updateRule.setName("testupdate");
			
			UpdateRuleGroupRequest ur = new UpdateRuleGroupRequest();
			ur.setAction("UPDATE");
			ur.setRuleGroupModel(updateRule);
			
			mrcresult = mockMvc.perform(
        			MockMvcRequestBuilders.post("/ruleGroup")
        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
        			.content(JsonToObjectUtil.objToJson(ur))
					)
        			.andExpect(MockMvcResultMatchers.status().isOk())
        			.andDo(MockMvcResultHandlers.print())
        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
        			.andReturn();
	    } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	@Test   
	@Transactional
	public void testRuleGroup_UpdateInvalidRuleGroupName_ReturnErrorResponse() throws JsonParseException, JsonMappingException, IOException{
		String input= "{\"action\":\"GET\",\"startPage\":\"1\",\"pageSize\":\"5\"}";
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
			
			GetRuleGroupResponse getRuleGroupRequest=  JsonToObjectUtil.jsonToObj(new GetRuleGroupResponse(), mrcresult.getResponse().getContentAsString());
			List<RuleGroupModel> dGroupModels = (List<RuleGroupModel>)JsonToObjectUtil.jsonToComplexObject(JsonToObjectUtil.objToJson(getRuleGroupRequest.getRuleGroupModel()),RuleGroupModel.class);
			
			RuleGroupModel updateRule = dGroupModels.get(0);
			updateRule.setName("F<>*YC");
			
			UpdateRuleGroupRequest ur = new UpdateRuleGroupRequest();
			ur.setAction("UPDATE");
			ur.setRuleGroupModel(updateRule);
			
			mrcresult = mockMvc.perform(
        			MockMvcRequestBuilders.post("/ruleGroup")
        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
        			.content(JsonToObjectUtil.objToJson(ur))
					)
        			.andExpect(MockMvcResultMatchers.status().isOk())
        			.andDo(MockMvcResultHandlers.print())
        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
//        			.andExpect(MockMvcResultMatchers.jsonPath("reasonDesc").value("Name cannot be input '<','>'......"))
        			.andReturn();
	    } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		
	}
	
	@Test  
	@Transactional
	public void testRuleGroup_deleteSuccessfully_ReturnSuccessResponse() throws JsonParseException, JsonMappingException, IOException{
		String input= "{\"action\":\"GET\",\"startPage\":\"1\",\"pageSize\":\"5\"}";
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/ruleGroup")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(input)
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
			
			GetRuleGroupResponse getRuleGroupRequest=  JsonToObjectUtil.jsonToObj(new GetRuleGroupResponse(), mrcresult.getResponse().getContentAsString());
			List<RuleGroupModel> dGroupModels = (List<RuleGroupModel>)JsonToObjectUtil.jsonToComplexObject(JsonToObjectUtil.objToJson(getRuleGroupRequest.getRuleGroupModel()),RuleGroupModel.class);
			
			DeleteRuleGroupRequest dr = new DeleteRuleGroupRequest();
			dr.setAction("DELETE");
			dr.setRuleGroupModelId(dGroupModels.get(0).getRuleGroupModelId());
			
			mrcresult = mockMvc.perform(
        			MockMvcRequestBuilders.post("/ruleGroup")
        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
        			.content(JsonToObjectUtil.objToJson(dr))
					)
        			.andExpect(MockMvcResultMatchers.status().isOk())
        			.andDo(MockMvcResultHandlers.print())
        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
        			.andReturn();
	    } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}

}