package com.aia.glory.common.util;

import org.junit.Assert;
import org.junit.Test;

public class ExceptionUtilsTest {
	   
	@Test
    public void encryptTest() {
		String log = LogUtils.errorTrackSpace(new Exception("test"));
    	System.out.println(log);
    	Assert.assertNotNull(log);
	}
	
}
