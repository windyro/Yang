package com.aia.glory.common.validator;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.util.ErrorMessageUtils;

public class ValidatorTest {
	
	@Test
	public  void ruleGroupModelTest() throws IOException
	{
		RuleGroupModel rgm = new RuleGroupModel();
		rgm.setActiveFlag("1");
		rgm.setChannel("test");
		rgm.setCompany("test");
		rgm.setCreatDate("2020-01-01");
		rgm.setDescription("test");
		rgm.setEffectedStartDate("2020-01-01");
		rgm.setEffectedEndDate("2020-02-02");
		rgm.setFrequency("test");
		rgm.setHoldFlag("1");
		rgm.setName("test");
		rgm.setPaymentFlag("1");
		rgm.setPeriodIndex("2");
		rgm.setPeriodType("d");
		rgm.setRuleGroupModelId("1");
		rgm.setSummaryType("w");
		rgm.setUpdateDate("2020-02-2");
		
		Errors error = new BeanPropertyBindingResult(new RuleGroupModel(), "ruleGroupModel");
		RuleGroupModelValidator rv = new RuleGroupModelValidator();
		rv.validate(rgm, error);
		if (error.hasErrors()){
			
			System.out.println("TEST");
			
	    }
		
		Assert.assertEquals( "test", rgm.getChannel());
	}
	
}
