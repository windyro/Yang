package com.aia.glory.common.util;

import org.junit.Assert;
import org.junit.Test;

public class DESUtilsTest {
	   
	@Test
    public void encryptTest() {
		String string = DESUtil.DESencode("223", "refy5678");
		System.out.println(string);
		String string2 = DESUtil.DESdecode(string, "refy5678");
		System.out.println(string2);
    	
    	Assert.assertEquals( "223", string2);
	}
	
}
