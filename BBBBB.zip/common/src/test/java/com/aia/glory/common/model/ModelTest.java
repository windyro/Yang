package com.aia.glory.common.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.ExceptionResponse;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.rule.CalculateModel;
import com.aia.glory.common.model.rule.CalculateParameter;
import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.model.rule.RuleModel;

public class ModelTest {

	
	@Test
	public  void generalInfomationTest() throws IOException
	{
		GeneralInfomation gi = new GeneralInfomation();
		gi.setSeq("12");
		gi.setName("hehe");
		gi.setDescription("ewfdfd");
		
		Assert.assertEquals( "hehe", gi.getName());
	}
	
	@Test
	public  void paginationModelTest() throws IOException
	{
		PaginationModel pagination = new PaginationModel();
		pagination.setPageSize(10);
		pagination.setStartPage(1);
		Assert.assertEquals( 10, pagination.getPageSize());
	}
	
	@Test
	public  void calculateModelTest() throws IOException
	{
		CalculateModel calculateModel = new CalculateModel();
		calculateModel.setAlgorithm("test");
		calculateModel.setName("test");
		CalculateParameter cp = new CalculateParameter();
		cp.setCriteriaKey("123456");
		cp.setCriteriaValue("123");
		cp.setName("testcp");
		List<CalculateParameter> cpList = new ArrayList<>();
		cpList.add(cp);
		calculateModel.setParameters(cpList);
		Assert.assertEquals( "test", calculateModel.getName());
	}
	
	@Test
	public  void ruleDetailModelTest() throws IOException
	{
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setCreatDate("2020-01-01");
		ruleDetailModel.setRuleDetailModelId("12");
		ruleDetailModel.setRuleGroupModelId("22");
		ruleDetailModel.setUpdateDate("2020-01-02");
		RuleModel rm = new RuleModel();
		rm.setComplicatedModelInd("test");
		rm.setCriteriaKey("key1");
		rm.setCriteriaValue("12");
		rm.setFunctionParameters("d*1");
		rm.setName("plus");
		rm.setRuleModelId("12");
		rm.setRuleTemplateId("22");
		
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(rm);
		
		CalculateModel calculateModel = new CalculateModel();
		calculateModel.setAlgorithm("test");
		calculateModel.setName("test");
		
		ruleDetailModel.setRuleModelList(ruleModelList);
		ruleDetailModel.setCalculateModel(calculateModel);
		Assert.assertEquals( "12", ruleDetailModel.getRuleDetailModelId());
	}
	
	@Test
	public  void ruleGroupModelTest() throws IOException
	{
		RuleGroupModel rgm = new RuleGroupModel();
		rgm.setActiveFlag("1");
		rgm.setChannel("test");
		rgm.setCompany("test");
		rgm.setCreatDate("2020-01-01");
		rgm.setDescription("test");
		rgm.setEffectedStartDate("2020-01-01");
		rgm.setEffectedEndDate("2020-02-02");
		rgm.setFrequency("test");
		rgm.setHoldFlag("1");
		rgm.setName("test");
		rgm.setPaymentFlag("1");
		rgm.setPeriodIndex("2");
		rgm.setPeriodType("d");
		rgm.setRuleGroupModelId("1");
		rgm.setSummaryType("w");
		rgm.setUpdateDate("2020-02-2");
		Assert.assertEquals( "test", rgm.getChannel());
	}
	
	@Test
	public  void exceptionResponseSuccessTest() throws IOException
	{
		ExceptionResponse er = ExceptionResponse.success(ResponseCode.NORMAL);
		Assert.assertEquals( "000", er.getResponseCode());
	}
	
	@Test
	public  void exceptionResponseFailTest() throws IOException
	{
		ExceptionResponse er = ExceptionResponse.fail(ResponseCode.ERROR, "test");
		Assert.assertEquals( "008", er.getResponseCode());
		Assert.assertEquals( "test", er.getReasonDesc().get(0));
	}
	
	@Test
	public  void generyResponseSuccessTest() throws IOException
	{
		GeneryResponse gr = GeneryResponse.success(ResponseCode.NORMAL, "test");
		Assert.assertEquals( "000", gr.getResponseCode());
	}
	
	@Test
	public  void generyResponseSuccess2Test() throws IOException
	{
		GeneryResponse gr = GeneryResponse.success();
		Assert.assertEquals( "000", gr.getResponseCode());
	}
	
	@Test
	public  void generyResponseSuccess3Test() throws IOException
	{
		GeneryResponse gr = GeneryResponse.success(ResponseCode.NORMAL, "test",22);
		Assert.assertEquals( "000", gr.getResponseCode());
	}
	
	@Test
	public  void generyResponseWarnTest() throws IOException
	{
		GeneryResponse gr = GeneryResponse.warn("warn");
		Assert.assertEquals( "004", gr.getResponseCode());
	}
	
	@Test
	public  void generyResponseFailTest() throws IOException
	{
		GeneryResponse gr = GeneryResponse.fail("fail");
		Assert.assertEquals( "008", gr.getResponseCode());
	}
	

	@Test
	public  void generyResponseFail2Test() throws IOException
	{
		GeneryResponse gr = GeneryResponse.fail(ResponseCode.ERROR,ReasonCode.EFFSD_NULL_ERROR, "test");
		System.out.println(gr.getReasonCode());
		Assert.assertEquals( "008", gr.getResponseCode());
		Assert.assertEquals( "test", gr.getReasonDesc().get(0));
	}
	
	
}
