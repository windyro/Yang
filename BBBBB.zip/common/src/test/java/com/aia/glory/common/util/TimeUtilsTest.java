package com.aia.glory.common.util;

import java.text.ParseException;

import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class TimeUtilsTest {
	   
	@Test
    public void getDateStringTest() {
		String string = TimeUtils.getDateString("2020-01-01 12:01:01.111");
		System.out.println(string);
    	Assert.assertEquals("2020-01-01",string);
	}
	
	@Test
    public void getMonthTest() {
		String string = TimeUtils.getDateMonthStr("January 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("February 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("March 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("April 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("May 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("June 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("July 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("August 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("September 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("October 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("November 2020");
		System.out.println(string);
		string = TimeUtils.getDateMonthStr("Dec 2020");
		System.out.println(string);
    	Assert.assertEquals("2020-12",string);
	}
	
	@Test
    public void parseSystemPeriodTest() {
		String string;
		try {
			string = TimeUtils.parseSystemPeriod("2020-01");
			System.out.println(string);
			Assert.assertEquals("January 2020",string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	
	}
	
	@Test
    public void monthComparisonTest() {
		int string;
		try {
			string = TimeUtils.monthComparison("2020-01","2020-06","yyyy-MM","yyyy-MM");
			System.out.println(string);
			Assert.assertEquals(5,string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	
	}
	
	@Test
    public void getQualterTest() {
		int string;
		try {
			string = TimeUtils.getQualter("2020-01","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.getQualter("2020-05","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.getQualter("2020-08","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.getQualter("2020-11","yyyy-MM");
			System.out.println(string);
			Assert.assertEquals(4,string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void getYearTest() {
		int string;
		try {
			string = TimeUtils.getYear("2020-01","yyyy-MM");
			System.out.println(string);
			Assert.assertEquals(2020,string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void isPeriodMonthQuaterEndTest() {
		boolean string;
		try {
			string = TimeUtils.isPeriodMonthQuaterEnd("2020-03","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthQuaterEnd("2020-06","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthQuaterEnd("2020-07","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthQuaterEnd("2020-09","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthQuaterEnd("2020-12","yyyy-MM");
			System.out.println(string);
			Assert.assertEquals(true,string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void isPeriodMonthYearEndTest() {
		boolean string;
		try {
			string = TimeUtils.isPeriodMonthYearEnd("2020-03","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthYearEnd("2020-06","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthYearEnd("2020-07","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthYearEnd("2020-09","yyyy-MM");
			System.out.println(string);
			string = TimeUtils.isPeriodMonthYearEnd("2020-12","yyyy-MM");
			System.out.println(string);
			Assert.assertEquals(true,string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void parseStringToDateTest() {
		Date string;
		try {
			string = TimeUtils.parseStringToDate("2020-03","yyyy-MM");
			System.out.println(string);
			
			Assert.assertEquals(string.toString(),string.toString());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void isDateInEffectivePeriodTest() {
		boolean string;
		try {
			string = TimeUtils.isDateInEffectivePeriod(TimeUtils.parseStringToDate("2020-04-04","yyyy-MM"),
					TimeUtils.parseStringToDate("2020-03-01","yyyy-MM"),
					TimeUtils.parseStringToDate("2020-03-23","yyyy-MM"));
			System.out.println(string);
			
			string = TimeUtils.isDateInEffectivePeriod(TimeUtils.parseStringToDate("2020-03-04","yyyy-MM"),
					TimeUtils.parseStringToDate("2020-03-01","yyyy-MM"),
					TimeUtils.parseStringToDate("2020-03-23","yyyy-MM"));
			System.out.println(string);
			
			Assert.assertEquals(true,string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void getDiffDateByDateTest() {
		String string;
		try {
			string = TimeUtils.getDiffDateByDate("2020-04-04",1);
			System.out.println(string);
			
			Assert.assertEquals("2020-04-05",string);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
    public void convertDateStringTest() {
		String string;
		try {
			string = TimeUtils.convertDateString("2020-04-04","yyyy-MM-dd","yyyy MM");
			System.out.println(string);
			
			Assert.assertEquals("2020 04",string);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
