package com.aia.glory.common.util;

import java.io.IOException;

import org.junit.Test;

import com.aia.glory.common.model.rule.RuleGroupModel;

import org.junit.Assert;

public class ByteArrayUtilsTest {
	
	@Test
	public  void byteToObjTest() throws IOException
	{
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		
		ruleGroupModel.setName("hehe");
		ruleGroupModel.setDescription("ewfdfd");
		ruleGroupModel.setCompany("rttt");
		byte[] bytes = ByteArrayUtils.objectToBytes(ruleGroupModel);
		
		RuleGroupModel newObj = (RuleGroupModel)ByteArrayUtils.bytesToObject(bytes);
		System.out.println(newObj.getName());
		Assert.assertEquals( "hehe", newObj.getName());
	}

}
