package com.aia.glory.common.util;

import org.junit.Assert;
import org.junit.Test;

public class EncryptUtilsTest {
	   
	@Test
    public void encryptTest() {
    	String string = EncryptUtil.AESencode("dsf", "1234");
    	System.out.println(string);
    	String string2=EncryptUtil.AESdecode(string,"1234");
    	System.out.println(string2);
    	
    	Assert.assertEquals( "dsf", string2);
	}
}
