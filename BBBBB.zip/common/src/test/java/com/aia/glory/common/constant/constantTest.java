package com.aia.glory.common.constant;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

public class constantTest {
	@Test
	public  void actionTypeTest() throws IOException
	{
		String string = ActionTypeConstant.POST;
		System.out.println(string);
		string = ActionTypeConstant.GET;
		System.out.println(string);
		string = ActionTypeConstant.UPDATE;
		System.out.println(string);
		string = ActionTypeConstant.DELETE;
		System.out.println(string);
		Assert.assertEquals( "DELETE", string);
	}
	
	@Test
	public  void commonConstantTest() throws IOException
	{
		String string = CommonConstant.YES;
		System.out.println(string);
		string = CommonConstant.NO;
		System.out.println(string);
		string = CommonConstant.COMMA;
		System.out.println(string);
		string = CommonConstant.EQUAL_MARK;
		System.out.println(string);
		Assert.assertEquals( "=", string);
	}
}
