package com.aia.glory.common.util;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aia.glory.common.model.rule.CalculateModel;
import com.aia.glory.common.model.rule.CalculateParameter;
import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.model.rule.RuleModel;

public class JsonToObjectUtilTest {
	
	@Test
	public  void objectToJsonTest() throws IOException
	{
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		
		ruleGroupModel.setName("hehe");
		ruleGroupModel.setDescription("ewfdfd");
		ruleGroupModel.setCompany("rttt");
		
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		CalculateModel calculateModel = new CalculateModel();
		calculateModel.setName("formula");
		calculateModel.setAlgorithm( "X1+X2*0.01");
		List<String> list = new ArrayList<String>();
		list.add("dd");
		
		List<CalculateParameter> lists = new ArrayList<CalculateParameter>();
		CalculateParameter parameter = new CalculateParameter();
		parameter.setName("Contributor Value");
		parameter.setCriteriaKey("Contributor_Value");
		CalculateParameter parameter1 = new CalculateParameter();
		parameter1.setName("Contributor BALANCE");
		parameter1.setCriteriaKey("Contributor_BALANCE");
		lists.add(parameter1);
		lists.add(parameter);
		calculateModel.setParameters(lists);
		ruleDetailModel.setCalculateModel(calculateModel);
		ruleDetailModelList.add(ruleDetailModel);
		
		RuleModel ruleModel1  = new RuleModel();
		ruleModel1.setRuleTemplateId("ji");
		
		RuleModel ruleModel2  = new RuleModel();
		ruleModel2.setRuleTemplateId("jr");
		ruleModelList.add(ruleModel1);
		ruleModelList.add(ruleModel2);
		ruleDetailModel.setRuleModelList(ruleModelList);
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		String jsonStr = JsonToObjectUtil.objToJson(ruleGroupModel);	
		System.out.println(jsonStr);
		
		Object obj = JsonToObjectUtil.jsonToObj(new RuleGroupModel(), jsonStr);		
		System.out.println(obj.toString());
		
		String ruleModelData = "[{\"ruleModelId\":null,\"name\":\"Relationship\",\"criteriaKey\":\"Relationship\",\"criteriaValue\":\"DIRECT\",\"ruleTemplateId\":\"T_EQUAL\"},{\"ruleModelId\":null,\"name\":\"Receiver Title\",\"criteriaKey\":\"Receiver_Title\",\"criteriaValue\":\"UM\",\"ruleTemplateId\":\"T_EQUAL\"},{\"ruleModelId\":null,\"name\":\"Contributor Title\",\"criteriaKey\":\"Contributor_Title\",\"criteriaValue\":\"UM\",\"ruleTemplateId\":\"T_EQUAL\"}]";
		List<RuleModel> ruleModelLst = (List<RuleModel>) JsonToObjectUtil.jsonToComplexObject(ruleModelData,RuleModel.class);
		System.out.print(ruleModelLst);
		Assert.assertNotNull(ruleModelLst);
	}


	
}
