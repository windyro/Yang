package com.aia.glory.common.util;

import org.junit.Assert;
import org.junit.Test;

public class JwtUtilsTest {
	   
	@Test
    public void encryptTest() {
		String token = JwtUtil.createJWT(10000, "1234", "test", "a1");
		System.out.println(token);
		token = JwtUtil.refresh(token);
		boolean flag = JwtUtil.isVerify(token);
    	Assert.assertTrue(flag);
	}
	
}
