package com.aia.glory.common.util;

import java.security.Key;
import java.security.Provider;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class DESUtil {

	public static final String DES = "DES";

	public static final String DESMODE = "DES/ECB/PKCS5Padding";

	public static String charset = "utf-8";
	private static String jdkvs = System.getProperty("java.vm.vendor");
	public static int keysizeDES = 0;

	private DESUtil() {
		throw new IllegalStateException("Utility class");
	}

	private static String keyGeneratorES(String res, String algorithm, String key, boolean isEncode) {
		String providerName = "SunJCE";
		try {
			if (null != jdkvs && jdkvs.startsWith("IBM")) {
				providerName = "IBMJCE";
				Security.addProvider((Provider) Class.forName("com.ibm.crypto.provider.IBMJCE").newInstance());
			} else {
				Security.addProvider((Provider) Class.forName("com.sun.crypto.provider.SunJCE").newInstance());
			}
			DESKeySpec dks = new DESKeySpec(key.getBytes(charset));
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES, providerName);
			Key secretKey = keyFactory.generateSecret(dks);
			Cipher cipher = Cipher.getInstance(algorithm, providerName);
			if (isEncode) {
				cipher.init(Cipher.ENCRYPT_MODE, secretKey);
				byte[] resBytes = charset == null ? res.getBytes() : res.getBytes(charset);
				return parseByte2HexStr(cipher.doFinal(resBytes));
			} else {
				cipher.init(Cipher.DECRYPT_MODE, secretKey);
				return new String(cipher.doFinal(parseHexStr2Byte(res)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 2->16
	 * 
	 */
	public static String parseByte2HexStr(byte buf[]) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * 16->2
	 * 
	 */
	public static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1)
			return null;
		byte[] result = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++) {
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
			result[i] = (byte) (high * 16 + low);
		}
		return result;
	}

	public static String DESencode(String res, String key) {
		return keyGeneratorES(res, DESMODE, key, true);
	}

	public static String DESdecode(String res, String key) {
		return keyGeneratorES(res, DESMODE, key, false);
	}
}