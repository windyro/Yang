package com.aia.glory.common.model;

public class PaginationModel 
{
    private int startPage = 1;
	
	private int pageSize = 10;

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

}
