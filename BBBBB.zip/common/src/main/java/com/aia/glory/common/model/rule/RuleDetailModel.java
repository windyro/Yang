package com.aia.glory.common.model.rule;

import java.io.Serializable;
import java.util.List;

public class RuleDetailModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String ruleDetailModelId;
	
	private List<RuleModel> ruleModelList;
	
	private List<CustomizedModel> customizedModel;
	
	private CalculateModel calculateModel;
	
	private String ruleGroupModelId;
	
	private String creatDate;
		
	private String updateDate;

	public List<RuleModel> getRuleModelList() {
		return ruleModelList;
	}

	public void setRuleModelList(List<RuleModel> ruleModelList) {
		this.ruleModelList = ruleModelList;
	}

	public CalculateModel getCalculateModel() {
		return calculateModel;
	}

	public void setCalculateModel(CalculateModel calculateModel) {
		this.calculateModel = calculateModel;
	}

	public String getRuleDetailModelId() {
		return ruleDetailModelId;
	}

	public void setRuleDetailModelId(String ruleDetailModelId) {
		this.ruleDetailModelId = ruleDetailModelId;
	}

	public String getRuleGroupModelId() {
		return ruleGroupModelId;
	}

	public void setRuleGroupModelId(String ruleGroupModelId) {
		this.ruleGroupModelId = ruleGroupModelId;
	}
	
	public String getCreatDate() {
		return creatDate;
	}

	public void setCreatDate(String creatDate) {
		this.creatDate = creatDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public List<CustomizedModel> getCustomizedModel() {
		return customizedModel;
	}

	public void setCustomizedModel(List<CustomizedModel> customizedModel) {
		this.customizedModel = customizedModel;
	}

	@Override
	public String toString() {
		return "RuleDetailModel [ruleDetailModelId=" + ruleDetailModelId
				+ ", ruleModelList=" + ruleModelList + ", customizedModel="
				+ customizedModel + ", calculateModel=" + calculateModel
				+ ", ruleGroupModelId=" + ruleGroupModelId + ", creatDate="
				+ creatDate + ", updateDate=" + updateDate + ", toString()="
				+ super.toString() + "]";
	}
	
}
