package com.aia.glory.common.model.request;

abstract public class Request {
	
	private String action;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
}
