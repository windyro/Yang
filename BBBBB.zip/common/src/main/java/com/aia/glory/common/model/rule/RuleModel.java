package com.aia.glory.common.model.rule;

import java.io.Serializable;

public class RuleModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String ruleModelId;
	
	private String name;
	
	private String criteriaKey;
	
	private String criteriaValue;
	
	private String functionParameters;
	
	private String ruleTemplateId;
	
	private String complicatedModelInd;

	
	public String getRuleModelId() {
		return ruleModelId;
	}

	public void setRuleModelId(String ruleModelId) {
		this.ruleModelId = ruleModelId;
	}

	public String getCriteriaKey() {
		return criteriaKey;
	}

	public void setCriteriaKey(String criteriaKey) {
		this.criteriaKey = criteriaKey;
	}

	public String getCriteriaValue() {
		return criteriaValue;
	}

	public void setCriteriaValue(String criteriaValue) {
		this.criteriaValue = criteriaValue;
	}

	public String getRuleTemplateId() {
		return ruleTemplateId;
	}

	public void setRuleTemplateId(String ruleTemplateId) {
		this.ruleTemplateId = ruleTemplateId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getComplicatedModelInd() {
		return complicatedModelInd;
	}

	public void setComplicatedModelInd(String complicatedModelInd) {
		this.complicatedModelInd = complicatedModelInd;
	}

	public String getFunctionParameters() {
		return functionParameters;
	}

	public void setFunctionParameters(String functionParameters) {
		this.functionParameters = functionParameters;
	}

	@Override
	public String toString() {
		return "RuleModel [ruleModelId=" + ruleModelId + ", name=" + name
				+ ", criteriaKey=" + criteriaKey + ", criteriaValue="
				+ criteriaValue + ", functionParameters=" + functionParameters
				+ ", ruleTemplateId=" + ruleTemplateId
				+ ", complicatedModelInd=" + complicatedModelInd + "]";
	}
	
}
