package com.aia.glory.common.util;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
public class GloryValidatorUtil {
	private GloryValidatorUtil() {
	    throw new IllegalStateException("Utility class");
	}
	private static Validator validator = 
			Validation.buildDefaultValidatorFactory().getValidator();

	public static <T> String dovBeenValidate(T t) {
		String rs = "";
		Set<ConstraintViolation<T>> violationSet = validator.validate(t);
		for (ConstraintViolation<T> model : violationSet) {
			rs = rs + model.getMessage();
		}
		return rs;
	}
}
