package com.aia.glory.common.validator;

import java.util.regex.Pattern;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.model.rule.RuleGroupModel;

public class RuleGroupModelValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		return RuleGroupModel.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		RuleGroupModel request = (RuleGroupModel) target;
		
		if(StringUtils.isEmpty(request.getName())){
			
			errors.rejectValue("name", ReasonCode.NAME_NULL_ERROR.getCode(), ReasonCode.NAME_NULL_ERROR.getDesc());
			
		}else if(!Pattern.matches("^[^<>\\n]+$",request.getName())){
				
				errors.rejectValue("name", ReasonCode.NAME_INPUT_ERROR.getCode(), ReasonCode.NAME_INPUT_ERROR.getDesc());
				
		}
		if(StringUtils.isEmpty(request.getCompany())) {
			
			errors.rejectValue("company", ReasonCode.COMPANY_NULL_ERROR.getCode(), ReasonCode.COMPANY_NULL_ERROR.getDesc());

		}else if(!Pattern.matches("^[^<>\\n]+$",request.getCompany())){
			
			errors.rejectValue("company", ReasonCode.COMPANY_INPUT_ERROR.getCode(), ReasonCode.COMPANY_INPUT_ERROR.getDesc());
			
		}
		//		if(StringUtils.isEmpty(request.getChannel())) {
//			
//			errors.rejectValue("channel", ReasonCode.CHANNEL_NULL_ERROR.getCode(), ReasonCode.CHANNEL_NULL_ERROR.getDesc());
//
//		}else if(!Pattern.matches("^[^<>\\n]+$",request.getChannel())){
//			
//			errors.rejectValue("channel", ReasonCode.CHANNEL_INPUT_ERROR.getCode(), ReasonCode.CHANNEL_INPUT_ERROR.getDesc());
//			
//		}
		if(StringUtils.isEmpty(request.getEffectedStartDate())) {
			
			errors.rejectValue("effectedStartDate", ReasonCode.EFFSD_NULL_ERROR.getCode(), ReasonCode.EFFSD_NULL_ERROR.getDesc());

		}else if(!Pattern.matches("^\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}$",request.getEffectedStartDate())){
			
			errors.rejectValue("effectedStartDate", ReasonCode.EFFD_FORMAT_ERROR.getCode(), ReasonCode.EFFD_FORMAT_ERROR.getDesc());
			
		}
		if(StringUtils.isEmpty(request.getEffectedEndDate())) {
	
			errors.rejectValue("effectedEndDate", ReasonCode.EFFED_NULL_ERROR.getCode(), ReasonCode.EFFED_NULL_ERROR.getDesc());

		}else if(!Pattern.matches("^\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}$",request.getEffectedEndDate())){
	
			errors.rejectValue("effectedEndDate", ReasonCode.EFFD_FORMAT_ERROR.getCode(), ReasonCode.EFFD_FORMAT_ERROR.getDesc());
	
		}
	}
	
}
