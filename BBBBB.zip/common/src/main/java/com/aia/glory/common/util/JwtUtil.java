package com.aia.glory.common.util;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

public class JwtUtil {
	
	private JwtUtil() {
	    throw new IllegalStateException("Utility class");
	}

	private static String getConfig(String key) {
		String rs = "";
		try {
			Properties ret = PropertiesLoaderUtils
			        .loadProperties(new ClassPathResource("config.properties"));
			rs = ret.getProperty(key);
			return rs;
		} catch (IOException e) {
			return "";
		}
	}
	public static String createJWT(long ttlMillis,String loginId, String username,String roleList) {
		
    	try {
    	    Algorithm algorithm = Algorithm.HMAC256("123456");
    	    Map<String, Object> headerClaims = new HashMap<String, Object>();
    	    headerClaims.put("alg", "RS256");
    	    headerClaims.put("typ", "JWT");
    	    
    	    String token = JWT.create().withIssuer("userservice")
    	    		.withExpiresAt(new Date(Timestamp.valueOf(LocalDateTime.now()).getTime()+ttlMillis))
    	    		.withSubject("login")
    	    		.withAudience(username)
    	    		.withIssuedAt(new Date())
    	    		.withClaim("loginId", loginId==null?"":loginId)
    	    		//.withClaim("admin", "true")
    	    		.withClaim("roleList", roleList==null?"":roleList)
    	    		.withHeader(headerClaims)
    	        .withIssuer("auth0")
    	        .sign(algorithm);
    	    
    	    return DESUtil.DESencode(token,getConfig("JWT_KEY"));
    	} catch (Exception exception){
    	    //Invalid Signing configuration / Couldn't convert Claims.
    	}
    	
		return null;
    	
    }
	
	public static String refresh(String token) {
    	
    	try {
    		DecodedJWT jwt = JWT.decode(DESUtil.DESdecode(token, getConfig("JWT_KEY")));
    	    Algorithm algorithm = Algorithm.HMAC256("123456");
    	    Map<String, Object> headerClaims = new HashMap();
    	    headerClaims.put("alg", "RS256");
    	    headerClaims.put("typ", "JWT");
    	    
    	    String newtoken = JWT.create().withIssuer("userservice")
    	    		.withExpiresAt(new Date(Timestamp.valueOf(LocalDateTime.now()).getTime()+(1000*60*30L)))
    	    		.withSubject("login")
    	    		.withAudience(jwt.getAudience().get(0).toString())
    	    		.withIssuedAt(new Date())
    	    		.withClaim("loginId", jwt.getClaim("login").asString())
    	    		//.withClaim("admin", "true")
    	    		.withClaim("roleList", jwt.getClaim("roleList").asString())
    	    		.withHeader(headerClaims)
    	        .withIssuer("auth0")
    	        .sign(algorithm);
    	    
    	    return DESUtil.DESencode(newtoken, getConfig("JWT_KEY"));
    	} catch (JWTCreationException exception){
    	    //Invalid Signing configuration / Couldn't convert Claims.
    	}
    	
		return null;
    	
    }

    public static Boolean isVerify(String token) {
        try {
        	token = DESUtil.DESdecode(token, getConfig("JWT_KEY"));
            Algorithm algorithm = Algorithm.HMAC256("123456");
            JWTVerifier verifier = JWT.require(algorithm)
                .withIssuer("auth0")
                .build(); //Reusable verifier instance
             DecodedJWT jwt = verifier.verify(token);
            
        } catch (JWTVerificationException exception){
            //Invalid signature/claims
        	// System.out.println(exception.getMessage());
        	return false;
        }
        return true;
    }

	public static Map<String,Claim> getAESdecodeToken(String token) {
		Map<String, Claim> claims = new HashMap<>();
		try {
			String tokenDecode = DESUtil.DESdecode(token, getConfig("JWT_KEY"));
			JWTVerifier verifier =JWT.require(Algorithm.HMAC256("123456")).build();
			claims = verifier.verify(tokenDecode).getClaims();
		} catch (IllegalArgumentException e) {
			return claims;
		} catch (JWTVerificationException e) {
			return claims;
		}
		return claims;
	}
	
}
