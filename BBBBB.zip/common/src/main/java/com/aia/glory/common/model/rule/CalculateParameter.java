package com.aia.glory.common.model.rule;

import java.io.Serializable;

public class CalculateParameter  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String name;
	
	private String criteriaKey;
	
	private String criteriaValue;

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCriteriaKey() {
		return criteriaKey;
	}

	public void setCriteriaKey(String criteriaKey) {
		this.criteriaKey = criteriaKey;
	}

	public String getCriteriaValue() {
		return criteriaValue;
	}

	public void setCriteriaValue(String criteriaValue) {
		this.criteriaValue = criteriaValue;
	}

	@Override
	public String toString() {
		return "CalculateParameter [name=" + name + ", criteriaKey="
				+ criteriaKey + ", criteriaValue=" + criteriaValue
				+ ", toString()=" + super.toString() + "]";
	}
	
}
