package com.aia.glory.common.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

public class ErrorMessageUtils {
	public ArrayList errorMessage(Errors errors) {
		List<ObjectError> errorList = errors.getAllErrors();
		ArrayList errorCodeList = new ArrayList();
		ArrayList errorDescList = new ArrayList();
		for(ObjectError error : errorList){
			errorCodeList.add(error.getCode());
			errorDescList.add(error.getDefaultMessage());
		}
		ArrayList list = new ArrayList();
		list.add(errorCodeList);
		list.add(errorDescList);
		return list;
	}
}
