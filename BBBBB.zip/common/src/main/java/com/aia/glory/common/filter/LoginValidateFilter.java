package com.aia.glory.common.filter;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.ExceptionResponse;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.common.util.JwtUtil;
import com.aia.glory.common.util.LogUtils;

public class LoginValidateFilter implements Filter {
	
	Log errorLog = LogFactory.getLog("sysError");
	
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    	// default implementation ignored
    }
 
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
    	
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, PATCH, DELETE, PUT,OPTIONS");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,token");
        
        if ("OPTIONS".equals(request.getMethod())) {
            response.setStatus(204);
        }

        
        String token = request.getHeader("token");
        if(StringUtils.isEmpty(token)) {
            token = request.getParameter("token");
        }
        
        String path = request.getRequestURI();
        
        if(path.indexOf("/token") > -1 || path.indexOf("/admin") > -1){
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }
 
        if(!StringUtils.isEmpty(token)) {

        	try{
                boolean va = JwtUtil.isVerify(token);
                // ((HttpServletResponse) servletResponse).setHeader("token", JwtUtil.refresh(token));
                if(!va) {
                	String userJson =  JsonToObjectUtil.objToJson(ExceptionResponse.fail(ResponseCode.ERROR,"please login"));
                    OutputStream out = servletResponse.getOutputStream();
                    out.write(userJson.getBytes("UTF-8"));
                    out.flush();
                }else {
                	filterChain.doFilter(servletRequest, servletResponse);
                }
            } catch (Exception e) {
            	errorLog.error(LogUtils.errorTrackSpace(e));
                String userJson = JsonToObjectUtil.objToJson(ExceptionResponse.fail(ResponseCode.ERROR,e.getMessage()));
                OutputStream out = servletResponse.getOutputStream();
                out.write(userJson.getBytes("UTF-8"));
                out.flush();
            }
        } else {
            String userJson =  JsonToObjectUtil.objToJson(ExceptionResponse.fail(ResponseCode.ERROR,"no login"));
            OutputStream out = servletResponse.getOutputStream();
            out.write(userJson.getBytes("UTF-8"));
            out.flush();
        }
    }
 
    @Override
    public void destroy() {
    	// default implementation ignored
    }
}
