package com.aia.glory.common.http;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

public class HttpClient {

	private HttpHeaders httpHeaders;
	
	private String url;
	
	public HttpClient(String url){
		this.url = url;
	}
	
	public <V> V post(final Request request, final Class<V> responseType,final String token) throws JsonProcessingException {
		this. httpHeaders = new HttpHeaders();
//		httpHeaders.add("Content-Type", "application/json");
		httpHeaders.add("token", token);
		String payload = JsonToObjectUtil.objToJson(request);
		HttpEntity<String> fullRequest = new HttpEntity<String>(payload, httpHeaders);
		return new RestTemplate().postForObject(url, fullRequest, responseType);
	}
}
