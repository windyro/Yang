package com.aia.glory.common.model;

public class GeneralInfomation 
{
    private String name;
    
    private String description;
    
    private String seq;
    
    

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
    
	@Override
	public String toString() {
		return "GeneralInfomation [name=" + name + ", description=" + description + ", seq=" + seq + "]";
	}
    
}
