package com.aia.glory.common.model.rule;

import java.io.Serializable;
import java.util.List;

public class CalculateModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<CalculateParameter> parameters;
	
	private String algorithm;
	
	private String name;


	public List<CalculateParameter> getParameters() {
		return parameters;
	}

	public void setParameters(List<CalculateParameter> parameters) {
		this.parameters = parameters;
	}

	public String getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "CalculateModel [parameters=" + parameters + ", algorithm="
				+ algorithm + ", name=" + name + "]";
	}
	
}
