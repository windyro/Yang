package com.aia.glory.common.util;
import java.io.IOException;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonToObjectUtil {
	private JsonToObjectUtil() {
	    throw new IllegalStateException("Utility class");
	}

	@SuppressWarnings("unchecked")
	public static <T> T jsonToObj(T t, String jsonStr)
			throws JsonParseException, JsonMappingException, IOException {
		if(jsonStr == null ){return null;}
		ObjectMapper mapper = new ObjectMapper();
		return (T) mapper.readValue(jsonStr, t.getClass());
	}
	
	public static String objToJson(Object obj) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(obj);
	}
	
	public static Object jsonToComplexObject(String jsonStr, Class<?> clazz) throws IOException {
		return JSONObject.parseArray(jsonStr, clazz);
	}
}
