package com.aia.glory.common.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;

public class ExceptionResponse extends Response{

	public static ExceptionResponse success(ResponseCode responseCode) {   
		
		ExceptionResponse tokenResponse = new ExceptionResponse();        
		tokenResponse.setResponseCode(responseCode.getCode());
		tokenResponse.setReasonCode(Arrays.asList("0000"));
		tokenResponse.setReasonDesc(Arrays.asList(""));
		return tokenResponse;    
		 
	 }
	
	public static ExceptionResponse fail(ResponseCode responseCode,String errorMsg) 
	 {        
		ExceptionResponse createRuleGroupResponse = new ExceptionResponse();        
		 createRuleGroupResponse.setResponseCode(responseCode.getCode());
			createRuleGroupResponse.setReasonCode(Arrays.asList("0000"));
			createRuleGroupResponse.setReasonDesc(Arrays.asList(errorMsg));
		 return createRuleGroupResponse;    
		 
	 }
}
