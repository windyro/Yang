package com.aia.glory.common.model.rule;

import java.io.Serializable;
import java.util.List;

public class RuleGroupModel implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String ruleGroupModelId;
	
//	@NotBlank(message="Name cannot be empty.")
//	@Pattern(regexp="^[^<>\\n]+$",message="Name cannot be input '<','>'......")
	private String name;
	
	private String description;
	
//	@NotBlank(message="Company cannot be empty.")
//	@Pattern(regexp="^[^<>\\n]+$",message="Company cannot be input '<','>'......")
	private String company;
	
//	@NotBlank(message="Channel cannot be empty.")
//	@Pattern(regexp="^[^<>\\n]+$",message="Channel cannot be input '<','>'......")
	private String channel;
	
	private String frequency;
	
	private String paymentFlag;
	
	private String activeFlag;
	
	private String summaryType;
	
//	@NotBlank(message="EffectedStartDate cannot be empty.")
//	@Pattern(regexp="^\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}$",message="Date format error。")
	private String effectedStartDate;
	
//	@NotBlank(message="EffectedEndDate cannot be empty.")
//	@Pattern(regexp="^\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}$",message="Date format error。")
	private String effectedEndDate;
	
	private String creatDate;
	
	private String updateDate;
	
	private List<RuleDetailModel> ruleDetailModelList;

	private String periodType;
	
	private String periodIndex;
	
	private String holdFlag;
	
	private String ruleType;
	
	public String getHoldFlag() {
		return holdFlag;
	}

	public void setHoldFlag(String holdFlag) {
		this.holdFlag = holdFlag;
	}

	public String getRuleGroupModelId() {
		return ruleGroupModelId;
	}

	public void setRuleGroupModelId(String ruleGroupModelId) {
		this.ruleGroupModelId = ruleGroupModelId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getPaymentFlag() {
		return paymentFlag;
	}

	public void setPaymentFlag(String paymentFlag) {
		this.paymentFlag = paymentFlag;
	}

	public String getEffectedStartDate() {
		return effectedStartDate;
	}

	public void setEffectedStartDate(String effectedStartDate) {
		this.effectedStartDate = effectedStartDate;
	}

	public String getEffectedEndDate() {
		return effectedEndDate;
	}

	public void setEffectedEndDate(String effectedEndDate) {
		this.effectedEndDate = effectedEndDate;
	}

	public List<RuleDetailModel> getRuleDetailModelList() {
		return ruleDetailModelList;
	}

	public void setRuleDetailModelList(List<RuleDetailModel> ruleDetailModelList) {
		this.ruleDetailModelList = ruleDetailModelList;
	}
	
	public String getCreatDate() {
		return creatDate;
	}

	public void setCreatDate(String creatDate) {
		this.creatDate = creatDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	
	public String getSummaryType() {
		return summaryType;
	}

	public void setSummaryType(String summaryType) {
		this.summaryType = summaryType;
	}

	public String getPeriodType() {
		return periodType;
	}

	public void setPeriodType(String periodType) {
		this.periodType = periodType;
	}

	public String getPeriodIndex() {
		return periodIndex;
	}

	public void setPeriodIndex(String periodIndex) {
		this.periodIndex = periodIndex;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	
	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	@Override
	public String toString() {
		return "RuleGroupModel [ruleGroupModelId=" + ruleGroupModelId
				+ ", name=" + name + ", description=" + description
				+ ", company=" + company + ", channel=" + channel
				+ ", frequency=" + frequency + ", paymentFlag=" + paymentFlag
				+ ", activeFlag=" + activeFlag + ", summaryType=" + summaryType
				+ ", effectedStartDate=" + effectedStartDate
				+ ", effectedEndDate=" + effectedEndDate + ", creatDate="
				+ creatDate + ", updateDate=" + updateDate
				+ ", ruleDetailModelList=" + ruleDetailModelList
				+ ", periodType=" + periodType + ", periodIndex=" + periodIndex
				+ ", holdFlag=" + holdFlag + ", ruleType=" + ruleType
				+ ", toString()=" + super.toString() + "]";
	}
	
}
