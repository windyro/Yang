package com.aia.glory.common.util;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Security;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;


public class RSAUtils {
	private static String jdkvs=System.getProperty( "java.vm.vendor");
	private RSAUtils() {
		throw new IllegalStateException("Utility class");
	}
	//private static Map<Integer, String> keyMap = new HashMap<Integer, String>();  

	/** 
	 * 随机生成密钥对 
	 * @throws NoSuchAlgorithmException 
	  
	public static void genKeyPair() throws NoSuchAlgorithmException {  
		
		KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");  
		keyPairGen.initialize(1024,new SecureRandom());  
		KeyPair keyPair = keyPairGen.generateKeyPair();  
		RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate(); 
		RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic(); 
		String publicKeyString = new String(Base64.encodeBase64(publicKey.getEncoded()));  
		String privateKeyString = new String(Base64.encodeBase64((privateKey.getEncoded())));  
		keyMap.put(0,publicKeyString);  //0 public
		keyMap.put(1,privateKeyString);  //1 private
	}  
	*/ 
	public static String encrypt( String str, String publicKey ) throws Exception{
		
		byte[] decoded = Base64.decodeBase64(publicKey);
		RSAPublicKey pubKey = (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(decoded));
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, pubKey);
		String outStr = Base64.encodeBase64String(cipher.doFinal(str.getBytes("UTF-8")));
		return outStr;
	}

	public static String decrypt(String str, String privateKey){
		
		String providerName = "SunJCE";
        try {
        	 if(null!=jdkvs && jdkvs.startsWith("IBM")){
        		 providerName = "IBMJCE";
        		 Security.addProvider((Provider)Class.forName("com.ibm.crypto.provider.IBMJCE").newInstance());
        	 }else {
        		 Security.addProvider((Provider)Class.forName("com.sun.crypto.provider.SunJCE").newInstance());
        	 }
			byte[] inputByte = Base64.decodeBase64(str.getBytes("UTF-8"));
			byte[] decoded = Base64.decodeBase64(privateKey);
			RSAPrivateKey priKey = (RSAPrivateKey) KeyFactory.getInstance("RSA")
					.generatePrivate(new PKCS8EncodedKeySpec(decoded));
			Cipher cipher = Cipher.getInstance("RSA",providerName);
			cipher.init(Cipher.DECRYPT_MODE, priKey);
			String outStr = new String(cipher.doFinal(inputByte));
			return outStr;
		} catch (Exception e) {
			return null;
		}
	}

	/*public static void main(String[] args) throws Exception {
		String pubkey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC2un/wd0+CN8V+QVDlSFzVmakjJdufeRrx36WffIBD4PbT8DUgZ5nE0jRSJW7mO+n/QKo4EQZliny9IOKU34CiCD+j06U9Xqj5oe448s0F/yQMjxDjLrUK7FNfzgKq7P1vbCvbhLijDVWDAOGxHsZNebTHP0cTb3ocgskDb1peewIDAQAB";
		String pvikey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALa6f/B3T4I3xX5BUOVIXNWZqSMl2595GvHfpZ98gEPg9tPwNSBnmcTSNFIlbuY76f9AqjgRBmWKfL0g4pTfgKIIP6PTpT1eqPmh7jjyzQX/JAyPEOMutQrsU1/OAqrs/W9sK9uEuKMNVYMA4bEexk15tMc/RxNvehyCyQNvWl57AgMBAAECgYAGkO8WAgOOZ1imb8xrYM1NM6dbRvn8Ygqw1FuMPpoRVl0oQoJ2NqLU6sTMiuHQTijbbkRvnVUAgxh2Z18dAGcL28mBQNgq2WdalCoefU4oNjh+9uLM3aDw2Vc0o0+fYtNFy1z2twEYA4ynlT6x9tJsKW0yuISggYov0kv1pmSxMQJBAP0XBhqmjOybZDSXFnwzGYqpKz3Bf3zqt1xeKihLwPScFCqKqEI5wa/fRCi9szQKbbZb6+vd2KFG2rBT/XPQQYkCQQC41F2MfSV1Zp1qOIR4DYeJKmsdKEhc6bCxG14HhUTMgClKrbFcY2BDMPxvwPBhnXA/jsIjG7hzP2SOGwWCZ7LjAkBhUSkXtlMZ5+ZwEmii+UMo/kOSS4UqE1bOPacYN4jKhfl7IjXwwSSo68DZqZfuutPU+yOMXpGd8hDFHIaosbuBAkBNHz/RqT6CGElC00ZjGbIeR/bd+bsIGfLCU9sOZEtq0WdpY8SH+mdmYgBTWTx0Xs9Blf3nzF9Qp3j72saXvVFlAkByAjWuJesNmKq+6oPDtdFQAfFjQvG/ldkRdJGJIRaq6R4a3m0C/+b8Egl5uu3IHCMCEqIMmtfzFEhTIB/6LS8e";
		
		System.out.println(encrypt("23", pubkey));
		String pwd = "qGnW7DdrHbdl8DvXxwiKeYaUQA593FECdOvFvf/SvK4rGMzJo+GDW8dxt9UXY34B8jUUQwmrwLGUcmJdeFMSKcylmuFf3uSiQZEuO1oPwm60nvMtp0SKNtAnzN3USgCfxEIp+h+oJgv9JzLQlEUPhPxv75oM3GWc6+2u/KUqxRk=";
		 
		System.out.println(decrypt(pwd, pvikey));
		
	}*/
}