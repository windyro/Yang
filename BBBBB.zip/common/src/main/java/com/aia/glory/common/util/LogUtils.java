package com.aia.glory.common.util;


public class LogUtils {

	private LogUtils() {
		throw new IllegalStateException("Utility class");
	}

	public static String errorTrackSpace(Exception e) {
		StringBuilder sb = new StringBuilder();
        if (e != null) {
            for (StackTraceElement element : e.getStackTrace()) {
                sb.append("\r\n\t").append(element);
            }
        }
        return sb.length() == 0 ? null : sb.toString();
    }
}
