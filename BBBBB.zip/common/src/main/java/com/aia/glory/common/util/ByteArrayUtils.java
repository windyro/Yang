package com.aia.glory.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ByteArrayUtils {

	private ByteArrayUtils() {
		throw new IllegalStateException("Utility class");
	}

	public static <T> byte[] objectToBytes(T obj) {
		byte[] bytes = null;
		
		
		try (ByteArrayOutputStream out = new ByteArrayOutputStream();
				ObjectOutputStream sOut =  new ObjectOutputStream(out);){
			sOut.writeObject(obj);
			sOut.flush();
			bytes = out.toByteArray();
			return bytes;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public static <T> T bytesToObject(byte[] bytes) {
		T t = null;
		
		
		try (ByteArrayInputStream in = new ByteArrayInputStream(bytes);
				ObjectInputStream sIn = new ObjectInputStream(in);){
			t = (T) sIn.readObject();
			return t;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 

	}

}
