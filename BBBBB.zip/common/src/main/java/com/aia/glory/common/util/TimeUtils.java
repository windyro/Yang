package com.aia.glory.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.util.StringUtils;

public class TimeUtils  
{
	private static ThreadLocal<DateFormat> threadLocal1 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd");
        }
    };
    private static ThreadLocal<DateFormat> threadLocal2 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        }
    };
    private static ThreadLocal<DateFormat> threadLocal3 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyyMM");
        }
    };
    private static ThreadLocal<DateFormat> threadLocal4 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM");
        }
    };
	
	private TimeUtils() {
	    throw new IllegalStateException("Utility class");
	}
	
	public static String getDateString(String str)
	{
		if (str == null || str.isEmpty()) 
		{
			return null;
		}
		try {
			Date date = threadLocal2.get().parse(str);
			String result = threadLocal1.get().format(date);
			return result;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	private static String getMonth(String monthName) {
		String month = "";
		switch (monthName) {
		case "January": month = "01"; break;
		case "February": month = "02"; break;
		case "March":   month = "03"; break;
		case "April":   month = "04"; break;
		case "May": month = "05"; break;
		case "June": month = "06"; break;
		case "July": month = "07"; break;
		case "August": month = "08"; break;
		case "September": month = "09"; break;
		case "October": month = "10"; break;
		case "November": month = "11"; break;
		default: month = "12"; break;
		}
		return month;
	}

	public static String getDateMonthStr(String date){
		if (date == null || date.isEmpty()) 
		{
			return null;
		}
		String result = null;
		String[] dates = date.split(" ");
		String monthName = dates[0];
		String year = dates[1];
		String month = getMonth(monthName);
		String date1 = year + month;
		Date date2;
		try {
			date2 = threadLocal3.get().parse(date1);
			result = threadLocal4.get().format(date2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}
	
    /* TODO: Optimise the above methods */
	
    public final static String PERIOD_FORMAT="MMMM yyyy";
    
    public final static String COMMON_DATE_FORMAT="yyyy-MM-dd";
	
    public final static String COMMON_DATE_TIME_FORMAT="yyyy-MM-dd";
    
    public final static String COMMON_PERIOD_FORMAT="yyyy-MM";
    
    public final static String STORE_PERIOD_FORMAT="yyyyMM";
	
	public static String parseSystemPeriod(String period) throws ParseException{
		
		Date date=new SimpleDateFormat("yyyy-MM").parse(period);
		String result = new SimpleDateFormat("MMMM yyyy").format(date);
		
		return result;
	}
	
	public static int monthComparison(String previousPeriod, String afterPeriod, String ppformatterStr, String apformatterStr) throws ParseException{
		
		SimpleDateFormat ppformatter = new SimpleDateFormat(ppformatterStr);
		SimpleDateFormat apformatter = new SimpleDateFormat(apformatterStr);
		
		Calendar previousCld = Calendar.getInstance();
        Calendar afterCld = Calendar.getInstance();
        previousCld.setTime(ppformatter.parse(previousPeriod));
        afterCld.setTime(apformatter.parse(afterPeriod));
       
		return  (afterCld.get(Calendar.YEAR)*12 + afterCld.get(Calendar.MONTH))-(previousCld.get(Calendar.YEAR)*12 + previousCld.get(Calendar.MONTH));
	}

	public static int getQualter(String dateStr, String formatString) throws ParseException{
		SimpleDateFormat formatter = new SimpleDateFormat(formatString);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(formatter.parse(dateStr));
		int month = calendar.get(Calendar.MONTH)+1;
		if(month<=3) {
			return 1;
		}else if(month<=6) {
			return 2;
		}else if(month<=9) {
			return 3;
		}else if(month<=12) {
			return 4;
		}else {
			return -1;
		}
		//return (month<=3) ? 1 : (month<=6) ? 2 : (month<=9) ? 3 : (month<=12) ? 4 : -1;
	}
	
	public static int getYear(String dateStr, String formatString) throws ParseException{
		SimpleDateFormat formatter = new SimpleDateFormat(formatString);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(formatter.parse(dateStr));
		return calendar.get(Calendar.YEAR);
	}
	
	public static boolean isPeriodMonthQuaterEnd(String periodStr, String formatString) throws ParseException{
		SimpleDateFormat formatter = new SimpleDateFormat(formatString);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(formatter.parse(periodStr));
		int month = calendar.get(Calendar.MONTH)+1;
		
		return (month == 3 || month == 6 || month == 9 || month == 12) ? true : false;
	}
	
	public static boolean isPeriodMonthYearEnd(String periodStr, String formatString) throws ParseException{
		SimpleDateFormat formatter = new SimpleDateFormat(formatString);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(formatter.parse(periodStr));
		int month = calendar.get(Calendar.MONTH)+1;
		
		return month == 12 ? true : false;
	}
	
	public static Date parseStringToDate(String dateString, String formatString) throws ParseException{
		SimpleDateFormat formatter = new SimpleDateFormat(formatString);
		return formatter.parse(dateString);
	}
	
	public static boolean isDateInEffectivePeriod(Date targetPeriod, Date effectiveStartDate, Date effectiveEndDate) throws ParseException{
		return targetPeriod.compareTo(effectiveStartDate)>-1 && targetPeriod.compareTo(effectiveEndDate)<1 ? true : false;
	}
	
    public static String getDiffDateByDate(String strData, int days) {
         String preDate = "";
         Calendar c = Calendar.getInstance();
         SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
         Date date = null;
         try {
             date = sdf.parse(strData);
         } catch (java.text.ParseException e) {
             e.printStackTrace();
         }
         
         c.setTime(date);
         int day1 = c.get(Calendar.DATE);
         c.set(Calendar.DATE, day1 + days);
         preDate = sdf.format(c.getTime());
        return preDate;
    }
    
    
    public static String convertDateString(String dateString, String sourceFormat, String targetFormat) throws ParseException{
    	
    	if(StringUtils.isEmpty(dateString)){return null;}
    	SimpleDateFormat sourceFormatter =new SimpleDateFormat(sourceFormat);
    	SimpleDateFormat targetFormatter =new SimpleDateFormat(targetFormat);
    	
    	return targetFormatter.format(sourceFormatter.parse(dateString));
	}
}
