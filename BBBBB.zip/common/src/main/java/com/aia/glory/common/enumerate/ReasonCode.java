package com.aia.glory.common.enumerate;

public enum ReasonCode {
	
	GENERIC_SUCCESS("00000","Sucessful"),
	
	GENERIC_ERROR("00001","Generic Error"),
	
	NAME_NULL_ERROR("00002","Name cannot be empty"),
	
	NAME_INPUT_ERROR("00003","Name cannot be input '<','>'......"),
	
	COMPANY_NULL_ERROR("00004","Company cannot be empty"),
	
	COMPANY_INPUT_ERROR("00005","Company cannot be input '<','>'......"),
	
	CHANNEL_NULL_ERROR("00006","Channel cannot be empty"),
	
	CHANNEL_INPUT_ERROR("00007","Channel cannot be input '<','>'......"),
	
	EFFSD_NULL_ERROR("00008","EffectedStartDate cannot be empty"),
	
	EFFD_FORMAT_ERROR("00009","Date format error"),
	
	EFFED_NULL_ERROR("00010","EffectedEndDate cannot be empty");
	
	private String code;
	
	private String desc;
	
	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	private ReasonCode(String code, String desc){
		this.code=code;
		this.desc=desc;
	}
	
}
