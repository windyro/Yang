package com.aia.glory.common.util;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.aia.glory.common.model.MailModel;

public class EmailUtil {

	private static JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
	static {
		mailSender.setHost(PropertiesUtil.getConfig("email.host"));
		mailSender.setPort(Integer.parseInt(PropertiesUtil.getConfig("email.port")));
		mailSender.setProtocol(PropertiesUtil.getConfig("email.protocol"));
	}
	
	private EmailUtil() {
	    throw new IllegalStateException("Utility class");
	}
	
	public static void sendMail(String from,String to,String sub,String content) throws Exception {
		Properties props = new Properties();
        props.setProperty("mail.transport.protocol", PropertiesUtil.getConfig("email.protocol"));
        props.setProperty("mail.host", PropertiesUtil.getConfig("email.host"));
        props.setProperty("mail.smtp.auth", "false");
        props.put("mail.smtp.ssl.enable", false);
		Session session = Session.getInstance(props, null);
		session.setDebug(true);
		MimeMessage message = new MimeMessage(session);

		message.setFrom(new InternetAddress(from));
		message.setRecipients(Message.RecipientType.TO, to);
		message.setSubject(sub);
        message.setText(content);

		message.saveChanges();
		Transport.send(message);
	}
	
	public static void sendMail(MailModel mailVo) {
		try {
			checkMail(mailVo);
			sendMimeMail(mailVo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void checkMail(MailModel mailVo) throws Exception {
		if (StringUtils.isEmpty(mailVo.getTo())) {
			throw new Exception("emailmodel field(To) is null");
		}
		if (StringUtils.isEmpty(mailVo.getSubject())) {
			throw new Exception("emailmodel field(sub) is null");
		}
		if (StringUtils.isEmpty(mailVo.getText())) {
			throw new Exception("emailmodel field(test) is null");
		}
	}

	private static void sendMimeMail(MailModel mailVo) throws Exception {
		try {
			MimeMessageHelper messageHelper = new MimeMessageHelper(mailSender.createMimeMessage(), true);// true: support MultipartFile
			mailVo.setFrom(mailVo.getFrom());
			messageHelper.setFrom(mailVo.getFrom());
			messageHelper.setTo(mailVo.getTo().split(","));
			messageHelper.setSubject(mailVo.getSubject());
			messageHelper.setText(mailVo.getText());
			 
			if (!StringUtils.isEmpty(mailVo.getCc())) {
				messageHelper.setCc(mailVo.getCc().split(","));
			}
			if (!StringUtils.isEmpty(mailVo.getBcc())) {
				messageHelper.setBcc(mailVo.getBcc().split(","));
			}
			if (mailVo.getMultipartFiles() != null) {
				for (MultipartFile multipartFile : mailVo.getMultipartFiles()) {
					messageHelper.addAttachment(multipartFile.getOriginalFilename(), multipartFile);
				}
			}
			if (StringUtils.isEmpty(mailVo.getSentDate())) {
				mailVo.setSentDate(new Date());
				messageHelper.setSentDate(mailVo.getSentDate());
			}
			mailSender.send(messageHelper.getMimeMessage());
			mailVo.setStatus("ok");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	/*
	private MailModel saveMail(MailModel mailVo) {
		// ... ...

		return mailVo;
	}

	public String getMailSendFrom() {
		return mailSender.getJavaMailProperties().getProperty("from");
	}*/
}
