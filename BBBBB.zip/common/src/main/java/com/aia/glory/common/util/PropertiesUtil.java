package com.aia.glory.common.util;

import java.io.IOException;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

public class PropertiesUtil {
	
	private PropertiesUtil() {
		throw new IllegalStateException("Utility class");
	}
	
	public static String getConfig(String key) {
		String rs = "";
		try {
			Properties ret = PropertiesLoaderUtils
			        .loadProperties(new ClassPathResource("config.properties"));
			rs = ret.getProperty(key);
			return rs;
		} catch (IOException e) {
			return "";
		}
	}
}
