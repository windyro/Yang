package com.aia.glory.common.model.request;

abstract public class PageRequest extends Request{

	private int pageSize;
	
	private int startPage;
	
	public void setPageSize(int pageSize) {
		if(pageSize < 1) {
			pageSize = 5;
		}
		this.pageSize = pageSize;
	}
	
	public void setStartPage(int startPage) {
		if(startPage < 1) {
			startPage = 1;
		}
		this.startPage = startPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public int getStartPage() {
		return startPage;
	}
	
}
