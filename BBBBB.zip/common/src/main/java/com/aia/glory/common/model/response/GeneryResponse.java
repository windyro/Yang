package com.aia.glory.common.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;

public class GeneryResponse extends Response {

	private Object data;

	private int total;

	public static GeneryResponse success() {

		GeneryResponse userSummaryResponse = new GeneryResponse();
		userSummaryResponse.setResponseCode(ResponseCode.NORMAL.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList("0000"));
		userSummaryResponse.setReasonDesc(Arrays.asList(""));
		return userSummaryResponse;

	}

	public static <T> GeneryResponse fail(T reasonDesc) {

		GeneryResponse generyResponse = new GeneryResponse();
		generyResponse.setResponseCode(ResponseCode.ERROR.getCode());
		generyResponse.setReasonCode(Arrays.asList(ReasonCode.GENERIC_ERROR.getCode()));
		generyResponse.setReasonDesc(Arrays.asList(reasonDesc));
		return generyResponse;

	}

	public static <T> GeneryResponse fail(ResponseCode responseCode,T reasonCode,T reasonDesc) {

		GeneryResponse generyResponse = new GeneryResponse();
		generyResponse.setResponseCode(responseCode.getCode());
		generyResponse.setReasonCode(Arrays.asList(reasonCode));
		generyResponse.setReasonDesc(Arrays.asList(reasonDesc));
		return generyResponse;

	}

	public static GeneryResponse warn(String warnMsg) {

		GeneryResponse generyResponse = new GeneryResponse();
		generyResponse.setResponseCode(ResponseCode.WARNING.getCode());
		generyResponse.setReasonCode(Arrays.asList("0000"));
		generyResponse.setReasonDesc(Arrays.asList(warnMsg));
		return generyResponse;

	}

	public static GeneryResponse success(ResponseCode responseCode, Object obj) {

		GeneryResponse generyResponse = new GeneryResponse();
		generyResponse.setResponseCode(responseCode.getCode());
		generyResponse.setReasonCode(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getCode()));
		generyResponse.setReasonDesc(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getDesc()));
		generyResponse.setData(obj);
		return generyResponse;

	}

	public static GeneryResponse success(ResponseCode responseCode, Object obj, int total) {

		GeneryResponse userSummaryResponse = new GeneryResponse();
		userSummaryResponse.setResponseCode(responseCode.getCode());
		userSummaryResponse.setReasonCode(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getCode()));
		userSummaryResponse.setReasonDesc(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getDesc()));
		userSummaryResponse.setData(obj);
		userSummaryResponse.setTotal(total);
		return userSummaryResponse;

	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "GeneryResponse [data=" + data + ", total=" + total + "]" + super.toString();
	}

}
