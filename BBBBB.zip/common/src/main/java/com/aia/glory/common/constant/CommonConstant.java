package com.aia.glory.common.constant;

public class CommonConstant {
	
    public static String YES = "Y";
    
    public static String NO = "N";
    
    public static final String COMMA = ",";
    
    public static final String EQUAL_MARK = "=";
    
    private CommonConstant() {
	    throw new IllegalStateException("Utility class");
	}
	
}
