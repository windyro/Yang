package com.aia.glory.common.constant;

public class ActionTypeConstant 
{
    public static String POST = "POST";

    public static String GET = "GET";
    
    public static String UPDATE = "UPDATE";
    
    public static String DELETE = "DELETE";
    
    private ActionTypeConstant() {
	    throw new IllegalStateException("Utility class");
	}
}
