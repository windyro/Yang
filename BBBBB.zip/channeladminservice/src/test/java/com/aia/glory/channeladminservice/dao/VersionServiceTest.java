package com.aia.glory.channeladminservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.channeladminservice.service.VersionService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class VersionServiceTest {
	   
	   @Autowired
	   VersionService versionService;

	   @Test
	   public void retrieveAgentVersion()
	   {
		   VersionRequest versionRequest = new VersionRequest();
		   versionRequest.setSeq("21");
		   Response rs = versionService.retrieveAgentVersion(versionRequest);
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   public void retrieveEntityVersion()
	   {
		   VersionRequest versionRequest = new VersionRequest();
		   versionRequest.setSeq("72");
		   Response rs = versionService.retrieveEntityVersion(versionRequest);
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   public void updateParticipantVersion()
	   {
			VersionRequest oldVersionRequest = new VersionRequest();
			oldVersionRequest.setSeq("139");
			oldVersionRequest.setIsLast("0");
			oldVersionRequest.setEffectiveStartDate("2030-09-03");
			oldVersionRequest.setEffectiveEndDate("2030-10-02");
			
			VersionModel oldVersion = new VersionModel();
			oldVersion.setRemoveDate("2001-01-01");
			
			VersionUpdateRequest versionUpdateRequest = new VersionUpdateRequest();
			versionUpdateRequest.setVersionRequest(oldVersionRequest);
			versionUpdateRequest.setVersionModel(oldVersion);
			Response rs = versionService.updateParticipantVersion(versionUpdateRequest);
			Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	
	   @Test
	   public void updatePositionVersion()
	   {
			VersionRequest oldVersionRequest = new VersionRequest();
			oldVersionRequest.setSeq("139");
			oldVersionRequest.setIsLast("0");
			oldVersionRequest.setEffectiveStartDate("2030-09-03");
			oldVersionRequest.setEffectiveEndDate("2030-10-02");
			
			VersionModel oldVersion = new VersionModel();
			oldVersion.setRemoveDate("2001-01-01");
			
			VersionUpdateRequest versionUpdateRequest = new VersionUpdateRequest();
			versionUpdateRequest.setVersionRequest(oldVersionRequest);
			versionUpdateRequest.setVersionModel(oldVersion);
			Response rs = versionService.updatePositionVersion(versionUpdateRequest);
			Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
}