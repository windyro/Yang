package com.aia.glory.channeladminservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.service.EntityService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.EntityRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class EntityServiceTest {
	
	   @Autowired
	   EntityService entityService;

	   @Test
	   public void retrieveEntity()
	   {
		   EntityRequest entityRequest = new EntityRequest();
		   entityRequest.setSeq("72");
		   entityRequest.setIsLast("1");
		   Response rs = entityService.retrieveEntity(entityRequest); 
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   public void getMaxParticipantSeq()
	   {
		   Integer rsult = entityService.getMaxParticipantSeq(); 
		   System.out.println(rsult);
		   Assert.assertEquals(Integer.class, rsult.getClass());
	   }
	   
	   @Test
	   public void getMaxPositionSeq()
	   {
		   Integer rsult = entityService.getMaxPositionSeq(); 
		   System.out.println(rsult);
		   Assert.assertEquals(Integer.class, rsult.getClass());
	   }
	
}