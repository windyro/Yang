package com.aia.glory.channeladminservice.controller;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
@AutoConfigureMockMvc
public class VersionControllerTest {
	   
	@Autowired
	VersionController versioinController;
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testVersion_GetSuccessfully_ReturnSuccessResponse() throws IOException{
	    VersionRequest versionRequest = new VersionRequest();
	    versionRequest.setAction("GET");
	    versionRequest.setType("AGENT");
	    versionRequest.setSeq("21");
	    versionRequest.setEffectiveStartDate("");
	    versionRequest.setEffectiveEndDate("");
	    versionRequest.setStartPage(1);
	    versionRequest.setPageSize(20);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/version")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(versionRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Response result = versioinController.version(versionRequest);
		//Assert.assertEquals("000", result.getResponseCode());
	}
	
	@Test   
	public void testVersion_UpdateSuccessfully_ReturnSuccessResponse() throws IOException{
		VersionRequest oldVersionRequest = new VersionRequest();
		oldVersionRequest.setType("ENTITY");
		oldVersionRequest.setSeq("139");
		oldVersionRequest.setIsLast("0");
		oldVersionRequest.setEffectiveStartDate("2030-09-03");
		oldVersionRequest.setEffectiveEndDate("2030-10-02");
		
		VersionModel oldVersion = new VersionModel();
		oldVersion.setRemoveDate("2001-01-01");
		
		VersionUpdateRequest versionUpdateRequest = new VersionUpdateRequest();
		versionUpdateRequest.setVersionRequest(oldVersionRequest);
		versionUpdateRequest.setVersionModel(oldVersion);
		versionUpdateRequest.setAction("UPDATE");
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/version")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(versionUpdateRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Response result = versioinController.version(versionRequest);
		//Assert.assertEquals("000", result.getResponseCode());
	}
	
}
