package com.aia.glory.channeladminservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.channeladminservice.service.PositionNodeService;
import com.aia.glory.channeladminservice.service.VersionService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.PositionNodeRequest;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class PositionNodeServiceTest {
	   
	   @Autowired
	   PositionNodeService positionNodeService;

	   @Test
	   public void retrievePositionNode()
	   {
		   PositionNodeRequest positionNodeRequest = new PositionNodeRequest();
		   positionNodeRequest.setAction("GET");
		   positionNodeRequest.setSeq("72");
		   positionNodeRequest.setPageSize(20);
		   positionNodeRequest.setStartPage(1);
		   Response rs = positionNodeService.retrievePositionNodeSelf(positionNodeRequest);
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }

	  
}