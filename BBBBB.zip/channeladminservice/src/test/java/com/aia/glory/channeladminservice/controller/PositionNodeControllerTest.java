package com.aia.glory.channeladminservice.controller;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.PositionNodeRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
@AutoConfigureMockMvc
public class PositionNodeControllerTest {
	   
	@Autowired
	PositionNodeController positionNodeController;
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testPositionNode_GetSuccessfully_ReturnSuccessResponse() throws IOException{
		PositionNodeRequest positionNodeRequest = new PositionNodeRequest();
		positionNodeRequest.setAction("GET");
		positionNodeRequest.setRecordType("AGY");
		positionNodeRequest.setNodeType("SELF");
		positionNodeRequest.setSeq("72");
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/positionNode")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(positionNodeRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Response result = versioinController.version(versionRequest);
		//Assert.assertEquals("000", result.getResponseCode());
	}
	
	
}
