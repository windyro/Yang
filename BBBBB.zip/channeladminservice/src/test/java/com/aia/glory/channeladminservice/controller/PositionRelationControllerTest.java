package com.aia.glory.channeladminservice.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.channeladminservice.model.PositionModel;
import com.aia.glory.channeladminservice.model.PositionRelationModel;
import com.aia.glory.channeladminservice.model.PositionRelationTypeModel;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.EntityCreateRequest;
import com.aia.glory.model.request.PositionRelationRequest;
import com.aia.glory.model.request.PositionRelationUpdateRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class} ,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
@AutoConfigureMockMvc
public class PositionRelationControllerTest {
	   
	@Autowired
	PositionRelationController positionRelationController;
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testPositionRelation_GetSuccessfully_ReturnSuccessResponse() throws IOException{
		PositionRelationRequest positionRelationRequest = new PositionRelationRequest();
		positionRelationRequest.setAction("GET");
		positionRelationRequest.setSeq("1");
		positionRelationRequest.setStartPage(1);
		positionRelationRequest.setPageSize(20);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/positionRelation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(positionRelationRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	@Test   
	@Transactional
	public void createPositionRelation_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		PositionRelationUpdateRequest pru = new PositionRelationUpdateRequest();
		pru.setAction("INSERT");
		PositionRelationTypeModel prt = new PositionRelationTypeModel();
		prt.setActive("1");
		prt.setCreateDate("2020-01-01");
		prt.setDataTypeSeq("2");
		prt.setDescription("test");
		prt.setName("unit test");
		prt.setRemoveDate("2020-01-01");
		
		List<PositionRelationModel> positionRelationModel = new ArrayList<PositionRelationModel>();
		PositionRelationModel prm = new PositionRelationModel();
		prm.setPositionRelationSeq("1");
		prm.setParentpositionSeq("2");
		prm.setChildpositionSeq("3");
		prm.setPositionRelationTypeSeq("4");
		prm.setEffectiveStartDate("2020-01-01");
		prm.setEffectiveEndDate("2025-01-01");
		prm.setRemoveDate("2020-01-01");
		positionRelationModel.add(prm);
		prt.setPositionRelationModel(positionRelationModel);
		pru.setPositionRelationTypeModel(prt);
		
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/positionRelation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(pru))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test   
	@Transactional
	public void updatePositionRelation_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		PositionRelationUpdateRequest pru = new PositionRelationUpdateRequest();
		pru.setAction("UPDATE");
		PositionRelationTypeModel prt = new PositionRelationTypeModel();
		prt.setActive("1");
		prt.setCreateDate("2020-01-01");
		prt.setDataTypeSeq("1");
		prt.setDescription("update test");
		prt.setName("unit test");
		prt.setRemoveDate("2020-01-01");
		
		List<PositionRelationModel> positionRelationModel = new ArrayList<PositionRelationModel>();
		PositionRelationModel prm = new PositionRelationModel();
		prm.setPositionRelationSeq("1");
		prm.setParentpositionSeq("2");
		prm.setChildpositionSeq("3");
		prm.setPositionRelationTypeSeq("4");
		prm.setEffectiveStartDate("2020-01-01");
		prm.setEffectiveEndDate("2025-01-01");
		prm.setRemoveDate("2020-01-01");
		positionRelationModel.add(prm);
		prt.setPositionRelationModel(positionRelationModel);
		pru.setPositionRelationTypeModel(prt);
		
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/positionRelation")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(pru))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
