package com.aia.glory.channeladminservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.ContractModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.channeladminservice.service.AgentService;
import com.aia.glory.model.request.AgentRequest;
import com.aia.glory.model.response.GetAgentResponse;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class AgentServiceTest {
	
	   @Autowired
	   AgentService agentService;
	   
	   @Autowired
		public AgentDao agentDao;

	   @Test
	   public void retrieveAgent()
	   {
		   AgentRequest agentRequest = new AgentRequest();
		   agentRequest.setSeq("296");
		   agentRequest.setIsLast("1");
		  // agentRequest.setEffectiveStartDate("2020-05-03");
		   //agentRequest.setEffectiveEndDate("2200-01-01");
		   GetAgentResponse rs = (GetAgentResponse)agentService.retrieveAgent(agentRequest);
		   System.out.println(rs.toString());
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   @Transactional
	   public void crateAgentTest()
	   {
		   try {
			ParticipantModel pp = new ParticipantModel();
			   pp.setEffectiveStartDate("2020-01-01");
			   pp.setEffectiveEndDate("2200-01-01");
			   pp.setAgentCode("a20001");
			   pp.setLastName("alan");
			   pp.setHireDate("2019-01-01");
			   ContractModel contractModel = new ContractModel();
			   System.out.println(pp.getSeq());
			   Assert.assertNotNull(pp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	
}