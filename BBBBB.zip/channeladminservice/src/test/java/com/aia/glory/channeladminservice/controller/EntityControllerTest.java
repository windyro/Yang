package com.aia.glory.channeladminservice.controller;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.channeladminservice.model.PositionModel;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.EntityRequest;
import com.aia.glory.model.request.EntityCreateRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class} ,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
@AutoConfigureMockMvc
public class EntityControllerTest {
	   
	@Autowired
	EntityController entityController;
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testEntity_GetSuccessfully_ReturnSuccessResponse() throws IOException{
		EntityRequest entityRequest = new EntityRequest();
		entityRequest.setAction("GET");
		entityRequest.setSeq("72");
		entityRequest.setIsLast("1");
		entityRequest.setStartPage(1);
		entityRequest.setPageSize(20);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/entity")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(entityRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	@Test   
	@Transactional
	public void createEntity_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		EntityCreateRequest entityRequest = new EntityCreateRequest();
		EntityModel entityModel = new EntityModel();
		ParticipantModel participantModel = new ParticipantModel();
		participantModel.setAgentCode("2356e");
		participantModel.setLastName("test");
		participantModel.setAgentStatus("1");
		participantModel.setPostalCode("d");
		participantModel.setResidentialAddress("adfd");
		participantModel.setAgentTelephone("123456");
		VersionModel versionModel = new VersionModel();
		versionModel.setEffectiveEndDate("2200-01-01");
		versionModel.setEffectiveStartDate("2020-01-01");
		versionModel.setIsLast("1");
		versionModel.setVersionLog("2");
		versionModel.setRemoveDate("2020-01-01");
		participantModel.setVersionModel(versionModel);
		PositionModel positionModel = new PositionModel();
		positionModel.setTitle("");
		positionModel.setEntityType("dd");
		positionModel.setManagerAgency("a");
		positionModel.setManagerSeq("1");
		positionModel.setLeaderCode("d");
		positionModel.setBusinessUnit("a");
		entityModel.setParticipantModel(participantModel);
		entityModel.setPositionModel(positionModel);
		entityRequest.setEntityModel(entityModel);
		entityRequest.setAction("INSERT");
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/entity")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(entityRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test   
	@Transactional
	public void createNewVersionEntity_GetSuccessfully_ReturnSuccessResponseTest() throws IOException{
		EntityCreateRequest entityRequest = new EntityCreateRequest();
		EntityModel entityModel = new EntityModel();
		ParticipantModel participantModel = new ParticipantModel();
		participantModel.setAgentCode("2356e");
		participantModel.setLastName("test");
		participantModel.setAgentStatus("1");
		participantModel.setPostalCode("d");
		participantModel.setResidentialAddress("adfd");
		participantModel.setAgentTelephone("123456");
		VersionModel versionModel = new VersionModel();
		versionModel.setEffectiveEndDate("2200-01-01");
		versionModel.setEffectiveStartDate("2020-01-01");
		versionModel.setSeq("166");
		versionModel.setIsLast("1");
		versionModel.setVersionLog("2");
		versionModel.setRemoveDate("2020-01-01");
		participantModel.setVersionModel(versionModel);
		PositionModel positionModel = new PositionModel();
		positionModel.setPositionSeq("121");
		positionModel.setTitle("");
		positionModel.setEntityType("dd");
		positionModel.setManagerAgency("a");
		positionModel.setManagerSeq("1");
		positionModel.setLeaderCode("d");
		positionModel.setBusinessUnit("a");
		entityModel.setParticipantModel(participantModel);
		entityModel.setPositionModel(positionModel);
		entityRequest.setEntityModel(entityModel);
		entityRequest.setAction("INSERT");
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/entity")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(entityRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
