package com.aia.glory.channeladminservice.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.model.ContractModel;
import com.aia.glory.channeladminservice.model.EducationModel;
import com.aia.glory.channeladminservice.model.FamilyModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.channeladminservice.model.PositionModel;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.AgentActionRequest;
import com.aia.glory.model.request.AgentRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class} ,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
@AutoConfigureMockMvc
public class AgentControllerTest {
	   
	@Autowired
	AgentController agentController;
	   
	@Autowired
	protected MockMvc mockMvc;
       
	@Test   
	public void testVersion_GetSuccessfully_ReturnSuccessResponse() throws IOException{
		AgentRequest agentRequest = new AgentRequest();
		agentRequest.setAction("GET");
		agentRequest.setIsLast("1");
		//agentRequest.setSeq("296");
	    agentRequest.setStartPage(1);
	    agentRequest.setPageSize(1);
	    //agentRequest.setIdentificationNumb("909877");
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/agent")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(agentRequest))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test  
	@Transactional
	public void createAgentTest() throws IOException{
		ParticipantModel pp = new ParticipantModel();
		pp.setRecordType("AGT");
		pp.setEffectiveStartDate("2020-02-06");
		pp.setEffectiveEndDate("2200-01-01");
		pp.setAgentCode("a2000123");
		pp.setLastName("alan");
		pp.setHireDate("2019-01-01");
		List<FamilyModel> familyModel = new ArrayList<FamilyModel>();
		ContractModel contractModel = new ContractModel();
		contractModel.setBaseSalary("10000");
		contractModel.setName("test");
		contractModel.setContractCode("test");
		FamilyModel fm = new FamilyModel();
		fm.setName("test");
		fm.setFamilyMemberName("ff");
		familyModel.add(fm);
		AgentActionRequest aar = new AgentActionRequest();
		aar.setContractModel(contractModel);
		aar.setFamilyModel(familyModel);
		aar.setParticipantModel(pp);
		aar.setAction("POST");
		EducationModel em = new EducationModel();
		em.setGraduateSchool("123");
		em.setHighestEducation("234");
		aar.setEducationModel(em);
		PositionModel pom = new PositionModel();
		pom.setAgencyCode("d");
		pom.setBusinessUnit("MM_PU");
		pom.setChannelCode("MMAGY");
		pom.setDistrictCode("dfsf");
		pom.setEntityType("");

		pom.setLeaderCode("dddd");
		pom.setManagerAgency("UNIT001");
		pom.setTitle("UM");
		aar.setPositionModel(pom);
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/agents")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(aar))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test  
	@Transactional
	public void updateAgentTest() throws IOException{
		VersionModel versionModel = new VersionModel();
		versionModel.setSeq("166");
		ParticipantModel pp = new ParticipantModel();
		pp.setVersionModel(versionModel);
		pp.setRecordType("AGY");
		pp.setEffectiveStartDate("2020-02-06");
		pp.setEffectiveEndDate("2200-01-01");
		pp.setAgentCode("a2000123");
		pp.setLastName("alan");
		pp.setHireDate("2019-01-01");
		List<FamilyModel> familyModel = new ArrayList<FamilyModel>();
		ContractModel contractModel = new ContractModel();
		contractModel.setBaseSalary("10000");
		contractModel.setName("test");
		contractModel.setContractCode("test");
		FamilyModel fm = new FamilyModel();
		fm.setName("test");
		fm.setFamilyMemberName("ff");
		familyModel.add(fm);
		AgentActionRequest aar = new AgentActionRequest();
		aar.setContractModel(contractModel);
		aar.setFamilyModel(familyModel);
		aar.setParticipantModel(pp);
		aar.setAction("POST");
		EducationModel em = new EducationModel();
		em.setGraduateSchool("123");
		em.setHighestEducation("234");
		aar.setEducationModel(em);
		PositionModel pom = new PositionModel();
		pom.setAgencyCode("d");
		pom.setBusinessUnit("MM_PU");
		pom.setChannelCode("MMAGY");
		pom.setDistrictCode("dfsf");
		pom.setEntityType("");
		
		pom.setPositionSeq("121");
		pom.setLeaderCode("dddd");
		pom.setManagerAgency("UNIT001");
		pom.setTitle("UM");
		aar.setPositionModel(pom);
		System.out.println(JsonToObjectUtil.objToJson(aar));
	    try {
			MvcResult mrcresult = mockMvc.perform(
			        			MockMvcRequestBuilders.post("/agents")
			        			.contentType(MediaType.APPLICATION_JSON_UTF8)      
			        			.content(JsonToObjectUtil.objToJson(aar))
								)
			        			.andExpect(MockMvcResultMatchers.status().isOk())
			        			.andDo(MockMvcResultHandlers.print())
			        			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
			        			.andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
