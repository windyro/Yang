package com.aia.glory.channeladminservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.ApplicationTest;
import com.aia.glory.channeladminservice.service.PositionRelationService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.PositionRelationRequest;;;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
public class PositionRelationServiceTest {
	
	   @Autowired
	   PositionRelationService positionRelationService;

	   @Test
	   public void retrievePositionRelation()
	   {
		   PositionRelationRequest positionRelationRequest = new PositionRelationRequest();
		   positionRelationRequest.setSeq("3");
		   Response rs = positionRelationService.retrievePositionRelation(positionRelationRequest); 
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	
}