package com.aia.glory.channeladminservice.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(value = "handler") 
public class EntityModel{
		
	private ParticipantModel participantModel = new ParticipantModel();
	
	private PositionModel positionModel = new PositionModel();
	
	private PositionNodeModel leaderModel;
	
	private PositionNodeModel managerAgencyModel;
	
	public ParticipantModel getParticipantModel() {
		return participantModel;
	}

	public void setParticipantModel(ParticipantModel participantModel) {
		this.participantModel = participantModel;
	}

	public PositionModel getPositionModel() {
		return positionModel;
	}

	public void setPositionModel(PositionModel positionModel) {
		this.positionModel = positionModel;
	}

	public PositionNodeModel getLeaderModel() {
		return leaderModel;
	}

	public void setLeaderModel(PositionNodeModel leaderModel) {
		this.leaderModel = leaderModel;
	}

	public PositionNodeModel getManagerAgencyModel() {
		return managerAgencyModel;
	}

	public void setManagerManagerAgencyModel(PositionNodeModel managerAgencyModel) {
		this.managerAgencyModel = managerAgencyModel;
	}

	@Override
	public String toString() {
		return "EntityModel [participantModel=" + participantModel
				+ ", positionModel=" + positionModel + ", leaderModel="
				+ leaderModel + ", managerAgencyModel=" + managerAgencyModel
				+ "]";
	}

}
