package com.aia.glory.channeladminservice.dao;

import java.util.List;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.channeladminservice.model.PositionRelationModel;
import com.aia.glory.channeladminservice.model.PositionRelationTypeModel;
import com.aia.glory.model.request.PositionRelationRequest;


public interface PositionRelationDao {

	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<PositionRelationTypeModel> selectPositionRelationType(PositionRelationRequest positionRelationRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectPositionRelationTypeTotal(PositionRelationRequest positionRelationRequest);
		
	public void insertPositionRelationType(PositionRelationTypeModel positionTypeModel);

	public void insertPositionRelation(PositionRelationModel positionRelationModel);

	public void updatePositionRelationType(PositionRelationTypeModel positionTypeModel);
	
	public void deletePositionRelation(PositionRelationTypeModel positionTypeModel);


}
