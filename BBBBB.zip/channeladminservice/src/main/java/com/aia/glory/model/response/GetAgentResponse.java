package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetAgentResponse extends Response
 {
	private Object agentModel;
	
	private int total;

	public Object getAgentModel() {
		return agentModel;
	}

	public void setAgentModel(Object agentModel) {
		this.agentModel = agentModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetAgentResponse success(ResponseCode responseCode) {
		GetAgentResponse getAgentResponse = new GetAgentResponse();
		getAgentResponse.setResponseCode(responseCode.getCode());
		getAgentResponse.setReasonCode(Arrays.asList("0000"));
		getAgentResponse.setReasonDesc(Arrays.asList(""));
		return getAgentResponse;
	}

	public static GetAgentResponse success(ResponseCode responseCode,Object agentModel,int total) 
	 {        
		GetAgentResponse getAgentResponse = new GetAgentResponse();        
		getAgentResponse.setResponseCode(responseCode.getCode());
		getAgentResponse.setReasonCode(Arrays.asList("0000"));
		getAgentResponse.setReasonDesc(Arrays.asList(""));
		getAgentResponse.setAgentModel(agentModel);
		getAgentResponse.setTotal(total);
		return getAgentResponse;    
		 
	 }
	
	public static GetAgentResponse fail(ResponseCode responseCode,String errorMsg) {
		GetAgentResponse getAgentResponse = new GetAgentResponse();
		getAgentResponse.setResponseCode(responseCode.getCode());
		getAgentResponse.setReasonCode(Arrays.asList("0000"));
		getAgentResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getAgentResponse;
	}

	@Override
	public String toString() {
		return "GetAgentResponse [agentModel=" + agentModel + ", total=" + total + "]" + super.toString();
	}
	
}
