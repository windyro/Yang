package com.aia.glory.channeladminservice.model;

public class ContractModel {

	private String participantSeq;
	
	private String name;
	
	private String contractCode;
	
	private String identificationNumb;
	
	private String baseSalary;
	
	private String hireDate;
	
	private String agentTitle;
	
	private String promotionDate;
	
	private String demotionDate;
	
	private String terminationDate;
	
	private String paidInPolicyCurrency;
	
	private String paymentMethod;
	
	private String usdAcctNumb;
	
	private String usdBankCode;
	
	private String usdBranchCode;
	
	private String localAcctNumb;
	
	private String localBankCode;
	
	private String localBranchCode;
	
	public String getParticipantSeq() {
		return participantSeq;
	}
	public void setParticipantSeq(String participantSeq) {
		this.participantSeq = participantSeq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContractCode() {
		return contractCode;
	}
	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}
	public String getIdentificationNumb() {
		return identificationNumb;
	}
	public void setIdentificationNumb(String identificationNumb) {
		this.identificationNumb = identificationNumb;
	}
	public String getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(String baseSalary) {
		this.baseSalary = baseSalary;
	}
	public String getHireDate() {
		return hireDate;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	public String getAgentTitle() {
		return agentTitle;
	}
	public void setAgentTitle(String agentTitle) {
		this.agentTitle = agentTitle;
	}
	public String getPromotionDate() {
		return promotionDate;
	}
	public void setPromotionDate(String promotionDate) {
		this.promotionDate = promotionDate;
	}
	public String getDemotionDate() {
		return demotionDate;
	}
	public void setDemotionDate(String demotionDate) {
		this.demotionDate = demotionDate;
	}
	public String getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}
	public String getPaidInPolicyCurrency() {
		return paidInPolicyCurrency;
	}
	public void setPaidInPolicyCurrency(String paidInPolicyCurrency) {
		this.paidInPolicyCurrency = paidInPolicyCurrency;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getUsdAcctNumb() {
		return usdAcctNumb;
	}
	public void setUsdAcctNumb(String usdAcctNumb) {
		this.usdAcctNumb = usdAcctNumb;
	}
	public String getUsdBankCode() {
		return usdBankCode;
	}
	public void setUsdBankCode(String usdBankCode) {
		this.usdBankCode = usdBankCode;
	}
	public String getUsdBranchCode() {
		return usdBranchCode;
	}
	public void setUsdBranchCode(String usdBranchCode) {
		this.usdBranchCode = usdBranchCode;
	}
	public String getLocalAcctNumb() {
		return localAcctNumb;
	}
	public void setLocalAcctNumb(String localAcctNumb) {
		this.localAcctNumb = localAcctNumb;
	}
	public String getLocalBankCode() {
		return localBankCode;
	}
	public void setLocalBankCode(String localBankCode) {
		this.localBankCode = localBankCode;
	}
	public String getLocalBranchCode() {
		return localBranchCode;
	}
	public void setLocalBranchCode(String localBranchCode) {
		this.localBranchCode = localBranchCode;
	}
	@Override
	public String toString() {
		return "ContractModel [participantSeq=" + participantSeq + ", name=" + name + ", contractCode=" + contractCode
				+ ", identificationNumb=" + identificationNumb + ", baseSalary=" + baseSalary + ", hireDate=" + hireDate
				+ ", agentTitle=" + agentTitle + ", promotionDate=" + promotionDate + ", demotionDate=" + demotionDate
				+ ", terminationDate=" + terminationDate + ", paidInPolicyCurrency=" + paidInPolicyCurrency
				+ ", paymentMethod=" + paymentMethod + ", usdAcctNumb=" + usdAcctNumb + ", usdBankCode=" + usdBankCode
				+ ", usdBranchCode=" + usdBranchCode + ", localAcctNumb=" + localAcctNumb + ", localBankCode="
				+ localBankCode + ", localBranchCode=" + localBranchCode + "]";
	}
	
	
}
