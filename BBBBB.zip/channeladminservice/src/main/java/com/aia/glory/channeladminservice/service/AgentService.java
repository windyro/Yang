package com.aia.glory.channeladminservice.service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.aia.glory.channeladminservice.dao.AgentDao;
import com.aia.glory.channeladminservice.model.AgentModel;
import com.aia.glory.channeladminservice.model.FamilyModel;
import com.aia.glory.channeladminservice.model.GenericAttributeModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.util.TimeUtils;
import com.aia.glory.model.request.AgentActionRequest;
import com.aia.glory.model.request.AgentRequest;
import com.aia.glory.model.response.GetAgentResponse;
import com.aia.glory.model.response.GetExtendFieldDescResponse;

@Service(value = "agentService")
public class AgentService {
	@Autowired
	public AgentDao agentDao;

	public GetAgentResponse retrieveAgent(AgentRequest agentRequest) {
		
		int total = agentDao.selectAgentTotal(agentRequest);
		List<AgentModel> agentList = agentDao.selectAgent(agentRequest);
		if(agentRequest.getSeq()!= null && !"".equals(agentRequest.getSeq())){
			this.retrieveGenericField(agentList, agentRequest);
		}
		return GetAgentResponse.success(ResponseCode.NORMAL, agentList, total);
	}
	
	public GetExtendFieldDescResponse retrieveExtendParticipantFieldDesc(){
		Map<String,String> descMap = agentDao.selectExtendParticipantFieldDesc();
		List<GenericAttributeModel> genericAttributeList = new ArrayList();
		if(descMap != null && descMap.size() > 0){
			for(Entry entry : descMap.entrySet()){
				if(!StringUtils.isEmpty(entry.getValue())){
					GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
					genericAttributeModel.setKey((String)entry.getKey());
					genericAttributeModel.setName((String)entry.getValue());
					genericAttributeList.add(genericAttributeModel);
				}
			}
		}
		return GetExtendFieldDescResponse.success(ResponseCode.NORMAL, genericAttributeList);
	}
	
	public GetExtendFieldDescResponse retrieveExtendPositionFieldDesc(){
		Map<String,String> descMap = agentDao.selectExtendPositionFieldDesc();
		List<GenericAttributeModel> genericAttributeList = new ArrayList();
		if(descMap != null && descMap.size() > 0){
			for(Entry entry : descMap.entrySet()){
				if(!StringUtils.isEmpty(entry.getValue())){
					GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
					genericAttributeModel.setKey((String)entry.getKey());
					genericAttributeModel.setName((String)entry.getValue());
					genericAttributeList.add(genericAttributeModel);
				}
			}
		}
		return GetExtendFieldDescResponse.success(ResponseCode.NORMAL, genericAttributeList);
	}
	
	@Transactional
	public GeneryResponse createAgent(AgentActionRequest agentRequest) throws Exception {
		
		boolean createAction = true;
		
		if(this.checkParticipantExsit(agentRequest)) {
			return GeneryResponse.fail(ResponseCode.ERROR, ReasonCode.GENERIC_ERROR.getCode(), "agent existed");
		}
		
		if(agentRequest.getParticipantModel() != null) {
			String requestSeq = agentRequest.getParticipantModel().getSeq();
			Map<String,String> valueMap = new HashMap<String, String>();
			List<GenericAttributeModel> genericAttributeList = agentRequest.getParticipantModel().getGenericFields(); 
			if(genericAttributeList!=null && genericAttributeList.size() >0 ){
				valueMap= genericAttributeList.stream().collect(Collectors.toMap(GenericAttributeModel::getKey, GenericAttributeModel::getValue));
			}
			if(requestSeq != null && !"".equals(requestSeq)) {
				createAction = false;
				this.updateOldVersion(agentRequest);// do updateagent then delete old data.
				agentDao.addNewParticipantVersion(agentRequest.getParticipantModel(),valueMap);
			}else {
				agentDao.addParticipant(agentRequest.getParticipantModel(),valueMap);
			}
		}
		String seq = agentRequest.getParticipantModel().getSeq();
		
		this.createContract(agentRequest,seq);
		this.createEducation(agentRequest,seq);
		this.createFamily(agentRequest,seq);
		this.createPosition(agentRequest,createAction);
		this.updateLeaderCode(agentRequest);
		
		return GeneryResponse.success(ResponseCode.NORMAL,seq);
	}
	
	private void createContract(AgentActionRequest agentRequest,String seq) {
		if(agentRequest.getContractModel() != null) {
			agentRequest.getContractModel().setParticipantSeq(seq);
			agentDao.addcontract(agentRequest.getContractModel());
		}
	}
	private void createEducation(AgentActionRequest agentRequest,String seq) {
		if(agentRequest.getEducationModel() != null) {
			agentRequest.getEducationModel().setParticipantSeq(seq);
			agentRequest.getEducationModel().setName(agentRequest.getParticipantModel().getAgentCode());
			agentDao.addAgentEducation(agentRequest.getEducationModel());
		}
	}
	private void createFamily(AgentActionRequest agentRequest,String seq) {
		if(agentRequest.getFamilyModel() != null && !agentRequest.getFamilyModel().isEmpty()) {
			for(FamilyModel fm : agentRequest.getFamilyModel()) {
				fm.setParticipantSeq(seq);
				fm.setEffectiveEndDate(agentRequest.getParticipantModel().getEffectiveEndDate());
				fm.setEffectiveStartDate(agentRequest.getParticipantModel().getEffectiveStartDate());
				agentDao.addAgentFamily(fm);
			}
		}
	}
	private void createPosition(AgentActionRequest agentRequest,boolean createAction) {
		Map<String,String> valueMap = new HashMap<String, String>();
		List<GenericAttributeModel> genericAttributeList = agentRequest.getPositionModel().getGenericFields(); 
		if(genericAttributeList!=null && genericAttributeList.size() >0 ){
			valueMap= genericAttributeList.stream().collect(Collectors.toMap(GenericAttributeModel::getKey, GenericAttributeModel::getValue));
		}
		if(agentRequest.getPositionModel() != null && createAction) {
			agentDao.addAgentPosition(agentRequest.getPositionModel(), agentRequest.getParticipantModel(),valueMap);
			//agentDao.addAgentEducation(agentRequest.getEducationModel());
		}else if(agentRequest.getPositionModel() != null){
			agentDao.updateAgentPositionVersion(agentRequest.getPositionModel(), agentRequest.getParticipantModel(),valueMap);
		}
	}
	private void updateLeaderCode(AgentActionRequest agentRequest){
		if(agentRequest.getPositionModel().getIsEntityLeader() != null && agentRequest.getPositionModel() != null) {
			if("Y".equals(agentRequest.getPositionModel().getIsEntityLeader()) ){
				agentDao.isEntityLeader(agentRequest);
			}else if("N".equals(agentRequest.getPositionModel().getIsEntityLeader()) ){
				agentDao.isNotEntityLeader(agentRequest);
			}
		}
	}
	private boolean checkParticipantExsit(AgentActionRequest agentRequest) {
		
		List<ParticipantModel> pmList = agentDao.checkParticipantModel(agentRequest.getParticipantModel().getAgentCode());
		if(pmList != null && !pmList.isEmpty() && agentRequest.getParticipantModel().getSeq() ==null) {
			return true;
		}else if(pmList != null && pmList.size() == 1 && agentRequest.getParticipantModel().getSeq() !=null){
			for(ParticipantModel pm : pmList) {
				if(agentRequest.getParticipantModel().getSeq().equals(pm.getSeq())) {
					return false;
				}else {
					return true;
				}
			}
		}else if(pmList != null && pmList.size() > 1){
			return true;
		}
		return false;
		
	}
	
	private void updateOldVersion(AgentActionRequest agentRequest) throws Exception{
		String partSeq = agentRequest.getParticipantModel().getSeq();
		String posSeq = agentRequest.getPositionModel().getPositionSeq();
		String startDate = agentRequest.getParticipantModel().getEffectiveStartDate();
		String endDate = TimeUtils.getDiffDateByDate(startDate, -1);
		
		agentDao.deleteAgentEducation(partSeq);
		agentDao.deleteAgentFamily(partSeq);
		agentDao.deleteContract(partSeq);
		agentDao.updateAgentToExpired(partSeq, endDate);
		agentDao.updateAgentPositionToExpired(posSeq, endDate);
	}
	
	private List<AgentModel> retrieveGenericField(List<AgentModel> agentList, AgentRequest agentRequest){
		List<AgentModel> ResultList = agentList;
		
		Map<String,String> descMap = agentDao.selectExtendParticipantFieldDesc();
		Map<String,String> descMapPos = agentDao.selectExtendPositionFieldDesc();
		
		for(AgentModel agent : ResultList){
			if(agent.getParticipantModel().getSeq()!=null && !"".equals(agent.getParticipantModel().getSeq()) ){
				Map<String,String> valueMap = agentDao.selectExtendParticipantFieldValue(agentRequest);
				if(valueMap ==null){
					valueMap = new HashMap<String, String>();
				}
				List<GenericAttributeModel> genericAttributeList = new ArrayList();
				for(Entry entry : descMap.entrySet()){
					if(!StringUtils.isEmpty(entry.getValue())){
						GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
						genericAttributeModel.setKey((String)entry.getKey());
						genericAttributeModel.setName((String)entry.getValue());
						
						Object value = valueMap.get(entry.getKey());
						if(value instanceof String){
							genericAttributeModel.setValue((String)value);
						}else if(value instanceof Date){
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
							genericAttributeModel.setValue(formatter.format(value));
						}else if(value instanceof BigDecimal){
							DecimalFormat format = new DecimalFormat("0.00");
						    String result = format.format(((BigDecimal) value));
							genericAttributeModel.setValue(result);
//							genericAttributeModel.setType("NUMBER");
						}else{
							genericAttributeModel.setValue((String) value);
						}
						genericAttributeList.add(genericAttributeModel);
					}
				}
				agent.getParticipantModel().setGenericFields(genericAttributeList);
				
				Map<String,String> valueMapPos = agentDao.selectExtendPositionFieldValue(agentRequest);
				if(valueMapPos ==null){
					valueMapPos = new HashMap<String, String>();
				}
				
				List<GenericAttributeModel> genericAttributeListPos = new ArrayList();
				for(Entry entry : descMapPos.entrySet()){
					if(!StringUtils.isEmpty(entry.getValue())){
						GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
						genericAttributeModel.setKey((String)entry.getKey());
						genericAttributeModel.setName((String)entry.getValue());
						
						Object value = valueMapPos.get(entry.getKey());
						if(value instanceof String){
							genericAttributeModel.setValue((String)value);
						}else if(value instanceof Date){
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
							genericAttributeModel.setValue(formatter.format(value));
						}else if(value instanceof BigDecimal){
							DecimalFormat format = new DecimalFormat("0.00");
						    String result = format.format(((BigDecimal) value));
							genericAttributeModel.setValue(result);
//							genericAttributeModel.setType("NUMBER");
						}else{
							genericAttributeModel.setValue((String) value);
						}
						genericAttributeListPos.add(genericAttributeModel);
					}
				}			
				agent.getPositionModel().setGenericFields(genericAttributeListPos);
				
			}
		}
		
		return ResultList;
	}
}

