package com.aia.glory.channeladminservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.channeladminservice.dao.AgentDao;
import com.aia.glory.channeladminservice.dao.EntityDao;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.EntityCreateRequest;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;
import com.aia.glory.model.response.GetVersionResponse;
import com.aia.glory.model.response.UpdateVersionResponse;

@Service(value = "versionService")
public class VersionService {
	@Autowired
	public AgentDao agentDao;
	@Autowired
	public EntityDao entityDao;

	public GetVersionResponse retrieveAgentVersion(VersionRequest versionRequest) {
		
		int total = agentDao.selectParticipantVersionTotal(versionRequest);
		List<VersionModel> versionList = agentDao.selectParticipantVersion(versionRequest);
		return GetVersionResponse.success(ResponseCode.NORMAL, versionList, total);
	}
	
	public GetVersionResponse retrieveEntityVersion(VersionRequest versionRequest) {
		
		int total = entityDao.selectEntityVersionTotal(versionRequest);
		List<VersionModel> versionList = entityDao.selectEntityVersion(versionRequest);
		return GetVersionResponse.success(ResponseCode.NORMAL, versionList, total);
	}
	
	public UpdateVersionResponse updateParticipantVersion(VersionUpdateRequest versionUpdateRequest) {		
		entityDao.updateParticipantVersion(versionUpdateRequest);
		return UpdateVersionResponse.success(ResponseCode.NORMAL);		
	}
	
	public UpdateVersionResponse updatePositionVersion(VersionUpdateRequest versionUpdateRequest) {		
		entityDao.updatePositionVersion(versionUpdateRequest);	
		return UpdateVersionResponse.success(ResponseCode.NORMAL);	
	}
}
