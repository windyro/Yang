package com.aia.glory.channeladminservice.model;

import java.util.List;

public class PositionModel{
	
	private String isEntityLeader;
	
	private String agencyCode;
	
	private String districtCode;
	
	private String title;
	
    private String managerAgency;
    
    private String managerSeq;
    
	private String leaderCode;
	
	private String businessUnit;
	
	private String entityType;
	
	private String positionSeq;
	
	private String channelCode;
	
	private String companyCode;
	
	private List<GenericAttributeModel> genericFields = null;

	public String getIsEntityLeader() {
		return isEntityLeader;
	}

	public void setIsEntityLeader(String isEntityLeader) {
		this.isEntityLeader = isEntityLeader;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getManagerAgency() {
		return managerAgency;
	}

	public void setManagerAgency(String managerAgency) {
		this.managerAgency = managerAgency;
	}

	public String getManagerSeq() {
		return managerSeq;
	}

	public void setManagerSeq(String managerSeq) {
		this.managerSeq = managerSeq;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getLeaderCode() {
		return leaderCode;
	}

	public void setLeaderCode(String leaderCode) {
		this.leaderCode = leaderCode;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getPositionSeq() {
		return positionSeq;
	}

	public void setPositionSeq(String positionSeq) {
		this.positionSeq = positionSeq;
	}

	public List<GenericAttributeModel> getGenericFields() {
		return genericFields;
	}

	public void setGenericFields(List<GenericAttributeModel> genericFields) {
		this.genericFields = genericFields;
	}

	@Override
	public String toString() {
		return "PositionModel [isEntityLeader=" + isEntityLeader
				+ ", agencyCode=" + agencyCode + ", districtCode="
				+ districtCode + ", title=" + title + ", managerAgency="
				+ managerAgency + ", managerSeq=" + managerSeq
				+ ", leaderCode=" + leaderCode + ", businessUnit="
				+ businessUnit + ", entityType=" + entityType
				+ ", positionSeq=" + positionSeq + ", channelCode="
				+ channelCode + ", companyCode=" + companyCode
				+ ", genericFields=" + genericFields + "]";
	}

}
