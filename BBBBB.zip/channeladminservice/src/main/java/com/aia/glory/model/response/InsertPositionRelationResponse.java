package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class InsertPositionRelationResponse extends Response
 {
	private String dataTypeSeq;

	public String getDataTypeSeq() {
		return dataTypeSeq;
	}

	public void setDataTypeSeq(String dataTypeSeq) {
		this.dataTypeSeq = dataTypeSeq;
	}

	public static InsertPositionRelationResponse success(ResponseCode responseCode) {
		InsertPositionRelationResponse getPositionNodeResponse = new InsertPositionRelationResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(""));
		return getPositionNodeResponse;
	}

	public static InsertPositionRelationResponse success(ResponseCode responseCode,String dataTypeSeq) 
	 {        
		InsertPositionRelationResponse getPositionRelationResponse = new InsertPositionRelationResponse();        
		getPositionRelationResponse.setResponseCode(responseCode.getCode());
		getPositionRelationResponse.setReasonCode(Arrays.asList("0000"));
		getPositionRelationResponse.setReasonDesc(Arrays.asList(""));
		getPositionRelationResponse.setDataTypeSeq(dataTypeSeq);
		return getPositionRelationResponse;    
		 
	 }
	
	public static InsertPositionRelationResponse fail(ResponseCode responseCode,String errorMsg) {
		InsertPositionRelationResponse getPositionNodeResponse = new InsertPositionRelationResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getPositionNodeResponse;
	}

	@Override
	public String toString() {
		return "InsertPositionRelationResponse [dataTypeSeq=" + dataTypeSeq + "]" + super.toString();
	}
	
}
