package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class InsertEntityResponse extends Response
 {
	private String participantSeq;

	private String positionSeq;
	
	public String getParticipantSeq() {
		return participantSeq;
	}

	public void setParticipantSeq(String participantSeq) {
		this.participantSeq = participantSeq;
	}

	public String getPositionSeq() {
		return positionSeq;
	}

	public void setPositionSeq(String positionSeq) {
		this.positionSeq = positionSeq;
	}

	public static InsertEntityResponse success(ResponseCode responseCode) {
		InsertEntityResponse getPositionNodeResponse = new InsertEntityResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(""));
		return getPositionNodeResponse;
	}

	public static InsertEntityResponse success(ResponseCode responseCode,String participantSeq) 
	 {        
		InsertEntityResponse getPositionRelationResponse = new InsertEntityResponse();        
		getPositionRelationResponse.setResponseCode(responseCode.getCode());
		getPositionRelationResponse.setReasonCode(Arrays.asList("0000"));
		getPositionRelationResponse.setReasonDesc(Arrays.asList(""));
		getPositionRelationResponse.setParticipantSeq(participantSeq);
		return getPositionRelationResponse;    
		 
	 }
	
	public static InsertEntityResponse fail(ResponseCode responseCode,String errorMsg) {
		InsertEntityResponse getPositionNodeResponse = new InsertEntityResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getPositionNodeResponse;
	}

	@Override
	public String toString() {
		return "InsertEntityResponse [participantSeq=" + participantSeq + ", positionSeq=" + positionSeq + "]" + super.toString();
	}
	
}
