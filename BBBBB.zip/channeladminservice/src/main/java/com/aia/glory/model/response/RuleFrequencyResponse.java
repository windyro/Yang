package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class RuleFrequencyResponse extends Response{
	
	private Object rule_frequency;
	
	public Object getRule_frequency() {
		return rule_frequency;
	}

	public void setRule_frequency(Object rule_frequency) {
		this.rule_frequency = rule_frequency;
	}

	public static RuleFrequencyResponse success(ResponseCode responseCode,Object rule_frequency) 
	 {        
		RuleFrequencyResponse generalInfomationResponse = new RuleFrequencyResponse();        
		generalInfomationResponse.setResponseCode(responseCode.getCode());
		generalInfomationResponse.setReasonCode(Arrays.asList("0000"));
		generalInfomationResponse.setReasonDesc(Arrays.asList(""));
		generalInfomationResponse.setRule_frequency(rule_frequency);
		return generalInfomationResponse;    
		 
	 }

	@Override
	public String toString() {
		return "RuleFrequencyResponse [rule_frequency=" + rule_frequency + "]" + super.toString();
	}
}
