package com.aia.glory.model.request;

import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.common.model.request.Request;

public class EntityCreateRequest extends Request{
	
	private EntityModel entityModel;

	public EntityModel getEntityModel() {
		return entityModel;
	}

	public void setEntityModel(EntityModel entityModel) {
		this.entityModel = entityModel;
	}

}
