package com.aia.glory.channeladminservice.model;

public class EducationModel {
	
	private String participantSeq;
	
	private String name;
	
	private String highestEducation;
	
	private String graduateSchool;

	public String getParticipantSeq() {
		return participantSeq;
	}

	public void setParticipantSeq(String participantSeq) {
		this.participantSeq = participantSeq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHighestEducation() {
		return highestEducation;
	}

	public void setHighestEducation(String highestEducation) {
		this.highestEducation = highestEducation;
	}

	public String getGraduateSchool() {
		return graduateSchool;
	}

	public void setGraduateSchool(String graduateSchool) {
		this.graduateSchool = graduateSchool;
	}

	@Override
	public String toString() {
		return "EducationModel [participantSeq=" + participantSeq + ", name=" + name + ", highestEducation="
				+ highestEducation + ", graduateSchool=" + graduateSchool + "]";
	}

	
}
