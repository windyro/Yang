package com.aia.glory.model.request;

import javax.validation.constraints.Pattern;

import com.aia.glory.common.model.request.Request;

public class PositionRelationRequest extends Request{
	 
	private String seq;
	
	private String typeName;
	
	private String typeNameEqual;
	
	private String description;
	
	private String active;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
    private String createDate;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
    private String removeDate;
	    
    private int startPage = 0;
	
   	private int pageSize = 0;


	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getTypeNameEqual() {
		return typeNameEqual;
	}

	public void setTypeNameEqual(String typeNameEqual) {
		this.typeNameEqual = typeNameEqual;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}
	
	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getRemoveDate() {
		return removeDate;
	}

	public void setRemoveDate(String removeDate) {
		this.removeDate = removeDate;
	}

	public void setStartPage(int startPage) {
		if(startPage == 0) {
			startPage =1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(int pageSize) {
		if(pageSize == 0) {
			pageSize =1;
		}
		this.pageSize = pageSize;
	}
	
	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}
}
