
package com.aia.glory.channeladminservice.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.channeladminservice.model.PositionModel;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.channeladminservice.service.EntityService;
import com.aia.glory.channeladminservice.service.VersionService;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.common.util.TimeUtils;
import com.aia.glory.model.request.EntityCreateRequest;
import com.aia.glory.model.request.EntityRequest;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;
import com.aia.glory.model.response.CreateEntityResponse;
import com.aia.glory.model.response.GetEntityResponse;
import com.aia.glory.model.response.GetVersionResponse;

@RestController
public class EntityController {
	
	@Autowired
	@Qualifier(value = "entityService")
	private EntityService entityService;
	
	@Autowired
	@Qualifier(value = "versionService")
	private VersionService versionService;
	
	@RequestMapping(value = "/entity", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Response entity(@Valid  HttpServletRequest request, @RequestBody String requestBody) throws IOException{
	
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		Response response = null;
		
		switch (action) {
		case "GET":
			response = retrieveEntity(requestBody);
			break;	
			
		case "GETPARTEXTDESC":
			response = retrieveExtendParticipantFieldDesc(requestBody);
			break;
			
		case "GETPOSEXTDESC":
			response = retrieveExtendPositionFieldDesc(requestBody);
			break;
			
		case "INSERT":
			response = insertEntity(requestBody);
			break;	
		default:
			break;
		}
		
		return response;
	}

	private Response retrieveEntity(String requestBody) throws IOException{
		EntityRequest entityRequest= (EntityRequest) JsonToObjectUtil.jsonToObj(new EntityRequest(), requestBody);
		Response response = entityService.retrieveEntity(entityRequest);
		return response;
	}
	
	private Response retrieveExtendParticipantFieldDesc(String requestBody) throws IOException{
		//ntityRequest entityRequest= (EntityRequest) JsonToObjectUtil.jsonToObj(new EntityRequest(), requestBody);
		Response response = entityService.retrieveExtendParticipantFieldDesc();
		return response;
	}
	
	private Response retrieveExtendPositionFieldDesc(String requestBody) throws IOException{
		//ntityRequest entityRequest= (EntityRequest) JsonToObjectUtil.jsonToObj(new EntityRequest(), requestBody);
		Response response = entityService.retrieveExtendPositionFieldDesc();
		return response;
	}
	
	private Response insertEntity(String requestBody) throws IOException{
		EntityCreateRequest entityCreateRequest= (EntityCreateRequest) JsonToObjectUtil.jsonToObj(new EntityCreateRequest(), requestBody);
		String seq = entityCreateRequest.getEntityModel().getParticipantModel().getSeq();
		
		//New entity
		if(seq == null || "".equals(seq) ){
			return createNewEntity(entityCreateRequest);
		}
		//New version of existed entity
		else{
			return createNewEntityVersion(entityCreateRequest);
		}
	}
	
	private Response createNewEntityVersion(EntityCreateRequest entityCreateRequest) throws IOException{

		VersionModel newVersion = entityCreateRequest.getEntityModel().getParticipantModel().getVersionModel();
		
		VersionRequest oldVersionRequest = new VersionRequest();
		oldVersionRequest.setSeq(newVersion.getSeq());
		oldVersionRequest.setIsLast("1");
		GetVersionResponse versionResponse = versionService.retrieveEntityVersion(oldVersionRequest);
		List<VersionModel> versionList = (List<VersionModel>)versionResponse.getVersionModel();
		if(versionList == null || versionList.isEmpty()){
			return CreateEntityResponse.fail(ResponseCode.ERROR, "Cant' find old versions");
		}
		VersionModel oldVersion = versionList.get(0);
		oldVersionRequest.setEffectiveStartDate(oldVersion.getEffectiveStartDate());
		oldVersionRequest.setEffectiveEndDate(oldVersion.getEffectiveEndDate());
		//End the old version at one day before.
		String effectiveEndDate = TimeUtils.getDiffDateByDate(newVersion.getEffectiveStartDate(), -1);
		oldVersion.setIsLast("0");
		oldVersion.setEffectiveEndDate(effectiveEndDate);
		VersionUpdateRequest versionUpdateRequest= new VersionUpdateRequest();
		versionUpdateRequest.setVersionRequest(oldVersionRequest);
		versionUpdateRequest.setVersionModel(oldVersion);
	    versionService.updateParticipantVersion(versionUpdateRequest);
		versionService.updatePositionVersion(versionUpdateRequest);
	    
		newVersion.setEffectiveEndDate(VersionModel.DEFAULT_END_DATE);
		newVersion.setEffectiveEndDate(VersionModel.DEFAULT_END_DATETIME);
		newVersion.setIsLast("1");
		
		Response response = null;
		response = entityService.insertEntityParticipant(entityCreateRequest);
		
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			entityService.insertEntityPosition(entityCreateRequest);
		}
		
		return response;
	}
	
	private Response createNewEntity(EntityCreateRequest entityCreateRequest) throws IOException{

		VersionModel newVersion = entityCreateRequest.getEntityModel().getParticipantModel().getVersionModel();
			    
		//Check if the entity code already used
		EntityRequest entityRequest = new EntityRequest();
		entityRequest.setAgencyCode(entityCreateRequest.getEntityModel().getParticipantModel().getAgentCode());
		GetEntityResponse getEntityResponse = entityService.retrieveEntity(entityRequest);
		List<EntityModel> entityList = (List<EntityModel>)getEntityResponse.getEntityModel();
		if(entityList != null && !entityList.isEmpty()){
			return CreateEntityResponse.fail(ResponseCode.ERROR, "Entity code alread existed!");
		}
		
		Integer maxPartSeq = entityService.getMaxParticipantSeq();
		newVersion.setSeq(Integer.toString(maxPartSeq));
		newVersion.setEffectiveEndDate(VersionModel.DEFAULT_END_DATE);
		newVersion.setEffectiveEndDate(VersionModel.DEFAULT_END_DATETIME);
		newVersion.setIsLast("1");
		Response response = null;
		response = entityService.insertEntityParticipant(entityCreateRequest);
		
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			PositionModel positionModel = entityCreateRequest.getEntityModel().getPositionModel();
			Integer maxPosSeq = entityService.getMaxPositionSeq();
			positionModel.setPositionSeq(Integer.toString(maxPosSeq));
			entityService.insertEntityPosition(entityCreateRequest);
		}
		
		return response;
	}
	
}
