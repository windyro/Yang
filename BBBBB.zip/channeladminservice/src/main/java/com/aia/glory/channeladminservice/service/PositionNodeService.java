package com.aia.glory.channeladminservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.channeladminservice.dao.GeneralInfomationDao;
import com.aia.glory.channeladminservice.dao.PositionNodeDao;
import com.aia.glory.channeladminservice.model.PositionNodeModel;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.GeneralInfomation;
import com.aia.glory.model.request.PositionNodeRequest;
import com.aia.glory.model.response.GetPositionNodeResponse;

@Service(value = "positionNodeService")
public class PositionNodeService {
	@Autowired
	public PositionNodeDao positionNodeDao;
	
	@Autowired
	public GeneralInfomationDao generalInfomationDao;

	public GetPositionNodeResponse retrievePositionNodeSelf(PositionNodeRequest positionNodeRequest) {
		
		int total = positionNodeDao.selectPositionNodeTotal(positionNodeRequest);
		List<PositionNodeModel> positionNodeList = positionNodeDao.selectPositionNodeModel(positionNodeRequest);
		//positionNodeList = this.convertSeqToName(positionNodeList);
		return GetPositionNodeResponse.success(ResponseCode.NORMAL, positionNodeList, total);
	}
	
	public GetPositionNodeResponse retrievePositionNodeWithParent(PositionNodeRequest positionNodeRequest) {
		
		int total = positionNodeDao.selectPositionNodeTotal(positionNodeRequest);
		List<PositionNodeModel> positionNodeList = positionNodeDao.selectPositionNodeModelWithParent(positionNodeRequest);
		//positionNodeList = this.convertSeqToName(positionNodeList);
		return GetPositionNodeResponse.success(ResponseCode.NORMAL, positionNodeList, total);
	}
	
	public GetPositionNodeResponse retrievePositionNodeWithChild(PositionNodeRequest positionNodeRequest) {
		
		int total = positionNodeDao.selectPositionNodeTotal(positionNodeRequest);
		List<PositionNodeModel> positionNodeList = positionNodeDao.selectPositionNodeModelWithChild(positionNodeRequest);
		//positionNodeList = this.convertSeqToName(positionNodeList);
		return GetPositionNodeResponse.success(ResponseCode.NORMAL, positionNodeList, total);
	}
	
	private List<PositionNodeModel> convertSeqToName(List<PositionNodeModel> positionNodeList){

		List<GeneralInfomation> titleLst = generalInfomationDao.getTitlelList();
		
		List<PositionNodeModel> ResultList = positionNodeList;
		ResultList.forEach(
				positionNode->{
			if(!"".equals(positionNode.getTitle())){
				positionNode.setTitle(this.getInformation(titleLst, positionNode.getTitle(), ""));
			}
			
			if(!"".equals(positionNode.getLeaderTitle())){
				positionNode.setLeaderTitle(this.getInformation(titleLst, positionNode.getLeaderTitle(), ""));
			}
		});
		
		return ResultList;
	}
	
	private String getInformation(List<GeneralInfomation> generalInfomationList, String seq, String name) {
	    
		String result = "";
		if(seq!= null && !"".equals(seq)){
	        for (GeneralInfomation item : generalInfomationList) {
	            if (seq.equals(item.getSeq())) {
	                result = item.getName();
	                break;
	            }
	        }
	    }    	
		else if(name!= null &&!"".equals(name)){
	        for (GeneralInfomation item : generalInfomationList) {
	            if (name.equals(item.getName())) {
	                result = item.getSeq();
	                break;
	            }
	        }
	    }
		
	    return result;
	}
}
