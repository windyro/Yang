package com.aia.glory.model.request;

import javax.validation.constraints.Pattern;

import com.aia.glory.common.model.request.Request;

public class EntityRequest extends Request{
	
    private String seq;
         
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgent need letters or Numbers")
    private String agencyCode;
    
    private String agencyName;
    
    private String leaderCode;
    
    private String managerAgency;
    
    private String managerSeq;
        
    private String type;
    
    private String isLast;
    	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String effectiveStartDate;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String effectiveEndDate;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
    private String createDate;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
    private String removeDate;
	
    private String versionLog;
    
    private String channel;
    
    private String company;
    
    private int startPage = 0;
	
   	private int pageSize = 0;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgentName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getLeaderCode() {
		return leaderCode;
	}

	public void setLeaderCode(String leaderCode) {
		this.leaderCode = leaderCode;
	}

	public String getManagerAgency() {
		return managerAgency;
	}

	public void setManagerAgency(String managerAgency) {
		this.managerAgency = managerAgency;
	}
	
	public String getManagerSeq() {
		return managerSeq;
	}

	public void setManagerSeq(String managerSeq) {
		this.managerSeq = managerSeq;
	}
	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIsLast() {
		return isLast;
	}

	public void setIsLast(String isLast) {
		this.isLast = isLast;
	}

	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getRemoveDate() {
		return removeDate;
	}

	public void setRemoveDate(String removeDate) {
		this.removeDate = removeDate;
	}

	public String getVersionLog() {
		return versionLog;
	}

	public void setVersionLog(String versionLog) {
		this.versionLog = versionLog;
	}

	public void setStartPage(int startPage) {
		if(startPage == 0) {
			startPage =1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(int pageSize) {
		if(pageSize == 0) {
			pageSize =1;
		}
		this.pageSize = pageSize;
	}
	
	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}

}
