package com.aia.glory.channeladminservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.channeladminservice.dao.PositionRelationDao;
import com.aia.glory.channeladminservice.model.PositionRelationModel;
import com.aia.glory.channeladminservice.model.PositionRelationTypeModel;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.model.request.PositionRelationRequest;
import com.aia.glory.model.request.PositionRelationUpdateRequest;
import com.aia.glory.model.response.GetPositionRelationResponse;
import com.aia.glory.model.response.InsertPositionRelationResponse;

@Service(value = "positionRelationService")
public class PositionRelationService {
	@Autowired
	public PositionRelationDao positionRelationDao;

	public GetPositionRelationResponse retrievePositionRelation(PositionRelationRequest positionRelationRequest) {
		
		int total = positionRelationDao.selectPositionRelationTypeTotal(positionRelationRequest);
		List<PositionRelationTypeModel> positionRelationList = positionRelationDao.selectPositionRelationType(positionRelationRequest);
		return GetPositionRelationResponse.success(ResponseCode.NORMAL, positionRelationList, total);
	}
	
	public InsertPositionRelationResponse insertPositionRelationType(PositionRelationUpdateRequest positionRelationUpdateRequest) {
		
		if(positionRelationUpdateRequest != null) {
			positionRelationDao.insertPositionRelationType(positionRelationUpdateRequest.getPositionRelationTypeModel());
		}
		return InsertPositionRelationResponse.success(ResponseCode.NORMAL, positionRelationUpdateRequest.getPositionRelationTypeModel().getDataTypeSeq());
	
	}
	
	public GeneryResponse insertPositionRelation(PositionRelationUpdateRequest positionRelationUpdateRequest) {
		
		if(positionRelationUpdateRequest != null) {
			PositionRelationTypeModel positionRelationTypeModel = positionRelationUpdateRequest.getPositionRelationTypeModel();
			for(PositionRelationModel positionRelationModel : positionRelationTypeModel.getPositionRelationModel()) {
				positionRelationModel.setPositionRelationTypeSeq(positionRelationTypeModel.getDataTypeSeq());
				positionRelationDao.insertPositionRelation(positionRelationModel);
			}
		}
		return GeneryResponse.success();
	
	}
	
	public GeneryResponse updatePositionRelationType(PositionRelationUpdateRequest positionRelationUpdateRequest) {
		
		if(positionRelationUpdateRequest != null) {
			positionRelationDao.updatePositionRelationType(positionRelationUpdateRequest.getPositionRelationTypeModel());
		}
		return GeneryResponse.success();
	
	}
	
	public GeneryResponse deletePositionRelation(PositionRelationUpdateRequest positionRelationUpdateRequest) {
		
		if(positionRelationUpdateRequest != null) {
			positionRelationDao.deletePositionRelation(positionRelationUpdateRequest.getPositionRelationTypeModel());
		}
		return GeneryResponse.success();
	
	}
}
