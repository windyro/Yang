package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetEntityResponse extends Response
 {
	private Object entityModel;
	
	private int total;

	public Object getEntityModel() {
		return entityModel;
	}

	public void setEntityModel(Object entityModel) {
		this.entityModel = entityModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetEntityResponse success(ResponseCode responseCode) {
		GetEntityResponse getEntityResponse = new GetEntityResponse();
		getEntityResponse.setResponseCode(responseCode.getCode());
		getEntityResponse.setReasonCode(Arrays.asList("0000"));
		getEntityResponse.setReasonDesc(Arrays.asList(""));
		return getEntityResponse;
	}

	public static GetEntityResponse success(ResponseCode responseCode,Object entityModel,int total) 
	 {        
		GetEntityResponse getEntityResponse = new GetEntityResponse();        
		getEntityResponse.setResponseCode(responseCode.getCode());
		getEntityResponse.setReasonCode(Arrays.asList("0000"));
		getEntityResponse.setReasonDesc(Arrays.asList(""));
		getEntityResponse.setEntityModel(entityModel);
		getEntityResponse.setTotal(total);
		return getEntityResponse;    
		 
	 }
	
	public static GetEntityResponse fail(ResponseCode responseCode,String errorMsg) {
		GetEntityResponse getEntityResponse = new GetEntityResponse();
		getEntityResponse.setResponseCode(responseCode.getCode());
		getEntityResponse.setReasonCode(Arrays.asList("0000"));
		getEntityResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getEntityResponse;
	}

	@Override
	public String toString() {
		return "GetEntityResponse [entityModel=" + entityModel + ", total=" + total + "]" + super.toString();
	}
	
}
