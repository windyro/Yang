package com.aia.glory.channeladminservice.model;

import java.util.List;

public class ParticipantModel{

	private String seq;
	
	private String agentCode;
	
	private String identificationNumb;
	
	private String firstName;

	private String middleName;
	
	private String lastName;
	
	private String agentStatus;
	
	private String hireDate;
	private String recordType;
	private String agentType;
	private String recruitSource;
	private String recruiterCode;
	private String businessUnit;
	private String email;
	private String domicilePlace;
	private String taxId;
	private String gender;
	private String dob;
	private String beneficiaryName;
	private String fsc1stAssignment;
	private String fortsAgent;
	private String nationality;
	private String preferredLanguage;
	private String agentTelephone;
	private String agentCellPhone;
	private String emergencyContact;
	private String emergencyContactNo;
	private String residentialAddress;
	private String postalCode;
	private String retiredDate;
	private String rejoinFlag;
	private String rejoinDate;
	private String effectiveStartDate;
	private String effectiveEndDate;
	private String maritalStatus;
	private String familyContact;
	private String familyAddress;
	private String eventCalendar;
	
	private VersionModel versionModel = new VersionModel();
	private List<GenericAttributeModel> genericFields = null;

	public void setSeq(String seq) {
		
		this.versionModel.setSeq(seq);
	}

	public String getAgentStatus() {
		return agentStatus;
	}

	public void setAgentStatus(String agentStatus) {
		this.agentStatus = agentStatus;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public String getSeq() {
		this.seq = this.versionModel==null ? null : this.versionModel.getSeq();
		return this.seq;
	}
	
	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getIdentificationNumb() {
		return identificationNumb;
	}

	public void setIdentificationNumb(String identificationNumb) {
		this.identificationNumb = identificationNumb;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public VersionModel getVersionModel() {
		return versionModel;
	}

	public void setVersionModel(VersionModel versionModel) {
		this.versionModel = versionModel;
	}

	public String getAgentType() {
		return agentType;
	}

	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}

	public String getRecruitSource() {
		return recruitSource;
	}

	public void setRecruitSource(String recruitSource) {
		this.recruitSource = recruitSource;
	}

	public String getRecruiterCode() {
		return recruiterCode;
	}

	public void setRecruiterCode(String recruiterCode) {
		this.recruiterCode = recruiterCode;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomicilePlace() {
		return domicilePlace;
	}

	public void setDomicilePlace(String domicilePlace) {
		this.domicilePlace = domicilePlace;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getFsc1stAssignment() {
		return fsc1stAssignment;
	}

	public void setFsc1stAssignment(String fsc1stAssignment) {
		this.fsc1stAssignment = fsc1stAssignment;
	}

	public String getFortsAgent() {
		return fortsAgent;
	}

	public void setFortsAgent(String fortsAgent) {
		this.fortsAgent = fortsAgent;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPreferredLanguage() {
		return preferredLanguage;
	}

	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	public String getAgentTelephone() {
		return agentTelephone;
	}

	public void setAgentTelephone(String agentTelephone) {
		this.agentTelephone = agentTelephone;
	}

	public String getAgentCellPhone() {
		return agentCellPhone;
	}

	public void setAgentCellPhone(String agentCellPhone) {
		this.agentCellPhone = agentCellPhone;
	}

	public String getEmergencyContact() {
		return emergencyContact;
	}

	public void setEmergencyContact(String emergencyContact) {
		this.emergencyContact = emergencyContact;
	}

	public String getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public void setEmergencyContactNo(String emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

	public String getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getRetiredDate() {
		return retiredDate;
	}

	public void setRetiredDate(String retiredDate) {
		this.retiredDate = retiredDate;
	}

	public String getRejoinFlag() {
		return rejoinFlag;
	}

	public void setRejoinFlag(String rejoinFlag) {
		this.rejoinFlag = rejoinFlag;
	}

	public String getRejoinDate() {
		return rejoinDate;
	}

	public void setRejoinDate(String rejoinDate) {
		this.rejoinDate = rejoinDate;
	}

	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getFamilyContact() {
		return familyContact;
	}

	public void setFamilyContact(String familyContact) {
		this.familyContact = familyContact;
	}

	public String getFamilyAddress() {
		return familyAddress;
	}

	public void setFamilyAddress(String familyAddress) {
		this.familyAddress = familyAddress;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getEventCalendar() {
		return eventCalendar;
	}

	public void setEventCalendar(String eventCalendar) {
		this.eventCalendar = eventCalendar;
	}

	public List<GenericAttributeModel> getGenericFields() {
		return genericFields;
	}

	public void setGenericFields(List<GenericAttributeModel> genericFields) {
		this.genericFields = genericFields;
	}

	@Override
	public String toString() {
		return "ParticipantModel [seq=" + seq + ", agentCode=" + agentCode
				+ ", identificationNumb=" + identificationNumb + ", firstName="
				+ firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", agentStatus=" + agentStatus + ", hireDate="
				+ hireDate + ", recordType=" + recordType + ", agentType="
				+ agentType + ", recruitSource=" + recruitSource
				+ ", recruiterCode=" + recruiterCode + ", businessUnit="
				+ businessUnit + ", email=" + email + ", domicilePlace="
				+ domicilePlace + ", taxId=" + taxId + ", gender=" + gender
				+ ", dob=" + dob + ", beneficiaryName=" + beneficiaryName
				+ ", fsc1stAssignment=" + fsc1stAssignment + ", fortsAgent="
				+ fortsAgent + ", nationality=" + nationality
				+ ", preferredLanguage=" + preferredLanguage
				+ ", agentTelephone=" + agentTelephone + ", agentCellPhone="
				+ agentCellPhone + ", emergencyContact=" + emergencyContact
				+ ", emergencyContactNo=" + emergencyContactNo
				+ ", residentialAddress=" + residentialAddress
				+ ", postalCode=" + postalCode + ", retiredDate=" + retiredDate
				+ ", rejoinFlag=" + rejoinFlag + ", rejoinDate=" + rejoinDate
				+ ", effectiveStartDate=" + effectiveStartDate
				+ ", effectiveEndDate=" + effectiveEndDate + ", maritalStatus="
				+ maritalStatus + ", familyContact=" + familyContact
				+ ", familyAddress=" + familyAddress + ", eventCalendar="
				+ eventCalendar + ", versionModel=" + versionModel
				+ ", genericFields=" + genericFields + "]";
	}
	
}
