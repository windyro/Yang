package com.aia.glory.channeladminservice.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(value = "handler") 
public class PositionRelationTypeModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String dataTypeSeq;
	
    private String createDate;
	
    private String removeDate;
    
    private String name;
	
    private String description;
    
    private String active;

    private List<PositionRelationModel> positionRelationModel;
    
	public String getDataTypeSeq() {
		return dataTypeSeq;
	}

	public void setDataTypeSeq(String dataTypeSeq) {
		this.dataTypeSeq = dataTypeSeq;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getRemoveDate() {
		return removeDate;
	}

	public void setRemoveDate(String removeDate) {
		this.removeDate = removeDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public List<PositionRelationModel> getPositionRelationModel() {
		return positionRelationModel;
	}

	public void setPositionRelationModel(List<PositionRelationModel> positionRelationModel) {
		this.positionRelationModel = positionRelationModel;
	}
    
	
}
