package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetPositionRelationResponse extends Response
 {
	private Object positionRelationList;
	
	private int total;

	public Object getPositionRelationList() {
		return positionRelationList;
	}

	public void setPositionRelationList(Object positionRelationList) {
		this.positionRelationList = positionRelationList;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetPositionRelationResponse success(ResponseCode responseCode) {
		GetPositionRelationResponse getPositionNodeResponse = new GetPositionRelationResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(""));
		return getPositionNodeResponse;
	}

	public static GetPositionRelationResponse success(ResponseCode responseCode,Object positionRelationList,int total) 
	 {        
		GetPositionRelationResponse getPositionRelationResponse = new GetPositionRelationResponse();        
		getPositionRelationResponse.setResponseCode(responseCode.getCode());
		getPositionRelationResponse.setReasonCode(Arrays.asList("0000"));
		getPositionRelationResponse.setReasonDesc(Arrays.asList(""));
		getPositionRelationResponse.setPositionRelationList(positionRelationList);
		getPositionRelationResponse.setTotal(total);
		return getPositionRelationResponse;    
		 
	 }
	
	public static GetPositionRelationResponse fail(ResponseCode responseCode,String errorMsg) {
		GetPositionRelationResponse getPositionNodeResponse = new GetPositionRelationResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getPositionNodeResponse;
	}

	@Override
	public String toString() {
		return "GetPositionRelationResponse [positionRelationList=" + positionRelationList + ", total=" + total + "]" + super.toString();
	}
	
}
