
package com.aia.glory.channeladminservice.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.channeladminservice.service.VersionService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.EntityRequest;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;

@RestController
public class VersionController {
	
	@Autowired
	@Qualifier(value = "versionService")
	private VersionService versionService;

	@RequestMapping(value = "/version", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response version(@Valid HttpServletRequest request, @RequestBody String requestBody) throws IOException{
			
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		
		Response response = null;
			
		switch (action) {
		case "GET":
			response=retrieveVersion(requestBody);
			break;	
		case "UPDATE":
			response=updateVersion(requestBody);
			break;			
		default:
			break;
		}
		
		return response;
	}
	
	private Response retrieveVersion(String requestBody) throws IOException{
		VersionRequest versionRequest= (VersionRequest) JsonToObjectUtil.jsonToObj(new VersionRequest(), requestBody);
		String type = versionRequest.getType();
		Response response = null;
		
		if(VersionRequest.TYPE_AGENT.equals(type)){
			response = versionService.retrieveAgentVersion(versionRequest);
		}else if(VersionRequest.TYPE_ENTITY.equals(type)){
			response = versionService.retrieveEntityVersion(versionRequest);
		}
		return response;
	}
	
	private Response updateVersion(String requestBody) throws IOException{
		VersionUpdateRequest versionUpdateRequest= (VersionUpdateRequest) JsonToObjectUtil.jsonToObj(new VersionUpdateRequest(), requestBody);
		String type = versionUpdateRequest.getVersionRequest().getType();
		Response response = null;
		
		if(VersionRequest.TYPE_AGENT.equals(type)){
			response = versionService.updateParticipantVersion(versionUpdateRequest);
			response = versionService.updatePositionVersion(versionUpdateRequest);
		}else if(VersionRequest.TYPE_ENTITY.equals(type)){
			response = versionService.updateParticipantVersion(versionUpdateRequest);
			response = versionService.updatePositionVersion(versionUpdateRequest);
		}
		return response;
	}

}
