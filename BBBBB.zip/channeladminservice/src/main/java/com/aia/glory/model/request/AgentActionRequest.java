package com.aia.glory.model.request;

import java.util.List;

import com.aia.glory.channeladminservice.model.ContractModel;
import com.aia.glory.channeladminservice.model.EducationModel;
import com.aia.glory.channeladminservice.model.FamilyModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.channeladminservice.model.PositionModel;
import com.aia.glory.common.model.request.Request;

public class AgentActionRequest extends Request{
	
	private ParticipantModel participantModel;
	
	private PositionModel positionModel;
	
	private ContractModel contractModel;
	
	private EducationModel educationModel;
	
	private List<FamilyModel> familyModel;
	
	public ParticipantModel getParticipantModel() {
		return participantModel;
	}

	public void setParticipantModel(ParticipantModel participantModel) {
		this.participantModel = participantModel;
	}

	public PositionModel getPositionModel() {
		return positionModel;
	}

	public void setPositionModel(PositionModel positionModel) {
		this.positionModel = positionModel;
	}

	public List<FamilyModel> getFamilyModel() {
		return familyModel;
	}

	public void setFamilyModel(List<FamilyModel> familyModel) {
		this.familyModel = familyModel;
	}

	public ContractModel getContractModel() {
		return contractModel;
	}

	public void setContractModel(ContractModel contractModel) {
		this.contractModel = contractModel;
	}

	public EducationModel getEducationModel() {
		return educationModel;
	}

	public void setEducationModel(EducationModel educationModel) {
		this.educationModel = educationModel;
	}
	
	
}
