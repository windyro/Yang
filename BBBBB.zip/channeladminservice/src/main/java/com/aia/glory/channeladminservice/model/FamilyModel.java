package com.aia.glory.channeladminservice.model;

public class FamilyModel{
	
	private String participantSeq;
	
	private String name;
	
	private String familyMemberName;
	
	private String identificationNumb;
	
	private String gender;
	
	private String relationshipWithAgent;
	
	private String dob;
	
	private String contactNo;
	
	private String residentialAddress;
	
	private String postalCode;
	
	private String effectiveStartDate;
	
	private String effectiveEndDate;

	public String getParticipantSeq() {
		return participantSeq;
	}

	public void setParticipantSeq(String participantSeq) {
		this.participantSeq = participantSeq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFamilyMemberName() {
		return familyMemberName;
	}

	public void setFamilyMemberName(String familyMemberName) {
		this.familyMemberName = familyMemberName;
	}

	public String getIdentificationNumb() {
		return identificationNumb;
	}

	public void setIdentificationNumb(String identificationNumb) {
		this.identificationNumb = identificationNumb;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationshipWithAgent() {
		return relationshipWithAgent;
	}

	public void setRelationshipWithAgent(String relationshipWithAgent) {
		this.relationshipWithAgent = relationshipWithAgent;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	@Override
	public String toString() {
		return "FamilyModel [participantSeq=" + participantSeq + ", name=" + name + ", familyMemberName="
				+ familyMemberName + ", identificationNumb=" + identificationNumb + ", gender=" + gender
				+ ", relationshipWithAgent=" + relationshipWithAgent + ", dob=" + dob + ", contactNo=" + contactNo
				+ ", residentialAddress=" + residentialAddress + ", postalCode=" + postalCode + ", effectiveStartDate="
				+ effectiveStartDate + ", effectiveEndDate=" + effectiveEndDate + "]";
	}
	
}
