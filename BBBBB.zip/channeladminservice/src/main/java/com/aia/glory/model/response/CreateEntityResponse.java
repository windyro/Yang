package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class CreateEntityResponse extends Response
 {

	public static CreateEntityResponse success(ResponseCode responseCode) {
		CreateEntityResponse createEntityResponse = new CreateEntityResponse();
		createEntityResponse.setResponseCode(responseCode.getCode());
		createEntityResponse.setReasonCode(Arrays.asList("0000"));
		createEntityResponse.setReasonDesc(Arrays.asList(""));
		return createEntityResponse;
	}

	public static CreateEntityResponse fail(ResponseCode responseCode,String errorMsg) 
	 {        
		 CreateEntityResponse createEntityResponse = new CreateEntityResponse();        
		 createEntityResponse.setResponseCode(responseCode.getCode());
		 createEntityResponse.setReasonCode(Arrays.asList("0000"));
		 createEntityResponse.setReasonDesc(Arrays.asList(errorMsg));
		 return createEntityResponse;    
		 
	 }
}
