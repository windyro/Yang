
package com.aia.glory.channeladminservice.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.channeladminservice.service.AgentService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.AgentActionRequest;
import com.aia.glory.model.request.AgentRequest;

@RestController
public class AgentController {
	
	@Autowired
	@Qualifier(value = "agentService")
	private AgentService agentService;

	
	@RequestMapping(value = "/agent", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response agent(@Valid @RequestBody AgentRequest agentRequest) throws IOException{
			
		String action =  agentRequest.getAction();
		Response response = null;
			
		switch (action) {
		case "GET":
			response = agentService.retrieveAgent(agentRequest);
			break;	
			
		case "GETPARTEXTDESC":
			response = agentService.retrieveExtendParticipantFieldDesc();
			break;
			
		case "GETPOSEXTDESC":
			response = agentService.retrieveExtendPositionFieldDesc();
			break;
			
		default:
			break;
		}
		
		return response;
	}
	
	@RequestMapping(value = "/agents", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response doAgent(@Valid @RequestBody AgentActionRequest request) throws Exception{
			
		String action =  request.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = agentService.createAgent(request);
			break;	
		default:
			break;
		}
		
		return response;
	}

}
