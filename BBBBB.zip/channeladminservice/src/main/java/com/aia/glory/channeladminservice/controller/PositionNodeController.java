
package com.aia.glory.channeladminservice.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.channeladminservice.service.PositionNodeService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.PositionNodeRequest;

@RestController
public class PositionNodeController {
	
	@Autowired
	@Qualifier(value = "positionNodeService")
	private PositionNodeService positionNodeService;
	
	@RequestMapping(value = "/positionNode", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response positionNode(@Valid @RequestBody PositionNodeRequest positionNodeRequest) throws IOException{
			
		String action =  positionNodeRequest.getAction();
		String nodeType = positionNodeRequest.getNodeType();
		Response response = null;
			
		switch (action) {
		case "GET":
			if(PositionNodeRequest.TYPE_SELF.equals(nodeType)){
				response = positionNodeService.retrievePositionNodeSelf(positionNodeRequest);
			}else if(PositionNodeRequest.TYPE_PARENT.equals(nodeType)){
				response = positionNodeService.retrievePositionNodeWithParent(positionNodeRequest);
			}else if(PositionNodeRequest.TYPE_CHILDREN.equals(nodeType)){
				response = positionNodeService.retrievePositionNodeWithChild(positionNodeRequest);
			}
			break;	
		default:
			break;
		}
		
		return response;
	}

}
