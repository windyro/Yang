package com.aia.glory.model.request;

import com.aia.glory.channeladminservice.model.PositionRelationTypeModel;
import com.aia.glory.common.model.request.Request;

public class PositionRelationUpdateRequest extends Request{
	
	private PositionRelationTypeModel positionRelationTypeModel;

	public PositionRelationTypeModel getPositionRelationTypeModel() {
		return positionRelationTypeModel;
	}

	public void setPositionRelationTypeModel(PositionRelationTypeModel positionRelationTypeModel) {
		this.positionRelationTypeModel = positionRelationTypeModel;
	}

}
