package com.aia.glory.channeladminservice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.aia.glory.common.model.GeneralInfomation;

@Mapper
public interface GeneralInfomationDao 
{
	@Select("select PROCESSINGUNITSEQ,name,description From CE_PROCESSINGUNIT")
	@Results({
		@Result(property = "seq",  column = "PROCESSINGUNITSEQ"),
      @Result(property = "name",  column = "name"),
      @Result(property = "description", column = "description")
  })
	public List<GeneralInfomation> getCompanyList();
	
	@Select("select BUSINESSUNITSEQ,NAME,DESCRIPTION From CE_BUSINESSUNIT")
	@Results({
		 @Result(property = "seq",  column = "BUSINESSUNITSEQ"),
      @Result(property = "name",  column = "NAME"),
      @Result(property = "description", column = "DESCRIPTION")
  })
	public List<GeneralInfomation> getChannelList();
	
	@Select("select titleseq,NAME,NAME From CE_TITLE WHERE REMOVEDATE = '22000101' AND ISLAST = 1")
	@Results({
		  @Result(property = "seq",  column = "titleseq"),
	      @Result(property = "name",  column = "NAME"),
	      @Result(property = "description", column = "NAME")
	  })
	public List<GeneralInfomation> getTitlelList();
	
	@Select("select DIMENSIONSEQ,NAME,DESCRIPTION From CE_DIMENSION")
	@Results({
		@Result(property = "seq",  column = "DIMENSIONSEQ"),
	      @Result(property = "name",  column = "NAME"),
	      @Result(property = "description", column = "DESCRIPTION")
	  })
	public List<GeneralInfomation> getSummarytypeList();
	
	@Select("select ASSIGNTYPESEQ,NAME,DESCRIPTION From CE_ASSIGNTYPE")
	@Results({
		@Result(property = "seq",  column = "ASSIGNTYPESEQ"),
	      @Result(property = "name",  column = "NAME"),
	      @Result(property = "description", column = "DESCRIPTION")
	  })
	public List<GeneralInfomation> getRelationshipList();
}
