package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetPositionNodeResponse extends Response
 {
	private Object positionNodeModel;
	
	private int total;

	public Object getPositionNodeModel() {
		return positionNodeModel;
	}

	public void setPositionNodeModel(Object positionNodeModel) {
		this.positionNodeModel = positionNodeModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetPositionNodeResponse success(ResponseCode responseCode) {
		GetPositionNodeResponse getPositionNodeResponse = new GetPositionNodeResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(""));
		return getPositionNodeResponse;
	}

	public static GetPositionNodeResponse success(ResponseCode responseCode,Object positionNodeModel,int total) 
	 {        
		GetPositionNodeResponse getPositionNodeResponse = new GetPositionNodeResponse();        
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(""));
		getPositionNodeResponse.setPositionNodeModel(positionNodeModel);
		getPositionNodeResponse.setTotal(total);
		return getPositionNodeResponse;    
		 
	 }
	
	public static GetPositionNodeResponse fail(ResponseCode responseCode,String errorMsg) {
		GetPositionNodeResponse getPositionNodeResponse = new GetPositionNodeResponse();
		getPositionNodeResponse.setResponseCode(responseCode.getCode());
		getPositionNodeResponse.setReasonCode(Arrays.asList("0000"));
		getPositionNodeResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getPositionNodeResponse;
	}

	@Override
	public String toString() {
		return "GetPositionNodeResponse [positionNodeModel=" + positionNodeModel + ", total=" + total + "]" + super.toString();
	}
	
}
