package com.aia.glory.model.request;

import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.common.model.request.Request;

public class VersionUpdateRequest extends Request{
	
	private VersionRequest versionRequest;
	
	private VersionModel versionModel;

	public VersionRequest getVersionRequest() {
		return versionRequest;
	}

	public void setVersionRequest(VersionRequest versionRequest) {
		this.versionRequest = versionRequest;
	}

	public VersionModel getVersionModel() {
		return versionModel;
	}

	public void setVersionModel(VersionModel versionModel) {
		this.versionModel = versionModel;
	}
	
}
