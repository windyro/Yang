package com.aia.glory.channeladminservice.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@JsonIgnoreProperties(value = "handler") 
@JsonIdentityInfo(generator = ObjectIdGenerators.IntSequenceGenerator.class,  property = "@id")
public class PositionNodeModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String seq;
	
	private String participantSeq;
	
	private String recordType;
	
    private String code;
    
	private String title;
	
	private String entityType;
    
	private String firstName;

	private String middleName;
	
	private String lastName;
            
    private String leaderCode;
    
    private String leaderTitle;
    
    private String managerAgencyCode;
        
    private PositionNodeModel managerAgencyNodeModel = null;
    
    private List<PositionNodeModel> childNodeModel = null;
    
    private VersionModel versionModel = new VersionModel();

	public void setSeq(String seq) {
		
		this.versionModel.setSeq(seq);
	}
	
	public String getSeq() {
		this.seq = this.versionModel.getSeq();
		return this.seq;
	}
	
    public String getParticipantSeq() {
		return participantSeq;
	}

	public void setParticipantSeq(String participantSeq) {
		this.participantSeq = participantSeq;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLeaderCode() {
		return leaderCode;
	}

	public void setLeaderCode(String leaderCode) {
		this.leaderCode = leaderCode;
	}

	public String getLeaderTitle() {
		return leaderTitle;
	}

	public void setLeaderTitle(String leaderTitle) {
		this.leaderTitle = leaderTitle;
	}

	public String getManagerAgencyCode() {
		return managerAgencyCode;
	}

	public void setManagerAgencyCode(String managerAgencyCode) {
		this.managerAgencyCode = managerAgencyCode;
	}

	public PositionNodeModel getManagerAgencyNodeModel() {
		return managerAgencyNodeModel;
	}

	public void setManagerAgencyNodeModel(PositionNodeModel managerAgencyNodeModel) {
		this.managerAgencyNodeModel = managerAgencyNodeModel;
	}

	public List<PositionNodeModel> getChildNodeModel() {
		return childNodeModel;
	}

	public void setChildNodeModel(List<PositionNodeModel> childNodeModel) {
		this.childNodeModel = childNodeModel;
	}

	public VersionModel getVersionModel() {
		return versionModel;
	}

	public void setVersionModel(VersionModel versionModel) {
		this.versionModel = versionModel;
	}

	@Override
	public String toString() {
		return "PositionNodeModel [code=" + code + ", title=" + title
				+ ", entityType=" + entityType + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", lastName=" + lastName
				+ ", leaderCode=" + leaderCode + ", leaderTitle=" + leaderTitle
				+ ", managerAgencyCode=" + managerAgencyCode
				+ ", managerAgencyNodeModel=" + managerAgencyNodeModel
				+ ", versionModel=" + versionModel + "]";
	}

}
