package com.aia.glory.channeladminservice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.channeladminservice.model.GenericAttributeModel;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.model.request.EntityRequest;
import com.aia.glory.model.request.VersionRequest;
import com.aia.glory.model.request.VersionUpdateRequest;

public interface EntityDao {

	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<VersionModel> selectEntityVersion(VersionRequest versionRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectEntityVersionTotal(VersionRequest versionRequest);
	
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<EntityModel> selectEntity(EntityRequest entityRequest);
		
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectEntityTotal(EntityRequest entityRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Integer selectMaxParticipantSeq();
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Integer selectMaxPositionSeq();
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendParticipantFieldValue(EntityRequest entityRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendParticipantFieldDesc();
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendPositionFieldValue(EntityRequest entityRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendPositionFieldDesc();
	
	public void insertEntityParticipant(@Param("entityModel")EntityModel entityModel, @Param("genericFieldMap")Map<String,String> genericFieldMap);
	
	public void insertEntityPosition(@Param("entityModel")EntityModel entityModel, @Param("genericFieldMap")Map<String,String> genericFieldMap);
	
	public void updateParticipantVersion(VersionUpdateRequest versionUpdateRequest);
	
	public void updatePositionVersion(VersionUpdateRequest versionUpdateRequest);
	
	//public void updateParticipantGenericField(@Param("entityModel")EntityModel entityModel, @Param("genericFieldMap")Map<String,String> genericFieldMap);

}
