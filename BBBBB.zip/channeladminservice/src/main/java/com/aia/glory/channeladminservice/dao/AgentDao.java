package com.aia.glory.channeladminservice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.channeladminservice.model.AgentModel;
import com.aia.glory.channeladminservice.model.ContractModel;
import com.aia.glory.channeladminservice.model.EducationModel;
import com.aia.glory.channeladminservice.model.FamilyModel;
import com.aia.glory.channeladminservice.model.ParticipantModel;
import com.aia.glory.channeladminservice.model.PositionModel;
import com.aia.glory.channeladminservice.model.VersionModel;
import com.aia.glory.model.request.AgentActionRequest;
import com.aia.glory.model.request.AgentRequest;
import com.aia.glory.model.request.EntityRequest;
import com.aia.glory.model.request.VersionRequest;

public interface AgentDao {

	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<VersionModel> selectParticipantVersion(VersionRequest versionRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectParticipantVersionTotal(VersionRequest versionRequest);
	
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<AgentModel> selectAgent(AgentRequest agentRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<FamilyModel> selectAgentFamily();
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public int selectAgentTotal(AgentRequest agentRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendParticipantFieldValue(AgentRequest agentRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendParticipantFieldDesc();
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendPositionFieldValue(AgentRequest agentRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public Map<String,String> selectExtendPositionFieldDesc();
	
	@Insert("<script>" +
			" INSERT INTO [dbo].[CE_PARTICIPANT](PARTICIPANTSEQ,[RECORDTYPE],[EFFECTIVESTARTDATE],[EFFECTIVEENDDATE],[ISLAST],[CREATEDATE],[REMOVEDATE],[VERSION_LOG]," + 
			"	[NAME],[FIRSTNAME],[MIDDLENAME],[LASTNAME]," + 
			"	[TAXID],[HIREDATE],[EMAIL]," + 
			"	[AGENT_STATUS],[AGENT_TYPE],[RECRUITER_CODE]," + 
			"	[RECRUIT_SOURCE],[IDENTIFICATION_NUMB],[DOMICILE_PLACE],[GENDER],[DOB],[BENEFICIARY_NAME]," + 
			"	[FSC_1ST_ASSIGNMENT],[FORTS_AGENT],[NATIONALITY],[PREFERRED_LANGUAGE],[AGENT_TELEPHONE],[AGENT_CELL_PHONE]," + 
			"	[EMERGENCY_CONTACT],[EMERGENCY_CONTACT_NO],[RESIDENTIAL_ADDRESS],[POSTAL_CODE],[RETIRED_DATE],[REJOIN_FLAG]," + 
			"	[REJOIN_DATE],[MARITAL_STATUS],[FAMILY_CONTACT],[FAMILY_ADDRESS], " +
			
			" <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"+
        	" <foreach collection='genericFieldMap.keys' item='key'>" +
            " ${key}," +
        	" </foreach>" +
        	" </if>" +
			
        	"   [EVENT_CALENDAR])" + 
			"	VALUES" + 
			"	(#{pam.seq},'AGT',#{pam.effectiveStartDate},#{pam.effectiveEndDate},'1',GETDATE(),'2200-01-01 00:00:00.000',#{pam.versionModel.versionLog},"
			+ "#{pam.agentCode},#{pam.firstName},#{pam.middleName},#{pam.lastName},"
			+ "#{pam.taxId},#{pam.hireDate},#{pam.email},"
			+ "#{pam.agentStatus},#{pam.agentType},#{pam.recruiterCode},"
			+ "#{pam.recruitSource},#{pam.identificationNumb},#{pam.domicilePlace},#{pam.gender},#{pam.dob},#{pam.beneficiaryName},"
			+ "#{pam.fsc1stAssignment},#{pam.fortsAgent},#{pam.nationality},#{pam.preferredLanguage},#{pam.agentTelephone},#{pam.agentCellPhone},"
			+ "#{pam.emergencyContact},#{pam.emergencyContactNo},#{pam.residentialAddress},#{pam.postalCode},#{pam.retiredDate},#{pam.rejoinFlag},"
			+ "#{pam.rejoinDate},#{pam.maritalStatus},#{pam.familyContact},#{pam.familyAddress}, "
			
			+ " <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"
        	+ " <foreach collection='genericFieldMap.keys' item='key'>" 
            + " #{genericFieldMap[${key}]}," 
        	+ " </foreach>" 
        	+ " </if>" 	
        	
			+ "#{pam.eventCalendar}"
			+ ")</script>")
	@SelectKey(keyProperty="pam.versionModel.seq", before = true, resultType = String.class, statement = "SELECT NEXT VALUE FOR CE_PARTICIPANT_SEQ")
	public int addParticipant(@Param("pam")ParticipantModel participantModel,@Param("genericFieldMap")Map<String,String> genericFieldMap);
	
	@Select("SELECT  * FROM CE_PARTICIPANT WHERE NAME = #{agentCode} and ISLAST=1 order by CREATEDATE desc")
	@Results({@Result(property = "seq",  column = "PARTICIPANTSEQ")})
	public List<ParticipantModel> checkParticipantModel(@Param("agentCode")String AgentCode);
	
	@Insert("<script>" +
			" INSERT INTO [dbo].[CE_PARTICIPANT](PARTICIPANTSEQ,[RECORDTYPE],[EFFECTIVESTARTDATE],[EFFECTIVEENDDATE],[ISLAST],[CREATEDATE],[REMOVEDATE],[VERSION_LOG]," + 
			"	[NAME],[FIRSTNAME],[MIDDLENAME],[LASTNAME]," + 
			"	[TAXID],[HIREDATE],[EMAIL]," + 
			"	[AGENT_STATUS],[AGENT_TYPE],[RECRUITER_CODE]," + 
			"	[RECRUIT_SOURCE],[IDENTIFICATION_NUMB],[DOMICILE_PLACE],[GENDER],[DOB],[BENEFICIARY_NAME]," + 
			"	[FSC_1ST_ASSIGNMENT],[FORTS_AGENT],[NATIONALITY],[PREFERRED_LANGUAGE],[AGENT_TELEPHONE],[AGENT_CELL_PHONE]," + 
			"	[EMERGENCY_CONTACT],[EMERGENCY_CONTACT_NO],[RESIDENTIAL_ADDRESS],[POSTAL_CODE],[RETIRED_DATE],[REJOIN_FLAG]," + 
			"	[REJOIN_DATE],[MARITAL_STATUS],[FAMILY_CONTACT],[FAMILY_ADDRESS], "+
			
			" <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"+
        	" <foreach collection='genericFieldMap.keys' item='key'>" +
            " ${key}," +
        	" </foreach>" +
        	" </if>" +
        	
			"   [EVENT_CALENDAR])" + 
			"	VALUES" + 
			"	(#{pam.seq},'AGT',#{pam.effectiveStartDate},#{pam.effectiveEndDate},'1',GETDATE(),'2200-01-01 00:00:00.000',#{pam.versionModel.versionLog},"
			+ "#{pam.agentCode},#{pam.firstName},#{pam.middleName},#{pam.lastName},"
			+ "#{pam.taxId},#{pam.hireDate},#{pam.email},"
			+ "#{pam.agentStatus},#{pam.agentType},#{pam.recruiterCode},"
			+ "#{pam.recruitSource},#{pam.identificationNumb},#{pam.domicilePlace},#{pam.gender},#{pam.dob},#{pam.beneficiaryName},"
			+ "#{pam.fsc1stAssignment},#{pam.fortsAgent},#{pam.nationality},#{pam.preferredLanguage},#{pam.agentTelephone},#{pam.agentCellPhone},"
			+ "#{pam.emergencyContact},#{pam.emergencyContactNo},#{pam.residentialAddress},#{pam.postalCode},#{pam.retiredDate},#{pam.rejoinFlag},"
			+ "#{pam.rejoinDate},#{pam.maritalStatus},#{pam.familyContact},#{pam.familyAddress}, "
			
			+ " <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"
        	+ " <foreach collection='genericFieldMap.keys' item='key'>" 
            + " #{genericFieldMap[${key}]}," 
        	+ " </foreach>" 
        	+ " </if>" 	
        	
			+ "#{pam.eventCalendar}"
			+ ")</script>")
	public int addNewParticipantVersion(@Param("pam")ParticipantModel participantModel,@Param("genericFieldMap")Map<String,String> genericFieldMap);
	
	@Insert("INSERT INTO [dbo].[CE_PARTICIPANT_CONTRACT]([PARTICIPANTSEQ],[NAME],[CONTRACT_CODE],[IDENTIFICATION_NUMB],"
			+ "[BASE_SALARY],[HIRE_DATE],[AGENT_TITLE]," + 
			"[PROMOTION_DATE],[DEMOTION_DATE],[TERMINATION_DATE],[PAID_IN_POLICY_CURRENCY],[PAYMENT_METHOD],[USD_ACCT_NUMB]," + 
			"[USD_BANK_CODE],[USD_BRANCH_CODE],[LOCAL_ACCT_NUMB],[LOCAL_BANK_CODE],[LOCAL_BRANCH_CODE])VALUES"
			+ "(#{participantSeq},#{name},#{contractCode},#{identificationNumb},#{baseSalary},#{hireDate},"
			+ "#{agentTitle},#{promotionDate},#{demotionDate},#{terminationDate},"
			+ "#{paidInPolicyCurrency},#{paymentMethod},#{usdAcctNumb},"
			+ "#{usdBankCode},#{usdBranchCode},#{localAcctNumb},#{localBankCode},#{localBranchCode})")
	public int addcontract(ContractModel contractModel);
	
	@Insert("INSERT INTO [CE_PARTICIPANT_FAMILY]([PARTICIPANTSEQ],[NAME],[FAMILY_MEMBER_NAME],[IDENTIFICATION_NUMB],[GENDER]," + 
			"[RELATIONSHIP_WITH_AGENT],[DOB],[CONTACT_NO],[RESIDENTIAL_ADDRESS],[POSTAL_CODE]," + 
			"[EFFECTIVESTARTDATE],[EFFECTIVEENDDATE])VALUES"
			+ "(#{participantSeq},#{name},#{familyMemberName},#{identificationNumb},#{gender},"
			+ "#{relationshipWithAgent},#{dob},#{contactNo},#{residentialAddress},#{postalCode},#{effectiveStartDate},"
			+ "#{effectiveEndDate})")
	public int addAgentFamily(FamilyModel familyModel);
	
	@Insert("INSERT INTO [CE_PARTICIPANT_EDUCATION]([PARTICIPANTSEQ],[NAME],[HIGHEST_EDUCATION],[GRADUATE_SCHOOL])VALUES"
			+ "(#{participantSeq},#{name},#{highestEducation},#{graduateSchool})")
	public int addAgentEducation(EducationModel educationModel);
	
	@Insert("<script>"
			+ " INSERT INTO [CE_POSITION]([POSITIONSEQ],[RECORDTYPE],[NAME],[LeaderCode],[PARTICIPANTSEQ],"
			+ "ISLAST,EFFECTIVESTARTDATE,EFFECTIVEENDDATE,CREATEDATE,[REMOVEDATE],"
			+ "[DistrictCode],[ManagerAgency],[TITLESEQ],"
			+ "[ENTITLE_TYPE],[MANAGERSEQ],BUSINESSUNITMAP,"
			
			+ " <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"
        	+ " <foreach collection='genericFieldMap.keys' item='key'>"
            + " ${key},"
        	+ " </foreach>"
        	+ " </if>"
        	
			+ " PROCESSUNITMAP) VALUES"
			+ "(NEXT VALUE FOR CE_POSITION_SEQ,'AGT',#{pam.agentCode},#{pom.leaderCode},#{pam.seq},"
			+ "'1',#{pam.effectiveStartDate},#{pam.effectiveEndDate},GETDATE(),'2200-01-01 00:00:00.000',"
			+ "#{pom.districtCode},#{pom.managerAgency},(select TITLESEQ from [CE_TITLE] where NAME=#{pom.title}),"
			+ "#{pom.entityType},#{pom.managerSeq},"
			+ "(select BUSINESSUNITSEQ From CE_BUSINESSUNIT where [NAME]=#{pom.channelCode}),"
			
			+ " <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"
        	+ " <foreach collection='genericFieldMap.keys' item='key'>" 
            + " #{genericFieldMap[${key}]}," 
        	+ " </foreach>" 
        	+ " </if>" 	
        	
			+ "(select PROCESSINGUNITSEQ From CE_PROCESSINGUNIT where [NAME]=#{pom.companyCode})"
			+ ")</script>")
	public int addAgentPosition(@Param("pom")PositionModel positionModel,@Param("pam")ParticipantModel participantModel,@Param("genericFieldMap")Map<String,String> genericFieldMap);
	
	
	@Delete("DELETE FROM CE_PARTICIPANT_CONTRACT WHERE PARTICIPANTSEQ=#{seq}")
	public void deleteContract(@Param("seq")String seq);
	
	@Delete("DELETE FROM CE_PARTICIPANT_EDUCATION WHERE PARTICIPANTSEQ=#{seq}")
	public void deleteAgentEducation(@Param("seq")String seq);
	
	@Delete("DELETE FROM CE_PARTICIPANT_FAMILY WHERE PARTICIPANTSEQ=#{seq}")
	public void deleteAgentFamily(@Param("seq")String seq);
	
	@Insert("<script>"
			+ " INSERT INTO [CE_POSITION]([POSITIONSEQ],[RECORDTYPE],[NAME],[LeaderCode],[PARTICIPANTSEQ],"
			+ "ISLAST,EFFECTIVESTARTDATE,EFFECTIVEENDDATE,CREATEDATE,[REMOVEDATE],"
			+ "[DistrictCode],[ManagerAgency],[TITLESEQ],"
			+ "[ENTITLE_TYPE],[MANAGERSEQ],BUSINESSUNITMAP,"
			
			+ " <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"
        	+ " <foreach collection='genericFieldMap.keys' item='key'>"
            + " ${key},"
        	+ " </foreach>"
        	+ " </if>"
        	
			+ " PROCESSUNITMAP)VALUES"	
			+ "(#{pom.positionSeq},'AGT',#{pam.agentCode},#{pom.leaderCode},#{pam.seq},"
			+ "'1',#{pam.effectiveStartDate},#{pam.effectiveEndDate},GETDATE(),'2200-01-01 00:00:00.000',"
			+ "#{pom.districtCode},#{pom.managerAgency},(select TITLESEQ from [CE_TITLE] where NAME=#{pom.title}),"
			+ "#{pom.entityType},#{pom.managerSeq},"
			+ "(select BUSINESSUNITSEQ From CE_BUSINESSUNIT where [NAME]=#{pom.channelCode}),"
			
			+ " <if test='genericFieldMap != null and genericFieldMap.size() > 0'>"
        	+ " <foreach collection='genericFieldMap.keys' item='key'>" 
            + " #{genericFieldMap[${key}]}," 
        	+ " </foreach>" 
        	+ " </if>" 	
        	
			+ "(select PROCESSINGUNITSEQ From CE_PROCESSINGUNIT where [NAME]=#{pom.companyCode})"
			+ ")</script>")
	public int updateAgentPositionVersion(@Param("pom")PositionModel positionModel,@Param("pam")ParticipantModel participantModel,@Param("genericFieldMap")Map<String,String> genericFieldMap);
	
	@Update("Update CE_POSITION set ISLAST=0,[EFFECTIVEENDDATE]=#{endDate} "
			+ "where POSITIONSEQ=#{positionSeq} and ISLAST=1")
	public void updateAgentPositionToExpired(@Param("positionSeq")String positionSeq,@Param("endDate")String endDate);
	
	@Update("Update CE_PARTICIPANT set ISLAST=0,[EFFECTIVEENDDATE]=#{endDate} "
			+ "where PARTICIPANTSEQ = #{participantSeq} and ISLAST=1")
	public void updateAgentToExpired(@Param("participantSeq")String participantSeq,@Param("endDate")String endDate);
	
	@Update("Update CE_POSITION set [LeaderCode]=#{participantModel.agentCode} "
			+ "WHERE RECORDTYPE = 'AGY' "
			+ "and name = #{positionModel.managerAgency} "
			+ "and #{participantModel.effectiveStartDate} <= EFFECTIVEENDDATE "
			+ "and #{participantModel.effectiveEndDate} >= EFFECTIVESTARTDATE")
	public void isEntityLeader(AgentActionRequest agentRequest);
	
	@Update("Update CE_POSITION set [LeaderCode]='' "
			+ "WHERE RECORDTYPE = 'AGY' "
			+ "and name = #{positionModel.managerAgency} "
			+ "and LeaderCode = #{participantModel.agentCode} "
			+ "and #{participantModel.effectiveStartDate} <= EFFECTIVEENDDATE "
			+ "and #{participantModel.effectiveEndDate} >= EFFECTIVESTARTDATE")
	public void isNotEntityLeader(AgentActionRequest agentRequest);
	
}
