package com.aia.glory.channeladminservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(value = "handler") 
public class PositionRelationModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String positionRelationSeq;
	
	private String parentpositionSeq;
	
	private String childpositionSeq;

	private String positionRelationTypeSeq;
		
	private String effectiveStartDate;
	
	private String effectiveEndDate;
	
    private String createDate;
	
    private String removeDate;
	
    private PositionNodeModel parentModel;
    
    private PositionNodeModel childModel;
    
	public String getPositionRelationSeq() {
		return positionRelationSeq;
	}

	public void setPositionRelationSeq(String positionRelationSeq) {
		this.positionRelationSeq = positionRelationSeq;
	}

	public String getParentpositionSeq() {
		return parentpositionSeq;
	}

	public void setParentpositionSeq(String parentpositionSeq) {
		this.parentpositionSeq = parentpositionSeq;
	}

	public String getChildpositionSeq() {
		return childpositionSeq;
	}

	public void setChildpositionSeq(String childpositionSeq) {
		this.childpositionSeq = childpositionSeq;
	}

	public String getPositionRelationTypeSeq() {
		return positionRelationTypeSeq;
	}

	public void setPositionRelationTypeSeq(String positionRelationTypeSeq) {
		this.positionRelationTypeSeq = positionRelationTypeSeq;
	}

	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getRemoveDate() {
		return removeDate;
	}

	public void setRemoveDate(String removeDate) {
		this.removeDate = removeDate;
	}

	public PositionNodeModel getParentModel() {
		return parentModel;
	}

	public void setParentModel(PositionNodeModel parentModel) {
		this.parentModel = parentModel;
	}

	public PositionNodeModel getChildModel() {
		return childModel;
	}

	public void setChildModel(PositionNodeModel childModel) {
		this.childModel = childModel;
	}    
	
}
