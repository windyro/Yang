package com.aia.glory.model.request;

import javax.validation.constraints.Pattern;

import com.aia.glory.common.model.request.Request;

public class PositionNodeRequest extends Request{
	
	public final static String TYPE_SELF= "SELF";
    
	public final static String TYPE_PARENT = "PARENT";
    
	public final static String TYPE_CHILDREN = "CHILDREN";
 
	private String nodeType;
	
    private String seq;
    
    private String managerSeq;
         
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgent need letters or Numbers")
    private String code;
    
    private String codeEqual;
                       
    private String recordType;
    
    private String isLast;
    	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String effectiveStartDate;
	
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String effectiveEndDate;
    
    private int startPage = 0;
	
   	private int pageSize = 0;

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getManagerSeq() {
		return managerSeq;
	}

	public void setManagerSeq(String managerSeq) {
		this.managerSeq = managerSeq;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCodeEqual() {
		return codeEqual;
	}

	public void setCodeEqual(String codeEqual) {
		this.codeEqual = codeEqual;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getIsLast() {
		return isLast;
	}

	public void setIsLast(String isLast) {
		this.isLast = isLast;
	}

	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public void setStartPage(int startPage) {
		if(startPage == 0) {
			startPage =1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(int pageSize) {
		if(pageSize == 0) {
			pageSize =1;
		}
		this.pageSize = pageSize;
	}
	
	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}
}
