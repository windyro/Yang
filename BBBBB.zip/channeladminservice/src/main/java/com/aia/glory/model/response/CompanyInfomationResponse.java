package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class CompanyInfomationResponse extends Response{
	
	private Object company;
	
	public Object getCompany() {
		return company;
	}

	public void setCompany(Object company) {
		this.company = company;
	}

	public static CompanyInfomationResponse success(ResponseCode responseCode,Object company) 
	 {        
		CompanyInfomationResponse generalInfomationResponse = new CompanyInfomationResponse();        
		generalInfomationResponse.setResponseCode(responseCode.getCode());
		generalInfomationResponse.setReasonCode(Arrays.asList("0000"));
		generalInfomationResponse.setReasonDesc(Arrays.asList(""));
		generalInfomationResponse.setCompany(company);
		return generalInfomationResponse;    
		 
	 }

	@Override
	public String toString() {
		return "CompanyInfomationResponse [company=" + company + "]" + super.toString();
	}
	
}
