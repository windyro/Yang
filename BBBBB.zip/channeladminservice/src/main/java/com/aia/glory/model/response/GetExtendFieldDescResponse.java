package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetExtendFieldDescResponse extends Response
 {
	private Object genericAttributeModel;
	
	private int total;

	public Object getGenericAttributeModel() {
		return genericAttributeModel;
	}

	public void setGenericAttributeModel(Object genericAttributeModel) {
		this.genericAttributeModel = genericAttributeModel;
	}

	public static GetExtendFieldDescResponse success(ResponseCode responseCode) {
		GetExtendFieldDescResponse getPariticipantExtendFieldDescResponse = new GetExtendFieldDescResponse();
		getPariticipantExtendFieldDescResponse.setResponseCode(responseCode.getCode());
		getPariticipantExtendFieldDescResponse.setReasonCode(Arrays.asList("0000"));
		getPariticipantExtendFieldDescResponse.setReasonDesc(Arrays.asList(""));
		return getPariticipantExtendFieldDescResponse;
	}

	public static GetExtendFieldDescResponse success(ResponseCode responseCode,Object genericAttributeModel) 
	 {        
		GetExtendFieldDescResponse getPariticipantExtendFieldDescResponse = new GetExtendFieldDescResponse();        
		getPariticipantExtendFieldDescResponse.setResponseCode(responseCode.getCode());
		getPariticipantExtendFieldDescResponse.setReasonCode(Arrays.asList("0000"));
		getPariticipantExtendFieldDescResponse.setReasonDesc(Arrays.asList(""));
		getPariticipantExtendFieldDescResponse.setGenericAttributeModel(genericAttributeModel);
		return getPariticipantExtendFieldDescResponse;    
		 
	 }
	
	public static GetExtendFieldDescResponse fail(ResponseCode responseCode,String errorMsg) {
		GetExtendFieldDescResponse getPariticipantExtendFieldDescResponse = new GetExtendFieldDescResponse();
		getPariticipantExtendFieldDescResponse.setResponseCode(responseCode.getCode());
		getPariticipantExtendFieldDescResponse.setReasonCode(Arrays.asList("0000"));
		getPariticipantExtendFieldDescResponse.setReasonDesc(Arrays.asList(errorMsg));
		return getPariticipantExtendFieldDescResponse;
	}

	@Override
	public String toString() {
		return "GetPariticipantExtendFieldDescResponse [genericAttributeModel="
				+ genericAttributeModel + "]";
	}
	
}
