package com.aia.glory.channeladminservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value = "handler") 
public class AgentModel{
	
	private ParticipantModel participantModel;
	
	private PositionModel positionModel;
	
	private EducationModel educationModel;
	
	private ContractModel contractModel;
	
	private List<FamilyModel> familyModel;
	
	public ParticipantModel getParticipantModel() {
		return participantModel;
	}

	public void setParticipantModel(ParticipantModel participantModel) {
		this.participantModel = participantModel;
	}

	public PositionModel getPositionModel() {
		return positionModel;
	}

	public void setPositionModel(PositionModel positionModel) {
		this.positionModel = positionModel;
	}

	public List<FamilyModel> getFamilyModel() {
		return familyModel;
	}

	public void setFamilyModel(List<FamilyModel> familyModel) {
		this.familyModel = familyModel;
	}

	public EducationModel getEducationModel() {
		return educationModel;
	}

	public void setEducationModel(EducationModel educationModel) {
		this.educationModel = educationModel;
	}

	public ContractModel getContractModel() {
		return contractModel;
	}

	public void setContractModel(ContractModel contractModel) {
		this.contractModel = contractModel;
	}

	@Override
	public String toString() {
		return "AgentModel [participantModel=" + participantModel
				+ ", positionModel=" + positionModel + ", educationModel="
				+ educationModel + ", contractModel=" + contractModel
				+ ", familyModel=" + familyModel + "]";
	}
	
}
