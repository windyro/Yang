
package com.aia.glory.channeladminservice.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.channeladminservice.model.PositionRelationModel;
import com.aia.glory.channeladminservice.model.PositionRelationTypeModel;
import com.aia.glory.channeladminservice.service.PositionRelationService;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.PositionRelationRequest;
import com.aia.glory.model.request.PositionRelationUpdateRequest;
import com.aia.glory.model.response.GetPositionRelationResponse;

@RestController
public class PositionRelationController {
	
	@Autowired
	@Qualifier(value = "positionRelationService")
	private PositionRelationService positionRelationService;
	
	@RequestMapping(value = "/positionRelation", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response positionRelation(@Valid  HttpServletRequest request, @RequestBody String requestBody) throws IOException{
			
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String action = (String) requestMap.get("action");
		Response response = null;
			
		switch (action) {
		case "GET":
			response = this.retrievePositionRelation(requestBody);
			break;
		case "INSERT":
			response = this.insertPositionRelation(requestBody);
			break;	
		case "UPDATE":
			response = this.updatePositionRelation(requestBody);
			break;
		default:
			break;
		}
		
		return response;
	}
	
	private Response retrievePositionRelation(String requestBody) throws IOException{
		PositionRelationRequest positionRelationRequest= (PositionRelationRequest) JsonToObjectUtil.jsonToObj(new PositionRelationRequest(), requestBody);
		Response response = positionRelationService.retrievePositionRelation(positionRelationRequest);
		return response;
	}
	
	private Response insertPositionRelation(String requestBody) throws IOException{
		
		PositionRelationUpdateRequest positionRelationUpdateRequest= (PositionRelationUpdateRequest) JsonToObjectUtil.jsonToObj(new PositionRelationUpdateRequest(), requestBody);
		PositionRelationTypeModel positionRelationTypeModel= positionRelationUpdateRequest.getPositionRelationTypeModel();
		
		//Check if the relation name already used
		PositionRelationRequest positionRelationRequest = new PositionRelationRequest();
		positionRelationRequest.setTypeNameEqual(positionRelationTypeModel.getName());
		GetPositionRelationResponse getPositionRelationResponse = positionRelationService.retrievePositionRelation(positionRelationRequest);
		List<PositionRelationTypeModel> positionRelationTypeModelList = (List<PositionRelationTypeModel>)getPositionRelationResponse.getPositionRelationList();
		if(positionRelationTypeModelList != null && !positionRelationTypeModelList.isEmpty()){
			return GeneryResponse.fail("Relation Type Name alread existed!");
		}
		
		Response response = null;
		//Insert relation type
		response = positionRelationService.insertPositionRelationType(positionRelationUpdateRequest);
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			//Insert relation
			positionRelationService.insertPositionRelation(positionRelationUpdateRequest);
		}
		
		return response;
	}
	
	private Response updatePositionRelation(String requestBody) throws IOException{
		
		PositionRelationUpdateRequest positionRelationUpdateRequest= (PositionRelationUpdateRequest) JsonToObjectUtil.jsonToObj(new PositionRelationUpdateRequest(), requestBody);
		PositionRelationTypeModel positionRelationTypeModel= positionRelationUpdateRequest.getPositionRelationTypeModel();
		
		//Check if the relation name already used
		PositionRelationRequest positionRelationRequest = new PositionRelationRequest();
		positionRelationRequest.setTypeNameEqual(positionRelationTypeModel.getName());
		GetPositionRelationResponse getPositionRelationResponse = positionRelationService.retrievePositionRelation(positionRelationRequest);
		List<PositionRelationTypeModel> positionRelationTypeModelList = (List<PositionRelationTypeModel>)getPositionRelationResponse.getPositionRelationList();
		if(positionRelationTypeModelList != null && !positionRelationTypeModelList.isEmpty()){
			for(PositionRelationTypeModel existPositionRelationTypeModel : positionRelationTypeModelList) {
				if(!existPositionRelationTypeModel.getDataTypeSeq().equals(positionRelationTypeModel.getDataTypeSeq())){
					return GeneryResponse.fail("Relation Type Name alread existed!");
				}
			}
		}
		
		Response response = null;
		//Update relation type
		response = positionRelationService.updatePositionRelationType(positionRelationUpdateRequest);
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			//Delete relation
			response = positionRelationService.deletePositionRelation(positionRelationUpdateRequest);
		}
		if(ResponseCode.NORMAL.getCode().equals(response.getResponseCode())){
			//Insert relation
			response = positionRelationService.insertPositionRelation(positionRelationUpdateRequest);
		}
		
		return response;
	}

}
