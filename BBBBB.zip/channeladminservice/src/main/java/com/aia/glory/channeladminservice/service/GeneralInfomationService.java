package com.aia.glory.channeladminservice.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.glory.common.model.GeneralInfomation;
import com.aia.glory.channeladminservice.dao.GeneralInfomationDao;

@Service
public class GeneralInfomationService 
{
	@Autowired
    public GeneralInfomationDao generalInfomationDao;
	
	 public List<GeneralInfomation> getCompanyList(){
		 return generalInfomationDao.getCompanyList();
	 }
	 
	 public List<GeneralInfomation> getChannelList(){
		 return generalInfomationDao.getChannelList();
	 }
	 
	 public List<GeneralInfomation> getTitlelList(){
		 return generalInfomationDao.getTitlelList();
	 }
	 
	 public List<GeneralInfomation> getRelationshipList(){
		 return generalInfomationDao.getRelationshipList();
	 }
	 
	 public List<GeneralInfomation> getSummaryTypeList(){
		 return generalInfomationDao.getSummarytypeList();
	 }
}
