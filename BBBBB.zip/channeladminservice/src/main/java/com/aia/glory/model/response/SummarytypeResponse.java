package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class SummarytypeResponse extends Response{
	
	private Object summarytype;
	
	public Object getSummarytype() {
		return summarytype;
	}

	public void setSummarytype(Object summarytype) {
		this.summarytype = summarytype;
	}

	public static SummarytypeResponse success(ResponseCode responseCode,Object summarytype) 
	 {        
		SummarytypeResponse generalInfomationResponse = new SummarytypeResponse();        
		generalInfomationResponse.setResponseCode(responseCode.getCode());
		generalInfomationResponse.setReasonCode(Arrays.asList("0000"));
		generalInfomationResponse.setReasonDesc(Arrays.asList(""));
		generalInfomationResponse.setSummarytype(summarytype);
		return generalInfomationResponse;    
		 
	 }

	@Override
	public String toString() {
		return "SummarytypeResponse [summarytype=" + summarytype + "]" + super.toString();
	}
	
}
