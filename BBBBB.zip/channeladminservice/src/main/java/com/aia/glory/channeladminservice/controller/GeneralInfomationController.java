package com.aia.glory.channeladminservice.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.GeneralInfomation;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.response.CompanyInfomationResponse;
import com.aia.glory.model.response.RelationshipInfomationResponse;
import com.aia.glory.model.response.RuleFrequencyResponse;
import com.aia.glory.model.response.SummarytypeResponse;
import com.aia.glory.model.response.TitleInfomationResponse;
import com.aia.glory.model.response.generalInfomationResponse;
import com.aia.glory.channeladminservice.config.InitGeneralInfomationConfig;
import com.aia.glory.channeladminservice.service.GeneralInfomationService;

@Controller
public class GeneralInfomationController 
{
    Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	@Autowired
	public GeneralInfomationService generalInfomationService;
	
	
	@Autowired
	InitGeneralInfomationConfig initGeneralInfomationConfig;
	
	@RequestMapping(value = "/generalInfomation",method = RequestMethod.POST)
	@ResponseBody
	public Response generalInfomation(HttpServletRequest request,@RequestBody String requestBody) throws IOException
	{
		HashMap requestMap =  (HashMap) JsonToObjectUtil.jsonToObj(new HashMap(), requestBody);
		String key = (String) requestMap.get("key");
		Response response = null;
		
		switch (key) {
		case "channel":
			response = getChannel();
			break;
        case "company":
        	response = getCompany();
			break;
        case "title":
        	response = getTitleLst();
        	break;
        case "relationship":
            response = getRelationshipLst();
            break;
        case "summarytype":
            response = getSummaryTypeLst();
            break;
		default:
			break;
		}
		return response;
	}
	
	@RequestMapping(value = "/frequency",method = RequestMethod.POST)
	@ResponseBody
	public Response getRuleFrequency(HttpServletRequest request){
		Response response = getFrequency();
		return response;
	}
	
	private generalInfomationResponse getChannel()
	{
		List<GeneralInfomation> channelLst = null;
		if (!initGeneralInfomationConfig.getGeneralInfoMap().isEmpty()) 
		{
			channelLst = initGeneralInfomationConfig.getGeneralInfoMap().get("channel");
			if (channelLst == null || channelLst.isEmpty()) 
			{
				channelLst = generalInfomationService.getChannelList();
			}
		}
		
		return generalInfomationResponse.success(ResponseCode.NORMAL, channelLst);
	}
	
	private CompanyInfomationResponse getCompany()
	{
		List<GeneralInfomation> companyLst = null;
		if (!initGeneralInfomationConfig.getGeneralInfoMap().isEmpty()) 
		{
			companyLst = initGeneralInfomationConfig.getGeneralInfoMap().get("company");
			if (companyLst == null || companyLst.isEmpty()) 
			{
				companyLst = generalInfomationService.getCompanyList();
			}
		}
		
		return CompanyInfomationResponse.success(ResponseCode.NORMAL, companyLst);
	}
	
	private RuleFrequencyResponse getFrequency()
	{
		List<GeneralInfomation> ruleFrequencyLst = null;
		if (!initGeneralInfomationConfig.getGeneralInfoMap().isEmpty()) 
		{
			ruleFrequencyLst = initGeneralInfomationConfig.getGeneralInfoMap().get("frequency");
		}
		
		return RuleFrequencyResponse.success(ResponseCode.NORMAL, ruleFrequencyLst);
	}
	
	private TitleInfomationResponse getTitleLst(){
		List<GeneralInfomation> titleLst = null;
		if (!initGeneralInfomationConfig.getGeneralInfoMap().isEmpty()) 
		{
			titleLst = initGeneralInfomationConfig.getGeneralInfoMap().get("title");
			if (titleLst == null || titleLst.isEmpty()) 
			{
				titleLst = generalInfomationService.getTitlelList();
			}
		}
		
		return TitleInfomationResponse.success(ResponseCode.NORMAL, titleLst);
	}
	
	private RelationshipInfomationResponse getRelationshipLst(){
		List<GeneralInfomation> relationshipLst = null;
		if (!initGeneralInfomationConfig.getGeneralInfoMap().isEmpty()) 
		{
			relationshipLst = initGeneralInfomationConfig.getGeneralInfoMap().get("relationship");
			if (relationshipLst == null || relationshipLst.isEmpty()) 
			{
				relationshipLst = generalInfomationService.getRelationshipList();
			}
		}
		
		return RelationshipInfomationResponse.success(ResponseCode.NORMAL, relationshipLst);
	}
	
	private SummarytypeResponse getSummaryTypeLst(){
		List<GeneralInfomation> summaryTypeLst = null;
		if (!initGeneralInfomationConfig.getGeneralInfoMap().isEmpty()) 
		{
			summaryTypeLst = initGeneralInfomationConfig.getGeneralInfoMap().get("summarytype");
			if (summaryTypeLst == null || summaryTypeLst.isEmpty()) 
			{
				summaryTypeLst = generalInfomationService.getSummaryTypeList();
			}
		}
		
		return SummarytypeResponse.success(ResponseCode.NORMAL, summaryTypeLst);
	}
}
