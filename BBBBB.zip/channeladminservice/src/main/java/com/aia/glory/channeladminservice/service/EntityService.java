package com.aia.glory.channeladminservice.service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.aia.glory.channeladminservice.dao.EntityDao;
import com.aia.glory.channeladminservice.dao.GeneralInfomationDao;
import com.aia.glory.channeladminservice.model.EntityModel;
import com.aia.glory.channeladminservice.model.GenericAttributeModel;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.GeneralInfomation;
import com.aia.glory.model.request.EntityCreateRequest;
import com.aia.glory.model.request.EntityRequest;
import com.aia.glory.model.response.GetEntityResponse;
import com.aia.glory.model.response.GetExtendFieldDescResponse;
import com.aia.glory.model.response.InsertEntityResponse;

@Service(value = "entityService")
public class EntityService {
	@Autowired
	public EntityDao entityDao;
	
	@Autowired
	public GeneralInfomationDao generalInfomationDao;

	public GetEntityResponse retrieveEntity(EntityRequest entityRequest) {
		
		int total = entityDao.selectEntityTotal(entityRequest);
		List<EntityModel> entityList = entityDao.selectEntity(entityRequest);
		entityList = this.convertSeqToName(entityList);
		if(entityRequest.getSeq()!= null && !"".equals(entityRequest.getSeq())){
			this.retrieveGenericField(entityList, entityRequest);
		}
		return GetEntityResponse.success(ResponseCode.NORMAL, entityList, total);
	}
	
	public GetExtendFieldDescResponse retrieveExtendParticipantFieldDesc(){
		Map<String,String> descMap = entityDao.selectExtendParticipantFieldDesc();
		List<GenericAttributeModel> genericAttributeList = new ArrayList();
		if(descMap != null && descMap.size() > 0){
			for(Entry entry : descMap.entrySet()){
				if(!StringUtils.isEmpty(entry.getValue())){
				GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
				genericAttributeModel.setKey((String)entry.getKey());
				genericAttributeModel.setName((String)entry.getValue());
				genericAttributeList.add(genericAttributeModel);
				}
			}
		}
		return GetExtendFieldDescResponse.success(ResponseCode.NORMAL, genericAttributeList);
	}
	
	public GetExtendFieldDescResponse retrieveExtendPositionFieldDesc(){
		Map<String,String> descMap = entityDao.selectExtendPositionFieldDesc();
		List<GenericAttributeModel> genericAttributeList = new ArrayList();
		if(descMap != null && descMap.size() > 0){
			for(Entry entry : descMap.entrySet()){
				if(!StringUtils.isEmpty(entry.getValue())){
				GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
				genericAttributeModel.setKey((String)entry.getKey());
				genericAttributeModel.setName((String)entry.getValue());
				genericAttributeList.add(genericAttributeModel);
				}
			}
		}
		return GetExtendFieldDescResponse.success(ResponseCode.NORMAL, genericAttributeList);
	}
	
	public Integer getMaxParticipantSeq(){
		return entityDao.selectMaxParticipantSeq();
	}
	
	public Integer getMaxPositionSeq(){
		return entityDao.selectMaxPositionSeq();
	}
	
	public InsertEntityResponse insertEntityParticipant(EntityCreateRequest entityCreateRequest) {
		
		if(entityCreateRequest != null) {			
			Map<String,String> valueMap = new HashMap<String, String>();
			List<GenericAttributeModel> genericAttributeList = entityCreateRequest.getEntityModel().getParticipantModel().getGenericFields(); 
			if(genericAttributeList!=null && genericAttributeList.size() >0 ){
				valueMap= genericAttributeList.stream().collect(Collectors.toMap(GenericAttributeModel::getKey, GenericAttributeModel::getValue));
			}
			entityDao.insertEntityParticipant(entityCreateRequest.getEntityModel(),valueMap);
			
			return InsertEntityResponse.success(ResponseCode.NORMAL, entityCreateRequest.getEntityModel().getParticipantModel().getSeq());
		}else {
			return InsertEntityResponse.fail(ResponseCode.ERROR, "Request is null");
		}
	}
	
	public void insertEntityPosition(EntityCreateRequest entityCreateRequest) {
		
		if(entityCreateRequest != null) {
			EntityModel entity = entityCreateRequest.getEntityModel();
			entity=this.convertNameToSeq(entity);
			Map<String,String> valueMap = new HashMap<String, String>();
			List<GenericAttributeModel> genericAttributeList = entityCreateRequest.getEntityModel().getPositionModel().getGenericFields(); 
			if(genericAttributeList!=null && genericAttributeList.size() >0 ){
				valueMap= genericAttributeList.stream().collect(Collectors.toMap(GenericAttributeModel::getKey, GenericAttributeModel::getValue));
			}
			entityDao.insertEntityPosition(entity,valueMap);
		}
	}
		
	private List<EntityModel> convertSeqToName(List<EntityModel> entityList){

		List<GeneralInfomation> titleLst = generalInfomationDao.getTitlelList();
		List<GeneralInfomation> channelLst = generalInfomationDao.getChannelList();
		List<GeneralInfomation> companylLst = generalInfomationDao.getCompanyList();
		
		List<EntityModel> ResultList = entityList;
		for(EntityModel entity : ResultList){
			if(!"".equals(entity.getPositionModel().getTitle())){
				entity.getPositionModel().setTitle(this.getInformation(titleLst, entity.getPositionModel().getTitle(), ""));
			}
			
//			if(entity.getLeaderModel()!=null && !"".equals(entity.getLeaderModel().getTitle())){
//				entity.getLeaderModel().setTitle(this.getInformation(titleLst, entity.getLeaderModel().getTitle(), ""));
//			}
//		
//			if(entity.getLeaderModel()!=null && !"".equals(entity.getLeaderModel().getLeaderTitle())){
//				entity.getLeaderModel().setLeaderTitle(this.getInformation(titleLst, entity.getLeaderModel().getLeaderTitle(), ""));
//			}
//		
//			if(entity.getManagerAgencyModel()!=null && !"".equals(entity.getManagerAgencyModel().getTitle())){
//				entity.getManagerAgencyModel().setTitle(this.getInformation(titleLst, entity.getManagerAgencyModel().getTitle(), ""));
//			}
//			
//			if(entity.getManagerAgencyModel()!=null && !"".equals(entity.getManagerAgencyModel().getLeaderTitle())){
//				entity.getManagerAgencyModel().setLeaderTitle(this.getInformation(titleLst, entity.getManagerAgencyModel().getLeaderTitle(), ""));
//			}
			
			if(!"".equals(entity.getPositionModel().getBusinessUnit())){
				entity.getPositionModel().setBusinessUnit(this.getInformation(channelLst, entity.getPositionModel().getBusinessUnit(), ""));
			}
			if(!"".equals(entity.getPositionModel().getCompanyCode())){
				entity.getPositionModel().setCompanyCode(this.getInformation(companylLst, entity.getPositionModel().getCompanyCode(), ""));
			}
		}
		
		return ResultList;
	}
	
	private EntityModel convertNameToSeq(EntityModel entity){

		List<GeneralInfomation> titleLst = generalInfomationDao.getTitlelList();
		List<GeneralInfomation> channelLst = generalInfomationDao.getChannelList();
		List<GeneralInfomation> companylLst = generalInfomationDao.getCompanyList();
		
		EntityModel Result = entity;

		if(!"".equals(entity.getPositionModel().getTitle())){
			entity.getPositionModel().setTitle(this.getInformation(titleLst, "", entity.getPositionModel().getTitle()));
		}
		
		if(!"".equals(entity.getPositionModel().getBusinessUnit())){
			entity.getPositionModel().setBusinessUnit(this.getInformation(channelLst,"", entity.getPositionModel().getBusinessUnit()));
		}
		
		if(!"".equals(entity.getPositionModel().getCompanyCode())){
			entity.getPositionModel().setCompanyCode(this.getInformation(companylLst,"", entity.getPositionModel().getCompanyCode()));
		}
		
		return Result;
	}

	private String getInformation(List<GeneralInfomation> generalInfomationList, String seq, String name) {
	    
		String result = "";
		if(seq!= null && !"".equals(seq)){
	        for (GeneralInfomation item : generalInfomationList) {
	            if (seq.equals(item.getSeq())) {
	                result = item.getName();
	                break;
	            }
	        }
	    }    	
		else if(name!= null &&!"".equals(name)){
	        for (GeneralInfomation item : generalInfomationList) {
	            if (name.equals(item.getName())) {
	                result = item.getSeq();
	                break;
	            }
	        }
	    }
		
	    return result;
	}
	
	private List<EntityModel> retrieveGenericField(List<EntityModel> entityList, EntityRequest entityRequest){
		List<EntityModel> ResultList = entityList;
		
		Map<String,String> descMap = entityDao.selectExtendParticipantFieldDesc();
		Map<String,String> descMapPos = entityDao.selectExtendPositionFieldDesc();
		
		for(EntityModel entity : ResultList){
			if(entity.getParticipantModel().getSeq()!=null && !"".equals(entity.getParticipantModel().getSeq()) ){
				Map<String,String> valueMap = entityDao.selectExtendParticipantFieldValue(entityRequest);
				if(valueMap ==null){
					valueMap = new HashMap<String, String>();
				}
				List<GenericAttributeModel> genericAttributeList = new ArrayList();
				for(Entry entry : descMap.entrySet()){
					if(!StringUtils.isEmpty(entry.getValue())){
						GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
						genericAttributeModel.setKey((String)entry.getKey());
						genericAttributeModel.setName((String)entry.getValue());
						
						Object value = valueMap.get(entry.getKey());
						if(value instanceof String){
							genericAttributeModel.setValue((String)value);
						}else if(value instanceof Date){
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
							genericAttributeModel.setValue(formatter.format(value));
						}else if(value instanceof BigDecimal){
							DecimalFormat format = new DecimalFormat("0.00");
						    String result = format.format(((BigDecimal) value));
							genericAttributeModel.setValue(result);
//							genericAttributeModel.setType("NUMBER");
						}else{
							genericAttributeModel.setValue((String) value);
						}
						genericAttributeList.add(genericAttributeModel);
					}
				}
				entity.getParticipantModel().setGenericFields(genericAttributeList);
				
				Map<String,String> valueMapPos = entityDao.selectExtendPositionFieldValue(entityRequest);
				if(valueMapPos ==null){
					valueMapPos = new HashMap<String, String>();
				}
				List<GenericAttributeModel> genericAttributeListPos = new ArrayList();
				for(Entry entry : descMapPos.entrySet()){
					if(!StringUtils.isEmpty(entry.getValue())){
						GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
						genericAttributeModel.setKey((String)entry.getKey());
						genericAttributeModel.setName((String)entry.getValue());
						
						Object value = valueMapPos.get(entry.getKey());
						if(value instanceof String){
							genericAttributeModel.setValue((String)value);
						}else if(value instanceof Date){
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
							genericAttributeModel.setValue(formatter.format(value));
						}else if(value instanceof BigDecimal){
							DecimalFormat format = new DecimalFormat("0.00");
						    String result = format.format(((BigDecimal) value));
							genericAttributeModel.setValue(result);
//							genericAttributeModel.setType("NUMBER");
						}else{
							genericAttributeModel.setValue((String) value);
						}
						genericAttributeListPos.add(genericAttributeModel);
					}
				}			
				entity.getPositionModel().setGenericFields(genericAttributeListPos);
				
			}
		}
		
		return ResultList;
	}
}
