package com.aia.glory.channeladminservice.model;

import java.io.Serializable;

public class VersionModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public final static String DEFAULT_END_DATE = "2200-01-01";
	 
	public final static String DEFAULT_END_DATETIME = "2200-01-01 00:00:00.0";
	
	private String seq;
	
	private String isLast;
	
	private String effectiveStartDate;
	
	private String effectiveEndDate;
	
    private String createDate;
	
    private String removeDate;
	
    private String versionLog;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getIsLast() {
		return isLast;
	}

	public void setIsLast(String isLast) {
		this.isLast = isLast;
	}

	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getRemoveDate() {
		return removeDate;
	}

	public void setRemoveDate(String removeDate) {
		this.removeDate = removeDate;
	}

	public String getVersionLog() {
		return versionLog;
	}

	public void setVersionLog(String versionLog) {
		this.versionLog = versionLog;
	}
	
	@Override
	public String toString() {
		return "VersionModel ["
				+"effectiveStartDate=" + effectiveStartDate + ", "
				+"effectiveEndDate="+ effectiveEndDate + ", "
				+"createDate=" + createDate + ", "
				+"removeDate=" + removeDate + ", "
				+"versionLog=" + versionLog + "]";
	}
}
