package com.aia.glory.model.response;

import java.util.Arrays;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class GetVersionResponse extends Response
 {
	private Object versionModel;
	
	private int total;

	public Object getVersionModel() {
		return versionModel;
	}

	public void setVersionModel(Object versionModel) {
		this.versionModel = versionModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static GetVersionResponse success(ResponseCode responseCode) {
		GetVersionResponse getVersionResponse = new GetVersionResponse();
		getVersionResponse.setResponseCode(responseCode.getCode());
		getVersionResponse.setReasonCode(Arrays.asList("0000"));
		getVersionResponse.setReasonDesc(Arrays.asList(""));
		return getVersionResponse;
	}

	public static GetVersionResponse success(ResponseCode responseCode,Object versionModel,int total) 
	 {        
		GetVersionResponse getVersionResponse = new GetVersionResponse();        
		getVersionResponse.setResponseCode(responseCode.getCode());
		getVersionResponse.setReasonCode(Arrays.asList("0000"));
		getVersionResponse.setReasonDesc(Arrays.asList(""));
		getVersionResponse.setVersionModel(versionModel);
		getVersionResponse.setTotal(total);
		return getVersionResponse;    
		 
	 }
	
	public static GetVersionResponse fail(ResponseCode responseCode,String msg) {
		GetVersionResponse getVersionResponse = new GetVersionResponse();
		getVersionResponse.setResponseCode(responseCode.getCode());
		getVersionResponse.setReasonCode(Arrays.asList("0000"));
		getVersionResponse.setReasonDesc(Arrays.asList(msg));
		return getVersionResponse;
	}

	@Override
	public String toString() {
		return "GetVersionResponse [versionModel=" + versionModel + ", total=" + total + "]" + super.toString();
	}
	
}
