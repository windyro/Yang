package com.aia.glory.calculationservice.validator;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.aia.glory.calculationresultservice.enumerate.ReasonCode;
import com.aia.glory.model.request.PipelineResultRequest;

public class PipelineResultValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		return PipelineResultRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		PipelineResultRequest request = (PipelineResultRequest) target;
		
		if(!StringUtils.isEmpty(request.getPageSize())
				&& (request.getStartPage() > Integer.MAX_VALUE || request.getStartPage() < 0)){
				
				errors.rejectValue("startPage", ReasonCode.PUT_EXCEPTION.getCode(), ReasonCode.PUT_EXCEPTION.getDesc());
				
		}
		
		if(!StringUtils.isEmpty(request.getPageSize())
				&& (request.getStartPage() > Integer.MAX_VALUE || request.getStartPage() < 0)){
				
				errors.rejectValue("pageSize", ReasonCode.PUT_EXCEPTION.getCode(), ReasonCode.PUT_EXCEPTION.getDesc());
				
		}
	}

}
