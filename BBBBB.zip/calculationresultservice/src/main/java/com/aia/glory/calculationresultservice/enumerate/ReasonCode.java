package com.aia.glory.calculationresultservice.enumerate;

public enum ReasonCode {
	
	SAMPLE_EXCEPTION("20004","sample Exception"),
	
	DATA_FORMAT_EXCEPTION("20005","Date format error"),
	
	COMMAGENT_EXCEPTION("20006","commAgent need letters or Numbers"),
	
	COMMAGENCY_EXCEPTION("20007","commAgency need letters or Numbers"),
	
	POLICYNUMBER_EXCEPTION("20008","policyNumber need letters or Numbers"),
	
	PUT_EXCEPTION("20009","please put correct value");
	private String code;
	
	private String desc;
	
	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	private ReasonCode(String code, String desc){
		this.code=code;
		this.desc=desc;
	}
	
}
