package com.aia.glory.model.compensation;

public class PaymentSummaryResult {

	private Integer paymentSeq;
	
	private String payee;
	
	private String period;
	
	private String value;
	
	private String channel;
	
	private String company;
	
	private String postDate;
	
	private String Status;
	
	private String payeeAgency;
	
	private String payeeTitle;
	
	private String paymentMethod;
	
	private String bank;
	
	private String bankAccount;

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public Integer getPaymentSeq() {
		return paymentSeq;
	}

	public void setPaymentSeq(Integer paymentSeq) {
		this.paymentSeq = paymentSeq;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPostDate() {
		return postDate;
	}

	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getPayeeAgency() {
		return payeeAgency;
	}

	public void setPayeeAgency(String payeeAgency) {
		this.payeeAgency = payeeAgency;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	@Override
	public String toString() {
		return "PaymentSummaryResult [paymentSeq=" + paymentSeq + ", payee=" + payee + ", period=" + period + ", value="
				+ value + ", channel=" + channel + ", company=" + company + ", postDate=" + postDate + ", Status="
				+ Status + ", payeeAgency=" + payeeAgency + ", payeeTitle=" + payeeTitle + ", paymentMethod="
				+ paymentMethod + ", bank=" + bank + ", bankAccount=" + bankAccount + "]";
	}

}
