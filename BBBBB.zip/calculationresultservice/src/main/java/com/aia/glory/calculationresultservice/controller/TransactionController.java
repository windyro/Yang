
package com.aia.glory.calculationresultservice.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.calculationresultservice.service.TransactionService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.DepositSummary;
import com.aia.glory.model.request.DpstTrsactionTraceRequest;
import com.aia.glory.model.request.GetTransactionSummaryRequest;
import com.aia.glory.model.request.PaymentSummary;
import com.aia.glory.model.request.PymntDpstTraceRequest;
import com.aia.glory.model.request.MeasurementSummary;

@RestController
public class TransactionController {
	
	@Autowired
	@Qualifier(value = "transactionService")
	private TransactionService transactionService;

	@RequestMapping(value = "/paymentSummary", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getPaymentSummary(@RequestBody PaymentSummary paymentSummary) throws Exception{
			
		String action =  paymentSummary.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = transactionService.retrievePaymentDetail(paymentSummary);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	@RequestMapping(value = "/depositPaymentTrace", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getDepositPaymentTrace(@RequestBody PymntDpstTraceRequest pymntDpstTraceRequest) throws Exception{
			
		String action =  pymntDpstTraceRequest.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = transactionService.retrieveDepositPaymentTrace(pymntDpstTraceRequest);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	@RequestMapping(value = "/depositSummary", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getDepositSummary(@RequestBody DepositSummary depositSummary) throws Exception{
			
		String action =  depositSummary.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = transactionService.retrieveDepositDetail(depositSummary);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	
	@RequestMapping(value = "/measurementSummary", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getMeasurementSummary(@RequestBody MeasurementSummary measurementSummary) throws Exception{
			
		String action =  measurementSummary.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = transactionService.retrieveMeasurementDetail(measurementSummary);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	
	
	@RequestMapping(value = "/transactionDepositTrace", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getTransactionDepositTrace(@RequestBody DpstTrsactionTraceRequest dpstTrsactionTraceRequest) throws Exception{
			
		String action =  dpstTrsactionTraceRequest.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = transactionService.retrieveTransactionDepositTrace(dpstTrsactionTraceRequest);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	@RequestMapping(value = "/transactiondetailDepositTrace", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getTransactiondetailDepositTrace(@RequestBody DpstTrsactionTraceRequest dpstTrsactionTraceRequest) throws Exception{
			
		String action =  dpstTrsactionTraceRequest.getAction();
		Response response = null;
			
		switch (action) {
		case "POST":
			response = transactionService.retrieveTransactiondetailDepositTrace(dpstTrsactionTraceRequest);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	@RequestMapping(value = "/transactionSummry", method = RequestMethod.POST)
	public Response retrieveTransactionSummaryList(@RequestBody GetTransactionSummaryRequest transactionSummaryRequest) throws IOException{
		String action = transactionSummaryRequest.getAction();
		Response response = null;
		switch (action) {
		case "POST":
			response = transactionService.retrieveTransactionSummary(transactionSummaryRequest);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
	@RequestMapping(value = "/transactionDetail", method = RequestMethod.POST)
	public Response transactionDetail(@RequestBody GetTransactionSummaryRequest transactionSummaryRequest) throws IOException{
		
		String action = transactionSummaryRequest.getAction();
		Response response = null;
		
		switch (action) {
		case "POST":
			response = transactionService.retrieveTransactionDetail(transactionSummaryRequest);
			break;	
		default:
			break;
		}
		
		return response;
	}
}
