package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;

public class DepositSummary extends Request{
	
	private Integer startPage = 0;
	
	private Integer pageSize = 0;
	
	private String payee;
	
	private String compensationName;
	
	private String period;
	
	private String channel;
	
	private String company;
	
	private String startPeriod;
	
	private String endPeriod;
	
	public void setStartPage(Integer startPage) {
		if(startPage == null || startPage==0) {
			startPage = 1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(Integer pageSize) {
		if(pageSize == null || pageSize == 0) {
			pageSize = 10;
		}
		this.pageSize = pageSize;
	}

	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getCompensationName() {
		return compensationName;
	}

	public void setCompensationName(String compensationName) {
		this.compensationName = compensationName;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getStartPeriod() {
		return startPeriod;
	}

	public void setStartPeriod(String startPeriod) {
		this.startPeriod = startPeriod;
	}

	public String getEndPeriod() {
		return endPeriod;
	}

	public void setEndPeriod(String endPeriod) {
		this.endPeriod = endPeriod;
	}
	

}
