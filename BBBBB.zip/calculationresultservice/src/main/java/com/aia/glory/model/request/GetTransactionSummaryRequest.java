package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;

public class GetTransactionSummaryRequest extends Request{
    
	private String transactionSeq;
	
	private String compensationDate;
	
	private String commAgent;
	
    private String commAgency;
    
    private String policyNumber;
    
    private String eventType;
    
    private String compStartDate;
    
    private String channel;
    
    private String company;
    
    private String compEndDate; 
    
    private int startPage = 0;
	
   	private int pageSize = 0;

	public void setStartPage(int startPage) {
		if(startPage == 0) {
			startPage =1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(int pageSize) {
		if(pageSize == 0) {
			pageSize =1;
		}
		this.pageSize = pageSize;
	}
	
	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getTransactionSeq() {
		return transactionSeq;
	}

	public void setTransactionSeq(String transactionSeq) {
		this.transactionSeq = transactionSeq;
	}

	public String getCompensationDate() {
		return compensationDate;
	}

	public void setCompensationDate(String compensationDate) {
		this.compensationDate = compensationDate;
	}

	public String getCommAgent() {
		return commAgent;
	}

	public void setCommAgent(String commAgent) {
		this.commAgent = commAgent;
	}

	public String getCommAgency() {
		return commAgency;
	}

	public void setCommAgency(String commAgency) {
		this.commAgency = commAgency;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getCompStartDate() {
		return compStartDate;
	}

	public void setCompStartDate(String compStartDate) {
		this.compStartDate = compStartDate;
	}

	public String getCompEndDate() {
		return compEndDate;
	}

	public void setCompEndDate(String compEndDate) {
		this.compEndDate = compEndDate;
	}
	
	
}
