package com.aia.glory.model.request;

import javax.validation.constraints.Pattern;

import com.aia.glory.common.model.request.Request;

public class CeTransactionRequest extends Request{
    
	@Pattern(regexp ="^(\\d{4}-\\d{2}-\\d{2})|\\s*$" , message = "Date format error")
	private String compensationDate;
	
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgent need letters or Numbers")
	private String agentCode;
	
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "commAgency need letters or Numbers")
    private String commAgency;
    
    @Pattern(regexp ="^[\\sA-Za-z0-9\\s]*$" , message = "policyNumber need letters or Numbers")
    private String policyNumber;
    
    private String eventType;
    
    private String productdesc;
    
    private String businessunitmap;
    
    private String description;
    
    private String value;
    
    private String mantxn;
    
    private String gstCode;
    
    private String expenseAccount;
    private String agentBalance;
    private String submittedBy;
	public String getCompensationDate() {
		return compensationDate;
	}
	public void setCompensationDate(String compensationDate) {
		this.compensationDate = compensationDate;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getCommAgency() {
		return commAgency;
	}
	public void setCommAgency(String commAgency) {
		this.commAgency = commAgency;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getProductdesc() {
		return productdesc;
	}
	public void setProductdesc(String productdesc) {
		this.productdesc = productdesc;
	}
	public String getBusinessunitmap() {
		return businessunitmap;
	}
	public void setBusinessunitmap(String businessunitmap) {
		this.businessunitmap = businessunitmap;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getMantxn() {
		return mantxn;
	}
	public void setMantxn(String mantxn) {
		this.mantxn = mantxn;
	}
	public String getGstCode() {
		return gstCode;
	}
	public void setGstCode(String gstCode) {
		this.gstCode = gstCode;
	}
	public String getExpenseAccount() {
		return expenseAccount;
	}
	public void setExpenseAccount(String expenseAccount) {
		this.expenseAccount = expenseAccount;
	}
	public String getAgentBalance() {
		return agentBalance;
	}
	public void setAgentBalance(String agentBalance) {
		this.agentBalance = agentBalance;
	}
	public String getSubmittedBy() {
		return submittedBy;
	}
	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}
}
