package com.aia.glory.calculationresultservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.calculationresultservice.service.impl.PipelineResultService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.PipelineResultRequest;

@RestController
public class PipelineResultController 
{
	@Autowired
	@Qualifier(value = "pipelineResultService")
	private PipelineResultService pipelineResultService;

	@RequestMapping(value = "/pipelineresult", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Response getPipelineResult(@RequestBody PipelineResultRequest pipelineResultRequest) throws Exception{
			
		String action =  pipelineResultRequest.getAction();
		pipelineResultRequest.setPageSize(pipelineResultRequest.getPageSize());
		pipelineResultRequest.setStartPage(pipelineResultRequest.getStartPage());
		Response response = null;
			
		switch (action) {
		case "GET":
			response = pipelineResultService.retrievePipelineResult(pipelineResultRequest);
			break;	
		default:
			break;
		}
		
		return response;
	}
	
}
