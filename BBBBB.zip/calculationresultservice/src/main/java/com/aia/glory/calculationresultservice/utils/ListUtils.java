package com.aia.glory.calculationresultservice.utils;

import java.util.ArrayList;
import java.util.List;

public class ListUtils {
	private ListUtils() {
	    throw new IllegalStateException("Utility class");
	}
	public static List<List> ListSplit(List list,int groupSize){
		ArrayList result = new ArrayList();
		int paramSize = list.size();
		int groupNum = paramSize / groupSize;
		for( int i = 0; i < groupNum ; i++ ){
			int fromIndex = i * groupSize;
			int toIndex = i * groupSize + groupSize - 1;
			List paramList = list.subList(fromIndex, toIndex);
			result.add(paramList);
		}
		if(paramSize % groupSize != 0 ){
			int fromIndex = groupNum * groupSize;
			int toIndex = groupNum * groupSize + paramSize % groupSize;
			List paramList = list.subList(fromIndex, toIndex);
			result.add(paramList);
		}
		
		return result;
	}
}
