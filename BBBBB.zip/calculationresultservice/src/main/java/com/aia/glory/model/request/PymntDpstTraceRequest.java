package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;

public class PymntDpstTraceRequest extends Request{

	private Integer startPage = 0;
	
	private Integer pageSize = 0;
	
	private Integer paymentSeq;
	
	public Integer getPaymentSeq() {
		return paymentSeq;
	}

	public void setPaymentSeq(Integer paymentSeq) {
		this.paymentSeq = paymentSeq;
	}

	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}
	
	public void setStartPage(Integer startPage) {
		this.startPage = startPage;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
