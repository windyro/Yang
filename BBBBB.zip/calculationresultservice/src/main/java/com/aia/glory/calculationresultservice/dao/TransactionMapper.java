package com.aia.glory.calculationresultservice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.model.compensation.AdjustmestResultModel;
import com.aia.glory.model.compensation.DepositSummaryResult;
import com.aia.glory.model.compensation.PaymentSummaryResult;
import com.aia.glory.model.compensation.TransactionDetail;
import com.aia.glory.model.compensation.TransactionModel;
import com.aia.glory.model.compensation.MeasurementSummaryResult;
import com.aia.glory.model.request.AdjustmentSummaryRequest;
import com.aia.glory.model.request.CeTransactionRequest;
import com.aia.glory.model.request.DepositSummary;
import com.aia.glory.model.request.DpstTrsactionTraceRequest;
import com.aia.glory.model.request.GetTransactionSummaryRequest;
import com.aia.glory.model.request.PaymentSummary;
import com.aia.glory.model.request.PymntDpstTraceRequest;
import com.aia.glory.model.request.MeasurementSummary;

@Mapper
public interface TransactionMapper {
 
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<TransactionModel> selectTransaction(GetTransactionSummaryRequest transactionSummaryRequest);

	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
   			+" SELECT count(1) "
   			+" FROM CE_TRANSACTION CT "
   			+" INNER JOIN CE_BUSINESSUNIT CBU "
   			+" ON "
   			+" CT.BUSINESSUNITMAP=CBU.BUSINESSUNITSEQ "
   			+" INNER JOIN "
   			+" CE_EVENTTYPE CET "
			+" ON CT.EVENTTYPESEQ=CET.DATATYPESEQ left join CE_BUSINESSUNIT cb on cb.businessunitseq = ct.businessunitmap\r\n" + 
			"	left join CE_PROCESSINGUNIT cp on cp.processingunitseq = ct.processingunitseq where 1=1"	
			+"<if test='compStartDate!=null and compStartDate!=\"\"'>" + 
			"	and convert(varchar(10),COMPENSATIONDATE,121)>=convert(varchar(10),#{compStartDate},121) " + 
			"	</if>" + 
			"	<if test='compEndDate != null and compEndDate!=\"\"'>" + 
			"	and convert(varchar(10),#{compEndDate},121)>=convert(varchar(10),COMPENSATIONDATE,121) " + 
			"	</if>"
		
			+"<if test='eventType!=null and eventType!=\"\"'>"
			+" AND CET.EVENTTYPEID like CONCAT(#{eventType},'%')"
			+"</if>"
			+"<if test='commAgent!=null and commAgent!=\"\"'>"
			+" AND CT.COMM_AGENT like CONCAT(#{commAgent},'%')"
			+"</if>"
			+"<if test='commAgency!=null and commAgency!=\"\"'>"
			+" AND CT.COMM_AGENCY like CONCAT(#{commAgency},'%')"
			+"</if><if test='channel!=null and channel!=\"\"'>\r\n" + 
			"	AND cb.NAME = #{channel}\r\n" + 
			"	</if>\r\n" + 
			"	<if test='company!=null and company!=\"\"'>\r\n" + 
			"	AND cp.NAME = #{company}\r\n" + 
			"	</if>"
			+"<if test='policyNumber!=null and policyNumber!=\"\"'>"
			+" AND CT.PONUMBER like CONCAT(#{policyNumber},'%')"
			+"</if>"
			+"<if test='transactionSeq!=null and transactionSeq!=\"\"'>"
			+" AND CT.TRANSACTIONSEQ=#{transactionSeq}"
			+"</if>"
   			+"</script>")
	public int selectTransactionTotal(GetTransactionSummaryRequest transactionSummaryRequest);
	
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
   	@Select("<script>"
   			+" SELECT CT.TRANSACTIONSEQ,CAST(CT.COMPENSATIONDATE  AS date) AS COMPENSATIONDATE,"
   			+ "concat(Convert(decimal(18,2),CT.VALUE),'') VALUE,CET.EVENTTYPEID,"
   			+ "CT.COMM_AGENT,CT.COMM_AGENCY,CT.PONUMBER,CT.PRODUCTCATEGORY,"
   			+ "CT.WRI_AGENT,CT.WRI_AGENCY,CT.PRODUCTID,CT.PRODUCTNAME,"
   			+ "CT.PRODUCTDESCRIPTION,CT.PRODUCTCATEGORY,CBU.NAME,CP.name,CT.DATASOURCE"
   			+" FROM CE_TRANSACTION CT "
   			+" INNER JOIN CE_BUSINESSUNIT CBU "
   			+" ON "
   			+" CT.BUSINESSUNITMAP=CBU.BUSINESSUNITSEQ "
   			+" INNER JOIN "
   			+" CE_EVENTTYPE CET "
			+" ON CT.EVENTTYPESEQ=CET.DATATYPESEQ"	
			+" INNER JOIN "
   			+" CE_PROCESSINGUNIT CP "
			+" ON CT.PROCESSINGUNITSEQ=CP.processingunitseq"	
			+"<if test='compStartDate!=null'>" + 
			"	and convert(varchar(10),COMPENSATIONDATE,121)>=convert(varchar(10),#{compStartDate},121) " + 
			"	</if>" + 
			"	<if test='compEndDate != null'>" + 
			"	and convert(varchar(10),#{compEndDate},121)>=convert(varchar(10),COMPENSATIONDATE,121) " + 
			"	</if>"
			+"<if test='eventType!=null'>"
			+" AND CET.EVENTTYPEID like CONCAT(#{eventType},'%')"
			+"</if>"
			+"<if test='commAgent!=null'>"
			+" AND CT.COMM_AGENT like CONCAT(#{commAgent},'%')"
			+"</if>"
			+"<if test='commAgency!=null'>"
			+" AND CT.COMM_AGENCY like CONCAT(#{commAgency},'%')"
			+"</if>"
			+"<if test='policyNumber!=null and policyNumber!=\"\"'>"
			+" AND CT.PONUMBER like CONCAT(#{policyNumber},'%')"
			+"</if>"
			+"<if test='transactionSeq!=null'>"
			+" AND CT.TRANSACTIONSEQ=#{transactionSeq}"
			+"</if>"
   			+"</script>")
	@ResultMap("selectTransactionDetail")
	public List<TransactionDetail> selectTransactionDetail(GetTransactionSummaryRequest transactionSummaryRequest);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
   			+" SELECT CT.TRANSACTIONSEQ,"
   			+" CT.GENERICATTRIBUTE1,CT.GENERICATTRIBUTE2,CT.GENERICATTRIBUTE3,CT.GENERICATTRIBUTE4,CT.GENERICATTRIBUTE5,CT.GENERICATTRIBUTE6,CT.GENERICATTRIBUTE7,"
   			+" CT.GENERICATTRIBUTE8,CT.GENERICATTRIBUTE9,CT.GENERICATTRIBUTE10,CT.GENERICATTRIBUTE11,CT.GENERICATTRIBUTE12,CT.GENERICATTRIBUTE13,CT.GENERICATTRIBUTE14,"
   			+" CT.GENERICATTRIBUTE15,CT.GENERICATTRIBUTE16,CT.GENERICATTRIBUTE17,CT.GENERICATTRIBUTE18,CT.GENERICATTRIBUTE19,CT.GENERICATTRIBUTE20,CT.GENERICATTRIBUTE21,"
   			+" CT.GENERICATTRIBUTE22,CT.GENERICATTRIBUTE23,CT.GENERICATTRIBUTE24,CT.GENERICATTRIBUTE25,CT.GENERICATTRIBUTE26,CT.GENERICATTRIBUTE27,CT.GENERICATTRIBUTE28,"
   			+" CT.GENERICATTRIBUTE29,CT.GENERICATTRIBUTE30,CT.GENERICATTRIBUTE31,CT.GENERICATTRIBUTE32,CT.GENERICNUMBER1,CT.GENERICNUMBER2,CT.GENERICNUMBER3,"
   			+" CT.GENERICNUMBER4,CT.GENERICNUMBER5,CT.GENERICNUMBER6,CT.GENERICDATE1,CT.GENERICDATE2,CT.GENERICDATE3,CT.GENERICDATE4,CT.GENERICDATE5,CT.GENERICDATE6,"
   			+" CT.GENERICBOOLEAN1,CT.GENERICBOOLEAN2,CT.GENERICBOOLEAN3,CT.GENERICBOOLEAN4,CT.GENERICBOOLEAN5,CT.GENERICBOOLEAN6"
   			+" FROM CE_TRANSACTION CT "
   			+ "<if test='transactionSeqList != null and transactionSeqList.size() > 0'>"
			+" WHERE CT.TRANSACTIONSEQ IN "
			+ " <foreach collection='transactionSeqList' item='transactionSeq' open='(' close=')' separator =',' >"
			+ "#{transactionSeq}"
			+ " </foreach>"
			+"</if>"
   			+"</script>")
	public  List<Map<String,String>> selectExtendFieldValue(@Param("transactionSeqList")List<String> transactionSeqList);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
			+"SELECT GENERICATTRIBUTE1,GENERICATTRIBUTE2,GENERICATTRIBUTE3,GENERICATTRIBUTE4,GENERICATTRIBUTE5,GENERICATTRIBUTE6,GENERICATTRIBUTE7,"
            +"GENERICATTRIBUTE8,GENERICATTRIBUTE9,GENERICATTRIBUTE10,GENERICATTRIBUTE11,GENERICATTRIBUTE12,GENERICATTRIBUTE13,GENERICATTRIBUTE14,GENERICATTRIBUTE15,"
            + "GENERICATTRIBUTE16,GENERICATTRIBUTE17,GENERICATTRIBUTE18,GENERICATTRIBUTE19,GENERICATTRIBUTE20,GENERICATTRIBUTE21,GENERICATTRIBUTE22,GENERICATTRIBUTE23,"
            + "GENERICATTRIBUTE24,GENERICATTRIBUTE25,GENERICATTRIBUTE26,GENERICATTRIBUTE27,GENERICATTRIBUTE28,GENERICATTRIBUTE29,GENERICATTRIBUTE30,GENERICATTRIBUTE31,"
            + "GENERICATTRIBUTE32,GENERICNUMBER1,GENERICNUMBER2,GENERICNUMBER3,GENERICNUMBER4,GENERICNUMBER5,GENERICNUMBER6,GENERICDATE1,GENERICDATE2,GENERICDATE3,GENERICDATE4,"
            + "GENERICDATE5,GENERICDATE6,GENERICBOOLEAN1,GENERICBOOLEAN2,GENERICBOOLEAN3,GENERICBOOLEAN4,GENERICBOOLEAN5,GENERICBOOLEAN6"
            +" FROM CE_EXTENDFIELDDESC WHERE TABLENAME='CE_TRANSACTION'"
            +"</script>")
	public Map<String,String> selectExtendFieldDesc();
	
	public List<DepositSummaryResult> selectDepositSummary(DepositSummary depositSummary);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
			+ " SELECT count(1) "
			+ "FROM [dbo].[CE_DEPOSIT] cf left join CE_POSITION cp on cf.positionseq = cp.positionseq "
			+ "left join ce_period ce on cf.PERIODSEQ=ce.PERIODSEQ "
			+ "left join [CE_BUSINESSUNIT] cb on cb.BUSINESSUNITSEQ=cf.BUSINESSUNITMAP "
			+ "left join [CE_PROCESSINGUNIT] co on co.processingunitseq = cf.PROCESSINGUNITSEQ "
			+ "where cp.ISLAST=1 and cp.REMOVEDATE = convert(date, '22000101')"
			+ "<if test='payee!=null'>" 
			+ " AND cp.NAME like CONCAT(#{payee},'%')" 
			+ "</if>"
			
			+ "<if test='compensationName!=null'>" 
			+ " AND cf.name like CONCAT(#{compensationName},'%')" 
			+ "</if>"
			
			+ "<if test='period!=null'>" 
			+ " AND CONVERT(varchar(7),ce.STARTDATE,23)=#{period}" 
			+ "</if>"
			+"\r\n" + 
			"	<if test='startPeriod != null'>\r\n" + 
			"		and convert(varchar(7),ce.STARTDATE,23) >=\r\n" + 
			"		convert(varchar(7),#{startPeriod},23)\r\n" + 
			"	</if>\r\n" + 
			"	<if test='endPeriod != null'>\r\n" + 
			"		and convert(varchar(7),#{endPeriod},23) >=\r\n" + 
			"		convert(varchar(7),ce.STARTDATE,23)\r\n" + 
			"	</if><if test='channel != null'>\r\n" + 
			"		AND cb.NAME like CONCAT(#{channel},'%')\r\n" + 
			"	</if>\r\n" + 
			"	<if test='company != null'>\r\n" + 
			"		AND co.NAME like CONCAT(#{company},'%')\r\n" + 
			"	</if>"
   			+"</script>")
	public int selectDepositSummaryTotal(DepositSummary depositSummary);
	
	
	public List<PaymentSummaryResult> selectPaymentSummary(PaymentSummary paymentSummary);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
			+ " SELECT count(1) "
			+ "FROM [dbo].[CE_PAYMENT] cf left join CE_POSITION cp on cf.positionseq = cp.positionseq "
			+ "left join ce_period ce on cf.PERIODSEQ=ce.PERIODSEQ "
			+ "left join [CE_BUSINESSUNIT] cb on cb.BUSINESSUNITSEQ=cf.BUSINESSUNITMAP "
			+ "left join [CE_PROCESSINGUNIT] co on co.processingunitseq = cf.PROCESSINGUNITSEQ "
			+ "where cp.ISLAST=1 "
			+ "<if test='payee!=null'>" 
			+ " AND cp.NAME like CONCAT(#{payee},'%')" 
			+ "</if>"
			+ "<if test='period!=null'>" + " AND CONVERT(varchar(7),ce.STARTDATE,23)=#{period}" + "</if>"
			+"\r\n" + 
			"	<if test='startPeriod != null'>\r\n" + 
			"		and convert(varchar(7),ce.STARTDATE,23) >=\r\n" + 
			"		convert(varchar(7),#{startPeriod},23)\r\n" + 
			"	</if>\r\n" + 
			"	<if test='endPeriod != null'>\r\n" + 
			"		and convert(varchar(7),#{endPeriod},23) >=\r\n" + 
			"		convert(varchar(7),ce.STARTDATE,23)\r\n" + 
			"	</if><if test='channel != null'>\r\n" + 
			"		AND cb.NAME like CONCAT(#{channel},'%')\r\n" + 
			"	</if>\r\n" + 
			"	<if test='company != null'>\r\n" + 
			"		AND co.NAME like CONCAT(#{company},'%')\r\n" + 
			"	</if>"
   			+"</script>")
	public int selectPaymentSummaryTotal(PaymentSummary paymentSummary);
	
	@Select("<script>"
			+ "SELECT TOP ${pageSize} * from ("
			+ " SELECT ROW_NUMBER() OVER( ORDER BY ct.TRANSACTIONSEQ) AS RowNumber,"
			+ "  ct.[TRANSACTIONSEQ],ct.[COMPENSATIONDATE],ct.[COMM_AGENT] commAgent,ct.[COMM_AGENCY] commAgency,ct.[WRI_AGENT],ct.[WRI_AGENCY]," 
			+ "  ct.[BUSINESSUNITMAP],ct.[PRODUCTCATEGORY] ProductCat,ct.[VALUE],ct.[PONUMBER] policyNumber,"
			+ " ct.[CHANNEL], ct.[PROCESSINGUNITSEQ],ce.[EVENTTYPEID] eventType " 
			+ "  from [CE_TRANSACTION] ct " 
			+ "  left join [CE_EVENTTYPE] ce on ct.[EVENTTYPESEQ] = ce.[DATATYPESEQ] " 
			+ " left join CE_BUSINESSUNIT cb on cb.businessunitseq = ct.businessunitmap "  
			+ "	left join CE_PROCESSINGUNIT cp on cp.processingunitseq = ct.processingunitseq "
			+ "  where ce.[EVENTTYPEID]='MA'"
			+ "<if test=\"commAgent != null and commAgent != ''\">" 
			+ " AND ct.COMM_AGENT like CONCAT(#{commAgent},'%')" 
			+ "</if>"
			+ "<if test=\"commAgency != null and commAgency != ''\">" 
			+ " AND ct.COMM_AGENCY like CONCAT(#{commAgency},'%')"
			+ "</if>"
			+ "<if test=\"policyNumber != null and policyNumber != ''\">" 
			+ " AND ct.PONUMBER like CONCAT(#{policyNumber},'%')"
			+ "</if>"
			+ "<if test=\"channel != null and channel != ''\">" 
			+ " AND cb.NAME like CONCAT(#{channel},'%')"
			+ "</if>"
			+ "<if test=\"company != null and company != ''\">" 
			+ " AND cp.NAME like CONCAT(#{company},'%')"
			+ "</if>"
			+ "<if test=\"compStartDate != null and compStartDate != ''\">" 
			+ "	and convert(varchar(10),COMPENSATIONDATE,121)>=convert(varchar(10),#{compStartDate},121) "
			+ "	</if>"
			+ "<if test=\"compEndDate != null and compEndDate != ''\">" 
			+ "	and convert(varchar(10),#{compEndDate},121)>=convert(varchar(10),COMPENSATIONDATE,121) " 
			+ "	</if>"
			+ ") as DE WHERE DE.RowNumber > (${pageSize}*(${startPage}-1))"
   			+ "</script>")
	public List<AdjustmestResultModel> selectAdjustmentSummary(AdjustmentSummaryRequest adjustmentSummaryRequest);
	
	@Select("<script>"
			+ " SELECT count(1) " 
			+ "  from [CE_TRANSACTION] ct " 
			+ "  left join [CE_EVENTTYPE] ce on ct.[EVENTTYPESEQ] = ce.[DATATYPESEQ] left join CE_BUSINESSUNIT cb on cb.businessunitseq = ct.businessunitmap\r\n" + 
			"	left join CE_PROCESSINGUNIT cp on cp.processingunitseq = ct.processingunitseq " 
			+ "  where ce.[EVENTTYPEID]='MA'"
			+ "<if test=\"commAgent != null and commAgent != ''\">" 
			+ " AND ct.COMM_AGENT like CONCAT(#{commAgent},'%')" 
			+ "</if>"
			+ "<if test=\"commAgency != null and commAgency != ''\">" 
			+ " AND ct.COMM_AGENCY like CONCAT(#{commAgency},'%')"
			+ "</if>"
			+ "<if test=\"policyNumber != null and policyNumber != ''\">" 
			+ " AND ct.PONUMBER like CONCAT(#{policyNumber},'%')"
			+ "</if>"
			+ "<if test=\"channel != null and channel != ''\">" 
			+ " AND cb.NAME like CONCAT(#{channel},'%')"
			+ "</if>"
			+ "<if test=\"company != null and company != ''\">" 
			+ " AND cp.NAME like CONCAT(#{company},'%')"
			+ "</if>"
			+ "<if test=\"compStartDate != null and compStartDate != ''\">" 
			+ "	and convert(varchar(10),COMPENSATIONDATE,121)>=convert(varchar(10),#{compStartDate},121) "
			+ "	</if>"
			+ "<if test=\"compEndDate != null and compEndDate != ''\">" 
			+ "	and convert(varchar(10),#{compEndDate},121)>=convert(varchar(10),COMPENSATIONDATE,121) " 
			+ "	</if>"
   			+ "</script>")
	public int selectAdjustmentSummaryTotal(AdjustmentSummaryRequest adjustmentSummaryRequest);
	
	@Insert("INSERT INTO [CE_TRANSACTION] (TRANSACTIONSEQ,EVENTTYPESEQ,COMPENSATIONDATE,COMM_AGENT,COMM_AGENCY, " + 
			"	WRI_AGENT,WRI_AGENCY,BUSINESSUNITMAP,PRODUCTDESCRIPTION,PRODUCTCATEGORY,VALUE, " + 
			"	PONUMBER,DATASOURCE,GENERICATTRIBUTE5,GENERICATTRIBUTE11,GENERICATTRIBUTE12,GENERICATTRIBUTE19, " + 
			"	PROCESSINGUNITSEQ,MODIFICATIONDATE)  " + 
			"  (SELECT NEXT VALUE FOR CE_TRANSACTION_SEQ, (SELECT DATATYPESEQ FROM  [CE_EVENTTYPE] where EVENTTYPEID = #{eventType}), #{compensationDate}, #{agentCode}, #{commAgency},"
			+ " #{agentCode}, #{commAgency}, (select businessunitmap from CE_POSITION where islast=1 and name=#{agentCode}), #{description}, #{productdesc}, #{value},"
			+ " #{policyNumber}, #{mantxn}, #{gstCode}, #{expenseAccount}, #{agentBalance}, #{submittedBy},"
			+ " (select cb.PROCESSINGUNITSEQ from CE_POSITION  ce left join CE_BUSINESSUNIT cb on cb.BUSINESSUNITSEQ=ce.businessunitmap where ce.islast=1 and ce.name=#{agentCode}) ,GETDATE())")
	public void insertCeTransaction(CeTransactionRequest adjustment);

	public List<DepositSummaryResult> selectDepositPaymentTrace(PymntDpstTraceRequest pymntDpstTraceRequest);
	
	@Select("<script>"
			+ "SELECT count(1) from ( "
			+ "SELECT ROW_NUMBER() OVER( ORDER BY cf.DEPOSITSEQ) AS RowNumber,"
			+ "cf.DEPOSITSEQ,cf.name as COMPENSATIONNAME,cp.NAME as PAYEE,cp.managerAgency,case when cp.name = cp.leaderCode then cp.genericattribute4 else 'AG' end title,"
			+ "CONVERT(varchar(7),ce.STARTDATE,23) as PERIOD,'' as RULENAME,"
			+ "cf.VALUE,cf.ISHELD,cf.RELEASEDATE,cf.DEPOSITDATE ,cb.NAME as CHANNEL,co.name as COMPANY "
			+ "FROM [dbo].[CE_DEPOSIT] cf "
			+ "left join CE_POSITION cp on cf.positionseq = cp.positionseq "
			+ "left join CE_PERIOD ce on cf.PERIODSEQ=ce.PERIODSEQ " 
			+ "left join [CE_BUSINESSUNIT] cb on cb.BUSINESSUNITSEQ=cf.BUSINESSUNITMAP "
			+ "left join [CE_PROCESSINGUNIT] co on co.processingunitseq =	cf.PROCESSINGUNITSEQ "
			+ "left join CE_DEPOSITAPPLDEPOSITTRACE cdap on cdap.DEPOSITSEQ = cf.DEPOSITSEQ "
			+ "left join CE_APPLDEPOSITPAYMENTTRACE cadp on cadp.APPLIEDDEPOSITSEQ = cdap.APPLIEDDEPOSITSEQ "
			+ "left join CE_PAYMENT cpt on cpt.PAYMENTSEQ = cadp.PAYMENTSEQ "
			+ "where cp.ISLAST=1 "
			+ "<if test=\"paymentSeq != null and paymentSeq != ''\"> "
			+ "	and cpt.paymentseq = #{paymentSeq} "
			+ "</if> "
			+ "<if test=\"measurementName!=null and measurementName!=''\"> "
			+ " where cf.name like CONCAT(#{measurementName},'%') "
			+ "</if>"
			+ "	)AS DE "
			+ "	WHERE DE.RowNumber > (${pageSize}*(${startPage}-1)) "
			+ "</script>")
	public int selectDepositPaymentTraceTotal(PymntDpstTraceRequest paymentSummaryToDepositSummary);
	
	@Select("<script>"
			+ "select measurementseq from CE_DEPOSITPMTRACE where DEPOSITSEQ = #{depositSeq}"
			+ "</script>")
	public List<Integer> selectDepositPMTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest);
	
	@Select("<script>"
			+ "select SUMMARYSEQ from CE_DEPOSITSUMTRACE where  DEPOSITSEQ = #{depositSeq}"
			+ "</script>")
	public List<Integer> selectDepositSummaryTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest);
	
	public List<Integer> selectPMselfTrace(List<Integer> measureseq);

	public List<Integer> selectPMSummaryTrace(List<Integer> measureseq);

	public List<Integer> selectSumTransTrace(List<Integer> summaryseq);

	public List<TransactionModel> selectAllSumTransTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest);
	
	public List<MeasurementSummaryResult> selectMeasurementSummary(MeasurementSummary measurementSummary);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
			+ " SELECT count(1) "
			+ "FROM [dbo].[CE_MEASUREMENT] cf left join CE_POSITION cp on cf.positionseq = cp.positionseq "
			+ "left join ce_period ce on cf.PERIODSEQ=ce.PERIODSEQ "
			+ "left join [CE_BUSINESSUNIT] cb on cb.BUSINESSUNITSEQ=cf.BUSINESSUNITMAP "
			+ "left join [CE_PROCESSINGUNIT] co on co.processingunitseq = cf.PROCESSINGUNITSEQ "
			+ "where 1=1 "
			+ "<if test='payee!=null'>" 
			+ " and cp.NAME like CONCAT(#{payee},'%')" 
			+ "</if>"
			
			+ "<if test='measurementName!=null'>" 
			+ " and cf.name like CONCAT(#{measurementName},'%')" 
			+ "</if>"
			
			+ "<if test='period!=null'>" 
			+ " AND CONVERT(varchar(7),ce.STARTDATE,23)=#{period}" 
			+ "</if>"
			+"\r\n" + 
			"	<if test='startPeriod != null'>\r\n" + 
			"		and convert(varchar(7),ce.STARTDATE,23) >=\r\n" + 
			"		convert(varchar(7),#{startPeriod},23)\r\n" + 
			"	</if>\r\n" + 
			"	<if test='endPeriod != null'>\r\n" + 
			"		and convert(varchar(7),#{endPeriod},23) >=\r\n" + 
			"		convert(varchar(7),ce.STARTDATE,23)\r\n" + 
			"	</if><if test='channel != null'>\r\n" + 
			"		AND cb.NAME like CONCAT(#{channel},'%')\r\n" + 
			"	</if>\r\n" + 
			"	<if test='company != null'>\r\n" + 
			"		AND co.NAME like CONCAT(#{company},'%')\r\n" + 
			"	</if>"
   			+"</script>")
	public int selectMeasurementSummaryTotal(MeasurementSummary measurementSummary);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<TransactionDetail> selectTransactiondetailDepositTrace(List<Integer> summaryList);

}
