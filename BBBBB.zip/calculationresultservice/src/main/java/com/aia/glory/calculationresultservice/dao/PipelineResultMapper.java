package com.aia.glory.calculationresultservice.dao;

import java.util.List;


import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.model.compensation.PipelineResultModel;
import com.aia.glory.model.request.PipelineResultRequest;

@Mapper
public interface PipelineResultMapper 
{
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public List<PipelineResultModel> selectPipelineResult(PipelineResultRequest pipelineResult);
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	@Select("<script>"
   			+" SELECT count(1) "
   			+" FROM CE_PIPELINERUN CPR "
   			+" INNER JOIN CE_PERIOD CPD "
   			+" ON "
   			+" CPR.periodseq=CPD.PERIODSEQ INNER JOIN CE_BUSINESSUNIT CB\r\n" + 
   			"    ON CB.BUSINESSUNITSEQ=CPR.businessunitseq "
   			+" INNER JOIN "
   			+" CE_PROCESSINGUNIT CPT "
			+" ON CPR.processingunitseq=CPT.processingunitseq"	
			+"<if test=\"period!=null and period != ''\">"
			+" AND CONVERT(varchar(7),CPD.STARTDATE,23)=#{period}"
			+"</if>"
			+"<if test=\"stage!=null and stage != ''\">"
			+" AND CPR.command=#{stage}"
			+"</if>"
			+"<if test=\"company!=null and company != ''\">"
			+" AND CPT.name=#{company}"
			+"</if>"
			+"<if test=\"jobSeq!=null and jobSeq != ''\">"
			+" AND CPR.pipelinerunseq=#{jobSeq}"
			+"</if>"
			+"<if test=\"status!=null and status != ''\">"
			+" AND CPR.status like CONCAT(#{status},'%')"
			+"</if>"
			+ "<if test=\"company!=null and company != ''\">" + 
			"	AND CPT.name=#{company}" + 
			"	</if>"  
			//+"	<if test=\"channel!=null and channel != ''\">\r\n" + 
			//"	AND CB.name=#{channel}\r\n" + 
			//"	</if>"
			
			+"<if test=\"startTime!=null and startTime != ''\">"
			+" AND CONVERT(varchar(16),CPR.starttime,120)=#{startTime}"
			+"</if>"
			+"<if test=\"endTime!=null and endTime != ''\">"
			+" AND CONVERT(varchar(16),CPR.stoptime,120)=#{endTime}"
			+"</if>"
   			+"</script>")
	public int selectPipelineResultTotal(PipelineResultRequest pipelineResult);
}
