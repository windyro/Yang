package com.aia.glory.calculationresultservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.glory.calculationresultservice.service.TransactionService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.AdjustmentSummaryRequest;
import com.aia.glory.model.request.CeTransactionRequest;

@RestController
public class AdjustmentResultController 
{
	@Autowired
	private TransactionService transactionService;

	@PostMapping(value = "/adjustmentresult")
	public Response getAdjustmentResult(@RequestBody AdjustmentSummaryRequest adjustmentSummaryRequest) throws Exception{
			
		Response response = null;
		
		response = transactionService.retrieveAdjustmentSummary(adjustmentSummaryRequest);
		
		
		return response;
	}
	
	@PostMapping(value = "/adjustmentBatch")
	public Response doAdjustmentBatch(@RequestBody List<CeTransactionRequest> arList) throws Exception{
			
		Response response = null;
		response = transactionService.addBulkCeTransaction(arList);
				
		return response;
	}
	
}
