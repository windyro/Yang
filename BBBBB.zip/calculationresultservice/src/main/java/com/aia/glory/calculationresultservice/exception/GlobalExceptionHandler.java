package com.aia.glory.calculationresultservice.exception;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.model.response.GetTransactionSummaryResponse;

@ControllerAdvice 
public class GlobalExceptionHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<GetTransactionSummaryResponse> defaultHandler(Exception ex) throws Exception {
                
    	GetTransactionSummaryResponse res = new GetTransactionSummaryResponse();
    	res.setResponseCode(ResponseCode.ERROR.getCode());
    	res.setReasonCode(Arrays.asList(ReasonCode.GENERIC_ERROR.getCode()));
    	res.setReasonDesc(Arrays.asList(ex.getMessage()));
        logger.error("catch exception:",ex);
        return new ResponseEntity<GetTransactionSummaryResponse>(res, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
