package com.aia.glory.model.compensation;

public class MeasurementSummaryResult {

	private Integer measurementSeq;
	
	private String measurementName;
	
	private String payee;
	
	private String period;
	
	private String ruleName;
	
	private String value;
	
	private String channel;
	
	private String company;
	
	private String measurementDate;
	
	private String managerAgency;
	
	private String title;
	
	public Integer getMeasurementSeq() {
		return measurementSeq;
	}

	public void setMeasurementSeq(Integer measurementSeq) {
		this.measurementSeq = measurementSeq;
	}

	public String getMeasurementName() {
		return measurementName;
	}

	public void setMeasurementName(String measurementName) {
		this.measurementName = measurementName;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getMeasurementDate() {
		return measurementDate;
	}

	public void setMeasurementDate(String measurementDate) {
		this.measurementDate = measurementDate;
	}

	public String getManagerAgency() {
		return managerAgency;
	}

	public void setManagerAgency(String managerAgency) {
		this.managerAgency = managerAgency;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "MeasurementSummaryResult [measurementSeq=" + measurementSeq + ", measurementName=" + measurementName + ", payee="
				+ payee + ", period=" + period + ", ruleName=" + ruleName + ", value=" + value + ", channel=" + channel
				+ ", company=" + company + ", measurementDate=" + measurementDate + ", managerAgency=" + managerAgency + ", title=" + title + "]";
	}
	
}
