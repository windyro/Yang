package com.aia.glory.calculationresultservice.service.impl;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import com.aia.glory.calculationresultservice.dao.TransactionMapper;
import com.aia.glory.calculationresultservice.service.TransactionService;
import com.aia.glory.calculationresultservice.utils.ListUtils;
import com.aia.glory.calculationservice.validator.AdjustmentResultValidator;
import com.aia.glory.calculationservice.validator.DepositSummaryValidator;
import com.aia.glory.calculationservice.validator.GetTransactionSummaryRequestValidator;
import com.aia.glory.calculationservice.validator.PaymentSummaryValidator;
import com.aia.glory.calculationservice.validator.MeasurementSummaryValidator;
import com.aia.glory.common.constant.CommonConstant;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.GeneryResponse;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.ErrorMessageUtils;
import com.aia.glory.model.compensation.AdjustmestResultModel;
import com.aia.glory.model.compensation.DepositSummaryResult;
import com.aia.glory.model.compensation.GenericAttributeModel;
import com.aia.glory.model.compensation.PaymentSummaryResult;
import com.aia.glory.model.compensation.TransactionDetail;
import com.aia.glory.model.compensation.TransactionModel;
import com.aia.glory.model.compensation.MeasurementSummaryResult;
import com.aia.glory.model.request.AdjustmentSummaryRequest;
import com.aia.glory.model.request.CeTransactionRequest;
import com.aia.glory.model.request.DepositSummary;
import com.aia.glory.model.request.DpstTrsactionTraceRequest;
import com.aia.glory.model.request.GetTransactionSummaryRequest;
import com.aia.glory.model.request.PaymentSummary;
import com.aia.glory.model.request.PymntDpstTraceRequest;
import com.aia.glory.model.request.MeasurementSummary;
import com.aia.glory.model.response.DepositSummaryResponse;
import com.aia.glory.model.response.GetTransactionDetailResponse;
import com.aia.glory.model.response.GetTransactionSummaryResponse;
import com.aia.glory.model.response.PaymentSummaryResponse;
import com.aia.glory.model.response.MeasurementSummaryResponse;

@Scope("prototype")
@Service(value = "transactionService")
@ConditionalOnProperty(prefix = "customize", name="disabled", havingValue = "true",matchIfMissing = true)
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired
    protected TransactionMapper transactionMapper;
	
	@Override
	public GetTransactionSummaryResponse retrieveTransactionSummary(GetTransactionSummaryRequest transactionSummaryRequest){
		Errors errors = new BeanPropertyBindingResult(new GetTransactionSummaryRequest(), "getTransactionSummaryRequest");
		GetTransactionSummaryRequestValidator transactionSummaryRequestValidator = new GetTransactionSummaryRequestValidator();
		transactionSummaryRequestValidator.validate(transactionSummaryRequest, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 GetTransactionSummaryResponse getTransactionSummaryResponse = GetTransactionSummaryResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return getTransactionSummaryResponse;
		}
	    int total = transactionMapper.selectTransactionTotal(transactionSummaryRequest);
	    List<TransactionModel> transactionList = transactionMapper.selectTransaction(transactionSummaryRequest);
	    return GetTransactionSummaryResponse.success(ResponseCode.NORMAL, transactionList, total);
	}
	
	@Override
	public GetTransactionDetailResponse retrieveTransactionDetail(GetTransactionSummaryRequest transactionSummaryRequest){
	
		Errors errors = new BeanPropertyBindingResult(new GetTransactionSummaryRequest(), "getTransactionSummaryRequest");
		GetTransactionSummaryRequestValidator transactionSummaryRequestValidator = new GetTransactionSummaryRequestValidator();
		transactionSummaryRequestValidator.validate(transactionSummaryRequest, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 GetTransactionDetailResponse getTransactionDetailResponse = GetTransactionDetailResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return getTransactionDetailResponse;
		}
		int total = transactionMapper.selectTransactionTotal(transactionSummaryRequest);
		List<TransactionDetail> transactionList = transactionMapper.selectTransactionDetail(transactionSummaryRequest);
		this.assembleTransactionGA(transactionList);
		return GetTransactionDetailResponse.success(ResponseCode.NORMAL, transactionList, total);
	}
	
	protected void assembleTransactionGA(List<TransactionDetail> transactionList){
		
		ArrayList<String> transactionSeqList = new ArrayList<String>();
		for(TransactionDetail transactionModel : transactionList){
			transactionSeqList.add(transactionModel.getTransactionSeq());
		}
		
		List<Map<String,String>> valueMapList = new ArrayList<Map<String,String>>();
		List<List> splitList = ListUtils.ListSplit(transactionSeqList,1000);
		for(List paramList : splitList){
			List resultList = transactionMapper.selectExtendFieldValue(paramList);
			valueMapList.addAll(resultList);
		}
		
		Map<String,String> descMap = transactionMapper.selectExtendFieldDesc();
		
		for(TransactionDetail transactionModel : transactionList){
			for(Map<String,String> valueMap : valueMapList){
				if(transactionModel.getTransactionSeq().equals(String.valueOf(valueMap.get("TRANSACTIONSEQ")))){
					transactionModel.setGenericFields(aseembleGenericAttribute(descMap,valueMap));
				}
			}
		}
	}
	
	private List<GenericAttributeModel> aseembleGenericAttribute(Map<String,String> descMap, Map<String,String> valueMap){
		List<GenericAttributeModel> genericAttributeList = new ArrayList();
		for(Entry entry : descMap.entrySet()){
			if(!StringUtils.isEmpty(entry.getValue())){
				GenericAttributeModel genericAttributeModel = new GenericAttributeModel();
//				genericAttributeModel.setKey((String)entry.getKey());
				genericAttributeModel.setName((String)entry.getValue());
				
				Object value = valueMap.get(entry.getKey());
				if(value instanceof String){
					genericAttributeModel.setValue((String)value);
				}else if(value instanceof Date){
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					genericAttributeModel.setValue(formatter.format(value));
				}else if(value instanceof BigDecimal){
					DecimalFormat format = new DecimalFormat("0.00");
				    String result = format.format(((BigDecimal) value));
					genericAttributeModel.setValue(result);
//					genericAttributeModel.setType("NUMBER");
				}else{
					genericAttributeModel.setValue((String) value);
				}
				genericAttributeList.add(genericAttributeModel);
			}
		}
		return genericAttributeList;
	}
	
	@Override
	public DepositSummaryResponse retrieveDepositDetail(DepositSummary depositSummary){
		Errors errors = new BeanPropertyBindingResult(new DepositSummary(), "depositSummary");
		DepositSummaryValidator depositSummaryValidator = new DepositSummaryValidator();
		depositSummaryValidator.validate(depositSummary, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 DepositSummaryResponse depositSummaryResponse = DepositSummaryResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return depositSummaryResponse;
	    }
		List<DepositSummaryResult> list = transactionMapper.selectDepositSummary(depositSummary);
		
		int total = transactionMapper.selectDepositSummaryTotal(depositSummary);
		
		return DepositSummaryResponse.success(ResponseCode.NORMAL, list, total);
	}
	
	
	@Override
	public MeasurementSummaryResponse retrieveMeasurementDetail(MeasurementSummary measurementSummary){
		Errors errors = new BeanPropertyBindingResult(new MeasurementSummary(), "measurementSummary");
		MeasurementSummaryValidator measurementSummaryValidator = new MeasurementSummaryValidator();
		measurementSummaryValidator.validate(measurementSummary, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 MeasurementSummaryResponse measurementSummaryResponse = MeasurementSummaryResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return measurementSummaryResponse;
	    }
		List<MeasurementSummaryResult> list = transactionMapper.selectMeasurementSummary(measurementSummary);
		
		int total = transactionMapper.selectMeasurementSummaryTotal(measurementSummary);
		
		return MeasurementSummaryResponse.success(ResponseCode.NORMAL, list, total);
	}
	
	
	@Override
	public PaymentSummaryResponse retrievePaymentDetail(PaymentSummary paymentSummary){
		Errors errors = new BeanPropertyBindingResult(new PaymentSummary(), "paymentSummary");
		PaymentSummaryValidator paymentSummaryValidator = new PaymentSummaryValidator();
		paymentSummaryValidator.validate(paymentSummary, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 PaymentSummaryResponse paymentSummaryResponse = PaymentSummaryResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return paymentSummaryResponse;
	    }
		List<PaymentSummaryResult> list = transactionMapper.selectPaymentSummary(paymentSummary);
		
		int total = transactionMapper.selectPaymentSummaryTotal(paymentSummary);
	
		return PaymentSummaryResponse.success(ResponseCode.NORMAL, list, total);
	}
	
	@Override
	public Response retrieveAdjustmentSummary(AdjustmentSummaryRequest adjustmentSummaryRequest){
		Errors errors = new BeanPropertyBindingResult(new AdjustmentSummaryRequest(), "adjustmentSummaryRequest");
		AdjustmentResultValidator adjustmentResultValidatior = new AdjustmentResultValidator();
		adjustmentResultValidatior.validate(adjustmentSummaryRequest, errors);
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 GeneryResponse generyResponse = GeneryResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return generyResponse;
	    }
		List<AdjustmestResultModel> list = transactionMapper.selectAdjustmentSummary(adjustmentSummaryRequest);
		
		int total = transactionMapper.selectAdjustmentSummaryTotal(adjustmentSummaryRequest);
		return GeneryResponse.success(ResponseCode.NORMAL, list, total);
	}
	
	@Override
	public Response addCeTransaction(CeTransactionRequest CeTransaction){
		if(CeTransaction != null) {
			transactionMapper.insertCeTransaction(CeTransaction);
		}
		return GeneryResponse.success();
	}
	
	@Override
	public Response addBulkCeTransaction(List<CeTransactionRequest> ceTraList){
		
		Optional.ofNullable(ceTraList).ifPresent(list->list.stream().forEach(ce->this.addCeTransaction(ce)));;
		
		return GeneryResponse.success();
	}
	
	@Override
	public Response retrieveDepositPaymentTrace(PymntDpstTraceRequest pymntDpstTraceRequest) {
		
		List<DepositSummaryResult> list = transactionMapper.selectDepositPaymentTrace(pymntDpstTraceRequest);
		
		int total = transactionMapper.selectDepositPaymentTraceTotal(pymntDpstTraceRequest);
	
		return DepositSummaryResponse.success(ResponseCode.NORMAL, list, total);
		
	}
	
	@Override
	public Response retrieveTransactionDepositTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest) {

		List<Integer> summaryList = findAllSummaryseq(dpstTrsactionTraceRequest);
		if(summaryList.isEmpty()) {
			return DepositSummaryResponse.success(ResponseCode.NORMAL, new ArrayList(), 0);
		}
		HashSet<Integer> transSeqSet = new HashSet<>();
		transSeqSet.addAll(transactionMapper.selectSumTransTrace(summaryList));
		StringBuilder allTransSeq = new StringBuilder();
		for (int transSeq : transSeqSet) {
			allTransSeq.append(transSeq).append(CommonConstant.COMMA);
		}
		
		List<TransactionModel> list = null;
		if(allTransSeq.length()!= 0){
			allTransSeq.deleteCharAt(allTransSeq.lastIndexOf(CommonConstant.COMMA));
			dpstTrsactionTraceRequest.setTransactionSeq(allTransSeq);
			list = transactionMapper.selectAllSumTransTrace(dpstTrsactionTraceRequest);
		}

		return DepositSummaryResponse.success(ResponseCode.NORMAL, list, transSeqSet.size());
	}

	protected List<Integer> findAllSummaryseq(DpstTrsactionTraceRequest dpstTrsactionTraceRequest) {
		List<Integer> mseseqList = transactionMapper.selectDepositPMTrace(dpstTrsactionTraceRequest);
		List<Integer> summaryList = new ArrayList<>();
		List<Integer> pmselfmseseqList = new ArrayList<>();
		List<Integer> timespmeseqList = new ArrayList<>();
		if (!(mseseqList.isEmpty())) {
			pmselfmseseqList = transactionMapper.selectPMselfTrace(mseseqList);
			if (!(pmselfmseseqList.isEmpty())) {
				while (!(pmselfmseseqList.isEmpty())) {
					timespmeseqList = transactionMapper.selectPMselfTrace(pmselfmseseqList);
					if (!(timespmeseqList.isEmpty())) {
						pmselfmseseqList = timespmeseqList;
					}else {
						break;
					}
				}
				summaryList.addAll(transactionMapper.selectPMSummaryTrace(pmselfmseseqList));
			} else {
				summaryList.addAll(transactionMapper.selectPMSummaryTrace(mseseqList));
			}
		} else {
			summaryList = transactionMapper.selectDepositSummaryTrace(dpstTrsactionTraceRequest);
		}
		return summaryList;
	}

	@Override
	public Response retrieveTransactiondetailDepositTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest) {
		
		List<Integer> summaryList = findAllSummaryseq(dpstTrsactionTraceRequest);

		if(summaryList.isEmpty()) {
			return GetTransactionDetailResponse.success(ResponseCode.NORMAL, new ArrayList(), 0);
		}
		List<TransactionDetail> transactionList = transactionMapper.selectTransactiondetailDepositTrace(summaryList);
		this.assembleTransactionGA(transactionList);
		
		return GetTransactionDetailResponse.success(ResponseCode.NORMAL, transactionList, transactionList.size());
	}
}		
