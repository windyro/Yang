package com.aia.glory.model.compensation;

import java.util.List;

import com.aia.glory.model.compensation.GenericAttributeModel;

public class TransactionDetail{
	
	private String transactionSeq;
	
	private String eventType;

	private String compensationDate;
	
    private String commAgent;
	
	private String commAgency;
	
	private String wriAgent;
	
	private String wriAgency;
	
	private String channel;
	
	private String productID;
	
	private String productName;
	
	private String productDesc;
	
	private String productCat;
	
	private String value;
	
	private String policyNumber;
	
	private String dataSource;
	
	private String company;
	
	private List<GenericAttributeModel> genericFields;

	public String getTransactionSeq() {
		return transactionSeq;
	}

	public void setTransactionSeq(String transactionSeq) {
		this.transactionSeq = transactionSeq;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getCompensationDate() {
		return compensationDate;
	}

	public void setCompensationDate(String compensationDate) {
		this.compensationDate = compensationDate;
	}

	public String getCommAgent() {
		return commAgent;
	}

	public void setCommAgent(String commAgent) {
		this.commAgent = commAgent;
	}

	public String getCommAgency() {
		return commAgency;
	}

	public void setCommAgency(String commAgency) {
		this.commAgency = commAgency;
	}

	public String getWriAgent() {
		return wriAgent;
	}

	public void setWriAgent(String wriAgent) {
		this.wriAgent = wriAgent;
	}

	public String getWriAgency() {
		return wriAgency;
	}

	public void setWriAgency(String wriAgency) {
		this.wriAgency = wriAgency;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductCat() {
		return productCat;
	}

	public void setProductCat(String productCat) {
		this.productCat = productCat;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}
	
	public List<GenericAttributeModel> getGenericFields() {
		return genericFields;
	}

	public void setGenericFields(List<GenericAttributeModel> genericFields) {
		this.genericFields = genericFields;
	}

	@Override
	public String toString() {
		return "TransactionDetail [transactionSeq=" + transactionSeq
				+ ", eventType=" + eventType + ", compensationDate="
				+ compensationDate + ", commAgent=" + commAgent
				+ ", commAgency=" + commAgency + ", wriAgent=" + wriAgent
				+ ", wriAgency=" + wriAgency + ", channel=" + channel
				+ ", productID=" + productID + ", productName=" + productName
				+ ", productDesc=" + productDesc + ", productCat=" + productCat
				+ ", value=" + value + ", policyNumber=" + policyNumber
				+ ", dataSource=" + dataSource + ", company=" + company
				+ ", genericFields=" + genericFields + "]";
	}
}
