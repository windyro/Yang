package com.aia.glory.model.request;

import com.aia.glory.common.model.request.Request;

public class PipelineResultRequest extends Request
 {
	private Integer startPage = 0;

	private Integer pageSize = 0;

	private String period;

	private String stage;

	private String company;
	
	private String channel;

	private String status;

	private String startTime;

	private String endTime;
	
	private String jobSeq;

	public void setStartPage(Integer startPage) {
		if (startPage == null || startPage == 0) {
			startPage = 1;
		}
		this.startPage = startPage;
	}

	public void setPageSize(Integer pageSize) {
		if (pageSize == null || pageSize == 0) {
			pageSize = 10;
		}
		this.pageSize = pageSize;
	}

	public int getStartPage() {
		if(this.startPage == 0) {
			return 1;
		}
		return this.startPage;
		
	}

	public int getPageSize() {
		if(this.pageSize == 0) {
			return 10000;
		}
		return this.pageSize;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getJobSeq() {
		return jobSeq;
	}

	public void setJobSeq(String jobSeq) {
		this.jobSeq = jobSeq;
	}
	
	
}
