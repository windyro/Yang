package com.aia.glory.calculationresultservice.common;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.aia.glory.common.util.JwtUtil;
import com.auth0.jwt.interfaces.Claim;

@Aspect
@Configuration
public class AspectController {

	Log infoLog = LogFactory.getLog("sysInfo");
	
    @Pointcut("execution(* com.aia.glory.calculationresultservice.controller.*.*(..))")
    public void printMsg(){
    	// implementation ignored
    }

    @Around("printMsg()")
    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();

		String url = request.getRequestURL().toString();
		String method = request.getMethod();
		String uri = request.getRequestURI();
		
		String token = request.getHeader("token");
		String loginId = "";
		if(!(StringUtils.isEmpty(token))) {
			Map<String, Claim> claims = JwtUtil.getAESdecodeToken(token);
			if(!(claims.isEmpty())) {
				loginId = claims.get("loginId").asString();
				if(StringUtils.isEmpty(loginId)) {
					loginId = "token doesn't has loginId";
				}
			}else {
				loginId = "token doesn't has loginId";
			}
		}
		
		ArrayList<Object> argList = new ArrayList<>();
		for (Object arg : pjp.getArgs()) {
			if (!(arg instanceof HttpServletRequest) && !(arg instanceof HttpServletResponse) && !(arg instanceof HttpHeaders)) {
				argList.add(arg);
			}
		}
		infoLog.info("url: " + url + ", " + "method: " + method + ", " + "uri: " + uri + ", "  + "loginId: " + loginId);
		infoLog.info("params: " + argList);
		Object result = pjp.proceed();
		infoLog.info("response data: " + result);
		return result;
    }
}
