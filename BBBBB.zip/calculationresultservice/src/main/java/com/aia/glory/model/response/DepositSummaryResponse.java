package com.aia.glory.model.response;

import java.util.ArrayList;
import java.util.Arrays;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class DepositSummaryResponse extends Response
 {
	private Object transModel;
	
	private int total;

	public Object getTransModel() {
		return transModel;
	}

	public void setTransModel(Object transModel) {
		this.transModel = transModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public static DepositSummaryResponse success(ResponseCode responseCode,Object transModel,int total) 
	 {        
		DepositSummaryResponse getRuleGroupResponse = new DepositSummaryResponse();        
		 getRuleGroupResponse.setResponseCode(responseCode.getCode());
		 getRuleGroupResponse.setReasonCode(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getCode()));
		 getRuleGroupResponse.setReasonDesc(Arrays.asList(ReasonCode.GENERIC_SUCCESS.getDesc()));
		 getRuleGroupResponse.setTransModel(transModel);
		 getRuleGroupResponse.setTotal(total);
		 return getRuleGroupResponse;    
		 
	 }
	
	public static DepositSummaryResponse fail(ResponseCode responseCode,ArrayList reasonCode,ArrayList reasonDesc) {
		DepositSummaryResponse getRuleGroupResponse = new DepositSummaryResponse();
		getRuleGroupResponse.setResponseCode(responseCode.getCode());
		getRuleGroupResponse.setReasonCode(Arrays.asList(reasonCode));
		getRuleGroupResponse.setReasonDesc(Arrays.asList(reasonDesc));
		return getRuleGroupResponse;
	}

	@Override
	public String toString() {
		return "DepositSummaryResponse [transModel=" + transModel + ", total=" + total + "]" + super.toString();
	}
	
}
