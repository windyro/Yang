package com.aia.glory.model.compensation;

public class PipelineResultModel 
{
    private String period;
	
	private String stage;
	
	private String company;
	
	private String status;
	
	private String startTime;
	
	private String endTime;
	

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	@Override
	public String toString() {
		return "PipelineResultModel [period=" + period + ", stage=" + stage + ", company=" + company + ", status="
				+ status + ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
	
}
