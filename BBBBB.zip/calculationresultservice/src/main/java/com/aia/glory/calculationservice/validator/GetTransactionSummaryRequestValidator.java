package com.aia.glory.calculationservice.validator;

import java.util.regex.Pattern;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.aia.glory.calculationresultservice.enumerate.ReasonCode;
import com.aia.glory.model.request.GetTransactionSummaryRequest;

public class GetTransactionSummaryRequestValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		return GetTransactionSummaryRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		GetTransactionSummaryRequest request = (GetTransactionSummaryRequest) target;
		if(!StringUtils.isEmpty(request.getCompensationDate()) && !Pattern.matches("^(\\d{4}-\\d{2}-\\d{2})|\\s*$",request.getCompensationDate())){
			
			errors.rejectValue("compensationDate", ReasonCode.DATA_FORMAT_EXCEPTION.getCode(), ReasonCode.DATA_FORMAT_EXCEPTION.getDesc());
			
		}
		if(!StringUtils.isEmpty(request.getCommAgent()) && !Pattern.matches("^[\\sA-Za-z0-9\\s]*$",request.getCommAgent())){
			
			errors.rejectValue("commAgent", ReasonCode.COMMAGENT_EXCEPTION.getCode(), ReasonCode.COMMAGENT_EXCEPTION.getDesc());
			
		}
		if(!StringUtils.isEmpty(request.getCommAgency()) && !Pattern.matches("^[\\sA-Za-z0-9\\s]*$",request.getCommAgency())){
			
			errors.rejectValue("commAgency", ReasonCode.COMMAGENCY_EXCEPTION.getCode(), ReasonCode.COMMAGENCY_EXCEPTION.getDesc());
			
		}
		if(!StringUtils.isEmpty(request.getPolicyNumber()) && !Pattern.matches("^[\\sA-Za-z0-9\\s]*$",request.getPolicyNumber())){
			
			errors.rejectValue("policyNumber", ReasonCode.POLICYNUMBER_EXCEPTION.getCode(), ReasonCode.POLICYNUMBER_EXCEPTION.getDesc());
			
		}
		if(!StringUtils.isEmpty(request.getCompStartDate()) && !Pattern.matches("^(\\d{4}-\\d{2}-\\d{2})|\\s*$",request.getCompStartDate())){
			
			errors.rejectValue("compStartDate", ReasonCode.DATA_FORMAT_EXCEPTION.getCode(), ReasonCode.DATA_FORMAT_EXCEPTION.getDesc());
			
		}
		if(!StringUtils.isEmpty(request.getCompEndDate()) && !Pattern.matches("^(\\d{4}-\\d{2}-\\d{2})|\\s*$",request.getCompEndDate())){
			
			errors.rejectValue("compEndDate", ReasonCode.DATA_FORMAT_EXCEPTION.getCode(), ReasonCode.DATA_FORMAT_EXCEPTION.getDesc());
			
		}
	}

}
