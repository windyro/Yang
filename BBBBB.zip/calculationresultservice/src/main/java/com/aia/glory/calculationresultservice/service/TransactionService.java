package com.aia.glory.calculationresultservice.service;

import java.util.List;

import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.AdjustmentSummaryRequest;
import com.aia.glory.model.request.CeTransactionRequest;
import com.aia.glory.model.request.DepositSummary;
import com.aia.glory.model.request.DpstTrsactionTraceRequest;
import com.aia.glory.model.request.GetTransactionSummaryRequest;
import com.aia.glory.model.request.PaymentSummary;
import com.aia.glory.model.request.PymntDpstTraceRequest;
import com.aia.glory.model.response.GetTransactionDetailResponse;
import com.aia.glory.model.response.GetTransactionSummaryResponse;
import com.aia.glory.model.request.MeasurementSummary;


public interface TransactionService {
	
	public GetTransactionSummaryResponse retrieveTransactionSummary(GetTransactionSummaryRequest transactionSummaryRequest);
	
	public GetTransactionDetailResponse retrieveTransactionDetail(GetTransactionSummaryRequest transactionSummaryRequest);
	
	public Response retrieveDepositDetail(DepositSummary depositSummary);
	
	public Response retrievePaymentDetail(PaymentSummary paymentSummary);
		
	public Response retrieveAdjustmentSummary(AdjustmentSummaryRequest adjustmentSummaryRequest);
	
	public Response addCeTransaction(CeTransactionRequest CeTransaction);
	
	public Response addBulkCeTransaction(List<CeTransactionRequest> CeTraList);
	
	public Response retrieveDepositPaymentTrace(PymntDpstTraceRequest pymntDpstTraceRequest);

	public Response retrieveTransactionDepositTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest);

	public Response retrieveTransactiondetailDepositTrace(DpstTrsactionTraceRequest dpstTrsactionTraceRequest);
	
	public Response retrieveMeasurementDetail(MeasurementSummary measurementSummary);
	
}		
