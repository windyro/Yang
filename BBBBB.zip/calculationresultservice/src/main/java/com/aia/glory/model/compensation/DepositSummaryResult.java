package com.aia.glory.model.compensation;

public class DepositSummaryResult {

	private Integer depositSeq;
	
	private String compensationName;
	
	private String payee;
	
	private String period;
	
	private String ruleName;
	
	private String value;
	
	private String channel;
	
	private String company;
	
	private String depositDate;
	
	private String releaseDate;
	
	private String isHeld;
	
	private String managerAgency;
	
	private String title;
	
	public Integer getDepositSeq() {
		return depositSeq;
	}

	public void setDepositSeq(Integer depositSeq) {
		this.depositSeq = depositSeq;
	}

	public String getCompensationName() {
		return compensationName;
	}

	public void setCompensationName(String compensationName) {
		this.compensationName = compensationName;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getDepositDate() {
		return depositDate;
	}

	public void setDepositDate(String depositDate) {
		this.depositDate = depositDate;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getIsHeld() {
		return isHeld;
	}

	public void setIsHeld(String isHeld) {
		this.isHeld = isHeld;
	}

	public String getManagerAgency() {
		return managerAgency;
	}

	public void setManagerAgency(String managerAgency) {
		this.managerAgency = managerAgency;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "DepositSummaryResult [depositSeq=" + depositSeq + ", compensationName=" + compensationName + ", payee="
				+ payee + ", period=" + period + ", ruleName=" + ruleName + ", value=" + value + ", channel=" + channel
				+ ", company=" + company + ", depositDate=" + depositDate + ", releaseDate=" + releaseDate + ", isHeld="
				+ isHeld + ", managerAgency=" + managerAgency + ", title=" + title + "]";
	}
	
}
