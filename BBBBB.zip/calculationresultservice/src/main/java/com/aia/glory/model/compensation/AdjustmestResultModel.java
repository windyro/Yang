package com.aia.glory.model.compensation;

public class AdjustmestResultModel{
	
	private String transactionSeq;

	private String compensationDate;

	private String eventType;
	
	private String value;
	
	private String commAgent;
	
	private String commAgency;
	
	private String policyNumber;
	
	private String ProductCat;

	public String getTransactionSeq() {
		return transactionSeq==null ? "": transactionSeq.trim();
	}

	public void setTransactionSeq(String transactionSeq) {
		this.transactionSeq = transactionSeq.trim();
	}

	public String getCompensationDate() {
		return compensationDate==null ? "": compensationDate.trim();
	}

	public void setCompensationDate(String compensationDate) {
		this.compensationDate = compensationDate.trim();
	}

	public String getEventType() {
		return eventType==null ? "" : eventType.trim();
	}

	public void setEventType(String eventType) {
		this.eventType = eventType.trim();
	}

	public String getValue() {
		return value==null ? "": value.trim();
	}

	public void setValue(String value) {
		this.value = value.trim();
	}

	public String getCommAgent() {
		return commAgent == null ? "" : commAgent.trim();
	}

	public void setCommAgent(String commAgent) {
		this.commAgent = commAgent.trim();
	}

	public String getCommAgency() {
		return commAgency == null ? "" : commAgency.trim();
	}

	public void setCommAgency(String commAgency) {
		this.commAgency = commAgency.trim();
	}

	public String getPolicyNumber() {
		return policyNumber == null ? "" : policyNumber.trim();
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber.trim();
	}

	public String getProductCat() {
		return ProductCat == null ? "" : ProductCat.trim();
	}

	public void setProductCat(String productCat) {
		ProductCat = productCat.trim();
	}

	@Override
	public String toString() {
		return "AdjustmestResultModel [transactionSeq=" + transactionSeq
				+ ", compensationDate=" + compensationDate + ", eventType="
				+ eventType + ", value=" + value + ", commAgent=" + commAgent
				+ ", commAgency=" + commAgency + ", policyNumber="
				+ policyNumber + ", ProductCat=" + ProductCat + "]";
	}

	
}
