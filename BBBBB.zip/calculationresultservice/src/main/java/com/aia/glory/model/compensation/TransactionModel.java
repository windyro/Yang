package com.aia.glory.model.compensation;

public class TransactionModel{
	
	private String transactionSeq;

	private String compensationDate;

	private String eventType;
	
	private String value;
	
	private String commAgent;
	
	private String commAgency;
	
	private String policyNumber;
	
	private String ProductCat;
	
	private String company;
	
	private String business;

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}


	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getTransactionSeq() {
		return transactionSeq;
	}

	public void setTransactionSeq(String transactionSeq) {
		this.transactionSeq = transactionSeq;
	}

	public String getCompensationDate() {
		return compensationDate;
	}

	public void setCompensationDate(String compensationDate) {
		this.compensationDate = compensationDate;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCommAgent() {
		return commAgent;
	}

	public void setCommAgent(String commAgent) {
		this.commAgent = commAgent;
	}

	public String getCommAgency() {
		return commAgency;
	}

	public void setCommAgency(String commAgency) {
		this.commAgency = commAgency;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getProductCat() {
		return ProductCat;
	}

	public void setProductCat(String productCat) {
		ProductCat = productCat;
	}

	@Override
	public String toString() {
		return "TransactionModel [transactionSeq=" + transactionSeq
				+ ", compensationDate=" + compensationDate + ", eventType="
				+ eventType + ", value=" + value + ", commAgent=" + commAgent
				+ ", commAgency=" + commAgency + ", policyNumber="
				+ policyNumber + ", ProductCat=" + ProductCat + "]";
	}

	
}
