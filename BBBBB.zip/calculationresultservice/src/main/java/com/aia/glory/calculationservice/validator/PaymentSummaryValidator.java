package com.aia.glory.calculationservice.validator;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.aia.glory.calculationresultservice.enumerate.ReasonCode;
import com.aia.glory.model.request.PaymentSummary;

public class PaymentSummaryValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		return PaymentSummary.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		PaymentSummary request = (PaymentSummary) target;
		
		if(!StringUtils.isEmpty(request.getStartPage())
				&& (request.getStartPage() > Integer.MAX_VALUE || request.getStartPage() < 0)){
		
				errors.rejectValue("startPage", ReasonCode.PUT_EXCEPTION.getCode(), ReasonCode.PUT_EXCEPTION.getDesc());
				
		}
		
		if(!StringUtils.isEmpty(request.getPageSize())
				&& (request.getPageSize() > Integer.MAX_VALUE || request.getPageSize() < 0)){
			
				errors.rejectValue("pageSize", ReasonCode.PUT_EXCEPTION.getCode(), ReasonCode.PUT_EXCEPTION.getDesc());
				
		}
	}

}
