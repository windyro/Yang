package com.aia.glory.calculationresultservice.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import com.aia.glory.calculationresultservice.dao.PipelineResultMapper;
import com.aia.glory.calculationservice.validator.PipelineResultValidator;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.util.ErrorMessageUtils;
import com.aia.glory.model.compensation.PipelineResultModel;
import com.aia.glory.model.request.PipelineResultRequest;
import com.aia.glory.model.response.PipelineResultResponse;

@Service(value = "pipelineResultService")
public class PipelineResultService 
{
	@Autowired
    PipelineResultMapper pipelineResultMapper;
	
    public PipelineResultResponse retrievePipelineResult(PipelineResultRequest pipelineResult){
		
    	Errors errors = new BeanPropertyBindingResult(new PipelineResultRequest(), "pipelineResultRequest");
    	PipelineResultValidator pipelineResultValidator = new PipelineResultValidator();
    	pipelineResultValidator.validate(pipelineResult, errors);
	
		if (errors.hasErrors()){
			 ArrayList list = new ErrorMessageUtils().errorMessage(errors);
			 PipelineResultResponse pipelineResultResponse = PipelineResultResponse.fail(ResponseCode.ERROR, (ArrayList)list.get(0), (ArrayList)list.get(1));
			 return pipelineResultResponse;
		}
		
		List<PipelineResultModel> list = pipelineResultMapper.selectPipelineResult(pipelineResult);
		
		int total = pipelineResultMapper.selectPipelineResultTotal(pipelineResult);
		
		return PipelineResultResponse.success(ResponseCode.NORMAL, list, total);
	}
}
