package com.aia.glory.calculationservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.AdjustmentSummaryRequest;
import com.aia.glory.model.request.CeTransactionRequest;


@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public class AdjustmentResultControllerTest {

	@Autowired
	protected MockMvc mockMvc;

	@Test
	public void testGetAdjustmentResult() throws Exception {
		AdjustmentSummaryRequest adjustmentSummaryRequest = new AdjustmentSummaryRequest();
		adjustmentSummaryRequest.setAction("POST");
		adjustmentSummaryRequest.setTransactionSeq("1");
		adjustmentSummaryRequest.setCompensationDate("2019");
		adjustmentSummaryRequest.setCommAgent("---");
		adjustmentSummaryRequest.setCommAgency("---");
		adjustmentSummaryRequest.setPolicyNumber("---");
		adjustmentSummaryRequest.setEventType("FYC");
		adjustmentSummaryRequest.setCompStartDate("23");
		adjustmentSummaryRequest.setCompEndDate("56");
		mockMvc.perform(MockMvcRequestBuilders.post("/adjustmentresult")
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(JsonToObjectUtil.objToJson(adjustmentSummaryRequest)))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andDo(MockMvcResultHandlers.print())
		.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
		.andReturn();
	}

	@Test
	@Transactional
	public void doAdjustmentBatchTest() throws Exception {
		List<CeTransactionRequest> arList = new ArrayList<CeTransactionRequest>();
		CeTransactionRequest ceTransactionRequest = new CeTransactionRequest();
		ceTransactionRequest.setAction("POST");
		ceTransactionRequest.setAgentBalance("test");
		ceTransactionRequest.setAgentCode("A00008");
		ceTransactionRequest.setBusinessunitmap("1");
		ceTransactionRequest.setCommAgency("A00008");
		ceTransactionRequest.setCompensationDate("2020-01-06");
		ceTransactionRequest.setDescription("test");
		ceTransactionRequest.setEventType("MA");
		ceTransactionRequest.setExpenseAccount("222");
		ceTransactionRequest.setGstCode("test");
		ceTransactionRequest.setMantxn("test");
		ceTransactionRequest.setPolicyNumber("E0000293843");
		ceTransactionRequest.setProductdesc("test");
		ceTransactionRequest.setSubmittedBy("test");
		ceTransactionRequest.setValue("333.45");
		
		arList.add(ceTransactionRequest);
		
		mockMvc.perform(MockMvcRequestBuilders.post("/adjustmentBatch")
						.contentType(MediaType.APPLICATION_JSON_UTF8)
						.content(JsonToObjectUtil.objToJson(arList)))
		
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
				.andReturn();
	}

}
