package com.aia.glory.calculationservice.controller;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import com.aia.glory.ApplicationTest;
import com.aia.glory.calculationresultservice.controller.TransactionController;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.DepositSummary;
import com.aia.glory.model.request.DpstTrsactionTraceRequest;
import com.aia.glory.model.request.GetTransactionSummaryRequest;
import com.aia.glory.model.request.PaymentSummary;
import com.aia.glory.model.request.PymntDpstTraceRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ) 
@AutoConfigureMockMvc
public class TransactionControllerTest 
{
	@Autowired
	TransactionController transactionController;
	   
	@Autowired
	protected MockMvc mockMvc;
    
	@Autowired
	public DataSource dataSource;
	
	@Test
	public void testTransactionSummary_getSuccessfully_ReturnSuccessResponse() throws Exception{
	   // String input= "{\"action\":\"POST\",\"commAgent\":\"A00008\",\"commAgency\":\"UNIT001\",\"policyNumber\":\"H001004201\",\"eventType\":\"FYC\",\"startPage\":1,\"pageSize\":5}";
	    GetTransactionSummaryRequest transactionSummaryRequest = new GetTransactionSummaryRequest();
	    transactionSummaryRequest.setAction("POST");
	    transactionSummaryRequest.setCommAgent("A00008");
	    transactionSummaryRequest.setCommAgency("UNIT001");
	    transactionSummaryRequest.setPolicyNumber("H001004201");
	    transactionSummaryRequest.setEventType("FYC");
	    transactionSummaryRequest.setStartPage(1);
	    transactionSummaryRequest.setPageSize(5);
	   /* Response result = transactionController.retrieveTransactionSummaryList(transactionSummaryRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionSummry")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(transactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testTransactionSummaryEmptyValue_getSuccessfully_ReturnSuccessResponse() throws Exception{
//	    String input= "{\"action\":\"POST\",\"commAgent\":\"\",\"commAgency\":\"\",\"policyNumber\":\"\",\"eventType\":\"\"}";
	    GetTransactionSummaryRequest transactionSummaryRequest = new GetTransactionSummaryRequest();
	    transactionSummaryRequest.setAction("POST");
	    transactionSummaryRequest.setCommAgent("");
	    transactionSummaryRequest.setCommAgency("");
	    transactionSummaryRequest.setPolicyNumber("");
	    transactionSummaryRequest.setEventType("");
	   // transactionSummaryRequest.setStartPage(1);
	    //transactionSummaryRequest.setPageSize(5);
		/*Response result = transactionController.retrieveTransactionSummaryList(transactionSummaryRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionSummry")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(transactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testTransactionSummaryNULL_getSuccessfully_ReturnSuccessResponse() throws Exception{
		//MockHttpServletRequest request = new MockHttpServletRequest("GET","/transactionSummry");
	    //String input= "{\"action\":\"POST\"}";
	    GetTransactionSummaryRequest transactionSummaryRequest = new GetTransactionSummaryRequest();
	    transactionSummaryRequest.setAction("POST");
	    //transactionSummaryRequest.setCommAgent("A00008");
	    //transactionSummaryRequest.setCommAgency("UNIT001");
	   // transactionSummaryRequest.setPolicyNumber("H001004201");
	   // transactionSummaryRequest.setEventType("FYC");
	   // transactionSummaryRequest.setStartPage(1);
	    //transactionSummaryRequest.setPageSize(5);
	    /*Response result = transactionController.retrieveTransactionSummaryList(transactionSummaryRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionSummry")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(transactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testTransactionDetail_getSuccessfully_ReturnSuccessResponse() throws Exception{
		//MockHttpServletRequest request = new MockHttpServletRequest("GET","/transactionSummry");
	    //String input= "{\"action\":\"POST\",\"commAgent\":\"A00008\",\"commAgency\":\"UNIT001\",\"policyNumber\":\"H001004201\",\"eventType\":\"FYC\"}";
	    GetTransactionSummaryRequest transactionSummaryRequest = new GetTransactionSummaryRequest();
	    transactionSummaryRequest.setAction("POST");
	    transactionSummaryRequest.setCommAgent("A00008");
	    transactionSummaryRequest.setCommAgency("UNIT001");
	    transactionSummaryRequest.setPolicyNumber("H001004201");
	    transactionSummaryRequest.setEventType("FYC");
		/*Response result = transactionController.transactionDetail(transactionSummaryRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDetail")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(transactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testTransactionDetailEmptyValue_getSuccessfully_ReturnSuccessResponse() throws Exception{
		//MockHttpServletRequest request = new MockHttpServletRequest("GET","/transactionSummry");
	    //String input= "{\"action\":\"POST\",\"commAgent\":\"\",\"commAgency\":\"\",\"policyNumber\":\"\",\"eventType\":\"\"}";
	    GetTransactionSummaryRequest transactionSummaryRequest = new GetTransactionSummaryRequest();
	    transactionSummaryRequest.setAction("POST");
	    transactionSummaryRequest.setCommAgent("");
	    transactionSummaryRequest.setCommAgency("");
	    transactionSummaryRequest.setPolicyNumber("CT000000");
	    transactionSummaryRequest.setEventType("");
		/*Response result = transactionController.transactionDetail(transactionSummaryRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDetail")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(transactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testTransactionDetail_TransactionSeq_getSuccessfully_ReturnSuccessResponse() throws Exception{
		// MockHttpServletRequest request = new MockHttpServletRequest("GET","/transactionSummry");
	    // String input= "{\"action\":\"POST\",\"transactionSeq\": \"4251\"}";
	    GetTransactionSummaryRequest transactionSummaryRequest = new GetTransactionSummaryRequest();
	    transactionSummaryRequest.setAction("POST");
	    transactionSummaryRequest.setTransactionSeq("4251");
	   /* Response result = transactionController.transactionDetail(transactionSummaryRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDetail")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(transactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testDepositSummary_getSuccessfully_ReturnSuccessResponse() throws Exception{
		DepositSummary depositSummary = new DepositSummary();
		depositSummary.setAction("POST");
		//depositSummary.setCompensationName("FYC_DEMO");
		depositSummary.setPageSize(100);
		depositSummary.setStartPage(1);
		depositSummary.setStartPeriod("2020-01");
		depositSummary.setEndPeriod("2020-06");
		//depositSummary.setPeriod("2020-01");
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/depositSummary")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(depositSummary))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testPaymentSummary_getSuccessfully_ReturnSuccessResponse() throws Exception{
		PaymentSummary paymentSummary = new PaymentSummary();
		paymentSummary.setAction("POST");
		paymentSummary.setPageSize(10);
		paymentSummary.setStartPage(1);
		paymentSummary.setStartPeriod("2019-1");
		paymentSummary.setEndPeriod("2019-11");
		//MockHttpServletRequest request = new MockHttpServletRequest("POST","/depositSummary");
	    //Response result = transactionController.getPaymentSummary(paymentSummary);
	    
	    MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/paymentSummary")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(paymentSummary))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	    
		//Assert.assertEquals("000", result.getResponseCode());
	}
	@Test
	public void testGetPaymentSummary() throws Exception{
		PaymentSummary paymentSummary = new PaymentSummary();
		paymentSummary.setAction("POST");
		paymentSummary.setPageSize(-2);
		paymentSummary.setStartPage(-3);
		paymentSummary.setPayee("A00032");
	    /*Response result = transactionController.getPaymentSummary(paymentSummary);
		Assert.assertEquals("008", result.getResponseCode());*/
		 MvcResult mrcresult = mockMvc.perform(
	    			MockMvcRequestBuilders.post("/paymentSummary")
	    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
	    			.content(JsonToObjectUtil.objToJson(paymentSummary))
					)
	    			.andExpect(MockMvcResultMatchers.status().isOk())
	    			.andDo(MockMvcResultHandlers.print())
	    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
	    			.andReturn();
	}
	@Test
	public void testGetDepositSummary() throws Exception{
		DepositSummary depositSummary = new DepositSummary();
		depositSummary.setAction("POST");
		depositSummary.setPageSize(-2);
		depositSummary.setStartPage(-3);
		depositSummary.setPayee("A00032");
	    /*Response result = transactionController.getDepositSummary(depositSummary);
		Assert.assertEquals("008", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/depositSummary")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(depositSummary))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
    			.andReturn();
	}
	
	@Test
	public void testRetrieveTransactionSummaryList() throws Exception{
		GetTransactionSummaryRequest getTransactionSummaryRequest = new GetTransactionSummaryRequest();
		getTransactionSummaryRequest.setAction("POST");
		getTransactionSummaryRequest.setAction("POST");
		getTransactionSummaryRequest.setTransactionSeq("1");
		getTransactionSummaryRequest.setCompensationDate("2019");
		getTransactionSummaryRequest.setCommAgent("---");
		getTransactionSummaryRequest.setCommAgency("---");
		getTransactionSummaryRequest.setPolicyNumber("---");
		getTransactionSummaryRequest.setEventType("FYC");
		getTransactionSummaryRequest.setCompStartDate("23");
		getTransactionSummaryRequest.setCompEndDate("56");
	    /*Response result = transactionController.retrieveTransactionSummaryList(getTransactionSummaryRequest);
		Assert.assertEquals("008", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionSummry")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(getTransactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
    			.andReturn();
	}
	
	@Test
	public void testTransactionDetail() throws Exception{
		GetTransactionSummaryRequest getTransactionSummaryRequest = new GetTransactionSummaryRequest();
		getTransactionSummaryRequest.setAction("POST");
		getTransactionSummaryRequest.setAction("POST");
		getTransactionSummaryRequest.setTransactionSeq("1");
		getTransactionSummaryRequest.setCompensationDate("2019");
		getTransactionSummaryRequest.setCommAgent("---");
		getTransactionSummaryRequest.setCommAgency("---");
		getTransactionSummaryRequest.setPolicyNumber("---");
		getTransactionSummaryRequest.setEventType("FYC");
		getTransactionSummaryRequest.setCompStartDate("23");
		getTransactionSummaryRequest.setCompEndDate("56");
	    /*Response result = transactionController.transactionDetail(getTransactionSummaryRequest);
		Assert.assertEquals("008", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDetail")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(getTransactionSummaryRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
    			.andReturn();
	}
	
	
	@Test
	@Transactional
	@Rollback(value = true)
	public void testDepositPaymentTrace() throws Exception{
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update("insert into CE_PAYMENT values(100000000,10,10,179,100000000.00,getdate(),1,1,'POSTED')\r\n" + 
	    		"insert into CE_APPLDEPOSITPAYMENTTRACE values(100000000,100000000,10,10,100000000.00,1,1,179)\r\n" + 
	    		"insert into CE_DEPOSITAPPLDEPOSITTRACE values(100000000,100000000,10,10,100000000.00,1,1,179)\r\n" + 
	    		"insert into [CE_DEPOSIT](DEPOSITSEQ,NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE,ISHELD) " + 
	    		"values(100000000,'LTI',10,10,179,30766,100000000.00,1,1,getdate(),0)\r\n"); 

		PymntDpstTraceRequest pymntDpstTraceRequest = new PymntDpstTraceRequest();
 		pymntDpstTraceRequest.setPaymentSeq(100000000);
 		pymntDpstTraceRequest.setAction("POST");
 		
        MvcResult mrcresult = mockMvc.perform(
        		MockMvcRequestBuilders.post("/depositPaymentTrace")
        		.contentType(MediaType.APPLICATION_JSON_UTF8)      
        		.content(JsonToObjectUtil.objToJson(pymntDpstTraceRequest))
        		)
        		.andExpect(MockMvcResultMatchers.status().isOk())
        		.andDo(MockMvcResultHandlers.print())
        		.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
        		.andReturn();
	}
	@Test
	@Transactional
	@Rollback(value = true)
	public void testTransactionDepositTrace_1() throws Exception{
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update("insert into CE_DEPOSITSUMTRACE values(100000000,100000000,'TEST_MEA2',NULL,10,100000000.00,1,1,179)\r\n" + 
	    		"insert into CE_SUMTRANSTRACE values(100000000,100000000,1,1,179)\r\n" +
	    		"insert into CE_TRANSACTION(TRANSACTIONSEQ,EVENTTYPESEQ,COMPENSATIONDATE,COMM_AGENT,COMM_AGENCY,WRI_AGENT,WRI_AGENCY,BUSINESSUNITMAP,PRODUCTID,PRODUCTNAME,PRODUCTDESCRIPTION,PRODUCTCATEGORY,VALUE,PROCESSINGUNITSEQ,MODIFICATIONDATE) " + 
	    		"values(100000000,1,getdate(),'A00007','CH0001','A00007','CH0001',1,'MER1','A-Life Med Regular','LIFE','LF',100000000.00,1,getdate())");
		
		DpstTrsactionTraceRequest dpstTrsactionTraceRequest = new DpstTrsactionTraceRequest();
		dpstTrsactionTraceRequest.setDepositSeq(100000000);
		dpstTrsactionTraceRequest.setAction("POST");
		dpstTrsactionTraceRequest.setPageSize(10);
		dpstTrsactionTraceRequest.setStartPage(1);
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDepositTrace")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(dpstTrsactionTraceRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	@Test
	@Transactional
	@Rollback(value = true)
	public void testTransactionDepositTrace_2() throws Exception{
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update("insert into CE_DEPOSITPMTRACE values(100000000,100000000,'QSB',NULL,10,100000000.00,1,1,179)\r\n" + 
	    		"insert into CE_PMSUMTRACE values(100000000,100000000,'TEST_MEA2',NULL,1,100000000.00,1,1,179)\r\n" + 
	    		"insert into CE_SUMTRANSTRACE values(100000000,100000000,1,1,179)\r\n" + 
	    		"insert into CE_TRANSACTION(TRANSACTIONSEQ,EVENTTYPESEQ,COMPENSATIONDATE,COMM_AGENT,COMM_AGENCY,WRI_AGENT,WRI_AGENCY,BUSINESSUNITMAP,PRODUCTID,PRODUCTNAME,PRODUCTDESCRIPTION,PRODUCTCATEGORY,VALUE,PROCESSINGUNITSEQ,MODIFICATIONDATE)\r\n" + 
	    		"values(100000000,1,getdate(),'A00007','CH0001','A00007','CH0001',1,'MER1','A-Life Med Regular','LIFE','LF',100000000.00,1,getdate())");
		
		DpstTrsactionTraceRequest dpstTrsactionTraceRequest = new DpstTrsactionTraceRequest();
		dpstTrsactionTraceRequest.setDepositSeq(100000000);
		dpstTrsactionTraceRequest.setAction("POST");
		dpstTrsactionTraceRequest.setPageSize(10);
		dpstTrsactionTraceRequest.setStartPage(1);
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDepositTrace")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(dpstTrsactionTraceRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	@Test
	@Transactional
	@Rollback(value = true)
	public void testTransactionDepositTrace_3() throws Exception{
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update("insert into CE_DEPOSITPMTRACE values(100000000,100000000,'QSB',NULL,10,100000000.00,1,1,179)\r\n" + 
				"insert into CE_PMSELFTRACE values(100000001,10000000,'TEST_MEA2',NULL,10,100000000.00,1,1,179)\r\n" +
	    		"insert into CE_PMSUMTRACE values(100000000,100000000,'TEST_MEA2',NULL,1,100000000.00,1,1,179)\r\n" + 
	    		"insert into CE_SUMTRANSTRACE values(100000000,100000000,1,1,179)\r\n" + 
	    		"insert into CE_TRANSACTION(TRANSACTIONSEQ,EVENTTYPESEQ,COMPENSATIONDATE,COMM_AGENT,COMM_AGENCY,WRI_AGENT,WRI_AGENCY,BUSINESSUNITMAP,PRODUCTID,PRODUCTNAME,PRODUCTDESCRIPTION,PRODUCTCATEGORY,VALUE,PROCESSINGUNITSEQ,MODIFICATIONDATE)\r\n" + 
	    		"values(100000000,1,getdate(),'A00007','CH0001','A00007','CH0001',1,'MER1','A-Life Med Regular','LIFE','LF',100000000.00,1,getdate())");
		
		DpstTrsactionTraceRequest dpstTrsactionTraceRequest = new DpstTrsactionTraceRequest();
		dpstTrsactionTraceRequest.setDepositSeq(100000000);
		dpstTrsactionTraceRequest.setAction("POST");
		dpstTrsactionTraceRequest.setPageSize(10);
		dpstTrsactionTraceRequest.setStartPage(1);
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactionDepositTrace")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(dpstTrsactionTraceRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	@Test
	@Transactional
	@Rollback(value = true)
	public void testTransactiondetailDepositTrace() throws Exception{
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update("insert into CE_DEPOSITSUMTRACE values(100000000,100000000,'TEST_MEA2',NULL,10,100000000.00,1,1,179)\r\n" + 
	    		"insert into CE_SUMTRANSTRACE values(100000000,100000000,1,1,179)\r\n" + 
	    		"insert into CE_TRANSACTION(TRANSACTIONSEQ,EVENTTYPESEQ,COMPENSATIONDATE,COMM_AGENT,COMM_AGENCY,WRI_AGENT,WRI_AGENCY,BUSINESSUNITMAP,PRODUCTID,PRODUCTNAME,PRODUCTDESCRIPTION,PRODUCTCATEGORY,VALUE,PROCESSINGUNITSEQ,MODIFICATIONDATE)\r\n" + 
	    		"values(100000000,1,getdate(),'A00007','CH0001','A00007','CH0001',1,'MER1','A-Life Med Regular','LIFE','LF',100000000.00,1,getdate())");
		
		DpstTrsactionTraceRequest dpstTrsactionTraceRequest = new DpstTrsactionTraceRequest();
		dpstTrsactionTraceRequest.setDepositSeq(100000000);
		dpstTrsactionTraceRequest.setAction("POST");
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/transactiondetailDepositTrace")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(dpstTrsactionTraceRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
}
