package com.aia.glory;

import javax.naming.InvalidNameException;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.aia.glory.model.request.AdjustmentSummaryRequest;

@SpringBootApplication
public class ApplicationTest{

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ApplicationTest.class,args);
    }
	

	@Test
    public void findone() throws InvalidNameException {
		AdjustmentSummaryRequest user = new AdjustmentSummaryRequest();
    	user.setAction("POST");
    	 Assert.assertEquals("POST", user.getAction());
    	 
    }
}