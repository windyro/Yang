package com.aia.glory.calculationservice.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.ApplicationTest;
import com.aia.glory.calculationresultservice.service.TransactionService;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.model.request.AdjustmentSummaryRequest;
import com.aia.glory.model.request.DepositSummary;
import com.aia.glory.model.request.PaymentSummary;
import com.aia.glory.model.response.DepositSummaryResponse;
import com.aia.glory.model.response.PaymentSummaryResponse;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class},webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
public class TransactionServiceTest {
	   
	   @Autowired
	   TransactionService transactionServiceImpl;
	   
	   @Test
	   public void insertRuleGroupTest()
	   {
		   DepositSummary depositSummary = new DepositSummary();
		   depositSummary.setAction("POST");
		   depositSummary.setCompensationName("FYC_DEMO");
		   depositSummary.setPageSize(10);
		   depositSummary.setStartPage(1);
		   depositSummary.setPayee("A00032");
		   //depositSummary.setPeriod("2020-01");
		   DepositSummaryResponse rs = (DepositSummaryResponse)transactionServiceImpl.retrieveDepositDetail(depositSummary);
		   System.out.println(rs);
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   public void queryPaymentTest()
	   {
		   PaymentSummary paymentSummary = new PaymentSummary();
		   paymentSummary.setAction("POST");
		   paymentSummary.setPageSize(10);
		   paymentSummary.setStartPage(1);
		   paymentSummary.setPayee("A00032");
		   //depositSummary.setPeriod("2020-01");
		   PaymentSummaryResponse rs = (PaymentSummaryResponse)transactionServiceImpl.retrievePaymentDetail(paymentSummary);
		   System.out.println(rs.toString());
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	   
	   @Test
	   public void queryAdjustmentTest()
	   {
		   AdjustmentSummaryRequest adjustmentSummaryRequest = new AdjustmentSummaryRequest();
		   adjustmentSummaryRequest.setAction("POST");
		   adjustmentSummaryRequest.setPageSize(10);
		   adjustmentSummaryRequest.setStartPage(1);
		   //adjustmentSummaryRequest.setPayee("A00032");
		   //depositSummary.setPeriod("2020-01");
		   Response rs = transactionServiceImpl.retrieveAdjustmentSummary(adjustmentSummaryRequest);
		   
		   Assert.assertEquals("t", "000", rs.getResponseCode());
	   }
	
}