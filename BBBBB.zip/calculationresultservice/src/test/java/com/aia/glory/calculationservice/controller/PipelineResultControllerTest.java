package com.aia.glory.calculationservice.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.aia.glory.ApplicationTest;
import com.aia.glory.calculationresultservice.controller.PipelineResultController;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.model.request.PipelineResultRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ApplicationTest.class} ,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
@AutoConfigureMockMvc
public class PipelineResultControllerTest 
{
	@Autowired
	PipelineResultController pipelineResultController;
	
	@Autowired
	protected MockMvc mockMvc;
	
	@Test
	public void testPipelineResult_getSuccessfully_ReturnSuccessResponse() throws Exception{
		PipelineResultRequest pipelineResultRequest = new PipelineResultRequest();
		pipelineResultRequest.setAction("GET");
		pipelineResultRequest.setPeriod("October 2019");
//		pipelineResultRequest.setStage("");
		pipelineResultRequest.setCompany("MM_BU");
		pipelineResultRequest.setStatus("Successful");
		pipelineResultRequest.setStartTime("2019-11-25 15:32:28");
		pipelineResultRequest.setEndTime("2019-11-25 15:32:28");
		pipelineResultRequest.setStartPage(1);
		pipelineResultRequest.setPageSize(5);
		
//	    String input= "{\"action\":\"GET\",\"period\":\"July 2019\",\"stage\":\"COMP_AND_PAY\",\"company\":\"MM_BU\",\"status\":\"Successful\",\"startTime\":\"2019-11-25 15:32:28\",\"endTime\":\"2019-11-25 15:32:28\",\"startPage\":1,\"pageSize\":5}";
		/*Response result = pipelineResultController.getPipelineResult(pipelineResultRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/pipelineresult")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(pipelineResultRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testPipelineResultEmptyValue_getSuccessfully_ReturnSuccessResponse() throws Exception{
		PipelineResultRequest pipelineResultRequest = new PipelineResultRequest();
		pipelineResultRequest.setAction("GET");
		pipelineResultRequest.setPeriod("October 2019");
		/*Response result = pipelineResultController.getPipelineResult(pipelineResultRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/pipelineresult")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(pipelineResultRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testPipelineResultNULL_getSuccessfully_ReturnSuccessResponse() throws Exception{
		MockHttpServletRequest request = new MockHttpServletRequest("GET","/pipelineresult");
		PipelineResultRequest pipelineResultRequest = new PipelineResultRequest();
		pipelineResultRequest.setAction("GET");
		/*Response result = pipelineResultController.getPipelineResult(pipelineResultRequest);
		Assert.assertEquals("000", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/pipelineresult")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(pipelineResultRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("000"))
    			.andReturn();
	}
	
	@Test
	public void testGetPipelineResult() throws Exception{
		PipelineResultRequest pipelineResultRequest = new PipelineResultRequest();
		pipelineResultRequest.setAction("GET");
		pipelineResultRequest.setStartPage(-1);
		pipelineResultRequest.setPageSize(-1);
		pipelineResultRequest.setPeriod("October 2019");
		pipelineResultRequest.setStage("1");
		pipelineResultRequest.setCompany("MM_BU");
		pipelineResultRequest.setStatus("Successful");
		pipelineResultRequest.setStartTime("2019-11-25 15:32:28");
		pipelineResultRequest.setEndTime("2019-11-25 15:32:28");
	    /*Response result = pipelineResultController.getPipelineResult(pipelineResultRequest);
		Assert.assertEquals("008", result.getResponseCode());*/
		MvcResult mrcresult = mockMvc.perform(
    			MockMvcRequestBuilders.post("/pipelineresult")
    			.contentType(MediaType.APPLICATION_JSON_UTF8)      
    			.content(JsonToObjectUtil.objToJson(pipelineResultRequest))
				)
    			.andExpect(MockMvcResultMatchers.status().isOk())
    			.andDo(MockMvcResultHandlers.print())
    			.andExpect(MockMvcResultMatchers.jsonPath("responseCode").value("008"))
    			.andReturn();
	}
}
