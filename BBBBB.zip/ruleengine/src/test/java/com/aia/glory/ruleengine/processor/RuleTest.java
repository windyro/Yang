package com.aia.glory.ruleengine.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.ruleengine.Application;
import com.aia.glory.ruleengine.constant.Constant;
import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;
import com.aia.glory.ruleengine.processor.impl.RuleGroupModelProcessor;
import com.aia.glory.ruleengine.util.RuleTemplateUtil;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class} ) 
public class RuleTest {
	
	@Autowired
	@Qualifier(value = "ruleGroupModelProcessor")
	private RuleGroupModelProcessor ruleGroupModelProcessor;
	
	@Test   
	public void testDateDiff_Rule_return_true(){
		
		List<Map<String,String>> criteriaMapList = new ArrayList<Map<String,String>>();
		
		RuleModel ruleModel1 = new RuleModel();
		ruleModel1.setCriteriaKey("T_DATE_DIFF");
		ruleModel1.setFunctionParameters("Contributor_ContractDate,2020-10-20");
		ruleModel1.setCriteriaValue("65");
		ruleModel1.setRuleTemplateId("T_GREATER_EQUAL");
		ruleModel1.setComplicatedModelInd("RULE_MODEL_API");
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(ruleModel1);
		
		//Construct RuleDetailModel
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setRuleDetailModelId("detail1");
		ruleDetailModel.setRuleModelList(ruleModelList);
		
		
		//Construct RuleGroupModel
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		ruleDetailModelList.add(ruleDetailModel);
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
        inputDataModel.setPayorContractDate("2019-10-01 00:00:00.0");
        inputDataModel.setPeriod("December 2019");

        List<Map> ruleDetailRuleMapList = ruleGroupModelProcessor.process(ruleGroupModel);
        for(Map ruleDetailRuleMap : ruleDetailRuleMapList){
			inputDataModel.setMatch(true);
			String drlOfRow = (String) ruleDetailRuleMap.get(Constant.RULE_DETAIL_DRL);
			drlOfRow = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;\n" + drlOfRow;
//			System.err.print(drlOfRow);
			
			KieSession kSession = RuleTemplateUtil.createKieSessionFromDRL(drlOfRow);
			kSession.insert(inputDataModel);
			kSession.fireAllRules();
			
			//System.err.println(inputDataModel.isMatch());
        }
        Assert.assertEquals(true, inputDataModel.isMatch());
	}
	
	
	@Test   
	public void testMonthDiff_Rule_return_true(){
		
		List<Map<String,String>> criteriaMapList = new ArrayList<Map<String,String>>();
		
		RuleModel ruleModel1 = new RuleModel();
		ruleModel1.setCriteriaKey("T_MONTH_DIFF");
		ruleModel1.setFunctionParameters("Contributor_ContractDate,2020-09-20");
		ruleModel1.setCriteriaValue("10");
		ruleModel1.setRuleTemplateId("T_GREATER_EQUAL");
		ruleModel1.setComplicatedModelInd("RULE_MODEL_API");
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(ruleModel1);
		
		//Construct RuleDetailModel
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setRuleDetailModelId("detail1");
		ruleDetailModel.setRuleModelList(ruleModelList);
		
		
		//Construct RuleGroupModel
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		ruleDetailModelList.add(ruleDetailModel);
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
        inputDataModel.setPayorContractDate("2019-10-01 00:00:00.0");
        inputDataModel.setPeriod("December 2019");

        List<Map> ruleDetailRuleMapList = ruleGroupModelProcessor.process(ruleGroupModel);
        for(Map ruleDetailRuleMap : ruleDetailRuleMapList){
			inputDataModel.setMatch(true);
			String drlOfRow = (String) ruleDetailRuleMap.get(Constant.RULE_DETAIL_DRL);
			drlOfRow = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;\n" + drlOfRow;
//			System.err.print(drlOfRow);
			
			KieSession kSession = RuleTemplateUtil.createKieSessionFromDRL(drlOfRow);
			kSession.insert(inputDataModel);
			kSession.fireAllRules();
			
			//System.err.println(inputDataModel.isMatch());
        }
        Assert.assertEquals(true, inputDataModel.isMatch());
	}
	
	
	@Test   
	public void testIsBlank_Rule_return_true(){
		
		List<Map<String,String>> criteriaMapList = new ArrayList<Map<String,String>>();
		
		RuleModel ruleModel1 = new RuleModel();
		ruleModel1.setCriteriaKey("T_ISBLANK");
		ruleModel1.setFunctionParameters("Contributor_TerminatedDate");
		ruleModel1.setCriteriaValue("Y");
		ruleModel1.setRuleTemplateId("T_EQUAL");
		ruleModel1.setComplicatedModelInd("RULE_MODEL_API");
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(ruleModel1);
		
		//Construct RuleDetailModel
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setRuleDetailModelId("detail1");
		ruleDetailModel.setRuleModelList(ruleModelList);
		
		//Construct RuleGroupModel
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		ruleDetailModelList.add(ruleDetailModel);
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
        inputDataModel.setPayorTeminatedDate("");

        List<Map> ruleDetailRuleMapList = ruleGroupModelProcessor.process(ruleGroupModel);
        for(Map ruleDetailRuleMap : ruleDetailRuleMapList){
			inputDataModel.setMatch(true);
			String drlOfRow = (String) ruleDetailRuleMap.get(Constant.RULE_DETAIL_DRL);
			drlOfRow = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;\n" + drlOfRow;
//			System.err.print(drlOfRow);
			
			KieSession kSession = RuleTemplateUtil.createKieSessionFromDRL(drlOfRow);
			kSession.insert(inputDataModel);
			kSession.fireAllRules();
			
			//System.err.println(inputDataModel.isMatch());
        }
        Assert.assertEquals(true, inputDataModel.isMatch());
		
	}
	
	@Test   
	public void testContain_Rule_return_true(){
		
		List<Map<String,String>> criteriaMapList = new ArrayList<Map<String,String>>();
		
		RuleModel ruleModel1 = new RuleModel();
		ruleModel1.setCriteriaKey("T_CONTAIN");
		ruleModel1.setFunctionParameters("Contributor_TerminatedDate,1&2&3&4&5&6");
		ruleModel1.setCriteriaValue("Y");
		ruleModel1.setRuleTemplateId("T_EQUAL");
		ruleModel1.setComplicatedModelInd("RULE_MODEL_API");
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(ruleModel1);
		
		//Construct RuleDetailModel
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setRuleDetailModelId("detail1");
		ruleDetailModel.setRuleModelList(ruleModelList);
		
		//Construct RuleGroupModel
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		ruleDetailModelList.add(ruleDetailModel);
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
        inputDataModel.setPayorTeminatedDate("4");

        List<Map> ruleDetailRuleMapList = ruleGroupModelProcessor.process(ruleGroupModel);
        for(Map ruleDetailRuleMap : ruleDetailRuleMapList){
			inputDataModel.setMatch(true);
			String drlOfRow = (String) ruleDetailRuleMap.get(Constant.RULE_DETAIL_DRL);
			drlOfRow = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;\n" + drlOfRow;
//			System.err.print(drlOfRow);
			
			KieSession kSession = RuleTemplateUtil.createKieSessionFromDRL(drlOfRow);
			kSession.insert(inputDataModel);
			kSession.fireAllRules();
			
			//System.err.println(inputDataModel.isMatch());
        }
        Assert.assertEquals(true, inputDataModel.isMatch());
		
	}
	
	@Test   
	public void testMeasurement_Val_return_true(){
		
		List<Map<String,String>> criteriaMapList = new ArrayList<Map<String,String>>();
		
		RuleModel ruleModel1 = new RuleModel();
		ruleModel1.setCriteriaKey("T_MEASUREMENT_VALUE");
		ruleModel1.setFunctionParameters("M1");
		ruleModel1.setCriteriaValue("5");
		ruleModel1.setRuleTemplateId("T_EQUAL");
		ruleModel1.setComplicatedModelInd("RULE_MODEL_API");
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(ruleModel1);
		
		//Construct RuleDetailModel
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setRuleDetailModelId("detail1");
		ruleDetailModel.setRuleModelList(ruleModelList);
		
		//Construct RuleGroupModel
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		ruleDetailModelList.add(ruleDetailModel);
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		com.aia.glory.ruleengine.model.data.measurement.CalculateDataModel inputDataModel = new com.aia.glory.ruleengine.model.data.measurement.CalculateDataModel();
		HashMap measurementValues = new HashMap();
		measurementValues.put("M1", "5");
		inputDataModel.setMeasurementValues(measurementValues);

        List<Map> ruleDetailRuleMapList = ruleGroupModelProcessor.process(ruleGroupModel);
        for(Map ruleDetailRuleMap : ruleDetailRuleMapList){
			inputDataModel.setMatch(true);
			String drlOfRow = (String) ruleDetailRuleMap.get(Constant.RULE_DETAIL_DRL);
			drlOfRow = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data.measurement.CalculateDataModel;\n" + drlOfRow;
//			System.err.print(drlOfRow);
			
			KieSession kSession = RuleTemplateUtil.createKieSessionFromDRL(drlOfRow);
			kSession.insert(inputDataModel);
			kSession.fireAllRules();
			
			//System.err.println(inputDataModel.isMatch());
        }
        Assert.assertEquals(true, inputDataModel.isMatch());
		
	}
}
