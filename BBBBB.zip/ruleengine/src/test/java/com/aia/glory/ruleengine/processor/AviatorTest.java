package com.aia.glory.ruleengine.processor;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;

public class AviatorTest {

	@Test
	public void testExpression() {
        String expression = "(a+b)*c*0.2";

        Expression compiledExp = AviatorEvaluator.compile(expression);
        
        
        
        Map<String, Object> env = new HashMap<String, Object>();
        env.put("a", 100.3);
        env.put("b", 45);
        env.put("c", 199.100);

        Double result = (Double) compiledExp.execute(env);
        System.out.println(result);  // false
	}

}
