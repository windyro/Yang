package com.aia.glory.ruleengine.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.common.model.rule.CalculateParameter;
import com.aia.glory.ruleengine.Application;
import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;
import com.aia.glory.ruleengine.service.CalculateService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class} ) 
public class CalculateServiceTest {

	@Autowired
	CalculateService calculateService;
	
	@Test   
	public void testCalculate_CalFormula_ReturnCorrectResult() throws JsonParseException, JsonMappingException, IOException{
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
		inputDataModel.setFycValue("2000");
		CalculateParameter param = new CalculateParameter();
		param.setCriteriaKey("FYC");
		param.setName("Value1");
		List<CalculateParameter>  parameters = new ArrayList<CalculateParameter>();
		parameters.add(param);
		Expression compiledExp =AviatorEvaluator.compile("Value1*0.2");;
		CalculateDataModel result = (CalculateDataModel) calculateService.calculate(inputDataModel, parameters, compiledExp);
		Assert.assertEquals("400.0", result.getResultValue());
	}
	
	@Test   
	public void testCalculate_CalFormula_WithMutilyParameters_ReturnCorrectResult() throws JsonParseException, JsonMappingException, IOException{
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
		inputDataModel.setFycValue("2000");
		inputDataModel.setRycValue("1000");
		
		List<CalculateParameter>  parameters = new ArrayList<CalculateParameter>();
		
		CalculateParameter param = new CalculateParameter();
		param.setCriteriaKey("FYC");
		param.setName("Value1");
		parameters.add(param);
		param = new CalculateParameter();
		param.setCriteriaKey("RYC");
		param.setName("Value2");
		parameters.add(param);
		
		Expression compiledExp =AviatorEvaluator.compile("Value1*0.2+Value2*0.3");;
		CalculateDataModel result = (CalculateDataModel) calculateService.calculate(inputDataModel, parameters, compiledExp);
		Assert.assertEquals("700.0", result.getResultValue());
	}
	
}
