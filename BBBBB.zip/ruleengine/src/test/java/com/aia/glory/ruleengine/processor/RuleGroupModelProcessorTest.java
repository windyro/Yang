package com.aia.glory.ruleengine.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.ruleengine.Application;
import com.aia.glory.ruleengine.config.RuleCriteriaConfig;
import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;
import com.aia.glory.ruleengine.service.RuleService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class} ) 
public class RuleGroupModelProcessorTest {
	
	@Autowired
	@Qualifier(value = "ruleService")
	private RuleService ruleService;
	
	@Autowired
	private RuleCriteriaConfig ruleCriteriaConfig;
	
	@Test
	public void print_drl() {
		
		//Construct RuleModel
		List<Map<String,String>> criteriaMapList = new ArrayList<Map<String,String>>();
		Map<String,String> criteriaMap = new HashMap<String,String>();
		criteriaMap.put("drt1", "FYC");
		criteriaMapList.add(criteriaMap);
		
		RuleModel ruleModel1 = new RuleModel();
		ruleModel1.setCriteriaKey("Contributor_LeaderTitle");
		ruleModel1.setCriteriaValue("FSC");
		ruleModel1.setRuleTemplateId("T_EQUAL");
		
		RuleModel ruleModel2 = new RuleModel();
		ruleModel2.setCriteriaKey("Contributor_Title");
		ruleModel2.setCriteriaValue("FSD");
		ruleModel2.setRuleTemplateId("T_NOT_EQUAL");
		
		List<RuleModel> ruleModelList = new ArrayList<RuleModel>();
		ruleModelList.add(ruleModel1);
		ruleModelList.add(ruleModel2);
		
		//Construct RuleDetailModel
		RuleDetailModel ruleDetailModel = new RuleDetailModel();
		ruleDetailModel.setRuleDetailModelId("detail1");
		ruleDetailModel.setRuleModelList(ruleModelList);
		
		//Construct RuleGroupModel
		List<RuleDetailModel> ruleDetailModelList = new ArrayList<RuleDetailModel>();
		ruleDetailModelList.add(ruleDetailModel);
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setRuleGroupModelId("group1");
		ruleGroupModel.setRuleDetailModelList(ruleDetailModelList);
		
		CalculateDataModel inputDataModel = new CalculateDataModel();
        inputDataModel.setPayorLeaderTitle("FSE");
        inputDataModel.setPayorTitle("FSD");
        inputDataModel = (CalculateDataModel) ruleService.processRule(ruleGroupModel, inputDataModel);
        
        System.err.println(ruleCriteriaConfig.getCriterias());
        System.err.println(inputDataModel==null ? null : inputDataModel.toString());
        
	}
	
}
