package com.aia.glory.ruleengine.model.criteria;

import java.util.List;
import java.util.Map;

public class CriteriaModel {
	
	private String ruleName;
	
	private String criteria_key;
	
	private String operator;

	private String criteria_value;
	
	
	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getCriteria_key() {
		return criteria_key;
	}

	public void setCriteria_key(String criteria_key) {
		this.criteria_key = criteria_key;
	}

	public String getCriteria_value() {
		return criteria_value;
	}

	public void setCriteria_value(String criteria_value) {
		this.criteria_value = criteria_value;
	}
	
}
