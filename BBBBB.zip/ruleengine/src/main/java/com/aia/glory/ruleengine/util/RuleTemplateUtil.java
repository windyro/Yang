package com.aia.glory.ruleengine.util;

import java.util.ArrayList;
import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.builder.KieScanner;
import org.kie.api.builder.Results;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.utils.KieHelper;

import com.aia.glory.ruleengine.config.RuleTemplateConfig;
import com.aia.glory.ruleengine.model.criteria.CriteriaModel;

public class RuleTemplateUtil {
	
	private RuleTemplateUtil() {
		throw new IllegalStateException("Utility class");
	}
	
	public static String getDrtCriteriaTemplateByRuldId(String ruleId,RuleTemplateConfig ruleTemplateConfig){
		if(ruleTemplateConfig == null) {
			return null;
		}
		return ruleTemplateConfig.getCriteriaTemplate() == null ? null : ruleTemplateConfig.getCriteriaTemplate().get(ruleId);
	}
	
	public static List constructDrlCriteriaParam(String key, String ruleName, String operator, String value){
		CriteriaModel criteriaModel = new CriteriaModel();
		criteriaModel.setRuleName(ruleName);
		criteriaModel.setCriteria_key(key);
		criteriaModel.setOperator(operator);
		criteriaModel.setCriteria_value(value);
		List<CriteriaModel> resultList = new ArrayList<CriteriaModel>();
		resultList.add(criteriaModel);
		return resultList;
	}
	
	public static KieSession getClassPathkieSession(KieServices ks,String sessionName){
		KieContainer kContainer = ks.getKieClasspathContainer();
		KieSession kSession = kContainer.newKieSession(sessionName);
		return kSession;
	}
	
	public static KieSession createKieSessionFromDRL(String drl) {
		KieHelper kieHelper = new KieHelper();
		kieHelper.addContent(drl, ResourceType.DRL);
		Results results = kieHelper.verify();
		return kieHelper.build().newKieSession();
	}

	public static KieSession getRepositorykieSession(KieServices ks){
		KieContainer kContainer = ks.newKieContainer(ks.newReleaseId("aia","demo", "1.0"));
		KieScanner kScanner = ks.newKieScanner(kContainer);
		kScanner.start(10000L);
		try {
			Thread.sleep(10000L);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			e.printStackTrace();
		}
		 KieSession kSession = kContainer.newKieSession("demo-rule");
		
		return kSession;
	}
	
}
