package com.aia.glory.ruleengine.util;

import java.lang.reflect.Method;

import com.aia.glory.ruleengine.config.RuleCriteriaConfig;

public class CriteriaKeyValue {
	
	private CriteriaKeyValue() {
		throw new IllegalStateException("Utility class");
	}

	public static String getFieldValueByName(RuleCriteriaConfig ruleCriteriaConfig,Object criteriaKey, Object o) {
		try {
			Method method;
			String fieldName = ruleCriteriaConfig.getCriterias().get(criteriaKey);
			String firstLetter = fieldName.substring(0, 1).toUpperCase();
			String getter = "get" + firstLetter + fieldName.substring(1);
			method = o.getClass().getMethod(getter, new Class[] {});
			return (String) method.invoke(o, new Object[] {});

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
