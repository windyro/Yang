package com.aia.glory.ruleengine.processor.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.ruleengine.processor.Processor;

@Scope("prototype")
@Service(value = "ruleDetailModelProcessor")
public class RuleDetailModelProcessor implements Processor{
	
	@Autowired
	@Qualifier(value = "ruleModelProcessor")
	private RuleModelProcessor ruleModelProcessor;
	
	/**
	 * Generate combine drl
	 */
	public  String process(Object paramObject){
		RuleDetailModel ruleDetailModel = (RuleDetailModel)paramObject;
		String result="";
		List<RuleModel> ruleModelList = ruleDetailModel.getRuleModelList();
		
		if (ruleModelList==null || ruleModelList.size()==0) return "";
		for(RuleModel ruleModel : ruleModelList){
			result = result + "\n" + ruleModelProcessor.process(ruleModel);
			
		}
//		result = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;\n" + result;
		return result;
	}
	
}
