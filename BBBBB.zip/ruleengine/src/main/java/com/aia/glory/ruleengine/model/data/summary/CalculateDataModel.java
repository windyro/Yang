package com.aia.glory.ruleengine.model.data.summary;

import com.aia.glory.ruleengine.model.data.DataModel;

public class CalculateDataModel extends DataModel{
	
	private String payorAgentCode;
	
	private String payorAgencyCode;
	
	private String payeeAgentCode;
	
	private String payeeAgencyCode;
	
	private String period; //YYYYMM
	
	private String fycValue;
	
	private String rycValue;
	
	private String fypValue;
	
	private String rypValue;
	
	private String maValue;

	private String product;
	
	private String manPower;
	
	private String payorTitle;
	
	private String payorClasscode;
	
	private String payorLeaderTitle;
	
	private String payorLeaderCode;
	
	private String payorContractDate;
	
	private String payorTeminatedDate;

	private String payeeTitle;
	
	private String payeeClasscode;
	
	private String payeeLeaderTitle;
	
	private String payeeLeaderCode;
	
	private String payeeContractDate;
	
	private String payeeTeminatedDate;
		
	private String relationShip;

	
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getMaValue() {
		return maValue;
	}

	public void setMaValue(String maValue) {
		this.maValue = maValue;
	}

	public String getManPower() {
		return manPower;
	}

	public void setManPower(String manPower) {
		this.manPower = manPower;
	}

	public String getPayorAgentCode() {
		return payorAgentCode;
	}

	public void setPayorAgentCode(String payorAgentCode) {
		this.payorAgentCode = payorAgentCode;
	}

	public String getPayorAgencyCode() {
		return payorAgencyCode;
	}

	public void setPayorAgencyCode(String payorAgencyCode) {
		this.payorAgencyCode = payorAgencyCode;
	}

	public String getPayeeAgentCode() {
		return payeeAgentCode;
	}

	public void setPayeeAgentCode(String payeeAgentCode) {
		this.payeeAgentCode = payeeAgentCode;
	}

	public String getPayeeAgencyCode() {
		return payeeAgencyCode;
	}

	public void setPayeeAgencyCode(String payeeAgencyCode) {
		this.payeeAgencyCode = payeeAgencyCode;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getFycValue() {
		return fycValue;
	}

	public void setFycValue(String fycValue) {
		this.fycValue = fycValue;
	}

	public String getRycValue() {
		return rycValue;
	}

	public void setRycValue(String rycValue) {
		this.rycValue = rycValue;
	}

	public String getFypValue() {
		return fypValue;
	}

	public void setFypValue(String fypValue) {
		this.fypValue = fypValue;
	}

	public String getRypValue() {
		return rypValue;
	}

	public void setRypValue(String rypValue) {
		this.rypValue = rypValue;
	}

	public String getPayorTitle() {
		return payorTitle;
	}

	public void setPayorTitle(String payorTitle) {
		this.payorTitle = payorTitle;
	}

	public String getPayorClasscode() {
		return payorClasscode;
	}

	public void setPayorClasscode(String payorClasscode) {
		this.payorClasscode = payorClasscode;
	}

	public String getPayorLeaderTitle() {
		return payorLeaderTitle;
	}

	public void setPayorLeaderTitle(String payorLeaderTitle) {
		this.payorLeaderTitle = payorLeaderTitle;
	}

	public String getPayorLeaderCode() {
		return payorLeaderCode;
	}

	public void setPayorLeaderCode(String payorLeaderCode) {
		this.payorLeaderCode = payorLeaderCode;
	}

	public String getPayorContractDate() {
		return payorContractDate;
	}

	public void setPayorContractDate(String payorContractDate) {
		this.payorContractDate = payorContractDate;
	}

	public String getPayorTeminatedDate() {
		return payorTeminatedDate;
	}

	public void setPayorTeminatedDate(String payorTeminatedDate) {
		this.payorTeminatedDate = payorTeminatedDate;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeClasscode() {
		return payeeClasscode;
	}

	public void setPayeeClasscode(String payeeClasscode) {
		this.payeeClasscode = payeeClasscode;
	}

	public String getPayeeLeaderTitle() {
		return payeeLeaderTitle;
	}

	public void setPayeeLeaderTitle(String payeeLeaderTitle) {
		this.payeeLeaderTitle = payeeLeaderTitle;
	}

	public String getPayeeLeaderCode() {
		return payeeLeaderCode;
	}

	public void setPayeeLeaderCode(String payeeLeaderCode) {
		this.payeeLeaderCode = payeeLeaderCode;
	}

	public String getPayeeContractDate() {
		return payeeContractDate;
	}

	public void setPayeeContractDate(String payeeContractDate) {
		this.payeeContractDate = payeeContractDate;
	}

	public String getPayeeTeminatedDate() {
		return payeeTeminatedDate;
	}

	public void setPayeeTeminatedDate(String payeeTeminatedDate) {
		this.payeeTeminatedDate = payeeTeminatedDate;
	}

	public String getRelationShip() {
		return relationShip;
	}

	public void setRelationShip(String relationShip) {
		this.relationShip = relationShip;
	}

	@Override
	public String toString() {
		return "CalculateDataModel [payorAgentCode=" + payorAgentCode + ", payorAgencyCode=" + payorAgencyCode
				+ ", payeeAgentCode=" + payeeAgentCode + ", payeeAgencyCode=" + payeeAgencyCode + ", period=" + period
				+ ", fycValue=" + fycValue + ", rycValue=" + rycValue + ", fypValue=" + fypValue + ", rypValue="
				+ rypValue + ", maValue=" + maValue + ", product=" + product + ", manPower=" + manPower
				+ ", payorTitle=" + payorTitle + ", payorClasscode=" + payorClasscode + ", payorLeaderTitle="
				+ payorLeaderTitle + ", payorLeaderCode=" + payorLeaderCode + ", payorContractDate=" + payorContractDate
				+ ", payorTeminatedDate=" + payorTeminatedDate + ", payeeTitle=" + payeeTitle + ", payeeClasscode="
				+ payeeClasscode + ", payeeLeaderTitle=" + payeeLeaderTitle + ", payeeLeaderCode=" + payeeLeaderCode
				+ ", payeeContractDate=" + payeeContractDate + ", payeeTeminatedDate=" + payeeTeminatedDate
				+ ", relationShip=" + relationShip + "]";
	}

	

}
