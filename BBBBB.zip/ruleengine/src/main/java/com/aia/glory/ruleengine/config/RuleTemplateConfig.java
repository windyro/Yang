package com.aia.glory.ruleengine.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:rule_template_config.properties")
@ConfigurationProperties(prefix = "rule")
public class RuleTemplateConfig {
	
	private Map<String, String> criteriaTemplate = new HashMap();
	
	public Map<String, String> getCriteriaTemplate() {
		return criteriaTemplate;
	}

	public void setCriteriaTemplate(Map<String, String> criteriaTemplate) {
		this.criteriaTemplate = criteriaTemplate;
	}

	
}
