package com.aia.glory.ruleengine.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.drools.core.util.StringUtils;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.aia.glory.common.model.rule.CalculateModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.ruleengine.constant.Constant;
import com.aia.glory.ruleengine.model.data.DataModel;
import com.aia.glory.ruleengine.processor.impl.RuleGroupModelProcessor;
import com.aia.glory.ruleengine.util.RuleTemplateUtil;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;

@Scope("prototype")
@Service(value = "ruleService")
public class RuleService {
		
    Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	@Autowired
	@Qualifier(value = "calculateService")
	private CalculateService calculateService;	
	
	@Autowired
	@Qualifier(value = "ruleGroupModelProcessor")
	private RuleGroupModelProcessor ruleGroupModelProcessor;
	
	public DataModel processRule(RuleGroupModel ruleGroupModel, DataModel inputDataModel){
		
		debugLog.debug("start generating rule");
		List<Map> ruleDetailRuleMapList = ruleGroupModelProcessor.process(ruleGroupModel);
		
		debugLog.debug("####### ruleGroupModel ##########");
		debugLog.debug(ruleGroupModel==null? "ruleGroupModel is empty" : ruleGroupModel.toString());
		debugLog.debug("####### inputDataModel ##########");
		debugLog.debug(inputDataModel==null? "inputDataModel is empty" : inputDataModel.toString());
		debugLog.debug("####### rule generated ##########");
		debugLog.debug(ruleDetailRuleMapList==null? "ruleDetailRuleMapList is empty" : ruleDetailRuleMapList.toString());
		
		if(ruleDetailRuleMapList==null || ruleDetailRuleMapList.size()==0) {
			inputDataModel.setMatch(false);
			inputDataModel.setResultValue(null);
			return inputDataModel;
		}
		for(Map ruleDetailRuleMap : ruleDetailRuleMapList){
			
			inputDataModel.setMatch(true);
			String drlOfRow = (String) ruleDetailRuleMap.get(Constant.RULE_DETAIL_DRL);
			if(StringUtils.isEmpty(drlOfRow)) continue;
			
			String folder = "";
			if(inputDataModel instanceof com.aia.glory.ruleengine.model.data.summary.CalculateDataModel){
				folder ="summary.";
			}else if(inputDataModel instanceof com.aia.glory.ruleengine.model.data.measurement.CalculateDataModel){
				folder ="measurement.";
			}
			drlOfRow = "package rulefile.template.summary\n"+"import com.aia.glory.ruleengine.model.data." + folder + "CalculateDataModel;\n" + drlOfRow;
			CalculateModel calculateModel = (CalculateModel) ruleDetailRuleMap.get(Constant.RULE_DETAIL_CALC);
			
//			debugLog.debug("RuleService : \\n" + drlOfRow);
			
			debugLog.debug("start processing rule");
			KieSession kSession = RuleTemplateUtil.createKieSessionFromDRL(drlOfRow);
			kSession.insert(inputDataModel);
			kSession.fireAllRules();
			debugLog.debug("rule processed");
			
			if(inputDataModel.isMatch()){
				debugLog.debug("calculation would be tirggerred");
				//TODO Get compiled Express from catch , if none then create new express
				Expression compiledExp = AviatorEvaluator.compile(calculateModel.getAlgorithm());
				return calculateService.calculate(inputDataModel,calculateModel.getParameters(),compiledExp);
			}
			
		}
		debugLog.debug("calculation wasn't tirggerred");
		return inputDataModel;
	}
		
}
