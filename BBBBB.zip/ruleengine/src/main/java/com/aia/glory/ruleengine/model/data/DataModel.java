package com.aia.glory.ruleengine.model.data;


public abstract class DataModel {

	private String resultValue;
	
	/*Store the result of a comparison*/
	private boolean match = true;

	
	public String getResultValue() {
		return resultValue;
	}

	public void setResultValue(String resultValue) {
		this.resultValue = resultValue;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

	@Override
	public String toString() {
		return "DataModel [resultValue=" + resultValue + ", match=" + match
				+ "]";
	}
	
}
