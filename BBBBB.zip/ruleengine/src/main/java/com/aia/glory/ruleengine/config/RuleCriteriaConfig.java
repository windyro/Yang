package com.aia.glory.ruleengine.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:rule_criteria_config.properties")
@ConfigurationProperties(prefix = "rule")
public class RuleCriteriaConfig {
	
	private Map<String, String> criterias = new HashMap();

	public Map<String, String> getCriterias() {
		return criterias;
	}

	public void setCriterias(Map<String, String> criterias) {
		this.criterias = criterias;
	}

	@Override
	public String toString() {
		return "RuleCriteriaConfig [criterias=" + criterias + "]";
	}
	
}
