package com.aia.glory.ruleengine.processor.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.ruleengine.constant.Constant;
import com.aia.glory.ruleengine.processor.Processor;

@Scope("prototype")
@Service(value = "ruleGroupModelProcessor")
public class RuleGroupModelProcessor implements Processor{
	
	@Autowired
	@Qualifier(value = "ruleDetailModelProcessor")
	private RuleDetailModelProcessor ruleDetailModelProcessor;
	
	/* return the completed drl 
	 * @see com.aia.glory.ruleengine.processor.Processor#process(java.lang.Object)
	 */
	public List<Map> process(Object paramObject){
		RuleGroupModel ruleGroupModel = (RuleGroupModel) paramObject;
		ArrayList<Map> ruleDetailRuleMapList = new ArrayList<Map>();
		List<RuleDetailModel> ruleDetailModelList = ruleGroupModel.getRuleDetailModelList();
		
		if(ruleDetailModelList==null || ruleDetailModelList.size()==0) return null;
		for(RuleDetailModel ruleDetailModel : ruleDetailModelList){
			HashMap ruleDetailRuleMap = new HashMap();
			ruleDetailRuleMap.put(Constant.RULE_DETAIL_DRL, ruleDetailModelProcessor.process(ruleDetailModel));
			ruleDetailRuleMap.put(Constant.RULE_DETAIL_CALC, ruleDetailModel.getCalculateModel());
			ruleDetailRuleMapList.add(ruleDetailRuleMap);
		}
		
		return ruleDetailRuleMapList;
	}
	
}
