package com.aia.glory.ruleengine.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:rule_operator_mapping.properties")
@ConfigurationProperties(prefix = "rule")
public class RuleOperatorMappingConfig {
	
	private Map<String, String> operator = new HashMap();

	public Map<String, String> getOperator() {
		return operator;
	}

	public void setOperator(Map<String, String> operator) {
		this.operator = operator;
	}

	@Override
	public String toString() {
		return "RuleOperatorMappingConfig [operator=" + operator + "]";
	}
	
}
