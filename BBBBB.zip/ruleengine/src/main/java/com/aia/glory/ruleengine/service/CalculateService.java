package com.aia.glory.ruleengine.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.aia.glory.common.model.rule.CalculateParameter;
import com.aia.glory.ruleengine.config.RuleCriteriaConfig;
import com.aia.glory.ruleengine.model.data.DataModel;
import com.aia.glory.ruleengine.util.CriteriaKeyValue;
import com.googlecode.aviator.Expression;

@Scope("prototype")
@Service(value = "calculateService")
public class CalculateService {

	Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	@Autowired
	private RuleCriteriaConfig ruleCriteriaConfig;

	public DataModel calculate(DataModel inputDataModel, List<CalculateParameter> parameters,
			Expression compiledExp) {

		Map<String, Object> env = new HashMap<String, Object>();

		for (CalculateParameter p : parameters) {
			
			String value;
			if("measurementValue".equals(p.getCriteriaKey())){
				Map measurementValues = ((com.aia.glory.ruleengine.model.data.measurement.CalculateDataModel) inputDataModel).getMeasurementValues();
				value = (String) measurementValues.get(p.getCriteriaValue()) ;
			}else{
				value = CriteriaKeyValue.getFieldValueByName(ruleCriteriaConfig,p.getCriteriaKey(), inputDataModel);
			}
			debugLog.debug("parameter name: " + p.getName());
			debugLog.debug("parameter value: " + value);
			env.put(StringUtils.trimAllWhitespace((String) p.getName()), Double.valueOf(value));
		}
		
		debugLog.debug("started calculation");
		inputDataModel.setResultValue(compiledExp.execute(env).toString());
		debugLog.debug("finished calculation");

		return inputDataModel;
	}

}
