package com.aia.glory.ruleengine.model.data.measurement;

import java.util.Map;

import com.aia.glory.ruleengine.model.data.DataModel;

public class CalculateDataModel extends DataModel{
	
	private String payeeAgentCode;
	
	private String payeeAgencyCode;
	
	private String period; //YYYYMM

	private String payeeTitle;
	
	private String payeeLeaderTitle;
	
	private String payeeLeaderCode;
	
	private String payeeContractDate;
	
	private String payeeTeminatedDate;
	
	private Map measurementValues;


	public String getPayeeAgentCode() {
		return payeeAgentCode;
	}

	public void setPayeeAgentCode(String payeeAgentCode) {
		this.payeeAgentCode = payeeAgentCode;
	}

	public String getPayeeAgencyCode() {
		return payeeAgencyCode;
	}

	public void setPayeeAgencyCode(String payeeAgencyCode) {
		this.payeeAgencyCode = payeeAgencyCode;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeLeaderTitle() {
		return payeeLeaderTitle;
	}

	public void setPayeeLeaderTitle(String payeeLeaderTitle) {
		this.payeeLeaderTitle = payeeLeaderTitle;
	}

	public String getPayeeLeaderCode() {
		return payeeLeaderCode;
	}

	public void setPayeeLeaderCode(String payeeLeaderCode) {
		this.payeeLeaderCode = payeeLeaderCode;
	}

	public String getPayeeContractDate() {
		return payeeContractDate;
	}

	public void setPayeeContractDate(String payeeContractDate) {
		this.payeeContractDate = payeeContractDate;
	}

	public String getPayeeTeminatedDate() {
		return payeeTeminatedDate;
	}

	public void setPayeeTeminatedDate(String payeeTeminatedDate) {
		this.payeeTeminatedDate = payeeTeminatedDate;
	}

	public Map getMeasurementValues() {
		return measurementValues;
	}

	public void setMeasurementValues(Map measurementValues) {
		this.measurementValues = measurementValues;
	}

	@Override
	public String toString() {
		return "CalculateDataModel [payeeAgentCode=" + payeeAgentCode
				+ ", payeeAgencyCode=" + payeeAgencyCode + ", period=" + period
				+ ", payeeTitle=" + payeeTitle + ", payeeLeaderTitle="
				+ payeeLeaderTitle + ", payeeLeaderCode=" + payeeLeaderCode
				+ ", payeeContractDate=" + payeeContractDate
				+ ", payeeTeminatedDate=" + payeeTeminatedDate
				+ ", measurementValues=" + measurementValues + ", toString()="
				+ super.toString() + "]";
	}
	
}
