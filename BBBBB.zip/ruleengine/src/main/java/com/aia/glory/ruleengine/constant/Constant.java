package com.aia.glory.ruleengine.constant;

public abstract class Constant {
	
	public static final String RULE_DETAIL_DRL = "RULE_DETAIL_DRL";
	
	public static final String RULE_DETAIL_CALC = "RULE_DETAIL_CALC";
	
	public static final String DOUBLE_QUOTE = "\"";
	
	public static final String RULE_MODEL_IND_API = "RULE_MODEL_API";
	
	private Constant() {
		throw new IllegalStateException("Utility class");
	}
}
