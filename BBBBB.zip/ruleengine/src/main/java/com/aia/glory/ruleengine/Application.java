package com.aia.glory.ruleengine;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) throws Exception {
    	
    	Log log = LogFactory.getLog(Application.class);
		SpringApplication app = new SpringApplication(Application.class);
		ConfigurableApplicationContext ctx = app.run(args);

    }
}
