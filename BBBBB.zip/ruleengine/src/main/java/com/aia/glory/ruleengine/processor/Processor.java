package com.aia.glory.ruleengine.processor;

public interface Processor {
	
	public Object process(Object input);
	
}
