package com.aia.glory.ruleengine.processor.impl;

import java.io.InputStream;
import java.util.List;

import org.drools.template.ObjectDataCompiler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import com.aia.glory.common.constant.CommonConstant;
import com.aia.glory.common.model.rule.RuleModel;
import com.aia.glory.ruleengine.config.RuleCriteriaConfig;
import com.aia.glory.ruleengine.config.RuleOperatorMappingConfig;
import com.aia.glory.ruleengine.config.RuleTemplateConfig;
import com.aia.glory.ruleengine.constant.Constant;
import com.aia.glory.ruleengine.processor.Processor;
import com.aia.glory.ruleengine.util.RuleTemplateUtil;

@Scope("prototype")
@Service(value = "ruleModelProcessor")
public class RuleModelProcessor implements Processor{
	
    @Autowired
	private RuleTemplateConfig ruleTemplateConfig;
	
    @Autowired
	private RuleCriteriaConfig ruleCriteriaConfig;
    
    @Autowired
	private RuleOperatorMappingConfig ruleOperatorMappingConfig;
    
    
	/**
	 * @param generate raw drl file
	 * @return
	 */
	public String process(Object paramObject){
		RuleModel ruleModel = (RuleModel) paramObject;
		String drl="";
		String drtTemplate = "";
		
		String criteriaKeyStr = ruleModel.getCriteriaKey();
		if(StringUtils.isEmpty(criteriaKeyStr)) return "";
		StringBuffer criteriaKeyDesc = null;
		List param = null;
		
		if(StringUtils.isEmpty(ruleModel.getComplicatedModelInd())){
			drtTemplate = RuleTemplateUtil.getDrtCriteriaTemplateByRuldId(ruleModel.getRuleTemplateId(),this.ruleTemplateConfig);
			if(StringUtils.isEmpty(drtTemplate)) return "";
			param = constructNormalCriteriaParam(criteriaKeyStr,ruleModel.getCriteriaValue());
			
		}else if(Constant.RULE_MODEL_IND_API.equals(ruleModel.getComplicatedModelInd())){
			drtTemplate = RuleTemplateUtil.getDrtCriteriaTemplateByRuldId(ruleModel.getCriteriaKey(),this.ruleTemplateConfig);
			if(StringUtils.isEmpty(drtTemplate)) return "";
			param = constructAPICriteriaParam(ruleModel.getFunctionParameters(),ruleOperatorMappingConfig.getOperator().get(ruleModel.getRuleTemplateId()),ruleModel.getCriteriaValue());
		}
		
		InputStream template = RuleModelProcessor.class.getResourceAsStream(drtTemplate);
		ObjectDataCompiler converter = new ObjectDataCompiler();
		drl = converter.compile(param, template);
		return drl;
	}
	
	private List constructNormalCriteriaParam(String criteriaKeyStr, String criteriaValue){
		StringBuffer criteriaKeyDesc = new StringBuffer();
		criteriaKeyDesc.append(ruleCriteriaConfig.getCriterias().get(criteriaKeyStr));
		List param = RuleTemplateUtil.constructDrlCriteriaParam(criteriaKeyDesc.toString(),DigestUtils.md5DigestAsHex(criteriaKeyDesc.toString().getBytes()),null,criteriaValue);
		return param;
	}
	
	private List constructAPICriteriaParam(String functionParameters,String operator,String criteriaValue){
		StringBuffer criteriaKeyDesc = null;
		for(String functionParameter : functionParameters.split(CommonConstant.COMMA)){
			if(criteriaKeyDesc == null){
				criteriaKeyDesc = new StringBuffer();
				criteriaKeyDesc.append(StringUtils.isEmpty(ruleCriteriaConfig.getCriterias().get(functionParameter))? Constant.DOUBLE_QUOTE + functionParameter + Constant.DOUBLE_QUOTE : ruleCriteriaConfig.getCriterias().get(functionParameter));
			}else{
				criteriaKeyDesc.append(CommonConstant.COMMA).append(StringUtils.isEmpty(ruleCriteriaConfig.getCriterias().get(functionParameter))? Constant.DOUBLE_QUOTE + functionParameter + Constant.DOUBLE_QUOTE : ruleCriteriaConfig.getCriterias().get(functionParameter));
			}
		}
		if(criteriaKeyDesc == null ) return null;
		List param = RuleTemplateUtil.constructDrlCriteriaParam(criteriaKeyDesc.toString(),DigestUtils.md5DigestAsHex(criteriaKeyDesc.toString().getBytes()),operator,criteriaValue);
		
		return param;
	}
}
