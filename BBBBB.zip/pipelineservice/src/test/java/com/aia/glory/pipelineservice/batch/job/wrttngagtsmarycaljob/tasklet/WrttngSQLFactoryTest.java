package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.tasklet;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.WrttngAgtSmryCalJobSQLFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class WrttngSQLFactoryTest {

	@Test   
	public void testQuarterlySQL() throws JsonParseException, JsonMappingException, IOException{
		
		WrttngAgtSmryCalJobSQLFactory f = new WrttngAgtSmryCalJobSQLFactory("314");
		System.out.print(f.getSql("QUARTERLY", "0"));
		Assert.assertEquals("", "");
	}
	
	@Test   
	public void testMonthlySQL() throws JsonParseException, JsonMappingException, IOException{
		
		WrttngAgtSmryCalJobSQLFactory f = new WrttngAgtSmryCalJobSQLFactory("314");
		System.out.print(f.getSql("MONTHLY", "0"));
		Assert.assertEquals("", "");
	}
	
	@Test   
	public void testYearlySQL() throws JsonParseException, JsonMappingException, IOException{
		
		WrttngAgtSmryCalJobSQLFactory f = new WrttngAgtSmryCalJobSQLFactory("314");
		System.out.print(f.getSql("YEARLY", "0"));
		Assert.assertEquals("", "");
	}
	
	@Test   
	public void testTHREE_YEARLYSQL() throws JsonParseException, JsonMappingException, IOException{
		
		WrttngAgtSmryCalJobSQLFactory f = new WrttngAgtSmryCalJobSQLFactory("314");
		System.out.print(f.getSql("THREE_YEARLY", "0"));
		Assert.assertEquals("", "");
	}
}
