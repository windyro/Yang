package com.aia.glory.pipelineservice;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.pipelineservice.constant.PipelineConstant;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class} ) 
public class JobTriggerTest {
	
	@Autowired
	ApplicationContext context;
	
	@Test   
	public void testTrigger_no_exception() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException, InterruptedException{
		
		HashMap jobParams = new HashMap();
		jobParams.put(PipelineConstant.PROCESSINGUNIT, "MM_BU");
		jobParams.put(PipelineConstant.PERIOD, "October 2019");
		jobParams.put(PipelineConstant.PIPELINE_SEQ, String.valueOf("258"));
		
//		JobTrigger.trigger("001", (ConfigurableApplicationContext) context, jobParams);
	}
	
}
