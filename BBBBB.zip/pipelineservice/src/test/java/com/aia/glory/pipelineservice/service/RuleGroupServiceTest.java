package com.aia.glory.pipelineservice.service;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.pipelineservice.Application;
import com.aia.glory.pipelineservice.constant.PipelineConstant;
import com.aia.glory.ruleengine.processor.impl.RuleGroupModelProcessor;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class} ) 
public class RuleGroupServiceTest {
	
	@Autowired
	@Qualifier(value = "ruleGroupService")
	private RuleGroupService ruleGroupService;
	
	@Test   
	public void testSelectRuleGroup_no_exception(){
		
		ruleGroupService.selectRuleGroup("MM_BU","COMM_AGENT");
	}
	
}
