package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.tasklet;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.pipelineservice.Application;
import com.aia.glory.pipelineservice.constant.PipelineConstant;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class} ) 
public class CombineDepositTaskletTest {
	
	@Autowired
	public DataSource dataSource;
	
	@Test   
	public void testCombineDepositTasklet_Return4000() throws Exception{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		
		jdbcTemplate.update("INSERT INTO WRTNG_AGY_DEPOSIT (NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE) "
    			+ "VALUES ('FYO', 99999999,120,99999999,99999999,1000,99999999,1, getDate())");
		jdbcTemplate.update("INSERT INTO WRTNG_AGY_DEPOSIT (NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE) "
    			+ "VALUES ('FYO', 99999999,120,99999999,99999999,2000,99999999,1, getDate())");
		jdbcTemplate.update("INSERT INTO WRTNG_AGY_DEPOSIT (NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE) "
    			+ "VALUES ('FYO', 99999999,120,99999999,99999999,1000,99999999,1, getDate())");
		
		JobExecution jobExecution = new JobExecution(new Long(123));
		StepExecution execution = new StepExecution("test", jobExecution);
		StepContribution stepContribution = new StepContribution(execution);
		StepContextMock stepContext = new StepContextMock(execution);
		ChunkContext chunkContext = new ChunkContext(stepContext);
		
		CombineDepositTasklet combineDepositTasklet = new CombineDepositTasklet(dataSource);
		combineDepositTasklet.execute(stepContribution, chunkContext);

		Map result = jdbcTemplate.queryForMap("select VALUE from CE_DEPOSIT WHERE POSITIONSEQ=99999999 and PERIODSEQ=120 and PIPELINERUNSEQ=99999999");
		BigDecimal actual = new BigDecimal(result.get("VALUE").toString());
		BigDecimal expect = new BigDecimal("4000");
		Assert.assertEquals(expect.longValue(), actual.longValue());
		
		jdbcTemplate.update("DELETE FROM CE_DEPOSIT WHERE POSITIONSEQ=99999999 and PERIODSEQ=120 and PIPELINERUNSEQ=99999999");
		jdbcTemplate.update("DELETE FROM WRTNG_AGY_DEPOSIT WHERE POSITIONSEQ=99999999 and PERIODSEQ=120 and PIPELINERUNSEQ=99999999");
	}
	
	private class StepContextMock extends StepContext{

		public StepContextMock(StepExecution stepExecution) {
			super(stepExecution);
		}
		
		public Map<String, Object> getJobParameters() {
			Map<String, Object> result = new HashMap<String, Object>();
			
			HashMap jobParams = new HashMap();
			jobParams.put(PipelineConstant.PROCESSINGUNIT, "MM_BU");
			jobParams.put(PipelineConstant.PERIOD, "December 2028");
			
			return Collections.unmodifiableMap(jobParams);
		}
	}
}


