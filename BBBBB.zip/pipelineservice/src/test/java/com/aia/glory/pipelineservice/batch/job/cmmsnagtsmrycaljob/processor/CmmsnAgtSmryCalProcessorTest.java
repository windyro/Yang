package com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.processor;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.pipelineservice.Application;
import com.aia.glory.pipelineservice.batch.model.CmmsnAgtSmryCalModel;
import com.aia.glory.pipelineservice.constant.PipelineConstant;

@RunWith(SpringRunner.class)
//@SpringBootTest(classes = {Application.class} ) 
public class CmmsnAgtSmryCalProcessorTest {
	

	@Test   
	public void testMatchPeriod_MONTHLY_CURRENT_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.MONTHLY);
		ruleGroupModel.setPeriodIndex("0");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.MONTHLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("January 2020");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_MONTHLY_minus_1_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.MONTHLY);
		ruleGroupModel.setPeriodIndex("-1");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.MONTHLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("December 2019");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_MONTHLY_minus_2_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.MONTHLY);
		ruleGroupModel.setPeriodIndex("-2");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.MONTHLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("November 2019");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_MONTHLY_minus_3_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.MONTHLY);
		ruleGroupModel.setPeriodIndex("-3");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.MONTHLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("October 2019");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_QUARTERLY_CURRENT_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.QUARTERLY);
		ruleGroupModel.setPeriodIndex("0");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.QUARTERLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("20201");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_QUARTERLY_minus_1_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.QUARTERLY);
		ruleGroupModel.setPeriodIndex("-1");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.QUARTERLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("20194");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_QUARTERLY_minus_2_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.QUARTERLY);
		ruleGroupModel.setPeriodIndex("-2");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.QUARTERLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("20193");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_QUARTERLY_minus_3_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.QUARTERLY);
		ruleGroupModel.setPeriodIndex("-3");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.QUARTERLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("20192");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_YEARLY_CURRENT_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.YEARLY);
		ruleGroupModel.setPeriodIndex("0");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.YEARLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("2020");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_YEARLY_minus_1_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.YEARLY);
		ruleGroupModel.setPeriodIndex("-1");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.YEARLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("2019");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_YEARLY_minus_2_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.YEARLY);
		ruleGroupModel.setPeriodIndex("-2");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.YEARLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("2018");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_YEARLY_minus_3_Return_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.YEARLY);
		ruleGroupModel.setPeriodIndex("-3");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.YEARLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("2017");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
	@Test   
	public void testMatchPeriod_THREE_YEARLY_true() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		CmmsnAgtSmryCalProcessor cmmsnAgtSmryCalProcessor = new CmmsnAgtSmryCalProcessor(null, null);
		Class cmmsnAgtSmryCalProcessorClass = cmmsnAgtSmryCalProcessor.getClass();
		RuleGroupModel ruleGroupModel = new RuleGroupModel();
		ruleGroupModel.setPeriodType(PipelineConstant.THREE_YEARLY);
		ruleGroupModel.setPeriodIndex("0");
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(PipelineConstant.THREE_YEARLY);
		cmmsnAgtSmryCalModel.setPeriod("January 2020");
		cmmsnAgtSmryCalModel.setFqPeriod("2018-2020");
		
		Method matchPeriod = cmmsnAgtSmryCalProcessorClass.getDeclaredMethod("matchPeriod", RuleGroupModel.class,CmmsnAgtSmryCalModel.class);
		matchPeriod.setAccessible(true);
		boolean result = (boolean) matchPeriod.invoke(cmmsnAgtSmryCalProcessor, ruleGroupModel, cmmsnAgtSmryCalModel);
		Assert.assertEquals(true, result);
	}
	
}