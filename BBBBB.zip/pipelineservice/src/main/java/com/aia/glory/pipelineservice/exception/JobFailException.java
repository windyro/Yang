package com.aia.glory.pipelineservice.exception;

public class JobFailException extends Exception {

}
