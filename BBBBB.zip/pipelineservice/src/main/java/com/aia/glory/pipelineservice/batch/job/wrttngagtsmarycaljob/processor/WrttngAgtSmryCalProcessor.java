package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.processor;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.util.TimeUtils;
import com.aia.glory.pipelineservice.batch.model.DepositModel;
import com.aia.glory.pipelineservice.batch.model.WrttngAgtSmryCalModel;
import com.aia.glory.pipelineservice.constant.PipelineConstant;
import com.aia.glory.pipelineservice.service.RuleGroupService;
import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;
import com.aia.glory.ruleengine.service.RuleService;

public class WrttngAgtSmryCalProcessor implements ItemProcessor<WrttngAgtSmryCalModel,List<DepositModel>>{
	
    Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	private RuleService ruleService;
	
	private RuleGroupService ruleGroupService;
	
	// private String period;
	
	private String processingUnit;
	
	public WrttngAgtSmryCalProcessor(RuleGroupService ruleGroupService,RuleService ruleService){
		this.ruleGroupService = ruleGroupService;
		this.ruleService = ruleService;
	}
	
	@BeforeStep
    public void beforeStep(final StepExecution stepExecution) {
        JobParameters jobParameters = stepExecution.getJobParameters();
        // this.period = jobParameters.getString(PipelineConstant.PERIOD);
        this.processingUnit = jobParameters.getString(PipelineConstant.PROCESSINGUNIT);
    }
	
	@Override
	public List<DepositModel> process(final WrttngAgtSmryCalModel wrttngAgtSmryCalModel) throws Exception {
		
		CalculateDataModel calculateDataModel = constructCalculateDataModel(wrttngAgtSmryCalModel);
		List<RuleGroupModel> ruleGroupModelList = ruleGroupService.selectRuleGroup(this.processingUnit,"WRI_AGENCY");
		
		return this.setDepositModelList(calculateDataModel, ruleGroupModelList,wrttngAgtSmryCalModel);
	}
	
	private List<DepositModel> setDepositModelList(CalculateDataModel calculateDataModel,
			List<RuleGroupModel> ruleGroupModelList, WrttngAgtSmryCalModel wrttngAgtSmryCalModel) throws ParseException {

		List<DepositModel> depositModelList = new ArrayList<DepositModel>();
			if(ruleGroupModelList != null){
				for (RuleGroupModel ruleGroupModel : ruleGroupModelList) {
					
					if(!matchPeriod(ruleGroupModel,wrttngAgtSmryCalModel)){
						continue;
					}
					
					synchronized(this){
						calculateDataModel.setMatch(true);
						calculateDataModel = (CalculateDataModel) this.ruleService.processRule(ruleGroupModel, calculateDataModel);
					}
					
					if (calculateDataModel.getResultValue() == null
							|| Double.parseDouble(calculateDataModel.getResultValue()) == 0
							|| calculateDataModel.isMatch() == false) {
						continue;
					}
					DepositModel depositModel = constructDepositModel(calculateDataModel, wrttngAgtSmryCalModel, ruleGroupModel);
					depositModelList.add(depositModel);
					
			}
		}
		return depositModelList;
	}
	
	private boolean matchPeriod(RuleGroupModel ruleGroupModel,WrttngAgtSmryCalModel WrttngAgtSmryCalModel) throws ParseException{
		String rulePeriodType = ruleGroupModel.getPeriodType() == null ? PipelineConstant.MONTHLY : ruleGroupModel.getPeriodType();
		String rulePeriodIndex = ruleGroupModel.getPeriodIndex() == null ? PipelineConstant.CURRENT : ruleGroupModel.getPeriodIndex();
		String dataPeriodType = WrttngAgtSmryCalModel.getFrequency()== null ? "" : WrttngAgtSmryCalModel.getFrequency();
	
		if(!rulePeriodType.equals(dataPeriodType)){
			return false;
		}else if(PipelineConstant.THREE_YEARLY.equals(rulePeriodType)){
			return true;
		}
		
		int index=-999;
		switch(rulePeriodType){
		case PipelineConstant.MONTHLY:
			index = TimeUtils.monthComparison(WrttngAgtSmryCalModel.getFqPeriod(),WrttngAgtSmryCalModel.getPeriod(),PipelineConstant.PERIOD_FORMAT,PipelineConstant.PERIOD_FORMAT);
			break;
		case PipelineConstant.QUARTERLY:
			if(TimeUtils.getYear(WrttngAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) == Integer.valueOf(WrttngAgtSmryCalModel.getFqPeriod().substring(0,4)).intValue()){
				index = TimeUtils.getQualter(WrttngAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) - Integer.valueOf(WrttngAgtSmryCalModel.getFqPeriod().substring(4)).intValue();
			}else{
				index = TimeUtils.getQualter(WrttngAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) + 4 - Integer.valueOf(WrttngAgtSmryCalModel.getFqPeriod().substring(4)).intValue();
			}
			break;
		case PipelineConstant.YEARLY:
			index = TimeUtils.getYear(WrttngAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) - Integer.valueOf(WrttngAgtSmryCalModel.getFqPeriod()).intValue();
			break;
		}
		
		return rulePeriodIndex.equals(String.valueOf(-index));
	}
	
	private CalculateDataModel constructCalculateDataModel(WrttngAgtSmryCalModel wrttngAgtSmryCalModel){
		CalculateDataModel calculateDataModel = new CalculateDataModel();
		calculateDataModel.setPeriod(wrttngAgtSmryCalModel.getPeriod());
		calculateDataModel.setFycValue(wrttngAgtSmryCalModel.getFyc());
		calculateDataModel.setRycValue(wrttngAgtSmryCalModel.getRyc());
		calculateDataModel.setFypValue(wrttngAgtSmryCalModel.getFyp());
		calculateDataModel.setRypValue(wrttngAgtSmryCalModel.getRyp());
		calculateDataModel.setManPower(wrttngAgtSmryCalModel.getManPower());
		calculateDataModel.setPayeeAgentCode(wrttngAgtSmryCalModel.getPayee());
	
		calculateDataModel.setPayeeAgencyCode(wrttngAgtSmryCalModel.getPayeeAgencyCode());
		calculateDataModel.setPayeeContractDate(wrttngAgtSmryCalModel.getPayeeContractDate());
		calculateDataModel.setPayeeLeaderCode(wrttngAgtSmryCalModel.getPayeeLeaderCode());
		calculateDataModel.setPayeeLeaderTitle(wrttngAgtSmryCalModel.getPayeeLeaderTitle());
		calculateDataModel.setPayeeTeminatedDate(wrttngAgtSmryCalModel.getPayeeTeminatedDate());
		calculateDataModel.setPayeeTitle(wrttngAgtSmryCalModel.getPayeeTitle());
		
		calculateDataModel.setPayorAgentCode(wrttngAgtSmryCalModel.getPayor());
		calculateDataModel.setPayorAgencyCode(wrttngAgtSmryCalModel.getPayorAgencyCode());
		calculateDataModel.setPayorContractDate(wrttngAgtSmryCalModel.getPayorContractDate());
		calculateDataModel.setPayorLeaderCode(wrttngAgtSmryCalModel.getPayorLeaderCode());
		calculateDataModel.setPayorLeaderTitle(wrttngAgtSmryCalModel.getPayorLeaderTitle());
		calculateDataModel.setPayorTeminatedDate(wrttngAgtSmryCalModel.getPayorTeminatedDate());
		calculateDataModel.setPayorTitle(wrttngAgtSmryCalModel.getPayorTitle());
		
		calculateDataModel.setRelationShip(wrttngAgtSmryCalModel.getRelationShip());
		
		return calculateDataModel;
	}
	
	private DepositModel constructDepositModel(CalculateDataModel calculateDataModel,WrttngAgtSmryCalModel wrttngAgtSmryCalModel,RuleGroupModel ruleGroupModel){
		DepositModel depositModel = new DepositModel();
		
		depositModel.setNAME(ruleGroupModel.getName());
		depositModel.setPERIODSEQ(wrttngAgtSmryCalModel.getPeriodSequence());
		depositModel.setPIPELINERUNSEQ(wrttngAgtSmryCalModel.getPipelineSequence());
		depositModel.setPOSITIONSEQ(wrttngAgtSmryCalModel.getPayeeLeaderPositionSequence());
		//TODO: Set rule detail 
		depositModel.setRULESEQ(ruleGroupModel.getRuleGroupModelId());
		depositModel.setBUSINESSUNITMAP(wrttngAgtSmryCalModel.getBusinessUnitMapSeq());
		depositModel.setPROCESSINGUNITSEQ(wrttngAgtSmryCalModel.getProcessingUnitSeq());
		depositModel.setVALUE(new BigDecimal(calculateDataModel.getResultValue()));
		
		return depositModel;
	}
	
}
