package com.aia.glory.pipelineservice.batch.job.measurementjob.tasklet;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.StringUtils;

import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.pipelineservice.batch.job.measurementjob.MrsrmntCalJobSQLFactory;
import com.aia.glory.pipelineservice.constant.PipelineConstant;
import com.aia.glory.pipelineservice.service.RuleGroupService;

public class MrsrmntCoreDataPreparationTasklet implements Tasklet{
	
	
    Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	private RuleGroupService ruleGroupService;
	
	private JdbcTemplate jdbcTemplate;
	
	
	public MrsrmntCoreDataPreparationTasklet(DataSource dataSource,RuleGroupService ruleGroupService){
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		this.ruleGroupService = ruleGroupService;
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		
		Map<String, Object> jobParameters = chunkContext.getStepContext().getJobParameters();
		String period = (String) jobParameters.get(PipelineConstant.PERIOD);
		String processingUnit = (String) jobParameters.get(PipelineConstant.PROCESSINGUNIT);
		String pipelineSequence = (String) jobParameters.get(PipelineConstant.PIPELINE_SEQ);
		
		List<RuleGroupModel> ruleGroupModelList = ruleGroupService.selectRuleGroup(processingUnit,"MEASUREMENT");
		Set<String> indicatorSet =new HashSet();
		if(ruleGroupModelList != null){
			for(RuleGroupModel ruleGroupModel : ruleGroupModelList){
				StringBuffer key = new StringBuffer();
				String periodType = StringUtils.isEmpty(ruleGroupModel.getPeriodType()) ? PipelineConstant.MONTHLY : ruleGroupModel.getPeriodType();
				String periodIndex = StringUtils.isEmpty(ruleGroupModel.getPeriodIndex()) ? PipelineConstant.CURRENT : ruleGroupModel.getPeriodIndex();
				indicatorSet.add(key.append(periodType).append(PipelineConstant.DELIMITER).append(periodIndex).toString());
			}
		}
		
		jdbcTemplate.execute("truncate table CE_MEASUREMENTCALJOB_STAGE");
		
		MrsrmntCalJobSQLFactory mearsurementCalJobSQLFactory = new MrsrmntCalJobSQLFactory();
		for(String key : indicatorSet){
			String[] params = key.split(PipelineConstant.DELIMITER);
			String sql = mearsurementCalJobSQLFactory.getSql(params[0], params[1]);
			debugLog.debug("SQL:" + sql);
			debugLog.debug("param1:" + pipelineSequence);
			debugLog.debug("param2:" + period);
			debugLog.debug("param2:" + processingUnit);
			jdbcTemplate.update(sql,new Object[]{pipelineSequence,period,processingUnit});
		}
		
		return null;
	}

}
