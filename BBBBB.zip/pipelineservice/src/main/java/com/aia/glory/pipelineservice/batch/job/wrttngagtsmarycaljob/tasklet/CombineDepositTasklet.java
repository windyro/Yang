package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.tasklet;

import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import com.aia.glory.pipelineservice.constant.PipelineConstant;

public class CombineDepositTasklet implements Tasklet{

private JdbcTemplate jdbcTemplate;
	
	public CombineDepositTasklet(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		
		Map<String, Object> jobParameters = chunkContext.getStepContext().getJobParameters();
		String period = (String) jobParameters.get(PipelineConstant.PERIOD);
		String processingUnit = (String) jobParameters.get(PipelineConstant.PROCESSINGUNIT);
		
		jdbcTemplate.update("INSERT INTO CE_DEPOSIT (DEPOSITSEQ,NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP"
				+ ",PROCESSINGUNITSEQ,DEPOSITDATE,RELEASEDATE,ISHELD,EARNINGCODEID,EARNINGGROUPID)"
				+ "SELECT NEXT VALUE FOR CE_DEPOSIT_SEQ,WAD.NAME,WAD.POSITIONSEQ,WAD.PERIODSEQ,WAD.PIPELINERUNSEQ,WAD.RULESEQ, "+
				" sum(WAD.VALUE) VALUE,WAD.BUSINESSUNITMAP,WAD.PROCESSINGUNITSEQ,CONVERT(varchar(100), "+
				" WAD.DEPOSITDATE, 23) DEPOSITDATE,CONVERT(varchar(100), WAD.RELEASEDATE, 23) RELEASEDATE, "+
				" 0 ISHELD,WAD.EARNINGCODEID,WAD.EARNINGGROUPID  "+
				" FROM WRTNG_AGY_DEPOSIT WAD "+
				" INNER JOIN CE_PERIOD CP "+
				" ON WAD.PERIODSEQ = CP.PERIODSEQ "+
				" AND REMOVEDATE='22000101' "+
				" AND CP.NAME=? "+
				" INNER JOIN CE_PROCESSINGUNIT CPR "+
				" ON WAD.PROCESSINGUNITSEQ=CPR.PROCESSINGUNITSEQ "+
				" AND CPR.NAME=? "+
				" group by WAD.NAME,WAD.POSITIONSEQ,WAD.PERIODSEQ,WAD.PIPELINERUNSEQ,WAD.RULESEQ,"
				+ "WAD.BUSINESSUNITMAP,WAD.PROCESSINGUNITSEQ,CONVERT(varchar(100),WAD.DEPOSITDATE, 23),"
				+ "CONVERT(varchar(100), WAD.RELEASEDATE, 23),WAD.ISHELD,WAD.EARNINGCODEID,WAD.EARNINGGROUPID "
				,new Object[]{period,processingUnit});
		
		
		return null;
	}
	
	
}
