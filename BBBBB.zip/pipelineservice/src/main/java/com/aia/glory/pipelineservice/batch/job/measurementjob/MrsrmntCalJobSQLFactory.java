package com.aia.glory.pipelineservice.batch.job.measurementjob;

import com.aia.glory.pipelineservice.constant.PipelineConstant;

public class MrsrmntCalJobSQLFactory {
	
	public final  String COMMON_INSERT = "INSERT INTO CE_MEASUREMENTCALJOB_STAGE (FREQUENCY,PERIOD,PERIODSEQ,FQPERIOD,MEASUREMENT_NAME,PIPELINERUNSEQ,PAYEEPOSSEQ,POSITION_TYPE,PAYEE_CODE,PAYEE_TITLE,PAYEE_LEADER_TITLE,VALUE,BUSINESSUNITMAP,CHANNEL,PROCESSINGUNITSEQ,company,ROW_NUM) ";
	
	public final  String MONTHLY_SELECT = "select 'monthly' FREQUENCY,CURPERIOD.NAME PERIOD,CURPERIOD.PERIODSEQ PERIODSEQ,CPE.NAME FQPeriod, ";
	
	public final  String MONTHLY_WHERE = " and CPE.startdate >= DATEADD(mm,DATEDIFF(mm,0,CURPERIOD.startdate)-{index},0) " 
										 +"and CPE.startdate <= DATEADD(ms,-3,DATEADD(mm,DATEDIFF(mm,0,CURPERIOD.startdate)+1-{index},0)) ";
	
	public final  String QUARTERLY_SELECT = "select 'quarterly' FREQUENCY,CURPERIOD.NAME PERIOD,CURPERIOD.PERIODSEQ PERIODSEQ,DateName(year,CPE.startdate) + DateName(quarter,CPE.startdate) FQPeriod, ";
	
	public final  String QUARTERLY_WHERE = " and CPE.startdate >= DATEADD(Quarter,DATEDIFF(Quarter,0,curPeriod.startdate)-{index},0) "
										   +"and CPE.startdate <= DATEADD(ms,-3,DATEADD(Quarter,DATEDIFF(Quarter,0,curPeriod.startdate)+1-{index},0)) ";
	
	public final  String YEARLY_SELECT = "select 'yearly' FREQUENCY,CURPERIOD.NAME PERIOD,CURPERIOD.PERIODSEQ PERIODSEQ,DateName(year,CPE.startdate) FQPeriod, ";
	
	public final  String YEARLY_WHERE =  " and CPE.startdate >= DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)-{index},0) "
									     +"and CPE.startdate <= DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1-{index},0)) ";
	
	public final  String THREE_YEARLY_SELECT = "select '3-yearly' FREQUENCY,CURPERIOD.NAME PERIOD,CURPERIOD.PERIODSEQ PERIODSEQ,DateName(year,DATEADD(Year,DATEDIFF(Year,0,CURPERIOD.startdate)-2,0))+'-'+DateName(year,DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,CURPERIOD.startdate)+1,0))) FQPeriod, ";
	
	public final  String THREE_YEARLY_WHERE = "AND CPE.startdate >= DATEADD(Year,DATEDIFF(Year,0,CURPERIOD.startdate)-2,0) "
											 +"AND CPE.startdate <= DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,CURPERIOD.startdate)+1,0)) ";
	
	public final  String COMMON_SELECT = " CM.NAME MEASUREMENT_NAME,? PIPELINERUNSEQ,CM.POSITIONSEQ PAYEEPOSSEQ,CPO.RECORDTYPE POSITION_TYPE,CPO.NAME PAYEE_CODE,CTTL.NAME PAYEE_TITLE, "
								    	+ "CPO.GENERICATTRIBUTE4 PAYEE_LEADER_TITLE,CM.VALUE,CM.BUSINESSUNITMAP,CBU.NAME CHANNEL,CM.PROCESSINGUNITSEQ,CPR.NAME company, "
										+"row_number() over(order by CPO.name ASC) ROW_NUM" ;
	
	public final  String COMMON_FROM = " FROM CE_MEASUREMENT CM,CE_POSITION CPO,CE_PERIOD CPE,CE_BUSINESSUNIT CBU,CE_PROCESSINGUNIT CPR,CE_TITLE CTTL,CE_PERIOD CURPERIOD " ;
	
	public final  String COMMON_WHERE = " WHERE CM.POSITIONSEQ=CPO.POSITIONSEQ AND CPO.REMOVEDATE='22000101' AND CPO.ISLAST='1' "
											+" AND CM.BUSINESSUNITMAP=CBU.BUSINESSUNITSEQ AND CM.PROCESSINGUNITSEQ=CM.PROCESSINGUNITSEQ "
											+" AND CM.PROCESSINGUNITSEQ=CPR.PROCESSINGUNITSEQ "
											+" AND CPO.TITLESEQ=CTTL.TITLESEQ AND CTTL.REMOVEDATE='22000101' AND CTTL.ISLAST='1' "
											+" AND CM.PERIODSEQ=CPE.PERIODSEQ AND CPE.REMOVEDATE='22000101' "
											+" AND CURPERIOD.NAME=? "
											+ "AND CPR.NAME=?";

	public  String getSql(String period, String index){
		String result = "";
		switch(period){
			case PipelineConstant.MONTHLY:
				result = constructMonthlySql(index);
				break;
			case PipelineConstant.QUARTERLY:
				result = constructQuarterlySql(index);
				break;
			case PipelineConstant.YEARLY:
				result = constructYearlySql(index);
				break;
			case PipelineConstant.THREE_YEARLY:
				result = constructThreeYearlySql();
				break;
			 default:
				 
	            break;
		}
		
		return result;
	}
	
	private  String constructMonthlySql(String index){
		
		StringBuffer result = new StringBuffer();
		switch(index){
			case PipelineConstant.CURRENT:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT));
				break;
			case PipelineConstant.PREVIOUS_1:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_2:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_3:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1)));
				break;
			 default:
				 
	            break;
		}
		
		return result.toString();
	}
	
	private  String constructQuarterlySql(String index){
		
		StringBuffer result = new StringBuffer();
		switch(index){
			case PipelineConstant.CURRENT:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT));
				break;
			case PipelineConstant.PREVIOUS_1:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_2:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_3:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1)));
				break;
			 default:
				 
	            break;
		}
		return result.toString();
	}
	
	private  String constructYearlySql(String index){
		StringBuffer result = new StringBuffer();
		switch(index){
			case PipelineConstant.CURRENT:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT));
				break;
			case PipelineConstant.PREVIOUS_1:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_2:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_3:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1)));
				break;
			 default:
				 
	            break;
		}
		return result.toString();
	}
	
	private  String constructThreeYearlySql(){
		StringBuffer result = new StringBuffer();
		result.append(COMMON_INSERT).append(THREE_YEARLY_SELECT).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(THREE_YEARLY_WHERE);
		return result.toString();
	}
}
