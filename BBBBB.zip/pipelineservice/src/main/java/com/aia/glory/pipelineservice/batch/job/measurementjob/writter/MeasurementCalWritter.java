package com.aia.glory.pipelineservice.batch.job.measurementjob.writter;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.InitializingBean;

import com.aia.glory.pipelineservice.batch.model.DepositModel;
import com.aia.glory.pipelineservice.batch.model.MeasurementModel;

public class MeasurementCalWritter<T> implements ItemWriter<T>, InitializingBean {
	
	Log debugLog = LogFactory.getLog("sysDebug");
	
	private JdbcBatchItemWriter<DepositModel> depositWriteDelegate;
	
	private JdbcBatchItemWriter<MeasurementModel> measurementWriteDelegate;

	@Override
	public void afterPropertiesSet() throws Exception {
		this.depositWriteDelegate.afterPropertiesSet();
		this.measurementWriteDelegate.afterPropertiesSet();
	}

	@Override
	public void write(List<? extends T> items) throws Exception {
		
		ArrayList<DepositModel> depositList = new ArrayList<DepositModel>();
		ArrayList<MeasurementModel> measurementList = new ArrayList<MeasurementModel>();
		
		for(T item : items){
			List tempList = (List) item;
			for(Object subItem : tempList){
				if(subItem instanceof DepositModel){
					depositList.add((DepositModel) subItem);
				}else if(subItem instanceof MeasurementModel){
					measurementList.add((MeasurementModel) subItem);
				}
			}
		}
		
		if(depositList != null && depositList.size() != 0){
			this.depositWriteDelegate.write(depositList);
		}
		
		if(measurementList != null && measurementList.size() != 0){
			this.measurementWriteDelegate.write(measurementList);
		}
		
//		debugLog.debug(depositList.toString());
//		debugLog.debug(measurementList.toString());
		
	}

	public void setDelegate(JdbcBatchItemWriter<DepositModel> depositWriteDelegate,JdbcBatchItemWriter<MeasurementModel> measurementWriteDelegate) {
		this.depositWriteDelegate = depositWriteDelegate;
		this.measurementWriteDelegate = measurementWriteDelegate;
	}

}
