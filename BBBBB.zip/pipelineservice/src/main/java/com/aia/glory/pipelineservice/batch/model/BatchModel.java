package com.aia.glory.pipelineservice.batch.model;

public class BatchModel {
	
	private String jobName;
	
	private String jobStatus;
	
	private String jobCreatTime;

	
	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getJobCreatTime() {
		return jobCreatTime;
	}

	public void setJobCreatTime(String jobCreatTime) {
		this.jobCreatTime = jobCreatTime;
	}

	@Override
	public String toString() {
		return "batchModel [jobName=" + jobName + ", jobStatus=" + jobStatus
				+ ", jobCreatTime=" + jobCreatTime + "]";
	}
	
}
