package com.aia.glory.pipelineservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.pipelineservice.enumerate.PipelineStatus;
import com.aia.glory.pipelineservice.request.JobTriggerRequest;
import com.aia.glory.pipelineservice.response.JobTriggerResponse;
import com.aia.glory.pipelineservice.service.JobTriggerService;
import com.aia.glory.pipelineservice.validator.JobTriggerValidatior;

@Controller
public class JobTriggerController {
	
	@Autowired
	@Qualifier(value = "jobTriggerService")
	private JobTriggerService jobTriggerService;
	
	@RequestMapping(value = "/pipelinetrigger", method = RequestMethod.POST)
	@ResponseBody
	public Response pipelinetrigger(@RequestBody String requestBody) throws Exception{
		
		JobTriggerRequest jobTriggerRequest= (JobTriggerRequest) JsonToObjectUtil.jsonToObj(new JobTriggerRequest(), requestBody);
		
		Errors errors = new BeanPropertyBindingResult(new JobTriggerRequest(), "jobTriggerRequest");
		JobTriggerValidatior jobTriggerValidatior = new JobTriggerValidatior();
		jobTriggerValidatior.validate(jobTriggerRequest, errors);
		
		if (errors.hasErrors()){
			FieldError error =  errors.getFieldError();
			JobTriggerResponse jobTriggerResponse = new JobTriggerResponse();
			jobTriggerResponse.setResponseCode(ResponseCode.ERROR.getCode());
			jobTriggerResponse.setReasonCode(error.getCode());
			jobTriggerResponse.setReasonDesc(error.getDefaultMessage());
			
			return jobTriggerResponse;
	    }
		
		jobTriggerService.trigger(jobTriggerRequest);
		
		JobTriggerResponse jobTriggerResponse = new JobTriggerResponse();
		jobTriggerResponse.setResponseCode(ResponseCode.NORMAL.getCode());
		jobTriggerResponse.setReasonCode("0000");
		jobTriggerResponse.setReasonDesc(jobTriggerRequest.getCompensationType() + " is triggerred");
		jobTriggerResponse.setJobStatus(PipelineStatus.Processing.name());
		
		return jobTriggerResponse;
	}
	
}
