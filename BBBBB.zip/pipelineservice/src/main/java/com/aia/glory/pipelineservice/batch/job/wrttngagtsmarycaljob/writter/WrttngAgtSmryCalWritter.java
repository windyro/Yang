package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.writter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.aia.glory.pipelineservice.batch.model.DepositModel;

public class WrttngAgtSmryCalWritter<T> implements ItemWriter<T>, InitializingBean {

	private JdbcBatchItemWriter<DepositModel> delegate;

	@Override
	public void afterPropertiesSet() throws Exception {
		this.delegate.afterPropertiesSet();
	}

	@Override
	public void write(List<? extends T> items) throws Exception {
		
		ArrayList<DepositModel> fullList = new ArrayList<DepositModel>();
		
		for(T item : items){
			List tempList = (List) item;
			fullList.addAll(tempList);
		}
		
		this.delegate.write(fullList);
		
	}

	public void setDelegate(JdbcBatchItemWriter<DepositModel> delegate) {
		this.delegate = delegate;
	}

}
