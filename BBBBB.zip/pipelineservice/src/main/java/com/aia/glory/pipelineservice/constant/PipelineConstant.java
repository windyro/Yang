package com.aia.glory.pipelineservice.constant;

public class PipelineConstant 
{
    public final static String PIPELINE_SEQ = "pipelineSequence";
    
    public final static String COMPENSATION_TYPE = "compensationType";
    
    public final static String PROCESSINGUNIT = "processingunit";
    
    public final static String PERIOD = "period";
    
    public final static String PROCESS_SUFFIX="_PROCESSING";
    
    public final static String SUCCESSFUL_SUFFIX="_COMPLETED";
    
    public final static String FAIL_SUFFIX="_FAILED";
    
    public final static String MONTHLY="MONTHLY";
    
    public final static String QUARTERLY="QUARTERLY";
    
    public final static String YEARLY="YEARLY";

    public final static String THREE_YEARLY="THREE_YEARLY";
    
    public final static String CURRENT="0";
    
    public final static String PREVIOUS_1="-1";
    
    public final static String PREVIOUS_2="-2";
    
    public final static String PREVIOUS_3="-3";
    
    public final static String INDEX_PLACE_HOLDER="{index}";
    
    public final static String DELIMITER="&";
    
    public final static String PERIOD_FORMAT="MMMM yyyy";
    
    private PipelineConstant() {
        throw new IllegalStateException("Utility class");
      }
}
