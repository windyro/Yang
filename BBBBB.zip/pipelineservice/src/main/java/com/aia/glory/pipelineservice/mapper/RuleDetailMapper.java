package com.aia.glory.pipelineservice.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.aia.glory.common.model.rule.RuleDetailModel;

public interface RuleDetailMapper {
	
	@Select("SELECT RULE_DETAIL_ID,RULE_MODEL_DATA,CALCULATE_MODEL_DATA,RULE_GROUP_ID FROM RULE_DETAILL_TABLE WHERE RULE_GROUP_ID = #{ruleGroupModelId}")
	public List<Map<String,Object>> selectRuleDetail(@Param("ruleGroupModelId") String ruleGroupModelId);
	
}
