package com.aia.glory.pipelineservice.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;

import com.aia.glory.common.model.rule.RuleGroupModel;

@Mapper
public interface RuleGroupMapper {
	
	@ResultMap("selectRuleGroup")
	public List<RuleGroupModel> selectRuleGroup(@Param("ruleGroupName")String ruleGroupName,@Param("company")String company,@Param("channel")String channel,@Param("summaryType")String summaryType);
	
}
