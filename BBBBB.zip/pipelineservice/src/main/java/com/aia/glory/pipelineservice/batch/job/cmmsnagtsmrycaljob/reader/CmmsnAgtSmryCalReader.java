package com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.reader;

import javax.sql.DataSource;

import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;

public class CmmsnAgtSmryCalReader{
	
	/*public CmmsnAgtSmryCalReader(DataSource dataSource) throws Exception{
		this.setDataSource(dataSource);
		
		final SqlPagingQueryProviderFactoryBean sqlPagingQueryProviderFactoryBean = new SqlPagingQueryProviderFactoryBean();
    	sqlPagingQueryProviderFactoryBean.setDataSource(dataSource);
    	sqlPagingQueryProviderFactoryBean.setSelectClause("select PERIOD,PERIODSEQ,BUSINESSUNITMAPSEQ,PROCESSINGUNITSEQ,PIPELINESEQ,PAYEEPOSSEQ,LEVEL,CHANNEL,COMPANY,PAYOR_AGENCY_CODE,PAYOR_CONTRACT_DATE,PAYOR_LEADER_CODE,PAYOR_LEADER_TITLE,PAYOR_TERMINATEDATE,PAYOR_TITLE,PAYEE_AGENCY_CODE,PAYEE_CONTRACT_DATE,PAYEE_LEADER_CODE,PAYEE_LEADER_TITLE,PAYEE_TEMINATED_DATE,PAYEE_TITLE,FYC,RYC,FYP,RYP,RELATIONSHIP,PAYOR,PAYEE,ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setFromClause("from CE_CMMSNAGTSMRYCALJOB_STAGE");
    	sqlPagingQueryProviderFactoryBean.setSortKey("ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setWhereClause("ROW_NUM >= :minId and ROW_NUM <= :maxId");
    	this.setQueryProvider(sqlPagingQueryProviderFactoryBean.getObject());
	}*/
	
}