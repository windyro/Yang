package com.aia.glory.pipelineservice.request;

import com.aia.glory.common.model.request.Request;
import com.aia.glory.common.model.rule.RuleGroupModel;

public class JobTriggerRequest extends Request{
	
	private String compensationType;
	
	private String company;
	
	private String period;

	
	public String getCompensationType() {
		return compensationType;
	}

	public void setCompensationType(String compensationType) {
		this.compensationType = compensationType;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	@Override
	public String toString() {
		return "JobTriggerRequest [compensationType=" + compensationType
				+ ", company=" + company + ", period=" + period + "]";
	}
	
}
