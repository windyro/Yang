package com.aia.glory.pipelineservice;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableBatchProcessing
@MapperScan("com.aia.glory.pipelineservice.mapper")
@ComponentScan("com.aia.glory.*")
@EnableCaching
public class Application extends SpringBootServletInitializer{
	
	public static void main(String[] args) throws Exception {
		
		SpringApplication app = new SpringApplication(Application.class);
		ConfigurableApplicationContext ctx = app.run(args);
		
    }
	
	@Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder){
        return builder.build();
	}
   
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(Application.class);
    }
}
