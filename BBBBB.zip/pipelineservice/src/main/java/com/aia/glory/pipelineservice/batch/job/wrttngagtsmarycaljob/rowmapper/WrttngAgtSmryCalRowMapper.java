package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.aia.glory.pipelineservice.batch.model.WrttngAgtSmryCalModel;

public class WrttngAgtSmryCalRowMapper implements RowMapper{
	
	public WrttngAgtSmryCalRowMapper() {
		// implementation ignored
	}
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		WrttngAgtSmryCalModel wrttngAgtSmryCalModel = new WrttngAgtSmryCalModel();
		wrttngAgtSmryCalModel.setFrequency(rs.getString("FREQUENCY"));
		wrttngAgtSmryCalModel.setPeriod(rs.getString("PERIOD"));
		wrttngAgtSmryCalModel.setFqPeriod(rs.getString("FQPERIOD"));
		wrttngAgtSmryCalModel.setPeriodSequence(rs.getString("PERIODSEQ"));
		wrttngAgtSmryCalModel.setBusinessUnitMapSeq(rs.getString("BUSINESSUNITMAPSEQ"));
		wrttngAgtSmryCalModel.setProcessingUnitSeq(rs.getString("PROCESSINGUNITSEQ"));
		wrttngAgtSmryCalModel.setPipelineSequence(rs.getString("PIPELINESEQ"));
		wrttngAgtSmryCalModel.setPayeePositionSequence(rs.getString("PAYEEPOSSEQ"));
		wrttngAgtSmryCalModel.setPayeeLeaderPositionSequence(rs.getString("PAYEE_LEADER_POSSEQ"));
		wrttngAgtSmryCalModel.setLevel(rs.getString("LEVEL"));
		wrttngAgtSmryCalModel.setChannel(rs.getString("CHANNEL"));
		wrttngAgtSmryCalModel.setCompany(rs.getString("COMPANY"));
		wrttngAgtSmryCalModel.setFyc(String.valueOf(rs.getDouble("FYC")));
		wrttngAgtSmryCalModel.setManPower(String.valueOf(rs.getDouble("MANPOWER")));
		wrttngAgtSmryCalModel.setRyc(String.valueOf(rs.getDouble("RYC")));
		wrttngAgtSmryCalModel.setFyp(String.valueOf(rs.getDouble("FYP")));
		wrttngAgtSmryCalModel.setRyp(String.valueOf(rs.getDouble("RYP")));
		wrttngAgtSmryCalModel.setRelationShip(rs.getString("RELATIONSHIP"));
		wrttngAgtSmryCalModel.setPayor(rs.getString("PAYOR"));
		wrttngAgtSmryCalModel.setPayee(rs.getString("PAYEE"));
		
		wrttngAgtSmryCalModel.setPayeeAgencyCode(rs.getString("PAYEE_AGENCY_CODE"));
		wrttngAgtSmryCalModel.setPayeeContractDate(rs.getString("PAYEE_CONTRACT_DATE"));
		wrttngAgtSmryCalModel.setPayeeLeaderCode(rs.getString("PAYEE_LEADER_CODE"));
		wrttngAgtSmryCalModel.setPayeeLeaderTitle(rs.getString("PAYEE_LEADER_TITLE"));
		wrttngAgtSmryCalModel.setPayeeTeminatedDate(rs.getString("PAYEE_TEMINATED_DATE"));
		wrttngAgtSmryCalModel.setPayeeTitle(rs.getString("PAYEE_TITLE"));
		
		wrttngAgtSmryCalModel.setPayorAgencyCode(rs.getString("PAYOR_AGENCY_CODE"));
		wrttngAgtSmryCalModel.setPayorContractDate(rs.getString("PAYOR_CONTRACT_DATE"));
		wrttngAgtSmryCalModel.setPayorLeaderCode(rs.getString("PAYOR_LEADER_CODE"));
		wrttngAgtSmryCalModel.setPayorLeaderTitle(rs.getString("PAYOR_LEADER_TITLE"));
		wrttngAgtSmryCalModel.setPayorTeminatedDate(rs.getString("PAYOR_TERMINATEDATE"));
		wrttngAgtSmryCalModel.setPayorTitle(rs.getString("PAYOR_TITLE"));
		
		return wrttngAgtSmryCalModel;
	}
}
