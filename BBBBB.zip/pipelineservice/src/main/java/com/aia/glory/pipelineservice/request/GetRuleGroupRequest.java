package com.aia.glory.pipelineservice.request;

import com.aia.glory.common.model.request.Request;

public class GetRuleGroupRequest extends Request{
    
    private String company;
	
    private String summaryType;

   	
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getSummaryType() {
		return summaryType;
	}

	public void setSummaryType(String summaryType) {
		this.summaryType = summaryType;
	}
    
}
