package com.aia.glory.pipelineservice.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.pipelineservice.enumerate.PipelineType;
import com.aia.glory.pipelineservice.request.JobTriggerRequest;

public class JobTriggerValidatior implements Validator {
	
	@Override
	public boolean supports(Class clazz) {
		return JobTriggerRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		JobTriggerRequest request = (JobTriggerRequest) target;
		
		if(!PipelineType.COMP_AND_PAY.name().equals(request.getCompensationType()) && 
				!PipelineType.POST.name().equals(request.getCompensationType()) &&
					!PipelineType.FINALIZE.name().equals(request.getCompensationType())){
			
			errors.rejectValue("company", ReasonCode.PIPELINE_TYPE_TYPE_ERROR.getCode(), ReasonCode.PIPELINE_TYPE_TYPE_ERROR.getDesc());
			
		}
	}

}
