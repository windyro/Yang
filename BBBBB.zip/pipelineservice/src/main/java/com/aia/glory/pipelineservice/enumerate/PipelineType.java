package com.aia.glory.pipelineservice.enumerate;

public enum PipelineType {
	
	COMP_AND_PAY("COMP_AND_PAY","COMP_AND_PAY"),
	
	POST("POST","POST"),
	
	FINALIZE("FINALIZE","FINALIZE");
	
	private final String code;
	
	private final String value;
	
	public String getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}

	private PipelineType(String code, String value){
		this.code=code;
		this.value=value;
	}
	
}
