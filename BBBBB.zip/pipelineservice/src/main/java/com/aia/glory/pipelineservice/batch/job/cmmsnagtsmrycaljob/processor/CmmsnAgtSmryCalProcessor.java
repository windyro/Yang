package com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.processor;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Scope;

import com.aia.glory.common.constant.CommonConstant;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.util.TimeUtils;
import com.aia.glory.pipelineservice.batch.model.CmmsnAgtSmryCalModel;
import com.aia.glory.pipelineservice.batch.model.DepositModel;
import com.aia.glory.pipelineservice.batch.model.MeasurementModel;
import com.aia.glory.pipelineservice.constant.PipelineConstant;
import com.aia.glory.pipelineservice.service.RuleGroupService;
import com.aia.glory.ruleengine.model.data.summary.CalculateDataModel;
import com.aia.glory.ruleengine.service.RuleService;

@Scope(value = "step")
public class CmmsnAgtSmryCalProcessor<T> implements ItemProcessor<CmmsnAgtSmryCalModel,List<T>>{
	
	private RuleService ruleService;
	
	private RuleGroupService ruleGroupService;
	
	// private String period;
	
	private String processingUnit;
	
	public CmmsnAgtSmryCalProcessor(RuleGroupService ruleGroupService,RuleService ruleService){
		this.ruleGroupService = ruleGroupService;
		this.ruleService = ruleService;
	}
	
	@BeforeStep
    public void beforeStep(final StepExecution stepExecution) {
        JobParameters jobParameters = stepExecution.getJobParameters();
        // this.period = jobParameters.getString(PipelineConstant.PERIOD);
        this.processingUnit = jobParameters.getString(PipelineConstant.PROCESSINGUNIT);
    }

	
	@Override
	public List<T> process(final CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel) throws Exception {
		
		CalculateDataModel calculateDataModel = constructCalculateDataModel(cmmsnAgtSmryCalModel);
		List<RuleGroupModel> ruleGroupModelList = ruleGroupService.selectRuleGroup(this.processingUnit,"COMM_AGENT");
		if(ruleGroupModelList == null) return null;
		
		return (List<T>) this.constructWriteModelList(calculateDataModel, ruleGroupModelList,cmmsnAgtSmryCalModel);
	}
	
	
	private List<T> constructWriteModelList(CalculateDataModel calculateDataModel,
			List<RuleGroupModel> ruleGroupModelList, CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel) throws ParseException {

			List<T> writeModelList = new ArrayList<T>();
			
			for (RuleGroupModel ruleGroupModel : ruleGroupModelList) {
				
				if(!matchPeriod(ruleGroupModel,cmmsnAgtSmryCalModel)){
					continue;
				}
				
				synchronized(this){
					calculateDataModel.setMatch(true);
					calculateDataModel = (CalculateDataModel) this.ruleService.processRule(ruleGroupModel, calculateDataModel);
				}
				
				if (calculateDataModel.getResultValue() == null
						|| Double.parseDouble(calculateDataModel.getResultValue()) == 0
						|| calculateDataModel.isMatch() == false) {
					continue;
				}
				
				if(CommonConstant.YES.equals(ruleGroupModel.getPaymentFlag())){
					DepositModel depositModel = constructDepositModel(calculateDataModel, cmmsnAgtSmryCalModel, ruleGroupModel);
					writeModelList.add((T) depositModel);
				}else if(CommonConstant.NO.equals(ruleGroupModel.getPaymentFlag())){
					MeasurementModel measurementModel = constructMeasurementModel(calculateDataModel, cmmsnAgtSmryCalModel, ruleGroupModel);
					writeModelList.add((T) measurementModel);
				}
					
			}
			
		return writeModelList;
	}
	
	private boolean matchPeriod(RuleGroupModel ruleGroupModel,CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel) throws ParseException{
		String rulePeriodType = ruleGroupModel.getPeriodType() == null ? PipelineConstant.MONTHLY : ruleGroupModel.getPeriodType();
		String rulePeriodIndex = ruleGroupModel.getPeriodIndex() == null ? PipelineConstant.CURRENT : ruleGroupModel.getPeriodIndex();
		String dataPeriodType = cmmsnAgtSmryCalModel.getFrequency()== null ? "" : cmmsnAgtSmryCalModel.getFrequency();
	
		if(!rulePeriodType.equals(dataPeriodType)){
			return false;
		}else if(PipelineConstant.THREE_YEARLY.equals(rulePeriodType)){
			return true;
		}
		
		int index=-999;
		switch(rulePeriodType){
		case PipelineConstant.MONTHLY:
			index = TimeUtils.monthComparison(cmmsnAgtSmryCalModel.getFqPeriod(),cmmsnAgtSmryCalModel.getPeriod(),PipelineConstant.PERIOD_FORMAT,PipelineConstant.PERIOD_FORMAT);
			break;
		case PipelineConstant.QUARTERLY:
			if(TimeUtils.getYear(cmmsnAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) == Integer.valueOf(cmmsnAgtSmryCalModel.getFqPeriod().substring(0,4)).intValue()){
				index = TimeUtils.getQualter(cmmsnAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) - Integer.valueOf(cmmsnAgtSmryCalModel.getFqPeriod().substring(4)).intValue();
			}else{
				index = TimeUtils.getQualter(cmmsnAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) + 4 - Integer.valueOf(cmmsnAgtSmryCalModel.getFqPeriod().substring(4)).intValue();
			}
			break;
		case PipelineConstant.YEARLY:
			index = TimeUtils.getYear(cmmsnAgtSmryCalModel.getPeriod(), PipelineConstant.PERIOD_FORMAT) - Integer.valueOf(cmmsnAgtSmryCalModel.getFqPeriod()).intValue();
			break;
		}
		
		return rulePeriodIndex.equals(String.valueOf(-index));
	}
	
	private CalculateDataModel constructCalculateDataModel(CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel){
		CalculateDataModel calculateDataModel = new CalculateDataModel();
		calculateDataModel.setPeriod(cmmsnAgtSmryCalModel.getPeriod());
		calculateDataModel.setFycValue(cmmsnAgtSmryCalModel.getFyc());
		calculateDataModel.setRycValue(cmmsnAgtSmryCalModel.getRyc());
		calculateDataModel.setFypValue(cmmsnAgtSmryCalModel.getFyp());
		calculateDataModel.setRypValue(cmmsnAgtSmryCalModel.getRyp());
		calculateDataModel.setPayeeAgentCode(cmmsnAgtSmryCalModel.getPayee());
	
		calculateDataModel.setPayeeAgencyCode(cmmsnAgtSmryCalModel.getPayeeAgencyCode());
		calculateDataModel.setPayeeContractDate(cmmsnAgtSmryCalModel.getPayeeContractDate());
		calculateDataModel.setPayeeLeaderCode(cmmsnAgtSmryCalModel.getPayeeLeaderCode());
		calculateDataModel.setPayeeLeaderTitle(cmmsnAgtSmryCalModel.getPayeeLeaderTitle());
		calculateDataModel.setPayeeTeminatedDate(cmmsnAgtSmryCalModel.getPayeeTeminatedDate());
		calculateDataModel.setPayeeTitle(cmmsnAgtSmryCalModel.getPayeeTitle());
		
		calculateDataModel.setPayorAgentCode(cmmsnAgtSmryCalModel.getPayor());
		calculateDataModel.setPayorAgencyCode(cmmsnAgtSmryCalModel.getPayorAgencyCode());
		calculateDataModel.setPayorContractDate(cmmsnAgtSmryCalModel.getPayorContractDate());
		calculateDataModel.setPayorLeaderCode(cmmsnAgtSmryCalModel.getPayorLeaderCode());
		calculateDataModel.setPayorLeaderTitle(cmmsnAgtSmryCalModel.getPayorLeaderTitle());
		calculateDataModel.setPayorTeminatedDate(cmmsnAgtSmryCalModel.getPayorTeminatedDate());
		calculateDataModel.setPayorTitle(cmmsnAgtSmryCalModel.getPayorTitle());
		
		calculateDataModel.setRelationShip(cmmsnAgtSmryCalModel.getRelationShip());
		
		return calculateDataModel;
	}
	
	private DepositModel constructDepositModel(CalculateDataModel calculateDataModel,CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel,RuleGroupModel ruleGroupModel){
		DepositModel depositModel = new DepositModel();
		
		depositModel.setNAME(ruleGroupModel.getName());
		depositModel.setPERIODSEQ(cmmsnAgtSmryCalModel.getPeriodSequence());
		depositModel.setPIPELINERUNSEQ(cmmsnAgtSmryCalModel.getPipelineSequence());
		depositModel.setPOSITIONSEQ(cmmsnAgtSmryCalModel.getPayeePositionSequence());
		//TODO: Set rule detail 
		depositModel.setRULESEQ(ruleGroupModel.getRuleGroupModelId());
		depositModel.setBUSINESSUNITMAP(cmmsnAgtSmryCalModel.getBusinessUnitMapSeq());
		depositModel.setPROCESSINGUNITSEQ(cmmsnAgtSmryCalModel.getProcessingUnitSeq());
		depositModel.setVALUE(new BigDecimal(calculateDataModel.getResultValue()));
		
		return depositModel;
	}
	
	private MeasurementModel constructMeasurementModel(CalculateDataModel calculateDataModel,CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel,RuleGroupModel ruleGroupModel){
		MeasurementModel measurementModel = new MeasurementModel();
		
		measurementModel.setNAME(ruleGroupModel.getName());
		measurementModel.setPERIODSEQ(cmmsnAgtSmryCalModel.getPeriodSequence());
		measurementModel.setPIPELINERUNSEQ(cmmsnAgtSmryCalModel.getPipelineSequence());
		measurementModel.setPOSITIONSEQ(cmmsnAgtSmryCalModel.getPayeePositionSequence());
		measurementModel.setRULESEQ(ruleGroupModel.getRuleGroupModelId());
		measurementModel.setBUSINESSUNITMAP(cmmsnAgtSmryCalModel.getBusinessUnitMapSeq());
		measurementModel.setPROCESSINGUNITSEQ(cmmsnAgtSmryCalModel.getProcessingUnitSeq());
		measurementModel.setVALUE(new BigDecimal(calculateDataModel.getResultValue()));
		
		return measurementModel;
	}
	
}
