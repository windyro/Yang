package com.aia.glory.pipelineservice.enumerate;

public enum SpringBatchStatus {
	
	COMPLETED,
	
	STARTING,
	
	STARTED,
	
	STOPPING,
	
	STOPPED,
	
	FAILED,
	
	ABANDONED,
	
	UNKNOWN;
	
}
