package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.processor.WrttngAgtSmryCalProcessor;
import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.rowmapper.WrttngAgtSmryCalRowMapper;
import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.tasklet.CombineDepositTasklet;
import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.tasklet.CoreDataPreparationTasklet;
import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.tasklet.SupportDataPreparationTasklet;
import com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob.writter.WrttngAgtSmryCalWritter;
import com.aia.glory.pipelineservice.batch.model.DepositModel;
import com.aia.glory.pipelineservice.batch.model.WrttngAgtSmryCalModel;
import com.aia.glory.pipelineservice.batch.partitioner.ColumnRangePartitioner;
import com.aia.glory.pipelineservice.service.RuleGroupService;
import com.aia.glory.ruleengine.service.RuleService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Configuration
@EnableBatchProcessing
public class WrttngAgtSmarycalJobConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    
	@Autowired
	@Qualifier(value = "ruleGroupService")
	private RuleGroupService ruleGroupService;
	
	@Autowired
	@Qualifier(value = "ruleService")
	private RuleService ruleService;

    @Autowired
    public DataSource dataSource;
    
    @Value("${summary-parition-threads}")
    private int maxThreads;
    
    @Value("${summary-parition-read-size}")
    private int readSize;
    
    @Value("${summary-parition-grid-size}")
    private int gridSize;
    
    @Value("${summary-parition-chunk-size}")
    private int chunkSize;
    
  	/*
  	 * Readers
  	 * 
  	 */
    @Bean
	@StepScope
	public JdbcPagingItemReader<WrttngAgtSmryCalModel> wrttngAgtSmryCalPartitionReader(@Value("#{stepExecutionContext[minValue]}") Integer minValue, @Value("#{stepExecutionContext[maxValue]}") Integer maxValue) throws Exception {
    	
    	JdbcPagingItemReader<WrttngAgtSmryCalModel> reader = new JdbcPagingItemReader<WrttngAgtSmryCalModel>();
    	reader.setDataSource(dataSource);
		
		final SqlPagingQueryProviderFactoryBean sqlPagingQueryProviderFactoryBean = new SqlPagingQueryProviderFactoryBean();
    	sqlPagingQueryProviderFactoryBean.setDataSource(dataSource);
    	sqlPagingQueryProviderFactoryBean.setSelectClause("select FREQUENCY,PERIOD,FQPERIOD,PERIODSEQ,BUSINESSUNITMAPSEQ,PROCESSINGUNITSEQ,PIPELINESEQ,PAYEEPOSSEQ,PAYEE_LEADER_POSSEQ,LEVEL,CHANNEL,COMPANY,PAYOR_AGENCY_CODE,PAYOR_CONTRACT_DATE,PAYOR_LEADER_CODE,PAYOR_LEADER_TITLE,PAYOR_TERMINATEDATE,PAYOR_TITLE,PAYEE_AGENCY_CODE,PAYEE_CONTRACT_DATE,PAYEE_LEADER_CODE,PAYEE_LEADER_TITLE,PAYEE_TEMINATED_DATE,PAYEE_TITLE,FYC,RYC,FYP,RYP,MANPOWER,RELATIONSHIP,PAYOR,PAYEE,ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setFromClause("from CE_WRTTNGAGTSMRYCALJOB_STAGE");
    	sqlPagingQueryProviderFactoryBean.setSortKey("ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setWhereClause("ROW_NUM >= :minId and ROW_NUM <= :maxId");
    	reader.setQueryProvider(sqlPagingQueryProviderFactoryBean.getObject());
    	
    	reader.setRowMapper(new WrttngAgtSmryCalRowMapper());
    	reader.setPageSize(readSize);
    	reader.setFetchSize(readSize);
    	
    	HashMap paramMap = new HashMap();
    	paramMap.put("minId", minValue);
    	paramMap.put("maxId", maxValue);
    	reader.setParameterValues(paramMap);
    	
        return reader;
    }
    
    /*
     * 
     * Processor
     * 
     */
    @Bean
	public WrttngAgtSmryCalProcessor wrttngAgtSmryCalPartitionProcessor() throws JsonParseException, JsonMappingException, IOException {
    	
        return new WrttngAgtSmryCalProcessor(ruleGroupService,ruleService);
    }
    
    /*
     * 
     * Writer
     * 
     */
    @Bean
	public WrttngAgtSmryCalWritter<List<DepositModel>> wrttngAgtSmryCalPartitionWriter() {
    	
    	WrttngAgtSmryCalWritter<List<DepositModel>> writer = new WrttngAgtSmryCalWritter<List<DepositModel>>();
    	JdbcBatchItemWriter<DepositModel> delegate = new JdbcBatchItemWriter<DepositModel>();
    	delegate.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<DepositModel>());
    	delegate.setSql("INSERT INTO WRTNG_AGY_DEPOSIT (NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE) "
    			+ "VALUES (:NAME, :POSITIONSEQ, :PERIODSEQ, :PIPELINERUNSEQ, :RULESEQ, :VALUE, :BUSINESSUNITMAP, :PROCESSINGUNITSEQ , getDate())");
    	delegate.setDataSource(dataSource);
//    	delegate.afterPropertiesSet();
    	writer.setDelegate(delegate);
    	
        return writer;
    }

    @Bean
    public ColumnRangePartitioner wrttngAgtSmryCalPartitioner() {
    	ColumnRangePartitioner partitioner = new ColumnRangePartitioner();
    	partitioner.setDataSource(dataSource);
    	partitioner.setColumn("ROW_NUM");
    	partitioner.setTable("CE_WRTTNGAGTSMRYCALJOB_STAGE");
        return partitioner;
    }
    
    @Bean(name = "wrttngAgtSmryCalJob")
    public Job wrttngAgtSmryCalJob() 
      throws Exception {
        return jobBuilderFactory.get("wrttngAgtSmryCalJob")
          .start(wrttngAgtSmryCalCoreDataPreStep())
          .next(wrttngAgtSmryCalSupportDataPreStep())
          .next(wrttngAgtSmryCalPartitionStep())
          .next(wrttngAgtSmryCombineDepositStep())
          .build();
    }
    
    @Bean
    public Step wrttngAgtSmryCalCoreDataPreStep() 
      throws Exception {
        return stepBuilderFactory.get("wrttngAgtSmryCalCoreDataPreStep")
          .tasklet(new CoreDataPreparationTasklet(dataSource,ruleGroupService))
          .build();
    }
    
    @Bean
    public Step wrttngAgtSmryCalSupportDataPreStep() 
      throws Exception {
        return stepBuilderFactory.get("wrttngAgtSmryCalSupportDataPreStep")
          .tasklet(new SupportDataPreparationTasklet(dataSource))
          .build();
    }
    
    @Bean
    public Step wrttngAgtSmryCalPartitionStep() 
      throws Exception {
        return stepBuilderFactory.get("wrttngAgtSmryCalPartitionStep")
          .partitioner("wrttngAgtSmryCalPartitionStep_slave", wrttngAgtSmryCalPartitioner()).gridSize(gridSize)
//          .partitionHandler(partitionHandler)
          .step(wrttngAgtSmryCalPartitionStep_slave())
          .taskExecutor(wrttngAgtTaskExecutor())
          .build();
    }
    
    @Bean
    public Step wrttngAgtSmryCombineDepositStep() 
      throws Exception {
        return stepBuilderFactory.get("wrttngAgtSmryCombineDepositStep")
          .tasklet(new CombineDepositTasklet(dataSource))
          .build();
    }
    
   
    
    @Bean
    public Step wrttngAgtSmryCalPartitionStep_slave() 
      throws Exception {
        return stepBuilderFactory.get("wrttngAgtSmryCalPartitionStep_slave").<WrttngAgtSmryCalModel, List<DepositModel>> chunk(chunkSize)
				.reader(wrttngAgtSmryCalPartitionReader(null, null))
				.processor(wrttngAgtSmryCalPartitionProcessor())
				.writer(wrttngAgtSmryCalPartitionWriter())
                .build();
    }
    
    @Bean
    public TaskExecutor wrttngAgtTaskExecutor() {
    	SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
    	taskExecutor.setConcurrencyLimit(maxThreads);
    	return taskExecutor;
    }
}
