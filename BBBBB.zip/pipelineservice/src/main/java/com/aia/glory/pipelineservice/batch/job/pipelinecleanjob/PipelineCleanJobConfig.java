package com.aia.glory.pipelineservice.batch.job.pipelinecleanjob;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aia.glory.pipelineservice.batch.job.pipelinecleanjob.tasklet.PipelineCleanExecTasklet;

@Configuration
@EnableBatchProcessing
public class PipelineCleanJobConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;
    
    @Bean(name = "pipelineCleanJob")
    public Job pipelineCleanJob() 
      throws Exception {
        return jobBuilderFactory.get("pipelineCleanJob")
          .start(pipelineCleanStep())
          .build();
    }
    
    @Bean
    public Step pipelineCleanStep() 
      throws Exception {
        return stepBuilderFactory.get("pipelineCleanStep")
          .tasklet(new PipelineCleanExecTasklet(dataSource))
          .build();
    }
    
}
