package com.aia.glory.pipelineservice.batch.job.smrygnnrtjob.tasklet;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public class SmryGnnrtExecTasklet implements Tasklet{
	
	private JdbcTemplate jdbcTemplate;

	public SmryGnnrtExecTasklet(DataSource dataSource){
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		Map<String, Object> jobParameters = chunkContext.getStepContext().getJobParameters();
		String pipelineSequence = (String) jobParameters.get("pipelineSequence");
		
		SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
         .withProcedureName("SummaryExec")
         .declareParameters(new SqlParameter("NewPIPELINERUNSEQ", Types.BIGINT));
		
		Map<String, Object> execute = call.execute(new MapSqlParameterSource("NewPIPELINERUNSEQ", pipelineSequence));
		 
		return null;
	}

}
