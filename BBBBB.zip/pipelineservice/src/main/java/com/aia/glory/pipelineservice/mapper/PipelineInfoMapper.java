package com.aia.glory.pipelineservice.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.pipelineservice.batch.model.BatchModel;

public interface PipelineInfoMapper {
	
	@Select(" <script>"
			+ "SELECT max(pipelinerunseq) "
			+ " from CE_PIPELINERUN CPI"
			+ " INNER JOIN CE_PERIOD CPE "
			+ " ON CPI.periodseq = CPE.periodseq"
			+ " AND CPE.NAME = #{period}"
			+ " AND CPI.command = #{pipelineType}"
			+"<if test='status!=null'>"
			+ " AND CPI.status=#{status}"
			+"</if>"
			+ " INNER JOIN CE_PROCESSINGUNIT CPR "
			+ " ON CPI.processingunitseq = CPR.processingunitseq"
			+ " AND CPR.name = #{processingunit}"
			+"</script>")
	public Integer selectPipelineSequence(@Param("period") String period, @Param("processingunit") String processingunit, @Param("pipelineType") String pipelineType, @Param("status") String status);
	
	
	@Insert("INSERT INTO CE_PIPELINERUN(pipelinerunseq, starttime,periodseq,userid,command,processingunitseq,removedate) "+
			" SELECT NEXT VALUE FOR CE_PIPELINERUN_SEQ, GETDATE(), CPR.PERIODSEQ,'SysAdmin',#{pipelineType},CP.processingunitseq,convert(date, '22000101') "+
			" FROM CE_PERIOD CPR, CE_PROCESSINGUNIT CP "+
			" WHERE "+
			" CPR.NAME=#{period} "+
			" AND CPR.REMOVEDATE='22000101' "+ 
			" AND CP.NAME=#{processingunit}")
    public void insertPipelineRun(@Param("period")String period, @Param("pipelineType")String pipelineType, @Param("processingunit")String processingunit);
	
	
	@Update(" <script>"
			+ "UPDATE CE_PIPELINERUN SET status=#{status},description=#{description} "
			+"<if test='stoptimeInd'>"
			+ " ,stoptime=getDate() "
			+"</if>"
			+ " WHERE pipelinerunseq=#{pipelinerunseq}"
			+"</script>")
    public void updatePipelineStatus(@Param("pipelinerunseq") String pipelinerunseq, @Param("status") String status, @Param("description") String description, @Param("stoptimeInd") boolean stoptimeInd);
	
	
	@Select(
	" select top 1 BJI.JOB_NAME, BJE.STATUS, max(BJE.CREATE_TIME) CURR_CRE_TIME from BATCH_JOB_EXECUTION BJE "+ 
	" INNER JOIN BATCH_JOB_INSTANCE BJI "+ 
	" ON BJE.JOB_INSTANCE_ID=BJI.JOB_INSTANCE_ID "+ 
	" WHERE "+ 
	" BJI.JOB_NAME = #{batchJobName} "+ 
	" GROUP BY BJI.JOB_NAME,BJE.STATUS "+
	" ORDER BY max(BJE.CREATE_TIME) desc" 
	)
	@ResultMap("retrieveSpringBatchStatus")
	public BatchModel retrieveSpringBatchStatus(@Param("batchJobName") String batchJobName);
}
