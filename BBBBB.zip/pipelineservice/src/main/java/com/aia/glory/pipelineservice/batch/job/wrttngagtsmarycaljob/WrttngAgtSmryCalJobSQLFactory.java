package com.aia.glory.pipelineservice.batch.job.wrttngagtsmarycaljob;

import com.aia.glory.pipelineservice.constant.PipelineConstant;

public class WrttngAgtSmryCalJobSQLFactory {
	
	private String pipelineSequence;
	
	public final  String COMMON_INSERT = "INSERT INTO CE_WRTTNGAGTSMRYCALJOB_STAGE (FREQUENCY,PERIOD,FQPERIOD,PERIODSEQ,BUSINESSUNITMAPSEQ,PROCESSINGUNITSEQ,PIPELINESEQ,PAYEEPOSSEQ,LEVEL,CHANNEL,COMPANY,MANPOWER,FYC,RYC,FYP,RYP,RELATIONSHIP,PAYOR,PAYEE,WRIAGENCYDATE,ROW_NUM,CREATEDATE) ";
	
	public final  String MONTHLY_SELECT = "SELECT 'MONTHLY' FREQUENCY,curPeriod.name PERIOD,cp.name FQPERIOD,curPeriod.periodseq PERIODSEQ,cs.businessunitmap BUSINESSUNITMAPSEQ,cs.processingunitseq PROCESSINGUNITSEQ,? PIPELINESEQ,payee_pos.positionseq PAYEEPOSSEQ,cd.name LEVEL,cb.name CHANNEL,cpu.name COMPANY, ";
	
	public final  String MONTHLY_WHERE = " and curPeriod.name = ? " +
										 " and cpu.name = ? "+
										 " and cp.startdate >= DATEADD(mm,DATEDIFF(mm,0,curPeriod.startdate)-{index},0) "+
										 " and cp.startdate <= DATEADD(ms,-3,DATEADD(mm,DATEDIFF(mm,0,curPeriod.startdate)+1-{index},0)) "+
										 " group by curPeriod.name, cp.name,curPeriod.periodseq,cs.businessunitmap,cs.processingunitseq,payee_pos.positionseq,cd.name,cb.name,cpu.name,payor_pos.name,payee_pos.name,cat.name ,cs.genericdate1  "+
										 " ORDER BY payor_pos.name,payee_pos.name,cat.name ";
	
	public final  String QUARTERLY_SELECT = "SELECT 'QUARTERLY' FREQUENCY,curPeriod.name PERIOD,DateName(year,cp.startdate) + DateName(quarter,cp.startdate) FQPeriod,curPeriod.periodseq PERIODSEQ,cs.businessunitmap BUSINESSUNITMAPSEQ,cs.processingunitseq PROCESSINGUNITSEQ,? PIPELINESEQ,payee_pos.positionseq PAYEEPOSSEQ,cd.name LEVEL,cb.name CHANNEL,cpu.name COMPANY, ";
	
	public final  String QUARTERLY_WHERE = " and curPeriod.name = ? " +
											" and cpu.name = ? "+
											" and cp.startdate >= DATEADD(Quarter,DATEDIFF(Quarter,0,curPeriod.startdate)-{index},0) "+
											" and cp.startdate <= DATEADD(ms,-3,DATEADD(Quarter,DATEDIFF(Quarter,0,curPeriod.startdate)+1-{index},0))  "+
											" group by curPeriod.name,DateName(year,cp.startdate) + DateName(quarter,cp.startdate),curPeriod.periodseq,cs.businessunitmap,cs.processingunitseq,payee_pos.positionseq,cd.name,cb.name,cpu.name,payor_pos.name,payee_pos.name,cat.name ,cs.genericdate1 "+
											" ORDER BY payor_pos.name,payee_pos.name,cat.name ";
	
	public final  String YEARLY_SELECT = "SELECT 'YEARLY' FREQUENCY,curPeriod.name PERIOD,DateName(year,cp.startdate) FQPeriod,curPeriod.periodseq PERIODSEQ,cs.businessunitmap BUSINESSUNITMAPSEQ,cs.processingunitseq PROCESSINGUNITSEQ,? PIPELINESEQ,payee_pos.positionseq PAYEEPOSSEQ,cd.name LEVEL,cb.name CHANNEL,cpu.name COMPANY, ";
	
	public final  String YEARLY_WHERE =  " and curPeriod.name = ? " +
												" and cpu.name = ? "+
												" and cp.startdate >= DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)-{index},0) "+
												" and cp.startdate <= DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1-{index},0)) "+
												" GROUP BY curPeriod.name,DateName(year,cp.startdate) ,curPeriod.periodseq,cs.businessunitmap,cs.processingunitseq,payee_pos.positionseq,cd.name,cb.name,cpu.name,payor_pos.name,payee_pos.name,cat.name ,cs.genericdate1 "+
												" ORDER BY payor_pos.name,payee_pos.name,cat.name  ";
	
	public final  String THREE_YEARLY_SELECT = "SELECT 'THREE_YEARLY' FREQUENCY,curPeriod.name PERIOD,DateName(year,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)-2,0))+'-'+DateName(year,DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1,0))) FQPERIOD,curPeriod.periodseq PERIODSEQ,cs.businessunitmap BUSINESSUNITMAPSEQ,cs.processingunitseq PROCESSINGUNITSEQ,? PIPELINESEQ,payee_pos.positionseq PAYEEPOSSEQ,cd.name LEVEL,cb.name CHANNEL,cpu.name COMPANY, ";
	
	public final  String THREE_YEARLY_WHERE = " and curPeriod.name = ? " +
												" and cpu.name = ? "+
												" and cp.startdate >= DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)-2,0) "+
												" and cp.startdate <= DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1,0))"+
												" GROUP BY curPeriod.name,DateName(year,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)-2,0))+'-'+DateName(year,DATEADD(ms,-3,DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1,0)))  ," + 
												"curPeriod.periodseq,cs.businessunitmap,cs.processingunitseq,payee_pos.positionseq,cd.name,cb.name,cpu.name,payor_pos.name,payee_pos.name,cat.name ,cs.genericdate1 " + 
												" ORDER BY payor_pos.name,payee_pos.name,cat.name ";
	
	public final  String COMMON_SELECT = " sum(case when ce.eventtypeid='FYC' then value else 0 end) FYC, "+
										 " sum(case when ce.eventtypeid='RYC' then value else 0 end) RYC, "+
										 " sum(case when ce.eventtypeid='FYP' then value else 0 end) FYP, "+
										 " sum(case when ce.eventtypeid='RYP' then value else 0 end) RYP, "+
										 " cat.name RELATIONSHIP,payor_pos.name PAYOR,payee_pos.name PAYEE, cs.genericdate1 wriAgencyDate,"+
										 " row_number() over(order by payor_pos.name,payee_pos.name, cat.name) ROW_NUM, getDate() CREATE_DATE" ;
	
	public final  String COMMON_FROM = " FROM ce_summary cs,ce_dimension cd,"
									 + "ce_period cp,ce_eventtype ce,ce_businessunit cb,"
									 + "ce_processingunit cpu,ce_assigntype cat,ce_assignment ca ,"
									 + "ce_position payor_pos, ce_participant payor_par,"
									 + "ce_position payee_pos, ce_participant payee_par, ce_period curPeriod " ;
	
	public final  String COMMON_WHERE = " WHERE cs.dimension1 = cd.dimensionseq "+
												"and cd.name = 'WRI_AGENCY' "+
												"and cp.periodseq = cs.periodseq "+
												"and ce.datatypeseq = cs.eventtypeseq "+
												"and cb.businessunitseq = cs.businessunitmap "
											  + "and cpu.processingunitseq = cs.processingunitseq "
											  + "and cs.summaryseq=ca.summaryseq "
											  + "and ca.assigntypeseq=cat.assigntypeseq "
											  + "and ca.positionseq = payee_pos.positionseq "
											  
											  + "and payee_pos.EFFECTIVESTARTDATE <=  cs.genericdate1 "
											  + "and payee_pos.EFFECTIVEENDDATE   >  cs.genericdate1 "
											  + "and payee_pos.removedate = convert(date, '22000101') "
											  + "and payee_pos.participantseq = payee_par.participantseq "
											  
											  + "and payee_par.EFFECTIVESTARTDATE <=  cs.genericdate1 "
											  + "and payee_par.EFFECTIVEENDDATE   >  cs.genericdate1 "
											  + "and payee_par.removedate = convert(date, '22000101') "
											  
											  + "and payor_pos.name = cs.dimension1ofvalue "
											  + "and payor_pos.EFFECTIVESTARTDATE <=  cs.genericdate1 "
											  + "and payor_pos.EFFECTIVEENDDATE   >  cs.genericdate1 "
											  + "and payor_pos.removedate = convert(date, '22000101') "
											  + "and payor_pos.participantseq = payor_par.participantseq "
											  
  											  + "and payor_par.EFFECTIVESTARTDATE <=  cs.genericdate1 "
  											  + "and payor_par.EFFECTIVEENDDATE   >  cs.genericdate1 "
											  + "and payor_par.removedate = convert(date, '22000101') ";
	
	public final String MONTH_MANPOWER =" sum(case when ce.eventtypeid='MP' and cp.enddate = DATEADD(mm,DATEDIFF(mm,0,curPeriod.startdate)+1-{index},0)-1  then value else 0 end) MANPOWER," ;
	
	public final String QUARTERLY_MANPOWER =" sum(case when ce.eventtypeid='MP' and cp.enddate = DATEADD(Quarter,DATEDIFF(Quarter,0,curPeriod.startdate)+1-{index},0)-1  then value else 0 end) MANPOWER," ;
	
	public final String YEARLY_MANPOWER =" sum(case when ce.eventtypeid='MP' and cp.enddate = DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1-{index},0)-1  then value else 0 end) MANPOWER," ;
	
	public final String THREE_YTARLY_MANPOWER =" sum(case when ce.eventtypeid='MP' and cp.enddate = DATEADD(Year,DATEDIFF(Year,0,curPeriod.startdate)+1,0)-1  then value else 0 end) MANPOWER," ;
	
	public WrttngAgtSmryCalJobSQLFactory(String pipelineSequence){
		this.pipelineSequence = pipelineSequence;
	}
	
	public  String getSql(String period, String index){
		String result = "";
		switch(period){
			case PipelineConstant.MONTHLY:
				result = constructMonthlySql(index);
				break;
			case PipelineConstant.QUARTERLY:
				result = constructQuarterlySql(index);
				break;
			case PipelineConstant.YEARLY:
				result = constructYearlySql(index);
				break;
			case PipelineConstant.THREE_YEARLY:
				result = constructThreeYearlySql();
				break;
			 default:
				 
	            break;
		}
		
		return result;
	}
	
	private  String constructMonthlySql(String index){
		
		StringBuffer result = new StringBuffer();
		switch(index){
			case PipelineConstant.CURRENT:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(MONTH_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT)).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT));
				break;
			case PipelineConstant.PREVIOUS_1:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(MONTH_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_2:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(MONTH_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_3:
				result.append(COMMON_INSERT).append(MONTHLY_SELECT).append(MONTH_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(MONTHLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1)));
				break;
			 default:
				 
	            break;
		}
		
		return result.toString();
	}
	
	private  String constructQuarterlySql(String index){
		
		StringBuffer result = new StringBuffer();
		switch(index){
			case PipelineConstant.CURRENT:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(QUARTERLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT)).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT));
				break;
			case PipelineConstant.PREVIOUS_1:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(QUARTERLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_2:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(QUARTERLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_3:
				result.append(COMMON_INSERT).append(QUARTERLY_SELECT).append(QUARTERLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(QUARTERLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1)));
				break;
			 default:
				 
	            break;
		}
		return result.toString();
	}
	
	private  String constructYearlySql(String index){
		StringBuffer result = new StringBuffer();
		switch(index){
			case PipelineConstant.CURRENT:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(YEARLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT)).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.CURRENT));
				break;
			case PipelineConstant.PREVIOUS_1:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(YEARLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_1.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_2:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(YEARLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_2.substring(1)));
				break;
			case PipelineConstant.PREVIOUS_3:
				result.append(COMMON_INSERT).append(YEARLY_SELECT).append(YEARLY_MANPOWER.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1))).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(YEARLY_WHERE.replace(PipelineConstant.INDEX_PLACE_HOLDER, PipelineConstant.PREVIOUS_3.substring(1)));
				break;
			 default:
				 
	            break;
		}
		return result.toString();
	}
	
	private  String constructThreeYearlySql(){
		StringBuffer result = new StringBuffer();
		result.append(COMMON_INSERT).append(THREE_YEARLY_SELECT).append(THREE_YTARLY_MANPOWER).append(COMMON_SELECT).append(COMMON_FROM).append(COMMON_WHERE).append(THREE_YEARLY_WHERE);
		return result.toString();
	}
}
