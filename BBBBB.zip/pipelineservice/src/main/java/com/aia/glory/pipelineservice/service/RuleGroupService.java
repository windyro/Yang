package com.aia.glory.pipelineservice.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.aia.glory.common.constant.ActionTypeConstant;
import com.aia.glory.common.http.HttpClient;
import com.aia.glory.common.model.rule.RuleDetailModel;
import com.aia.glory.common.model.rule.RuleGroupModel;
import com.aia.glory.common.util.JsonToObjectUtil;
import com.aia.glory.pipelineservice.mapper.RuleDetailMapper;
import com.aia.glory.pipelineservice.mapper.RuleGroupMapper;
import com.aia.glory.pipelineservice.request.GetRuleGroupRequest;
import com.aia.glory.pipelineservice.response.GetRuleGroupResponse;

@Service(value = "ruleGroupService")
public class RuleGroupService {
	
	@Autowired
    public RuleGroupMapper ruleGroupMapper;
	
	@Autowired
    public RuleDetailMapper ruleDetailMapper;
	
    @Value("${rule-service-url}")
    private String ruleServiceUrl;
	
	@Cacheable(value="ruleGroup")
	public List<RuleGroupModel> selectRuleGroup(String company,String summaryType){
		
		HttpClient httpClient = new HttpClient(ruleServiceUrl);
		GetRuleGroupRequest request = new GetRuleGroupRequest();
		request.setAction(ActionTypeConstant.GET);
		request.setCompany(company);
		request.setSummaryType(summaryType);
		GetRuleGroupResponse response = httpClient.post(request, GetRuleGroupResponse.class);
		
		return response.getRuleGroupModel();
	}

}
