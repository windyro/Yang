package com.aia.glory.pipelineservice.batch.job.finalizejob;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aia.glory.pipelineservice.batch.job.finalizejob.tasklet.FinalizeExecTasklet;

@Configuration
@EnableBatchProcessing
public class FinalizeJobConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;
    
    @Bean(name = "finalizeJob")
    public Job finalizeJob() 
      throws Exception {
        return jobBuilderFactory.get("finalizeJob")
          .start(finalizeStep())
          .build();
    }
    
    @Bean
    public Step finalizeStep() 
      throws Exception {
        return stepBuilderFactory.get("finalizeStep")
          .tasklet(new FinalizeExecTasklet(dataSource))
          .build();
    }
    
}
