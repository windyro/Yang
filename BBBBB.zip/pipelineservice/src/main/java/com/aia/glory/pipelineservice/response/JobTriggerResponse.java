package com.aia.glory.pipelineservice.response;

import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.common.model.response.Response;

public class JobTriggerResponse extends Response {
	
	private String JobStatus;

	public String getJobStatus() {
		return JobStatus;
	}

	public void setJobStatus(String jobStatus) {
		JobStatus = jobStatus;
	}
	
}
