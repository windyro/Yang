package com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.processor.CmmsnAgtSmryCalProcessor;
import com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.rowmapper.CmmsnAgtSmryCalRowMapper;
import com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.tasklet.CoreDataPreparationTasklet;
import com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.tasklet.SupportDataPreparationTasklet;
import com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.writter.CmmsnAgtSmryCalWritter;
import com.aia.glory.pipelineservice.batch.model.CmmsnAgtSmryCalModel;
import com.aia.glory.pipelineservice.batch.model.DepositModel;
import com.aia.glory.pipelineservice.batch.model.MeasurementModel;
import com.aia.glory.pipelineservice.batch.partitioner.ColumnRangePartitioner;
import com.aia.glory.pipelineservice.service.RuleGroupService;
import com.aia.glory.ruleengine.service.RuleService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Configuration
@EnableBatchProcessing
public class CmmsnAgtSmryCalJobConfig<T> {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    
	@Autowired
	@Qualifier(value = "ruleGroupService")
	private RuleGroupService ruleGroupService;
	
	@Autowired
	@Qualifier(value = "ruleService")
	private RuleService ruleService;

    @Autowired
    public DataSource dataSource;
    
    @Value("${summary-parition-threads}")
    private int maxThreads;
    
    @Value("${summary-parition-read-size}")
    private int readSize;
    
    @Value("${summary-parition-grid-size}")
    private int gridSize;
    
    @Value("${summary-parition-chunk-size}")
    private int chunkSize;
    
  	/*
  	 * Readers
  	 * 
  	 */
    @Bean
	@StepScope
	public JdbcPagingItemReader<CmmsnAgtSmryCalModel> cmmsnAgtSmryCalPartitionReader(@Value("#{stepExecutionContext[minValue]}") Integer minValue, @Value("#{stepExecutionContext[maxValue]}") Integer maxValue) throws Exception {
    	
    	JdbcPagingItemReader<CmmsnAgtSmryCalModel> reader = new JdbcPagingItemReader<CmmsnAgtSmryCalModel>();
    	reader.setDataSource(dataSource);
    	final SqlPagingQueryProviderFactoryBean sqlPagingQueryProviderFactoryBean = new SqlPagingQueryProviderFactoryBean();
    	sqlPagingQueryProviderFactoryBean.setDataSource(dataSource);
    	sqlPagingQueryProviderFactoryBean.setSelectClause("select FREQUENCY,PERIOD,FQPERIOD,PERIODSEQ,BUSINESSUNITMAPSEQ,PROCESSINGUNITSEQ,PIPELINESEQ,PAYEEPOSSEQ,LEVEL,CHANNEL,COMPANY,PAYOR_AGENCY_CODE,PAYOR_CONTRACT_DATE,PAYOR_LEADER_CODE,PAYOR_LEADER_TITLE,PAYOR_TERMINATEDATE,PAYOR_TITLE,PAYEE_AGENCY_CODE,PAYEE_CONTRACT_DATE,PAYEE_LEADER_CODE,PAYEE_LEADER_TITLE,PAYEE_TEMINATED_DATE,PAYEE_TITLE,FYC,RYC,FYP,RYP,RELATIONSHIP,PAYOR,PAYEE,ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setFromClause("from CE_CMMSNAGTSMRYCALJOB_STAGE");
    	sqlPagingQueryProviderFactoryBean.setSortKey("ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setWhereClause("ROW_NUM >= :minId and ROW_NUM <= :maxId");
    	reader.setQueryProvider(sqlPagingQueryProviderFactoryBean.getObject());
    	
    	reader.setRowMapper(new CmmsnAgtSmryCalRowMapper());
    	reader.setPageSize(readSize);
    	reader.setFetchSize(readSize);
    	
    	HashMap paramMap = new HashMap();
    	paramMap.put("minId", minValue);
    	paramMap.put("maxId", maxValue);
    	reader.setParameterValues(paramMap);
    	
        return reader;
    }
    
    /*
     * 
     * Processor
     * 
     */
    @Bean
	public CmmsnAgtSmryCalProcessor<T> cmmsnAgtSmryCalPartitionProcessor() throws JsonParseException, JsonMappingException, IOException {
    	
        return new CmmsnAgtSmryCalProcessor(ruleGroupService,ruleService);
    }
    
    /*
     * 
     * Writer
     * 
     */
    @Bean
	public CmmsnAgtSmryCalWritter<List<T>> cmmsnAgtSmryCalPartitionWriter() {
    	
    	CmmsnAgtSmryCalWritter<List<T>> writer = new CmmsnAgtSmryCalWritter<List<T>>();
    	
    	JdbcBatchItemWriter<DepositModel> depositWriteDelegate = new JdbcBatchItemWriter<DepositModel>();
    	depositWriteDelegate.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<DepositModel>());
    	depositWriteDelegate.setSql("INSERT INTO CE_DEPOSIT (DEPOSITSEQ,NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE,ISHELD) "
    			+ "VALUES (NEXT VALUE FOR CE_DEPOSIT_SEQ, :NAME, :POSITIONSEQ, :PERIODSEQ, :PIPELINERUNSEQ, :RULESEQ, :VALUE, :BUSINESSUNITMAP, :PROCESSINGUNITSEQ , getDate(), 0)");
    	depositWriteDelegate.setDataSource(dataSource);
    	
    	JdbcBatchItemWriter<MeasurementModel> measurementWriteDelegate = new JdbcBatchItemWriter<MeasurementModel>();
    	measurementWriteDelegate.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<MeasurementModel>());
    	measurementWriteDelegate.setSql("INSERT INTO CE_MEASUREMENT (MEASUREMENTSEQ,NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ) "
    			+ "VALUES (NEXT VALUE FOR CE_MEASUREMENT_SEQ, :NAME, :POSITIONSEQ, :PERIODSEQ, :PIPELINERUNSEQ, :RULESEQ, :VALUE, :BUSINESSUNITMAP, :PROCESSINGUNITSEQ)");
    	measurementWriteDelegate.setDataSource(dataSource);
    	
//    	delegate.afterPropertiesSet();
    	writer.setDelegate(depositWriteDelegate, measurementWriteDelegate);
    	
        return writer;
    }

    @Bean
    public ColumnRangePartitioner summaryCalculatePartitioner() {
    	ColumnRangePartitioner partitioner = new ColumnRangePartitioner();
    	partitioner.setDataSource(dataSource);
    	partitioner.setColumn("ROW_NUM");
    	partitioner.setTable("CE_CMMSNAGTSMRYCALJOB_STAGE");
        return partitioner;
    }
    
    @Bean(name = "cmmsnAgtSmryCalJob")
    public Job cmmsnAgtSmryCalJob() 
      throws Exception {
        return jobBuilderFactory.get("cmmsnAgtSmryCalJob")
          .start(cmmsnAgtSmryCalCoreDataPreStep()).next(cmmsnAgtSmryCalSupportDataPreStep()).next(cmmsnAgtSmryCalPartitionStep())
          .build();
    }
    
    @Bean
    public Step cmmsnAgtSmryCalCoreDataPreStep() 
      throws Exception {
        return stepBuilderFactory.get("cmmsnAgtSmryCalCoreDataPreStep")
          .tasklet(new CoreDataPreparationTasklet(dataSource,ruleGroupService))
          .build();
    }
    
    @Bean
    public Step cmmsnAgtSmryCalSupportDataPreStep() 
      throws Exception {
        return stepBuilderFactory.get("cmmsnAgtSmryCalSupportDataPreStep")
          .tasklet(new SupportDataPreparationTasklet(dataSource))
          .build();
    }
    
    @Bean
    public Step cmmsnAgtSmryCalPartitionStep() 
      throws Exception {
        return stepBuilderFactory.get("cmmsnAgtSmryCalPartitionStep")
          .partitioner("cmmsnAgtSmryCalPartitionStep_slave", summaryCalculatePartitioner()).gridSize(gridSize)
//          .partitionHandler(partitionHandler)
          .step(cmmsnAgtSmryCalPartitionStep_slave())
          .taskExecutor(cmmsnAgtSmryCalTaskExecutor())
          .build();
    }
    
    @Bean
    public Step cmmsnAgtSmryCalPartitionStep_slave() 
      throws Exception {
        return stepBuilderFactory.get("cmmsnAgtSmryCalPartitionStep_slave").<CmmsnAgtSmryCalModel, List<T>> chunk(chunkSize)
				.reader(cmmsnAgtSmryCalPartitionReader(null, null))
				.processor(cmmsnAgtSmryCalPartitionProcessor())
				.writer(cmmsnAgtSmryCalPartitionWriter())
                .build();
    }
    
    @Bean
    public TaskExecutor cmmsnAgtSmryCalTaskExecutor() {
    	SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
    	taskExecutor.setConcurrencyLimit(maxThreads);
    	return taskExecutor;
    }
}
