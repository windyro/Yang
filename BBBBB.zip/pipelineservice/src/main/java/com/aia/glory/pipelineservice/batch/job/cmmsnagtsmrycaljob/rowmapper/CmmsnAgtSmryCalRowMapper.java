package com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.aia.glory.pipelineservice.batch.model.CmmsnAgtSmryCalModel;

public class CmmsnAgtSmryCalRowMapper implements RowMapper{
	
	public CmmsnAgtSmryCalRowMapper() {
		// implementation ignored
	}
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		CmmsnAgtSmryCalModel cmmsnAgtSmryCalModel = new CmmsnAgtSmryCalModel();
		cmmsnAgtSmryCalModel.setFrequency(rs.getString("FREQUENCY"));
		cmmsnAgtSmryCalModel.setPeriod(rs.getString("PERIOD"));
		cmmsnAgtSmryCalModel.setFqPeriod(rs.getString("FQPERIOD"));
		cmmsnAgtSmryCalModel.setPeriodSequence(rs.getString("PERIODSEQ"));
		cmmsnAgtSmryCalModel.setBusinessUnitMapSeq(rs.getString("BUSINESSUNITMAPSEQ"));
		cmmsnAgtSmryCalModel.setProcessingUnitSeq(rs.getString("PROCESSINGUNITSEQ"));
		cmmsnAgtSmryCalModel.setPipelineSequence(rs.getString("PIPELINESEQ"));
		cmmsnAgtSmryCalModel.setPayeePositionSequence(rs.getString("PAYEEPOSSEQ"));
		cmmsnAgtSmryCalModel.setLevel(rs.getString("LEVEL"));
		cmmsnAgtSmryCalModel.setChannel(rs.getString("CHANNEL"));
		cmmsnAgtSmryCalModel.setCompany(rs.getString("COMPANY"));
		cmmsnAgtSmryCalModel.setFyc(String.valueOf(rs.getDouble("FYC")));
		cmmsnAgtSmryCalModel.setRyc(String.valueOf(rs.getDouble("RYC")));
		cmmsnAgtSmryCalModel.setFyp(String.valueOf(rs.getDouble("FYP")));
		cmmsnAgtSmryCalModel.setRyp(String.valueOf(rs.getDouble("RYP")));
		cmmsnAgtSmryCalModel.setRelationShip(rs.getString("RELATIONSHIP"));
		cmmsnAgtSmryCalModel.setPayor(rs.getString("PAYOR"));
		cmmsnAgtSmryCalModel.setPayee(rs.getString("PAYEE"));
		
		cmmsnAgtSmryCalModel.setPayeeAgencyCode(rs.getString("PAYEE_AGENCY_CODE"));
		cmmsnAgtSmryCalModel.setPayeeContractDate(rs.getString("PAYEE_CONTRACT_DATE"));
		cmmsnAgtSmryCalModel.setPayeeLeaderCode(rs.getString("PAYEE_LEADER_CODE"));
		cmmsnAgtSmryCalModel.setPayeeLeaderTitle(rs.getString("PAYEE_LEADER_TITLE"));
		cmmsnAgtSmryCalModel.setPayeeTeminatedDate(rs.getString("PAYEE_TEMINATED_DATE"));
		cmmsnAgtSmryCalModel.setPayeeTitle(rs.getString("PAYEE_TITLE"));
		
		cmmsnAgtSmryCalModel.setPayorAgencyCode(rs.getString("PAYOR_AGENCY_CODE"));
		cmmsnAgtSmryCalModel.setPayorContractDate(rs.getString("PAYOR_CONTRACT_DATE"));
		cmmsnAgtSmryCalModel.setPayorLeaderCode(rs.getString("PAYOR_LEADER_CODE"));
		cmmsnAgtSmryCalModel.setPayorLeaderTitle(rs.getString("PAYOR_LEADER_TITLE"));
		cmmsnAgtSmryCalModel.setPayorTeminatedDate(rs.getString("PAYOR_TERMINATEDATE"));
		cmmsnAgtSmryCalModel.setPayorTitle(rs.getString("PAYOR_TITLE"));
		
		cmmsnAgtSmryCalModel.setRelationShip(rs.getString("RELATIONSHIP"));
		
		return cmmsnAgtSmryCalModel;
	}
}
