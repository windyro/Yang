package com.aia.glory.pipelineservice.batch.job.cmmsnagtsmrycaljob.tasklet;

import javax.sql.DataSource;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class SupportDataPreparationTasklet implements Tasklet{
	
	private JdbcTemplate jdbcTemplate;
	
	public SupportDataPreparationTasklet(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		
		//Prepare Payor support data
		jdbcTemplate.execute("UPDATE CE_CMMSNAGTSMRYCALJOB_STAGE "
				+ " set PAYOR_LEADER_CODE=PAYOR_POS.LeaderCode,PAYOR_LEADER_TITLE=PAYOR_POS.GENERICATTRIBUTE4,PAYOR_TITLE=PAYOR_TITLE.NAME,PAYOR_CONTRACT_DATE=PAYOR_PAR.HIREDATE,PAYOR_TERMINATEDATE=PAYOR_PAR.TERMINATIONDATE,PAYOR_AGENCY_CODE=PAYOR_POS.GENERICATTRIBUTE1 "
				+ " from CE_CMMSNAGTSMRYCALJOB_STAGE CT "
				+ " INNER JOIN CE_POSITION PAYOR_POS ON CT.PAYOR = PAYOR_POS.NAME and PAYOR_POS.removedate = convert(date, '22000101') and PAYOR_POS.ISLAST=1"
				+ " INNER JOIN CE_TITLE PAYOR_TITLE ON PAYOR_POS.TITLESEQ = PAYOR_TITLE.TITLESEQ "
				+ " INNER JOIN CE_PARTICIPANT PAYOR_PAR ON PAYOR_POS.PARTICIPANTSEQ = PAYOR_PAR.PARTICIPANTSEQ and PAYOR_PAR.removedate = convert(date, '22000101') and PAYOR_PAR.ISLAST=1"
				);
		
		//Prepare Payee support data
		jdbcTemplate.execute("UPDATE CE_CMMSNAGTSMRYCALJOB_STAGE "
				+ "set PAYEE_LEADER_CODE=PAYEE_POS.LeaderCode,PAYEE_LEADER_TITLE=PAYEE_POS.GENERICATTRIBUTE4,PAYEE_TITLE=TITLE.NAME,PAYEE_CONTRACT_DATE=PAYEE_PAR.HIREDATE,PAYEE_TEMINATED_DATE=PAYEE_PAR.TERMINATIONDATE,PAYEE_AGENCY_CODE=PAYEE_POS.GENERICATTRIBUTE1 "
				+ "from CE_CMMSNAGTSMRYCALJOB_STAGE CT "
				+ "INNER JOIN CE_POSITION PAYEE_POS ON CT.PAYEE = PAYEE_POS.NAME and PAYEE_POS.removedate = convert(date, '22000101') and PAYEE_POS.ISLAST=1"
				+ "INNER JOIN CE_TITLE TITLE ON PAYEE_POS.TITLESEQ = TITLE.TITLESEQ "
				+ "INNER JOIN CE_PARTICIPANT PAYEE_PAR ON PAYEE_POS.PARTICIPANTSEQ = PAYEE_PAR.PARTICIPANTSEQ and PAYEE_PAR.removedate = convert(date, '22000101') and PAYEE_PAR.ISLAST=1");
		
		return null;
	}

}
