package com.aia.glory.pipelineservice.batch.model;


public class CmmsnAgtSmryCalModel {
	
	private String frequency;
	
	private String period;
	
	private String fqPeriod;
	
	private String businessUnitMapSeq;
	
	private String processingUnitSeq;
	
	private String periodSequence;
	
	private String pipelineSequence;
	
	private String payeePositionSequence;
	
	private String level;
	
	private String channel;
	
	private String company;
	
    private String payorTitle;
	
	private String payorClasscode;
	
	private String payorLeaderTitle;
	
	private String payorLeaderCode;
	
	private String payorContractDate;
	
	private String payorTeminatedDate;

	private String payeeTitle;
	
	private String payeeClasscode;
	
	private String payeeLeaderTitle;
	
	private String payeeLeaderCode;
	
	private String payeeContractDate;
	
	private String payeeTeminatedDate;
	
	private String fyc;
	
	private String ryc;
	
	private String fyp;
	
	private String ryp;
	
	private String relationShip;
	
	private String payor;
	
	private String payee;

	private String payorAgencyCode;
	
	private String payeeAgencyCode;
	
	
	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getFqPeriod() {
		return fqPeriod;
	}

	public void setFqPeriod(String fqPeriod) {
		this.fqPeriod = fqPeriod;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getBusinessUnitMapSeq() {
		return businessUnitMapSeq;
	}

	public void setBusinessUnitMapSeq(String businessUnitMapSeq) {
		this.businessUnitMapSeq = businessUnitMapSeq;
	}

	public String getProcessingUnitSeq() {
		return processingUnitSeq;
	}

	public void setProcessingUnitSeq(String processingUnitSeq) {
		this.processingUnitSeq = processingUnitSeq;
	}

	public String getPeriodSequence() {
		return periodSequence;
	}

	public void setPeriodSequence(String periodSequence) {
		this.periodSequence = periodSequence;
	}

	public String getPipelineSequence() {
		return pipelineSequence;
	}

	public void setPipelineSequence(String pipelineSequence) {
		this.pipelineSequence = pipelineSequence;
	}

	public String getPayeePositionSequence() {
		return payeePositionSequence;
	}

	public void setPayeePositionSequence(String payeePositionSequence) {
		this.payeePositionSequence = payeePositionSequence;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPayorTitle() {
		return payorTitle;
	}

	public void setPayorTitle(String payorTitle) {
		this.payorTitle = payorTitle;
	}

	public String getPayorClasscode() {
		return payorClasscode;
	}

	public void setPayorClasscode(String payorClasscode) {
		this.payorClasscode = payorClasscode;
	}

	public String getPayorLeaderTitle() {
		return payorLeaderTitle;
	}

	public void setPayorLeaderTitle(String payorLeaderTitle) {
		this.payorLeaderTitle = payorLeaderTitle;
	}

	public String getPayorLeaderCode() {
		return payorLeaderCode;
	}

	public void setPayorLeaderCode(String payorLeaderCode) {
		this.payorLeaderCode = payorLeaderCode;
	}

	public String getPayorContractDate() {
		return payorContractDate;
	}

	public void setPayorContractDate(String payorContractDate) {
		this.payorContractDate = payorContractDate;
	}

	public String getPayorTeminatedDate() {
		return payorTeminatedDate;
	}

	public void setPayorTeminatedDate(String payorTeminatedDate) {
		this.payorTeminatedDate = payorTeminatedDate;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeClasscode() {
		return payeeClasscode;
	}

	public void setPayeeClasscode(String payeeClasscode) {
		this.payeeClasscode = payeeClasscode;
	}

	public String getPayeeLeaderTitle() {
		return payeeLeaderTitle;
	}

	public void setPayeeLeaderTitle(String payeeLeaderTitle) {
		this.payeeLeaderTitle = payeeLeaderTitle;
	}

	public String getPayeeLeaderCode() {
		return payeeLeaderCode;
	}

	public void setPayeeLeaderCode(String payeeLeaderCode) {
		this.payeeLeaderCode = payeeLeaderCode;
	}

	public String getPayeeContractDate() {
		return payeeContractDate;
	}

	public void setPayeeContractDate(String payeeContractDate) {
		this.payeeContractDate = payeeContractDate;
	}

	public String getPayeeTeminatedDate() {
		return payeeTeminatedDate;
	}

	public void setPayeeTeminatedDate(String payeeTeminatedDate) {
		this.payeeTeminatedDate = payeeTeminatedDate;
	}

	public String getFyc() {
		return fyc;
	}

	public void setFyc(String fyc) {
		this.fyc = fyc;
	}

	public String getRyc() {
		return ryc;
	}

	public void setRyc(String ryc) {
		this.ryc = ryc;
	}

	public String getFyp() {
		return fyp;
	}

	public void setFyp(String fyp) {
		this.fyp = fyp;
	}

	public String getRyp() {
		return ryp;
	}

	public void setRyp(String ryp) {
		this.ryp = ryp;
	}

	public String getRelationShip() {
		return relationShip;
	}

	public void setRelationShip(String relationShip) {
		this.relationShip = relationShip;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getPayorAgencyCode() {
		return payorAgencyCode;
	}

	public void setPayorAgencyCode(String payorAgencyCode) {
		this.payorAgencyCode = payorAgencyCode;
	}

	public String getPayeeAgencyCode() {
		return payeeAgencyCode;
	}

	public void setPayeeAgencyCode(String payeeAgencyCode) {
		this.payeeAgencyCode = payeeAgencyCode;
	}

	@Override
	public String toString() {
		return "CmmsnAgtSmryCalModel [frequency=" + frequency + ", period="
				+ period + ", fqPeriod=" + fqPeriod + ", businessUnitMapSeq="
				+ businessUnitMapSeq + ", processingUnitSeq="
				+ processingUnitSeq + ", periodSequence=" + periodSequence
				+ ", pipelineSequence=" + pipelineSequence
				+ ", payeePositionSequence=" + payeePositionSequence
				+ ", level=" + level + ", channel=" + channel + ", company="
				+ company + ", payorTitle=" + payorTitle + ", payorClasscode="
				+ payorClasscode + ", payorLeaderTitle=" + payorLeaderTitle
				+ ", payorLeaderCode=" + payorLeaderCode
				+ ", payorContractDate=" + payorContractDate
				+ ", payorTeminatedDate=" + payorTeminatedDate
				+ ", payeeTitle=" + payeeTitle + ", payeeClasscode="
				+ payeeClasscode + ", payeeLeaderTitle=" + payeeLeaderTitle
				+ ", payeeLeaderCode=" + payeeLeaderCode
				+ ", payeeContractDate=" + payeeContractDate
				+ ", payeeTeminatedDate=" + payeeTeminatedDate + ", fyc=" + fyc
				+ ", ryc=" + ryc + ", fyp=" + fyp + ", ryp=" + ryp
				+ ", relationShip=" + relationShip + ", payor=" + payor
				+ ", payee=" + payee + ", payorAgencyCode=" + payorAgencyCode
				+ ", payeeAgencyCode=" + payeeAgencyCode + "]";
	}

}
