package com.aia.glory.pipelineservice.batch.job.measurementjob.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.aia.glory.pipelineservice.batch.model.MeasurementCalModel;

public class MrsrmntCalRowMapper implements RowMapper{
	
	public MrsrmntCalRowMapper() {
		// implementation ignored
	}
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		MeasurementCalModel measurementCalModel = new MeasurementCalModel();
		measurementCalModel.setMeasurementName(rs.getString("MEASUREMENT_NAME"));
		measurementCalModel.setFrequency(rs.getString("FREQUENCY"));
		measurementCalModel.setPeriod(rs.getString("PERIOD"));
		measurementCalModel.setPeriodSequence(rs.getString("PERIODSEQ"));
		measurementCalModel.setFqPeriod(rs.getString("FQPeriod"));
		measurementCalModel.setBusinessUnitMapSeq(rs.getString("BUSINESSUNITMAP"));
		measurementCalModel.setProcessingUnitSeq(rs.getString("PROCESSINGUNITSEQ"));
		measurementCalModel.setPipelineSequence(rs.getString("PIPELINERUNSEQ"));
		measurementCalModel.setPayeePositionSequence(rs.getString("PAYEEPOSSEQ"));
		measurementCalModel.setChannel(rs.getString("CHANNEL"));
		measurementCalModel.setCompany(rs.getString("COMPANY"));
		measurementCalModel.setMeasurementVaule(String.valueOf(rs.getDouble("VALUE")));
		measurementCalModel.setPayee(rs.getString("PAYEE_CODE"));
		
//		measurementCalModel.setPayeeAgencyCode(rs.getString("PAYEE_AGENCY_CODE"));
//		measurementCalModel.setPayeeContractDate(rs.getString("PAYEE_CONTRACT_DATE"));
//		measurementCalModel.setPayeeLeaderCode(rs.getString("PAYEE_LEADER_CODE"));
		measurementCalModel.setPayeeLeaderTitle(rs.getString("PAYEE_LEADER_TITLE"));
//		measurementCalModel.setPayeeTeminatedDate(rs.getString("PAYEE_TEMINATED_DATE"));
		measurementCalModel.setPayeeTitle(rs.getString("PAYEE_TITLE"));
		
		return measurementCalModel;
	}
}
