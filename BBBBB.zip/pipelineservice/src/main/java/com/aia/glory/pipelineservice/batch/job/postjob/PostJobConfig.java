package com.aia.glory.pipelineservice.batch.job.postjob;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aia.glory.pipelineservice.batch.job.postjob.tasklet.PostExecTasklet;

@Configuration
@EnableBatchProcessing
public class PostJobConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;
    
    @Bean(name = "postJob")
    public Job postJob() 
      throws Exception {
        return jobBuilderFactory.get("postJob")
          .start(postStep())
          .build();
    }
    
    @Bean
    public Step postStep() 
      throws Exception {
        return stepBuilderFactory.get("postStep")
          .tasklet(new PostExecTasklet(dataSource))
          .build();
    }
    
}
