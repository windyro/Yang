package com.aia.glory.pipelineservice.enumerate;

public enum PipelineStatus {
	
	Successful,
	
	Processing,
	
	Fail,
	
}
