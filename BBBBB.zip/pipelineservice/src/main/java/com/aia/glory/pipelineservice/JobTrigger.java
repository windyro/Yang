package com.aia.glory.pipelineservice;

import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.ConfigurableApplicationContext;


public class JobTrigger {
	
	static Log debugLog = LogFactory.getLog("sysDebug");
	
	static Log errorLog = LogFactory.getLog("sysError");
	
	private JobTrigger() {
	    throw new IllegalStateException("Utility class");
	  }
	
	public static final HashMap<String,String> map = new HashMap<String,String>();
	static{
		{
			map.put("001", "cmmsnAgtSmryCalJob");
			map.put("002", "wrttngAgtSmryCalJob");
			map.put("003", "pipelineCleanJob");
			map.put("004", "smrygnnrtjob");
			map.put("005", "postJob");
			map.put("006", "finalizeJob");
			map.put("007", "measurementCalJob");
		}
	};

	public static String trigger(String jobNum,
			ConfigurableApplicationContext ctx, HashMap<String,String> paramsMap)
			throws JobExecutionAlreadyRunningException, JobRestartException,
			JobInstanceAlreadyCompleteException, JobParametersInvalidException,
			InterruptedException {

				JobLauncher jobLauncher = ctx.getBean(JobLauncher.class);
				Job job = ctx.getBean((String) map.get(jobNum),Job.class);
				JobParametersBuilder jobparameterBuilder = new JobParametersBuilder();
				jobparameterBuilder.addDate("date", new Date());
				if(MapUtils.isNotEmpty(paramsMap)){
					for(Entry<String, String> entry : paramsMap.entrySet()){
						jobparameterBuilder.addString(entry.getKey(), entry.getValue());
					}
				}
				JobExecution jobExecution = jobLauncher.run(job,jobparameterBuilder.toJobParameters());
				BatchStatus batchStatus = jobExecution.getStatus();
				while (batchStatus.isRunning()) {
					debugLog.info("*********** Still running.... **************");
					Thread.sleep(1000);
				}
				debugLog.info(String.format("*********** Exit status: %s",
						jobExecution.getExitStatus().getExitCode()));
				JobInstance jobInstance = jobExecution.getJobInstance();
				debugLog.info(String.format("********* Name of the job %s",
						jobInstance.getJobName()));
				debugLog.info(String.format("*********** job instance Id: %d",
						jobInstance.getId()));

		return "SUCCESS";
	}

}
