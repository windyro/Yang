package com.aia.glory.pipelineservice.service;

import java.text.ParseException;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.drools.core.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.aia.glory.common.util.LogUtils;
import com.aia.glory.common.util.TimeUtils;
import com.aia.glory.pipelineservice.JobTrigger;
import com.aia.glory.pipelineservice.batch.model.BatchModel;
import com.aia.glory.pipelineservice.constant.PipelineConstant;
import com.aia.glory.pipelineservice.enumerate.PipelineStatus;
import com.aia.glory.pipelineservice.enumerate.PipelineType;
import com.aia.glory.pipelineservice.enumerate.SpringBatchStatus;
import com.aia.glory.pipelineservice.exception.JobFailException;
import com.aia.glory.pipelineservice.mapper.PipelineInfoMapper;
import com.aia.glory.pipelineservice.request.JobTriggerRequest;

@Service(value = "jobTriggerService")
public class JobTriggerService {

    Log debugLog = LogFactory.getLog("sysDebug");
	
	Log errorLog = LogFactory.getLog("sysError");
	
	@Autowired
	private ApplicationContext context;
	
	@Autowired
    public PipelineInfoMapper pipelineInfoMapper;
	
	
	@Async("asyncExecutor")
	public void trigger(JobTriggerRequest jobTriggerRequest){
		
		try {
			//get pipeline with businessunit
			String pipelineTypeKey = jobTriggerRequest.getCompensationType();
			String period = TimeUtils.parseSystemPeriod(jobTriggerRequest.getPeriod());
			String processingunit = jobTriggerRequest.getCompany();
			
			if(PipelineType.COMP_AND_PAY.getCode().equals(pipelineTypeKey)){
				compAndPay(period,processingunit);
				return;
			}
			
			if(PipelineType.POST.getCode().equals(pipelineTypeKey)){
				postPipeline(period,processingunit);
				return;
			}
			
			if(PipelineType.FINALIZE.getCode().equals(pipelineTypeKey)){
				finalizePipeline(period,processingunit);
				return;
			}
		
		} catch (ParseException e) {
			errorLog.error(LogUtils.errorTrackSpace(e));
		} catch (Exception e) {
			errorLog.error(LogUtils.errorTrackSpace(e));
		}
	}
	
	private void compAndPay(String period, String processingunit) throws Exception{
		
		String pipelineType = PipelineType.COMP_AND_PAY.getValue();

		BatchModel batchModel = null;
		Integer prevPipelineSequence = pipelineInfoMapper.selectPipelineSequence(period,processingunit,pipelineType,null);
		String prevPipelineSequenceStr = prevPipelineSequence == null ? "" : prevPipelineSequence.toString();
		
		HashMap jobParams = new HashMap();
		jobParams.put(PipelineConstant.PROCESSINGUNIT, processingunit);
		jobParams.put(PipelineConstant.PERIOD, period);
		jobParams.put(PipelineConstant.PIPELINE_SEQ, String.valueOf(prevPipelineSequenceStr));
		
		pipelineInfoMapper.insertPipelineRun(period, pipelineType, processingunit);
		
		String newPipelineSequence = pipelineInfoMapper.selectPipelineSequence(period,processingunit,pipelineType,null).toString();
		//call clear privious pipline job
		if(!StringUtils.isEmpty(prevPipelineSequenceStr)){runSpringBatchJob(newPipelineSequence,"003",jobParams);}
		
		jobParams.put(PipelineConstant.PIPELINE_SEQ, String.valueOf(newPipelineSequence));
		//call summary generation job
		runSpringBatchJob(newPipelineSequence,"004",jobParams);
		
		//call commission agent job
		runSpringBatchJob(newPipelineSequence,"001",jobParams);
		
		//call writting agency job
		runSpringBatchJob(newPipelineSequence,"002",jobParams);
		
		//call measurement job
		runSpringBatchJob(newPipelineSequence,"007",jobParams);
		
		pipelineInfoMapper.updatePipelineStatus(newPipelineSequence, PipelineStatus.Successful.name(),PipelineStatus.Successful.name(), true);
		
	}
	
	
	private void postPipeline(String period, String processingunit) throws Exception{
	
		String pipelineType = PipelineType.POST.getValue();
		
		pipelineInfoMapper.insertPipelineRun(period, pipelineType, processingunit);
		String newPipelineSequence = String.valueOf(pipelineInfoMapper.selectPipelineSequence(period,processingunit,pipelineType,null));
		
		HashMap jobParams = new HashMap();
		jobParams.put(PipelineConstant.PIPELINE_SEQ, newPipelineSequence);
		
		//call post job
		runSpringBatchJob(newPipelineSequence,"005",jobParams);
		
		pipelineInfoMapper.updatePipelineStatus(newPipelineSequence, PipelineStatus.Successful.name(),PipelineStatus.Successful.name(), true);
	}
	
	
	private void finalizePipeline(String period, String processingunit) throws Exception{
		
		String pipelineType = PipelineType.FINALIZE.getValue();
		
		pipelineInfoMapper.insertPipelineRun(period, pipelineType, processingunit);
		String newPipelineSequence = String.valueOf(pipelineInfoMapper.selectPipelineSequence(period,processingunit,pipelineType,null));
		
		HashMap jobParams = new HashMap();
		jobParams.put(PipelineConstant.PIPELINE_SEQ, newPipelineSequence);
		
		//call finalize job
		runSpringBatchJob(newPipelineSequence,"006",jobParams);
		
		pipelineInfoMapper.updatePipelineStatus(newPipelineSequence, PipelineStatus.Successful.name(),PipelineStatus.Successful.name(), true);
	}
	
	
	private BatchModel runSpringBatchJob(String pipelineSequence, String jobId, HashMap jobParams) throws Exception{
		
		String jobName = (String) JobTrigger.map.get(jobId);
		pipelineInfoMapper.updatePipelineStatus(pipelineSequence, PipelineStatus.Processing.name(), jobName + PipelineConstant.PROCESS_SUFFIX, false);
		JobTrigger.trigger(jobId, (ConfigurableApplicationContext) context, jobParams);
		BatchModel batchModel = pipelineInfoMapper.retrieveSpringBatchStatus(jobName);
		
		if(!SpringBatchStatus.COMPLETED.name().equals(batchModel.getJobStatus())){
			pipelineInfoMapper.updatePipelineStatus(pipelineSequence, PipelineStatus.Fail.name(),batchModel.getJobName() + PipelineConstant.FAIL_SUFFIX, false);
			throw new JobFailException();
		}else{
			pipelineInfoMapper.updatePipelineStatus(pipelineSequence, PipelineStatus.Processing.name() ,batchModel.getJobName() + PipelineConstant.SUCCESSFUL_SUFFIX, false);
		}
		
		return batchModel;
	}
	
}
