package com.aia.glory.pipelineservice.batch.job.measurementjob;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import com.aia.glory.pipelineservice.batch.job.measurementjob.processor.MeasurementCalProcessor;
import com.aia.glory.pipelineservice.batch.job.measurementjob.rowmapper.MrsrmntCalRowMapper;
import com.aia.glory.pipelineservice.batch.job.measurementjob.tasklet.MrsrmntCoreDataPreparationTasklet;
import com.aia.glory.pipelineservice.batch.job.measurementjob.writter.MeasurementCalWritter;
import com.aia.glory.pipelineservice.batch.model.DepositModel;
import com.aia.glory.pipelineservice.batch.model.MeasurementCalModel;
import com.aia.glory.pipelineservice.batch.model.MeasurementModel;
import com.aia.glory.pipelineservice.batch.partitioner.ColumnRangePartitioner;
import com.aia.glory.pipelineservice.service.RuleGroupService;
import com.aia.glory.ruleengine.service.RuleService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Configuration
@EnableBatchProcessing
public class MearsurementCalJobConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    
	@Autowired
	@Qualifier(value = "ruleGroupService")
	private RuleGroupService ruleGroupService;
	
	@Autowired
	@Qualifier(value = "ruleService")
	private RuleService ruleService;

    @Autowired
    public DataSource dataSource;
    
    @Value("${summary-parition-threads}")
    private int maxThreads;
    
    @Value("${summary-parition-read-size}")
    private int readSize;
    
    @Value("${summary-parition-grid-size}")
    private int gridSize;
    
    @Value("${summary-parition-chunk-size}")
    private int chunkSize;
    
  	/*
  	 * Readers
  	 * 
  	 */
    @Bean
	@StepScope
	public JdbcPagingItemReader<MeasurementCalModel> measurementCalPartitionReader(@Value("#{stepExecutionContext[minValue]}") Integer minValue, @Value("#{stepExecutionContext[maxValue]}") Integer maxValue) throws Exception {
    	
    	JdbcPagingItemReader<MeasurementCalModel> reader = new JdbcPagingItemReader<MeasurementCalModel>();
    	reader.setDataSource(dataSource);
		final SqlPagingQueryProviderFactoryBean sqlPagingQueryProviderFactoryBean = new SqlPagingQueryProviderFactoryBean();
    	sqlPagingQueryProviderFactoryBean.setDataSource(dataSource);
    	sqlPagingQueryProviderFactoryBean.setSelectClause("select FREQUENCY,PERIOD,PERIODSEQ,FQPeriod,MEASUREMENT_NAME,PIPELINERUNSEQ,PAYEEPOSSEQ,POSITION_TYPE,PAYEE_CODE,PAYEE_TITLE,PAYEE_LEADER_TITLE,VALUE,BUSINESSUNITMAP,CHANNEL,PROCESSINGUNITSEQ,company,ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setFromClause("from CE_MEASUREMENTCALJOB_STAGE");
    	sqlPagingQueryProviderFactoryBean.setSortKey("ROW_NUM");
    	sqlPagingQueryProviderFactoryBean.setWhereClause("ROW_NUM >= :minId and ROW_NUM <= :maxId");
    	reader.setQueryProvider(sqlPagingQueryProviderFactoryBean.getObject());
    	
    	reader.setRowMapper(new MrsrmntCalRowMapper());
    	reader.setPageSize(readSize);
    	reader.setFetchSize(readSize);
    	
    	HashMap paramMap = new HashMap();
    	paramMap.put("minId", minValue);
    	paramMap.put("maxId", maxValue);
    	reader.setParameterValues(paramMap);
    	
        return reader;
    }
    
    /*
     * 
     * Processor
     * 
     */
    @Bean
	public MeasurementCalProcessor measurementCalPartitionProcessor() throws JsonParseException, JsonMappingException, IOException {
    	
        return new MeasurementCalProcessor(ruleGroupService,ruleService);
    }
    
    /*
     * 
     * Writer
     * 
     */
    @Bean
	public MeasurementCalWritter<List<T>> measurementCalPartitionWriter() {
    	
    	MeasurementCalWritter<List<T>> writer = new MeasurementCalWritter<List<T>>();
     	JdbcBatchItemWriter<DepositModel> depositWriteDelegate = new JdbcBatchItemWriter<DepositModel>();
    	depositWriteDelegate.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<DepositModel>());
    	depositWriteDelegate.setSql("INSERT INTO CE_DEPOSIT (DEPOSITSEQ,NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ,DEPOSITDATE,ISHELD) "
    			+ "VALUES (NEXT VALUE FOR CE_DEPOSIT_SEQ, :NAME, :POSITIONSEQ, :PERIODSEQ, :PIPELINERUNSEQ, :RULESEQ, :VALUE, :BUSINESSUNITMAP, :PROCESSINGUNITSEQ , getDate(), 0)");
    	depositWriteDelegate.setDataSource(dataSource);
    	
    	JdbcBatchItemWriter<MeasurementModel> measurementWriteDelegate = new JdbcBatchItemWriter<MeasurementModel>();
    	measurementWriteDelegate.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<MeasurementModel>());
    	measurementWriteDelegate.setSql("INSERT INTO CE_MEASUREMENT (MEASUREMENTSEQ,NAME,POSITIONSEQ,PERIODSEQ,PIPELINERUNSEQ,RULESEQ,VALUE,BUSINESSUNITMAP,PROCESSINGUNITSEQ) "
    			+ "VALUES (NEXT VALUE FOR CE_MEASUREMENT_SEQ, :NAME, :POSITIONSEQ, :PERIODSEQ, :PIPELINERUNSEQ, :RULESEQ, :VALUE, :BUSINESSUNITMAP, :PROCESSINGUNITSEQ)");
    	measurementWriteDelegate.setDataSource(dataSource);
    	
    	writer.setDelegate(depositWriteDelegate, measurementWriteDelegate);
    	
        return writer;
    }

    @Bean
    public ColumnRangePartitioner measurementCalculatePartitioner() {
    	ColumnRangePartitioner partitioner = new ColumnRangePartitioner();
    	partitioner.setDataSource(dataSource);
    	partitioner.setColumn("ROW_NUM");
    	partitioner.setTable("CE_MEASUREMENTCALJOB_STAGE");
        return partitioner;
    }
    
    @Bean(name = "measurementCalJob")
    public Job measurementCalJob() 
      throws Exception {
        return jobBuilderFactory.get("measurementCalJob")
          .start(measurementCalCoreDataPreStep())
          .next(measurementCalPartitionStep())
          .build();
    }
    
    @Bean
    public Step measurementCalCoreDataPreStep() 
      throws Exception {
        return stepBuilderFactory.get("measurementCalCoreDataPreStep")
          .tasklet(new MrsrmntCoreDataPreparationTasklet(dataSource,ruleGroupService))
          .build();
    }
    
    
    @Bean
    public Step measurementCalPartitionStep() 
      throws Exception {
        return stepBuilderFactory.get("measurementCalPartitionStep")
          .partitioner("measurementCalPartitionStep_slave", measurementCalculatePartitioner()).gridSize(gridSize)
//          .partitionHandler(partitionHandler)
          .step(measurementCalPartitionStep_slave())
          .taskExecutor(measurementCalTaskExecutor())
          .build();
    }
    
    @Bean
    public Step measurementCalPartitionStep_slave() 
      throws Exception {
        return stepBuilderFactory.get("measurementCalPartitionStep_slave").<MeasurementCalModel, List<T>> chunk(chunkSize)
				.reader(measurementCalPartitionReader(null, null))
				.processor(measurementCalPartitionProcessor())
				.writer(measurementCalPartitionWriter())
                .build();
    }
    
    @Bean
    public TaskExecutor measurementCalTaskExecutor() {
    	SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
    	taskExecutor.setConcurrencyLimit(maxThreads);
    	return taskExecutor;
    }
}
