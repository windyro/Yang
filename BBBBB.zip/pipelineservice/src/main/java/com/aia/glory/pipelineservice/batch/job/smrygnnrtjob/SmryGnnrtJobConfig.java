package com.aia.glory.pipelineservice.batch.job.smrygnnrtjob;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aia.glory.pipelineservice.batch.job.smrygnnrtjob.tasklet.SmryGnnrtExecTasklet;

@Configuration
@EnableBatchProcessing
public class SmryGnnrtJobConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;
    
    @Bean(name = "smrygnnrtjob")
    public Job smrygnnrtjob() 
      throws Exception {
        return jobBuilderFactory.get("smrygnnrtjob")
          .start(smryGnnrtStep())
          .build();
    }
    
    @Bean
    public Step smryGnnrtStep() 
      throws Exception {
        return stepBuilderFactory.get("smryGnnrtStep")
          .tasklet(new SmryGnnrtExecTasklet(dataSource))
          .build();
    }
    
}
