package com.aia.glory.pipelineservice.response;

import java.util.List;

import com.aia.glory.common.model.response.Response;
import com.aia.glory.common.model.rule.RuleGroupModel;

public class GetRuleGroupResponse extends Response
 {
	private List<RuleGroupModel> ruleGroupModel;
	
	private int total;

	
	public List<RuleGroupModel> getRuleGroupModel() {
		return ruleGroupModel;
	}

	public void setRuleGroupModel(List<RuleGroupModel> ruleGroupModel) {
		this.ruleGroupModel = ruleGroupModel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

}
