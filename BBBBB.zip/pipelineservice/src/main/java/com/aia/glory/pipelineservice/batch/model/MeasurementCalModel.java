package com.aia.glory.pipelineservice.batch.model;


public class MeasurementCalModel {

	private String frequency;
	
	private String measurementName;
	
	private String period;
	
	private String fqPeriod;
	
	private String businessUnitMapSeq;
	
	private String processingUnitSeq;
	
	private String periodSequence;
	
	private String pipelineSequence;
	
	private String payeePositionSequence;
	
	private String channel;
	
	private String company;

	private String payeeTitle;
	
	private String payeeLeaderTitle;
	
	private String payeeLeaderCode;
	
	private String payeeContractDate;
	
	private String payeeTeminatedDate;
	
	private String measurementVaule;
	
	private String summaryType;
	
	private String payee;
	
	private String payeeAgencyCode;
	
	
	public String getMeasurementName() {
		return measurementName;
	}

	public void setMeasurementName(String measurementName) {
		this.measurementName = measurementName;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getBusinessUnitMapSeq() {
		return businessUnitMapSeq;
	}

	public void setBusinessUnitMapSeq(String businessUnitMapSeq) {
		this.businessUnitMapSeq = businessUnitMapSeq;
	}

	public String getProcessingUnitSeq() {
		return processingUnitSeq;
	}

	public void setProcessingUnitSeq(String processingUnitSeq) {
		this.processingUnitSeq = processingUnitSeq;
	}

	public String getPeriodSequence() {
		return periodSequence;
	}

	public void setPeriodSequence(String periodSequence) {
		this.periodSequence = periodSequence;
	}

	public String getPipelineSequence() {
		return pipelineSequence;
	}

	public void setPipelineSequence(String pipelineSequence) {
		this.pipelineSequence = pipelineSequence;
	}

	public String getPayeePositionSequence() {
		return payeePositionSequence;
	}

	public void setPayeePositionSequence(String payeePositionSequence) {
		this.payeePositionSequence = payeePositionSequence;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeLeaderTitle() {
		return payeeLeaderTitle;
	}

	public void setPayeeLeaderTitle(String payeeLeaderTitle) {
		this.payeeLeaderTitle = payeeLeaderTitle;
	}

	public String getPayeeLeaderCode() {
		return payeeLeaderCode;
	}

	public void setPayeeLeaderCode(String payeeLeaderCode) {
		this.payeeLeaderCode = payeeLeaderCode;
	}

	public String getPayeeContractDate() {
		return payeeContractDate;
	}

	public void setPayeeContractDate(String payeeContractDate) {
		this.payeeContractDate = payeeContractDate;
	}

	public String getPayeeTeminatedDate() {
		return payeeTeminatedDate;
	}

	public void setPayeeTeminatedDate(String payeeTeminatedDate) {
		this.payeeTeminatedDate = payeeTeminatedDate;
	}

	public String getMeasurementVaule() {
		return measurementVaule;
	}

	public void setMeasurementVaule(String measurementVaule) {
		this.measurementVaule = measurementVaule;
	}

	public String getSummaryType() {
		return summaryType;
	}

	public void setSummaryType(String summaryType) {
		this.summaryType = summaryType;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getPayeeAgencyCode() {
		return payeeAgencyCode;
	}

	public void setPayeeAgencyCode(String payeeAgencyCode) {
		this.payeeAgencyCode = payeeAgencyCode;
	}
	
	public String getFqPeriod() {
		return fqPeriod;
	}

	public void setFqPeriod(String fqPeriod) {
		this.fqPeriod = fqPeriod;
	}
	
	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	@Override
	public String toString() {
		return "MeasurementCalModel [frequency=" + frequency
				+ ", measurementName=" + measurementName + ", period=" + period
				+ ", fqPeriod=" + fqPeriod + ", businessUnitMapSeq="
				+ businessUnitMapSeq + ", processingUnitSeq="
				+ processingUnitSeq + ", periodSequence=" + periodSequence
				+ ", pipelineSequence=" + pipelineSequence
				+ ", payeePositionSequence=" + payeePositionSequence
				+ ", channel=" + channel + ", company=" + company
				+ ", payeeTitle=" + payeeTitle + ", payeeLeaderTitle="
				+ payeeLeaderTitle + ", payeeLeaderCode=" + payeeLeaderCode
				+ ", payeeContractDate=" + payeeContractDate
				+ ", payeeTeminatedDate=" + payeeTeminatedDate
				+ ", measurementVaule=" + measurementVaule + ", summaryType="
				+ summaryType + ", payee=" + payee + ", payeeAgencyCode="
				+ payeeAgencyCode + "]";
	}
	
}

