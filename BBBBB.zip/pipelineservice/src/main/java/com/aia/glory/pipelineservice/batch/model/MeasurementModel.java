package com.aia.glory.pipelineservice.batch.model;

import java.math.BigDecimal;

public class MeasurementModel {
	
	private String NAME;                             
	private String POSITIONSEQ;                     
	private String PERIODSEQ;                         
	private String PIPELINERUNSEQ;                    
	private String RULESEQ;                          
	private BigDecimal VALUE;                         
	private String BUSINESSUNITMAP;                
	private String PROCESSINGUNITSEQ;
	
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getPOSITIONSEQ() {
		return POSITIONSEQ;
	}
	public void setPOSITIONSEQ(String pOSITIONSEQ) {
		POSITIONSEQ = pOSITIONSEQ;
	}
	public String getPERIODSEQ() {
		return PERIODSEQ;
	}
	public void setPERIODSEQ(String pERIODSEQ) {
		PERIODSEQ = pERIODSEQ;
	}
	public String getPIPELINERUNSEQ() {
		return PIPELINERUNSEQ;
	}
	public void setPIPELINERUNSEQ(String pIPELINERUNSEQ) {
		PIPELINERUNSEQ = pIPELINERUNSEQ;
	}
	public String getRULESEQ() {
		return RULESEQ;
	}
	public void setRULESEQ(String rULESEQ) {
		RULESEQ = rULESEQ;
	}
	public BigDecimal getVALUE() {
		return VALUE;
	}
	public void setVALUE(BigDecimal vALUE) {
		VALUE = vALUE;
	}
	public String getBUSINESSUNITMAP() {
		return BUSINESSUNITMAP;
	}
	public void setBUSINESSUNITMAP(String bUSINESSUNITMAP) {
		BUSINESSUNITMAP = bUSINESSUNITMAP;
	}
	public String getPROCESSINGUNITSEQ() {
		return PROCESSINGUNITSEQ;
	}
	public void setPROCESSINGUNITSEQ(String pROCESSINGUNITSEQ) {
		PROCESSINGUNITSEQ = pROCESSINGUNITSEQ;
	}
	@Override
	public String toString() {
		return "MeasurementModel [NAME=" + NAME + ", POSITIONSEQ="
				+ POSITIONSEQ + ", PERIODSEQ=" + PERIODSEQ
				+ ", PIPELINERUNSEQ=" + PIPELINERUNSEQ + ", RULESEQ=" + RULESEQ
				+ ", VALUE=" + VALUE + ", BUSINESSUNITMAP=" + BUSINESSUNITMAP
				+ ", PROCESSINGUNITSEQ=" + PROCESSINGUNITSEQ + "]";
	}     
	
}
