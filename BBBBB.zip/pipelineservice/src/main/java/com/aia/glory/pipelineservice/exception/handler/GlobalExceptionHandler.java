package com.aia.glory.pipelineservice.exception.handler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.aia.glory.common.enumerate.ReasonCode;
import com.aia.glory.common.enumerate.ResponseCode;
import com.aia.glory.pipelineservice.response.JobTriggerResponse;

@ControllerAdvice 
public class GlobalExceptionHandler {
    
	Log debugLog = LogFactory.getLog("sysDebug");

	Log errorLog = LogFactory.getLog("sysError");
    
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<JobTriggerResponse> defaultHandler(Exception ex) throws Exception {
                
    	JobTriggerResponse res = new JobTriggerResponse();
    	res.setResponseCode(ResponseCode.ERROR.getCode());
    	res.setReasonCode(ReasonCode.GENERIC_ERROR.getCode());
    	res.setReasonDesc(ReasonCode.GENERIC_ERROR.getDesc());
    	errorLog.error("catch exception:",ex);
        return new ResponseEntity<JobTriggerResponse>(res, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
